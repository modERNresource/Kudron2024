/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.LinkedHashMap;
import java.util.TreeMap;
import org.rhwlab.chipseq.dcc.SubmitDCC;
import org.rhwlab.chipseq.pipeline.PipelineRun;
import org.rhwlab.chipseq.qa.Directories;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipHelper;
import org.rhwlab.chipseqweb.ChipRun;
import org.rhwlab.chipseqweb.HibernateUtil;

/**
 *
 * @author gevirl
 */
public class CheckDCC {

    static public TreeMap<String, LinkedHashMap<String, String>> aliasesByExp() throws Exception {
        TreeMap<String, LinkedHashMap<String, String>> expMap = new TreeMap<>();
        for (Object runObj : ChipHelper.getAll("ChipRun", "SubmitID")) {
            ChipRun chipRun = (ChipRun) runObj;
            if (chipRun.getMarkedForDcc() != null) {
                for (Object expObj : ChipHelper.getEquals("ChipExperiment", "ExpID", chipRun.getExpId(), "ExpID")) {
                    ChipExperiment chipExp = (ChipExperiment) expObj;
                    File expDir = new File(Directories.sourceDir, chipExp.getExpId());
                    File chipDir = new File(expDir, "chip");
                    File runDir = new File(chipDir, chipRun.getChipId());
                    PipelineRun pipeRun = new PipelineRun(runDir);
                    LinkedHashMap<String, String> map = SubmitDCC.getAllAliases(chipExp, pipeRun);
                    expMap.put(chipExp.getExpId(), map);
                    for (String alias : map.keySet()) {
                        String label = map.get(alias);

                    }
                }
            }
        }
        HibernateUtil.shutdown();
        return expMap;
    }

    // check the status of DCC 
    static public void reportAliases() throws Exception {
        TreeMap<String, LinkedHashMap<String, String>> expMap = new TreeMap<>();
        File allAliasesFile = new File(new File(Directories.sourceDir, "CheckAll"),"AllAliases");
        File expAliasFile = new File(new File(Directories.sourceDir,"CheckAll"), "AllAliasesByExp");
        PrintStream stream = new PrintStream(allAliasesFile);
        PrintStream expStream = new PrintStream(expAliasFile);
        for (Object runObj : ChipHelper.getAll("ChipRun", "SubmitID")) {
            ChipRun chipRun = (ChipRun) runObj;
            if (chipRun.getMarkedForDcc() != null) {
                for (Object expObj : ChipHelper.getEquals("ChipExperiment", "ExpID", chipRun.getExpId(), "ExpID")) {
                    ChipExperiment chipExp = (ChipExperiment) expObj;
                    File expDir = new File(Directories.sourceDir, chipExp.getExpId());
                    File chipDir = new File(expDir, "chip");
                    File runDir = new File(chipDir, chipRun.getChipId());
                    PipelineRun pipeRun = new PipelineRun(runDir);
                    LinkedHashMap<String, String> map = SubmitDCC.getAllAliases(chipExp, pipeRun);
                    expMap.put(chipExp.getExpId(), map);
                    for (String alias : map.keySet()) {
                        String label = map.get(alias);
                        stream.printf("%s\n", alias);
                    }
                }
            }
        }
        stream.close();
        HibernateUtil.shutdown();

        for (String expID : expMap.keySet()) {
            expStream.println(expID);
            LinkedHashMap<String, String> map = expMap.get(expID);
            for (String alias : map.keySet()) {
                String label = map.get(alias);
                expStream.printf("\t%s\t%s\n", label, alias);
            }
        }
        expStream.close();
    }

    static public TreeMap<String, String[]> aliasesMap() throws Exception {
        TreeMap<String, String[]> ret = new TreeMap<>();
        TreeMap<String, LinkedHashMap<String, String>> map = aliasesByExp();
        for (String expID : map.keySet()) {
            LinkedHashMap<String, String> aliasMap = map.get(expID);
            for (String alias : aliasMap.keySet()) {
                String[] a = new String[2];
                a[0] = expID;
                a[1] = aliasMap.get(alias);
                ret.put(alias, a);
            }
        }
        return ret;
    }

    static public void firstNotPosted() throws Exception {
        PrintStream stream = new PrintStream("/net/waterston/vol9/ChipSeqPipeline/CheckAll/AllAliases.notPosted.out");
        TreeMap<String, String[]> map = aliasesMap();
        File notPosted = new File("/net/waterston/vol9/ChipSeqPipeline/CheckAll/AllAliases.notPosted");
        BufferedReader reader = new BufferedReader(new FileReader(notPosted));
        String currentExp = null;
        String alias = reader.readLine();
        while (alias != null){
            String[] vals = map.get(alias);
            if (!vals[0].equals(currentExp)){          
                stream.printf("%s\t%s\t%s\n", vals[0],alias,vals[1]);
                currentExp = vals[0];
            }
            alias = reader.readLine();
        }
        stream.close();
        int iuasgdifu=0;
    }
    
        static public void main(String[] args) throws Exception {
//            reportAliases() ;
            
            firstNotPosted();
        }
}
