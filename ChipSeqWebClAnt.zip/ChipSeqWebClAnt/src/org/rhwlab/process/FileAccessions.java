/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.List;
import java.util.TreeMap;
import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import org.rhwlab.chipseq.qa.Directories;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipHelper;
import org.rhwlab.chipseqweb.ChipSequencingFile;
import org.rhwlab.chipseqweb.HibernateUtil;

/**
 *
 * @author gevirl
 */
public class FileAccessions {

    static public void main(String[] args) throws Exception {
        TreeMap<String, List<ChipExperiment>> map = ChipHelper.allExperiments();
        for (String species : map.keySet()) {
            for (ChipExperiment exp : map.get(species)) {
                System.out.println(exp.getExpId());
                if (exp.getGene().equals("ceh-20")) {
                    int iuahdsfiuh = 0;
                }
                File expDir = new File(Directories.sourceDir, exp.getExpId());
                File oldFormatFile = new File(expDir, "file/EU_Logs/log_eu_prod_posted.txt");
                if (oldFormatFile.exists()) {
                    BufferedReader reader = new BufferedReader(new FileReader(oldFormatFile));
                    String line = reader.readLine();
                    while (line != null) {
                        String[] tokens = line.split("\t");
                        String acc = tokens[3];
                        String fileID = tokens[1].split(":")[1].replace("_fastq", "");
                        Object obj = ChipHelper.getEquals("ChipSequencingFile", "FileID", fileID, "FileID").get(0);
                        ChipSequencingFile seqFile = (ChipSequencingFile) obj;
                        seqFile.setAccession(acc);
                        ChipHelper.update(seqFile);
                        line = reader.readLine();
                    }
                    reader.close();
                } else if (expDir.exists()) {
                    for (File fastqDir : expDir.listFiles()) {
                        if (fastqDir.getName().endsWith("fastq")) {
                            System.out.println(fastqDir.getName());
                            File euDir = new File(fastqDir, "EU_Logs");
                            File jsonFile = new File(fastqDir, "file.json");
                            if (jsonFile.exists()) {
                                JsonReader jsonreader = Json.createReader(new FileReader(jsonFile));
                                JsonObject metadata = jsonreader.readObject();
                                jsonreader.close();
                                String md5 = metadata.getString("md5sum");
                                List objs = ChipHelper.getEquals("ChipSequencingFile", "MD5", md5, "MD5");
                                for (Object obj : objs) {
                                    ChipSequencingFile seqFile = (ChipSequencingFile) obj;
                                    System.out.println(md5);
                                    File accFile = new File(euDir, "log_eu_prod_posted.txt");
                                    if (accFile.exists()) {
                                        BufferedReader reader = new BufferedReader(new FileReader(accFile));
                                        String line = reader.readLine();
                                        reader.close();
                                        if (line != null) {
                                            String[] tokens = line.split("\t");
                                            System.out.println(tokens[3]);
                                            seqFile.setAccession(tokens[3]);
                                            ChipHelper.update(seqFile);
                                        }
                                    }
                                    int laskdhiushd = 0;

                                }
                            }
                        }
                    }
                }
            }
        }
        HibernateUtil.shutdown();
    }
}
