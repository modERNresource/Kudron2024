/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonString;
import org.rhwlab.chipseq.qa.Directories;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipHelper;
import org.rhwlab.chipseqweb.ChipRun;
import org.rhwlab.chipseqweb.HibernateUtil;

/**
 *
 * @author gevirl
 */
public class UnfinishedRuns {

    public static void main(String[] args) throws Exception {
        TreeMap<String, String> chipMap = new TreeMap<>();
        List<File> orphanRuns = new ArrayList<>();
        List<String> epicOrphans = new ArrayList<>();
        int n = 0;
        TreeMap<String, List<ChipExperiment>> expMap = ChipHelper.allExperiments();
        for (String species : expMap.keySet()) {
            for (ChipExperiment chipExp : expMap.get(species)) {
                String expID = chipExp.getExpId();
                File expDir = new File(Directories.sourceDir, expID);
                File chipDir = new File(expDir, "chip");
                if (chipDir.exists()) {

                    for (File runDir : chipDir.listFiles()) {
                        if (runDir.isDirectory()) {
                            ++n;
                            File metaFile = new File(runDir, "metadata.json");
                            String submitID = "";
                            String submitBy = "";
                            if (metaFile.exists()) {
                                JsonReader reader = Json.createReader(new FileReader(metaFile));
                                JsonObject metadata = reader.readObject();
                                reader.close();

                                String status = metadata.getString("status");
                                String started = metadata.getJsonString("start").getString();
                                JsonObject inputs = metadata.getJsonObject("inputs");
                                JsonString titleObj = inputs.getJsonString("title");
                                if (titleObj == null){
                                    titleObj = inputs.getJsonString("chip.title");
                                }
                                submitID = titleObj.getString();
                                chipMap.put(submitID, runDir.getName());

                            } else {
                                orphanRuns.add(runDir);
                                File epicRunDir = new File(Directories.epicDir,runDir.getName());
                                if (epicRunDir.exists()){
                                    epicOrphans.add(epicRunDir.getName());
                                }
                            }
                            //                           System.out.printf("%s %s %s\n", runDir.getName(), submitID, submitBy);
                        }

                    }
                }
            }
        }
        for (Object obj : ChipHelper.getAll("ChipRun", "SubmitID")) {
            ChipRun chipRun = (ChipRun) obj;
            String runID = chipMap.get(chipRun.getSubmitId());
            if (runID == null) {
                System.out.println(chipRun.getSubmitId());
            }
        }
        HibernateUtil.shutdown();
        System.out.printf("total: %d   linked: %d   orphan: %d  %d\n", n, chipMap.size(), orphanRuns.size(),epicOrphans.size());
        PrintStream stream = new PrintStream("/net/waterston/vol9/ChipSeqPipeline/removeOrhphans.sh");
        for (File orphan : orphanRuns ){
            stream.printf("rm -rf %s\n", orphan.getPath());
        }
        stream.close();
    }
}
