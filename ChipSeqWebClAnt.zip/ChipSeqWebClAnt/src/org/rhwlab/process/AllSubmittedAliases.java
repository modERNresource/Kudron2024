/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipHelper;
import org.rhwlab.chipseqweb.ChipRun;

/**
 *
 * @author gevirl
 */
public class AllSubmittedAliases {
    public static void main(String[] args)throws Exception {
        for (Object runObj : ChipHelper.getAll("ChipRun", "SubmitID")) {
            ChipRun chipRun = (ChipRun) runObj;
            if (chipRun.getMarkedForDcc() != null) {
                for (Object expObj : ChipHelper.getEquals("ChipExperiment", "ExpID", chipRun.getExpId(), "ExpID")) {
                    ChipExperiment chipExp = (ChipExperiment) expObj;     
                }
            }
        }
    }
}
