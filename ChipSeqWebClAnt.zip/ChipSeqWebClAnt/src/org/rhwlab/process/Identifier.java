/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

/**
 *
 * @author gevirl
 */
public class Identifier implements Comparable{
    String gene;
    String strain;
    String stage;
    
    public Identifier(String gene, String strain,String stage){
        this.gene = gene;
        this.stage = stage;
        this.strain = strain;
    }

    @Override
    public int compareTo(Object o) {
        Identifier other = (Identifier)o;
        int i = this.gene.compareTo(other.gene);
        if (i == 0){
            i = this.strain.compareTo(other.strain);
            if (i==0){
                i = this.stage.compareTo(other.stage);
            }
        }
        return i;
    }
    @Override
    public boolean equals(Object o){
        return this.compareTo(o)==0;
    }
}
