
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.TreeMap;
import javax.json.JsonObject;
import org.rhwlab.chipseq.dcc.Biosample;
import org.rhwlab.chipseq.dcc.Donor;
import org.rhwlab.chipseq.dcc.Experiment;
import org.rhwlab.chipseq.dcc.GeneticModification;
import org.rhwlab.chipseq.dcc.Library;
import org.rhwlab.chipseq.dcc.Replicate;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipHelper;
import org.rhwlab.chipseqweb.ChipTag;
import org.rhwlab.chipseqweb.HibernateUtil;

/**
 *
 * @author gevirl
 */
public class UpdateMetadata {

    ChipExperiment exp;

    public UpdateMetadata(ChipExperiment exp) throws Exception {
        this.exp = exp;
    }

    public UpdateMetadata(String expID) throws Exception {
        List list = ChipHelper.getEquals("ChipExperiment", "expID", expID, "expID");
        if (list != null) {
            if (!list.isEmpty()) {
                exp = (ChipExperiment) list.get(0);
            }
        }
    }

    public void update() throws Exception {
        String acc = exp.getAccession();
        String desc = exp.getDescription();

        if (acc != null) {
            Experiment expObj = new Experiment(acc);
            Replicate[] reps = expObj.getReplicates();
            Library lib = reps[0].getLibrary();
            Biosample samp = lib.getBiosample();
            Donor donor = samp.getDonor();
            GeneticModification genMod = donor.getGenMod();

            if (desc != null && desc.contains("ENCODE bams")) {
                // only updating experiments from DCC bams

                if (genMod != null) {
                    String genModDesc = genMod.getDesc();
                    exp.setGeneticModDesc(genModDesc);
                    String[] base = genModDesc.split("follows: ");
                    if (base.length == 2) {
                        exp.setBasesBeforeTag(base[1]);
                    }
                    String treat = genMod.getTreatment();
                    if (treat != null) {
                        exp.setTreatment(treat);
                    }
                    JsonObject modSite = null;
                    if (exp.getSpecies().equals("Dmel")) {
                        modSite = genMod.getModSite("dm6");
                        String extID = donor.getExternalID();
                        if (extID != null) {
                            if (extID.startsWith("BDSC")) {
                                exp.setExternalId(extID.split(":")[1]);
                            }
                        }
                    } else {
                        modSite = genMod.getModSite("ce11");
                    }
                    if (modSite != null) {
                        exp.setAssembly(genMod.getAssembly(modSite));
                        exp.setChromosome(genMod.getChromo(modSite).replace("chr", ""));
                        exp.setStart(genMod.getStart(modSite));
                        exp.setEnd(genMod.getEnd(modSite));
                    }
                    List tagList = ChipHelper.getEquals("ChipTag", "ExpID", exp.getExpId(), "TagID");
                    for (ChipTag tag : genMod.getTags()) {
                        // has the tag already been added?
                        boolean found = false;
                        for (Object obj : tagList) {
                            ChipTag tagObj = (ChipTag) obj;
                            if (tagObj.getName().equals(tag.getName()) & tagObj.getLocation().equals(tag.getLocation())) {
                                found = true;
                                break;
                            }
                        }
                        if (!found) {
                            String tagID = ChipHelper.nextID("ChipTag", "TagID", exp.getExpId(), "getTagId");
                            tag.setExpId(exp.getExpId());
                            tag.setTagId(tagID);

                            int isaudhf = 0;
                            ChipHelper.save(tag);
                        }
                    }
                }

                SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
                exp.setEnteredOn(fmt.parse(expObj.getDate()));

                exp.setAntibody(reps[0].getAntibody());
                exp.setAntibodyProduct(reps[0].getAntibodyProduct());

                exp.setGenotype(donor.getGenotype());

                exp.setAge(samp.getAge());
                exp.setAgeUnits(samp.getAgeUnits());

                ChipHelper.update(exp);

                int asdifh = 0;
            }
        }
    }

    static public void UpdateEncodeBamExperiments() throws Exception {
        TreeMap<String, List<ChipExperiment>> map = ChipHelper.allExperiments();
        for (String species : map.keySet()) {
            List<ChipExperiment> list = map.get(species);
            for (ChipExperiment exp : list) {
                System.out.println(exp.getExpId());
                UpdateMetadata expMeta = new UpdateMetadata(exp);
                expMeta.update();
            }
        }
    }

    static public void main(String[] args) throws Exception {
               UpdateEncodeBamExperiments();
/*
        String expID = "atf-7_OP638_youngadult_1";
        UpdateMetadata meta = new UpdateMetadata(expID);
        meta.update();
*/
        HibernateUtil.shutdown();
    }
}
