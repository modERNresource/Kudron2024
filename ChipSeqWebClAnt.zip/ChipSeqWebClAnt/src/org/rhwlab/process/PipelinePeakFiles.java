/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import java.io.File;
import java.util.List;
import java.util.TreeMap;
import org.rhwlab.chipseq.PeakClusters;
import org.rhwlab.chipseq.PeakFile;
import org.rhwlab.chipseq.pipeline.PipelineRun;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipHelper;
import org.rhwlab.chipseqweb.ChipRun;
import org.rhwlab.chipseqweb.HibernateUtil;

/**
 *
 * @author gevirl
 */
public class PipelinePeakFiles {

    TreeMap<String, PeakFile> allPeakFileMap = new TreeMap<>();
    TreeMap<String, PeakFile> dccPeakFileMap = new TreeMap<>();

    public PipelinePeakFiles(String species) throws Exception {
        for (Object expObj : ChipHelper.allExperiments(species)) {
            ChipExperiment chipExp = (ChipExperiment) expObj;
            if (chipExp.getStatus() != null) {
//                if (!(chipExp.getStatus().equals("Testing") || chipExp.getStatus().equals("Error") || chipExp.getStatus().equals("Failed"))) {
                if (chipExp.getStatus().equals("Complete")) {
                    for (Object obj : ChipHelper.getEquals("ChipRun", "ExpID", chipExp.getExpId(), "SubmitID")) {
                        ChipRun chipRun = (ChipRun) obj;
                        if (chipRun.getChipId() != null) {
                            String tf = chipRun.getExpId().split("_")[0];
                            if (tf.equals("pie-1")) {
                                int lidufsh = 0;
                            }

                            String stage = chipRun.getExpId().split("_")[2];
                            File bigBedFile = PipelineRun.idrOptimalPeakFile(chipRun);
                            if (bigBedFile.exists()) {
                                String prefix = "";
                                if (species.equals("CElegans")) {
//                                    prefix = "chr";
                                }
                                PeakFile peakFile = new PeakFile(bigBedFile, tf, prefix, stage); // puts chr into chromosome
                                allPeakFileMap.put(chipRun.getSubmitId(), peakFile);
                                if (chipRun.getMarkedForDcc() != null) {
                                    dccPeakFileMap.put(chipRun.getSubmitId(), peakFile);
                                }
                            }
                        }
                    }
                }
            }
        }

    }

    public TreeMap<String, PeakFile> allPeakFiles() {
        return allPeakFileMap;
    }

    public TreeMap<String, PeakFile> dccPeakFiles() {
        return dccPeakFileMap;
    }

    public static void main(String[] args) throws Exception {
        File oldDir = new File("/net/waterston/vol2/home/gevirl/ChipSeqPeaks/worm/ce11");
        List<PeakFile> oldDCCFileList = PeakClusters.PeakFiles(oldDir, "");  // these files have chr in chromosome
        PipelinePeakFiles files = new PipelinePeakFiles("CElegans");
        int ergsdg = 0;
    }

}
