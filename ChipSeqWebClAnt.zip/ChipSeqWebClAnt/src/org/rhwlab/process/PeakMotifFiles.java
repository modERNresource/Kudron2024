/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.rhwlab.process;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.TreeSet;

/**
 *
 * @author gevirl
 */
public class PeakMotifFiles {

    static public void main(String[] args) throws Exception {
        String dir = "/net/waterston/vol2/home/gevirl/Downloads";
        File peakFile = new File(dir, "FlyTFPeaksPrimaryTargets.tsv");
        File motifFile = new File(dir, "FlyTFPeaksPrimaryTargets_motif.txt");

        PrintStream withMotif = new PrintStream(new File(dir, "FlyTFPeaksPrimaryTargetsWithMotif"));
        BufferedReader peakReader = new BufferedReader(new FileReader(peakFile));
        peakReader.readLine();
        BufferedReader motifReader = new BufferedReader(new FileReader(motifFile));

        TreeSet<String> motifIDs = new TreeSet<>();
        String line = peakReader.readLine();
        while (line != null) {
            String[] tokens = line.split("\t");
            String tf = tokens[3].split("_")[0];
            String id = String.format("%s_%s_%s_%s", tokens[0], tokens[1], tokens[2], tokens[3]);
            for (String motif : motifReader.readLine().split(",")) {
                if (motif.equals(tf)) {
                    withMotif.println(id);
                    if (motifIDs.contains(id)){
                        System.out.println(id);
                    }
                    motifIDs.add(id);
                    break;
                }
            }

            line = peakReader.readLine();
        }
        peakReader.close();
        motifReader.close();
        withMotif.close();
    }
}
