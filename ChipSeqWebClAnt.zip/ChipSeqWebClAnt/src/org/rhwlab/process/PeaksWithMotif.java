package org.rhwlab.process;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.zip.GZIPInputStream;
import org.apache.commons.math3.stat.inference.ChiSquareTest;
import org.rhwlab.chipseq.peaks.MasterPeakFile;

/**
 *
 * @author gevirl
 */
public class PeaksWithMotif {

    TreeMap<String, TreeSet> motifs = new TreeMap<>();
    File file;

    public PeaksWithMotif(File file) throws Exception {
        this.file = file;
        int total = 0;
        BufferedReader reader;
        if (file.getName().endsWith(".gz")) {
            reader = new BufferedReader(new InputStreamReader(new GZIPInputStream(new FileInputStream(file))));
        } else {
            reader = new BufferedReader(new FileReader(file));
        }
        TreeMap<String, Integer> tfMotifCount = new TreeMap<>();
        TreeMap<String, Integer> tfsCount = new TreeMap<>();
        int count = 0;
        String line = reader.readLine();
        while (line != null) {
            ++total;
            String[] tokens = line.split("\t");

            String tf = tokens[3].split("_")[0];

            if (tf.equals("ceh-28")) {
                tf = "ceh-38";
                tokens[3] = tokens[3].replace("ceh-28", "ceh-38");
            }
            if (tf.equals("nhr-27")) {
                tf = "nhr-270";
                tokens[3] = tokens[3].replace("nhr-27", "nhr-270");
            }
            String id = String.format("%s_%s_%s_%s", tokens[0], tokens[1], tokens[2], tokens[3]);
            id = id.replace("3e+05", "300000");
            String[] motif_tfs = tokens[11].replace("{", "").replace("}", "").replace("\'", "").replace(" ", "").split(",");
            TreeSet<String> tfSet = new TreeSet<>();
            //           motifs.put(id, tfSet);
            boolean found = false;
            if (tf.equals("hlh-1") & tokens[0].equals("chrI") & tokens[1].equals("74578") & tokens[2].equals("74914")) {
                int askjdf = 0;
            }
            for (int i = 0; i < motif_tfs.length; ++i) {
                tfSet.add(motif_tfs[i]);
                int ltf = tf.length();
                String s = motif_tfs[i];
                int ls = s.length();
                if (s.compareTo(tf) == 0) {
                    found = true;
                    break;
                }
            }
            // count the matching motifs by tf
            if (found) {
                Integer c = tfMotifCount.get(tf);
                if (c == null) {
                    tfMotifCount.put(tf, 1);
                } else {
                    tfMotifCount.put(tf, c + 1);
                }
                ++count;
            }
            // count the total peaks by tf
            Integer c = tfsCount.get(tf);
            if (c == null) {
                tfsCount.put(tf, 1);
            } else {
                tfsCount.put(tf, c + 1);
            }

            line = reader.readLine();
        }
        reader.close();

        PrintStream stream = new PrintStream(file.getPath().replace("motif.txt.gz", "motifCountsByTF.txt"));
        stream.println("TF\tPeaksWithMotif\tTotalPeaks\tRatio");
        for (String tf : tfMotifCount.keySet()) {
            stream.printf("%s\t%d\t%d\t%f\n", tf, tfMotifCount.get(tf), tfsCount.get(tf), (double) tfMotifCount.get(tf) / (double) tfsCount.get(tf));
        }

        stream.printf("Total=%d,matching=%d,TF count=%d\n", total, count, tfMotifCount.size());
        stream.close();
    }

    static public TreeMap<String, TreeMap<String, TreeSet<String>>> readFile(File file) throws Exception {
        TreeMap<String, TreeMap<String, TreeSet<String>>> ret = new TreeMap<>();

        TreeMap<String, TreeSet<String>> motifPeaks = new TreeMap<>();
        TreeMap<String, TreeSet<String>> noMotifPeaks = new TreeMap<>();
        ret.put("Motif", motifPeaks);
        ret.put("NoMotif", noMotifPeaks);

        BufferedReader reader;
        if (file.getName().endsWith(".gz")) {
            reader = new BufferedReader(new InputStreamReader(new GZIPInputStream(new FileInputStream(file))));
        } else {
            reader = new BufferedReader(new FileReader(file));
        }
        String line = reader.readLine();
        while (line != null) {
            String[] tokens = line.split("\t");
            String tf = tokens[3].split("_")[0];

            TreeSet<String> tfMotifPeaks = motifPeaks.get(tf);
            if (tfMotifPeaks == null) {
                tfMotifPeaks = new TreeSet<>();
                motifPeaks.put(tf, tfMotifPeaks);
            }

            TreeSet<String> tfNoMotifPeaks = noMotifPeaks.get(tf);
            if (tfNoMotifPeaks == null) {
                tfNoMotifPeaks = new TreeSet<>();
                noMotifPeaks.put(tf, tfNoMotifPeaks);
            }

            if (tf.equals("ceh-28")) {
                tf = "ceh-38";
                tokens[3] = tokens[3].replace("ceh-28", "ceh-38");
            }
            if (tf.equals("nhr-27")) {
                tf = "nhr-270";
                tokens[3] = tokens[3].replace("nhr-27", "nhr-270");
            }
            String id = String.format("%s_%s_%s_%s", tokens[0], tokens[1], tokens[2], tokens[3]);
            id = id.replace("3e+05", "300000");
            String[] motif_tfs = tokens[11].replace("{", "").replace("}", "").replace("\'", "").replace(" ", "").split(",");

            boolean found = false;
            for (int i = 0; i < motif_tfs.length; ++i) {
                String s = motif_tfs[i];
                if (s.compareTo(tf) == 0) {
                    found = true;
                    break;
                }
            }
            if (found) {
                tfMotifPeaks.add(id);
            } else {
                tfNoMotifPeaks.add(id);
            }

            line = reader.readLine();
        }
        reader.close();

        return ret;
    }

    static public void reportPeakIDs(File file, TreeMap<String, TreeSet<String>> map, Set<String> ids) throws Exception {
        PrintStream stream = new PrintStream(file);
        stream.println("TF\tPeakID");
        for (String tf : map.keySet()) {
            TreeSet<String> set = map.get(tf);
            if (!set.isEmpty()) {
                for (String id : set) {
                    if (ids.contains(id)) {
                        stream.printf("%s\t%s\n", tf, id);
                    }
                }
            }
        }
        stream.close();
    }

    public TreeSet<String> getMotifs(String id) {
        return this.motifs.get(id);
    }

    public Set<String> getIDs() {
        return this.motifs.keySet();
    }

    public boolean hasMatchingMotif(String peakID, String tf) {
        TreeSet peakMotifs = motifs.get(peakID);
        boolean ret = peakMotifs.contains(tf);
        return ret;
    }

    public void separateTargets(MasterPeakFile master, String tf) throws Exception {
        TreeMap<String, TreeSet<String>> targets = motifTargets(master);
        TreeSet<String> withMotif = targets.get(tf);
        String outFileName = String.format("%s.TargetsWithMotif.%s", tf, file.getName());
        File outFile = new File(file.getParent(), outFileName);
        PrintStream stream = new PrintStream(outFile);
        for (String target : withMotif) {
            stream.println(target);
        }
        stream.close();

        targets = noMotifTargets(master);
        TreeSet<String> withoutMotif = targets.get(tf);
        outFileName = String.format("%s.TargetsWithoutMotif.%s", tf, file.getName());
        outFile = new File(file.getParent(), outFileName);
        stream = new PrintStream(outFile);
        for (String target : withoutMotif) {
            stream.println(target);
        }
        stream.close();
    }

    // tf -> set of targets for peaks with matching motif
    public TreeMap<String, TreeSet<String>> motifTargets(MasterPeakFile master) {
        TreeMap<String, TreeSet<String>> ret = new TreeMap<>();
        for (String peakID : master.getIDs()) {
            String tf = master.get(peakID, "TF");
            TreeSet<String> targetSet = ret.get(tf);
            if (targetSet == null) {
                targetSet = new TreeSet<>();
                ret.put(tf, targetSet);
            }
            String geneTarget = master.get(peakID, "Gene");
            if (this.hasMatchingMotif(peakID, tf)) {
                targetSet.add(geneTarget);
            }
        }
        return ret;
    }

    public TreeMap<String, TreeSet<String>> noMotifTargets(MasterPeakFile master) {
        TreeMap<String, TreeSet<String>> ret = new TreeMap<>();
        for (String peakID : master.getIDs()) {
            String tf = master.get(peakID, "TF");
            TreeSet<String> targetSet = ret.get(tf);
            if (targetSet == null) {
                targetSet = new TreeSet<>();
                ret.put(tf, targetSet);
            }
            String geneTarget = master.get(peakID, "Gene");
            if (!this.hasMatchingMotif(peakID, tf)) {
                targetSet.add(geneTarget);
            }
        }
        return ret;
    }

    static public void main(String[] args) throws Exception {
        File peakFile = new File("/net/waterston/vol2/home/gevirl/Downloads/PublishedOptimalFlyPeaks");
        File motifFile = new File("/net/waterston/vol2/home/gevirl/Downloads/PublishedOptimalFlyPeaks_motif.txt");
    }
    
    static public void mainSave(String[] args) throws Exception {
        String[] columns = {"TF", "numPeaks", "Gene"};
        File wormPeakFile = new File("/net/waterston/vol2/home/gevirl/Downloads/WormTFPeaksPrimaryTargets.tsv");
        MasterPeakFile wormMaster = new MasterPeakFile(wormPeakFile, "peakID", columns);
        Set<String> ids = wormMaster.getIDs();

        File wormFile = new File("/net/waterston/vol2/home/gevirl/Downloads/OptimalTFClusteredWormPeaks_motif.txt.gz");
        TreeMap<String, TreeMap<String, TreeSet<String>>> map = readFile(wormFile);
        File wormMotifFile = new File("/net/waterston/vol9/ChipSeqPipeline/WormPeaksWithMotif.tsv");
        reportPeakIDs(wormMotifFile, map.get("Motif"), ids);
        File wormNoMotifFile = new File("/net/waterston/vol9/ChipSeqPipeline/WormPeaksWithoutMotif.tsv");
        reportPeakIDs(wormNoMotifFile, map.get("NoMotif"), ids);

        int hhh = 0;

        File file = new File("/net/waterston/vol2/home/gevirl/Downloads/OptimalTFClusteredFlyPeaks_motif.txt.gz");
        PeaksWithMotif motif = new PeaksWithMotif(file);

        TreeMap<String, long[][]> tfMap = new TreeMap<>();
        TreeMap<String, Integer> motifSizeMatch = new TreeMap<>();
        TreeMap<String, Integer> motifSizeNoMatch = new TreeMap<>();

        File peakFile = new File("/net/waterston/vol2/home/gevirl/Downloads/FlyTFPeaksPrimaryTargets.tsv");
        MasterPeakFile master = new MasterPeakFile(peakFile, "peakID", columns);
//        motif.separateTargets(master, "hlh-1");

        for (String peakID : master.getIDs()) {
            String tf = master.get(peakID, "TF");
            long[][] data = tfMap.get(tf);
            Integer motifSizeCount = motifSizeMatch.get(tf);
            if (motifSizeCount == null) {
                motifSizeCount = 0;
                motifSizeMatch.put(tf, 0);
            }
            Integer noMotifSizeCount = motifSizeNoMatch.get(tf);
            if (noMotifSizeCount == null) {
                noMotifSizeCount = 1;
                motifSizeNoMatch.put(tf, 0);
            }
            if (data == null) {
                data = new long[2][];
                data[0] = new long[2];
                data[1] = new long[2];
                tfMap.put(tf, data);
            }
            TreeSet<String> motifs = motif.getMotifs(peakID);

            int metaPeakSize = Integer.parseInt(master.get(peakID, "numPeaks"));

            if (metaPeakSize <= 84) {
                if (motifs.contains(tf)) {
                    data[0][0] = 1 + data[0][0];
                    motifSizeMatch.put(tf, motifSizeCount + motifs.size());
                } else {
                    data[0][1] = 1 + data[0][1];
                    motifSizeNoMatch.put(tf, noMotifSizeCount + motifs.size());
                }
            } else {
                if (motifs.contains(tf)) {
                    data[1][0] = 1 + data[1][0];
                    motifSizeMatch.put(tf, motifSizeCount + motifs.size());
                } else {
                    data[1][1] = 1 + data[1][1];
                    motifSizeNoMatch.put(tf, noMotifSizeCount + motifs.size());
                }
            }

        }

        ChiSquareTest chi = new ChiSquareTest();
        System.out.print("\nTF\t-hot+M\t-hot-M\t+hot+M\t+hot-M\tChi\tmatch\tavgMatch\tnoMatch\tavgNoMatch\n");
        for (String tf : tfMap.keySet()) {
            long[][] data = tfMap.get(tf);
            int motifCount = motifSizeMatch.get(tf);
            int noMotifCount = motifSizeNoMatch.get(tf);
            double motifPeakCount = (double) (data[0][0] + data[1][0]);
            double noMotifPeakCount = (double) (data[0][1] + data[1][1]);
            System.out.printf("%s\t%d\t%d\t%d\t%d\t%f\t%d\t%f\t%d\t%f\n",
                    tf, data[0][0], data[0][1], data[1][0], data[1][1], chi.chiSquareTest(data),
                    motifCount, motifCount / motifPeakCount, noMotifCount, noMotifCount / noMotifPeakCount);
        }
    }
}
