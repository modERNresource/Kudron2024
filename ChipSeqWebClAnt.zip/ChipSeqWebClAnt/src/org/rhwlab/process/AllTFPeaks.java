/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.NavigableMap;
import java.util.TreeMap;
import java.util.TreeSet;
import org.rhwlab.chipseq.Peak;
import org.rhwlab.chipseq.PeakFile;
import org.rhwlab.gene.model.Annotation;
import org.rhwlab.gene.model.ModelFromGFF;
import static org.rhwlab.process.PeakClustering.gffFile;
import org.rhwlab.tfs.TF_DB;

/**
 *
 * @author gevirl
 */
public class AllTFPeaks {

    TreeMap<String, TreeMap<Integer, List<Peak>>> map = new TreeMap<>(); // chromo -> apex -> peaks
    TreeSet<String> allTFs = new TreeSet<>();

    public AllTFPeaks() throws Exception {
        TF_DB tfdb = new TF_DB();
        List<PeakFile> peakFiles = PeakClustering.allWormPeakFiles();
        for (PeakFile pf : peakFiles) {
            if (tfdb.isTF(pf.getTF())) {
                allTFs.add(pf.getTF());
                for (Peak peak : pf.allPeaks()) {
                    String chromo = peak.getBedRecord().getChromosome().replace("chr", "");
                    TreeMap<Integer, List<Peak>> chromoMap = map.get(chromo);
                    if (chromoMap == null) {
                        chromoMap = new TreeMap<>();
                        map.put(chromo, chromoMap);
                    }
                    int apex = peak.getApex();
                    List<Peak> peakList = chromoMap.get(apex);
                    if (peakList == null) {
                        peakList = new ArrayList<>();
                        chromoMap.put(apex, peakList);
                    }
                    peakList.add(peak);
                }
            }
        }
    }

    // get the highest rank for each tf peak in the range 
    public TreeMap<String, Double> highestRank(String chromo, int start, int end) {
        TreeMap<String, Double> tfRankMap = new TreeMap<>();
        for (Peak peak : between(chromo, start, end)) {
            String tf = peak.getBedRecord().getTF();
            double rank = peak.getRank();
            Double maxRank = tfRankMap.get(tf);
            if (maxRank == null) {
                tfRankMap.put(tf, rank);
            } else if (maxRank < rank) {
                tfRankMap.put(tf, rank);
            }
        }
        return tfRankMap;
    }

    public String[] getAllTFs() {
        return this.allTFs.toArray(new String[0]);
    }

    // all peaks in the range
    public List<Peak> between(String chromo, int start, int end) {
        ArrayList<Peak> peaks = new ArrayList<>();
        TreeMap<Integer, List<Peak>> chromoMap = map.get(chromo);
        NavigableMap<Integer, List<Peak>> subMap = chromoMap.subMap(start, true, end, true);
        for (List<Peak> peakList : subMap.values()) {
            peaks.addAll(peakList);
        }
        return peaks;
    }


    public static void reportAllTFsChipped(File outFile) throws Exception {

        PrintStream stream = new PrintStream(outFile);

        Annotation.remapChromo = false;
        ModelFromGFF gff = new ModelFromGFF(gffFile);

        String[] tfs = new AllTFPeaks().getAllTFs();

        stream.println("wbgene\tgene\tsequence");
        for (String tf : tfs) {
            String[] names = gff.geneNameTriplet(tf);
            stream.printf("%s\t%s\t%s\n", names[2], names[1], names[0]);
        }
        stream.close();
    }

    public static void main(String[] args) throws Exception {
        File dir = new File("/net/waterston/vol9/UVA_YoungAdult");
        File outFile = new File(dir, "chipTFs.tsv");
        reportAllTFsChipped(outFile);
    }
}
