/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import org.rhwlab.chipseq.qa.ChipSeqTargets;
import org.rhwlab.chipseq.qa.DistanceMatrix;
import org.rhwlab.gene.model.Annotation;
import org.rhwlab.gene.model.ModelFromGFF;
import org.rhwlab.singlecell.expression.PrefixMaps;

/**
 *
 * @author gevirl
 */
public class AlecBedProject {

    public static void targets(File dir) throws Exception {
        File gffFile = new File("/net/waterston/vol9/References/WS260/c_elegans.PRJNA13758.WS260.annotations.WormBase.gff3");
        Annotation.remapChromo = false;
        ModelFromGFF gff = new ModelFromGFF(gffFile);
        for (File bed : dir.listFiles()) {
            if (bed.getName().endsWith(".bed")) {
                System.out.println(bed.getPath());
                ChipSeqTargets targets = ChipSeqTargets.targetsFromBedPeaks(bed, gff);
                File targetFile = new File(dir, bed.getName().replace(".bed", ".targets"));
                targets.saveTargets(targetFile);
            }
        }
    }

    static public TreeMap<String, Double> mannWhitney(File dir) {
        TreeMap<String, Double> ret = new TreeMap<>();
        for (File bed : dir.listFiles()) {
            if (bed.getName().endsWith(".targets")) {
                Identifier id = identifier(bed.getName());

            }
        }
        return ret;
    }

    static public Identifier identifier(String fName) {
        Identifier ret = null;
        if (fName.contains("regionPeak")) {
            fName = fName.replace("spp.optimal.", "");
            String[] tokens = fName.split("_");
            if (tokens[3].equals("WA")) {
                ret = new Identifier(tokens[0], tokens[1] + "_" + tokens[2], tokens[4]);
            } else {
                ret = new Identifier(tokens[0], tokens[1], tokens[3]);
            }
        } else if (fName.contains("oort-1")) {
            String[] tokens = fName.split("_");
            if (tokens.length == 5) {
                ret = new Identifier(tokens[0], tokens[1], tokens[2]);
            } else {
                ret = new Identifier(tokens[0], tokens[1] + "_" + tokens[2], tokens[3]);
            }
        } else {
            String[] tokens = fName.split("_");
            if (tokens.length == 4) {
                ret = new Identifier(tokens[0], tokens[1], tokens[2]);
            } else {
                ret = new Identifier(tokens[0], tokens[1] + "_" + tokens[2], tokens[3]);
            }
        }
        return ret;
    }

    static Map<Identifier, List<File>> targetFiles(List<File> dirs) {
        TreeMap<Identifier, List<File>> ret = new TreeMap<>();
        for (File dir : dirs) {
            for (File bed : dir.listFiles()) {
                if (bed.getName().endsWith("targets")) {
                    Identifier id = identifier(bed.getName());
                    List<File> files = ret.get(id);
                    if (files == null) {
                        files = new ArrayList<>();
                        ret.put(id, files);
                    }
                    files.add(bed);
                }
            }
        }
        return ret;
    }

    /*
    static TreeMap<Identifier, File[]> pairBed(File motifDir, File origDir) {
        TreeMap<Identifier, File[]> ret = new TreeMap<>();

        for (File bed : motifDir.listFiles()) {
            if (bed.getName().endsWith("targets")) {
                File[] files = new File[2];
                files[0] = bed;
                Identifier id = identifier(bed.getName());
                if (ret.get(id) != null) {
                    int iuashdfhs = 0;
                }
                ret.put(id, files);
            }
        }

        for (File bed : origDir.listFiles()) {
            if (bed.getName().endsWith("targets")) {
                Identifier id = identifier(bed.getName());
                File[] files = ret.get(id);
                files[1] = bed;
            }
        }
        return ret;
    }
     */
    static public void main(String[] args) throws Exception {
        ArrayList<File> dirList = new ArrayList<>();
        ArrayList<String> labels = new ArrayList<>();

           
        File motifDir = new File("/net/waterston/vol2/home/gevirl/AlecBeds/motif");
        File origDir = new File("/net/waterston/vol2/home/gevirl/AlecBeds/original");
        dirList.add(motifDir);
        dirList.add(origDir);
 //       targets(motifDir);
        labels.add(motifDir.getName());
        labels.add(origDir.getName());
 //       targets(origDir);        
         
        
        File leftDir = new File("/net/waterston/vol2/home/gevirl/AlecBeds/leftover");
        dirList.add(leftDir);
        labels.add(leftDir.getName());
 //       targets(leftDir);

        Map<Identifier, List<File>> targetMap = targetFiles(dirList);

        System.out.print("Gene,Strain,Stage");
        for (String label : labels) {
            System.out.printf(",%s", label);
        }
        
        System.out.println();
        PrefixMaps maps = new PrefixMaps();
        for (String prefix : maps.getSignedDistanceMatrixMap().keySet()) {
            DistanceMatrix signedDistMatrix = new DistanceMatrix(maps.getSignedDistanceMatrixMap().get(prefix));

            for (Identifier id : targetMap.keySet()) {
                List<File> targetFiles = targetMap.get(id);
                if ((prefix.equals("Emb") && id.stage.contains("E")) || (prefix.equals("L2") && id.stage.contains("L"))) {
                    String tf;
                    if (id.gene.contains("-")) {
                        tf = DistanceMatrix.wbGene(id.gene.toLowerCase());
                    } else {
                        tf = DistanceMatrix.wbGene(id.gene);
                    }
                    if (tf == null) {
                    }
                    System.out.printf("%s,%s,%s", id.gene, id.strain, id.stage);
                    for (File targetFile : targetFiles) {
                        ChipSeqTargets targets = new ChipSeqTargets(targetFile);
                        List<String> wbGeneTargets = targets.wbGeneList();
                        String fname = targetFile.getName();

                        // compute the Mannwhitney scores
                        TreeMap<String, Object> mann = signedDistMatrix.scoreMannWhitney(wbGeneTargets, tf);
                        double score = (Double) mann.get("Unorm");
                        System.out.printf(",%f", (Double.valueOf(score) - 0.5) * 200.0);
                    }
                    System.out.println();
                }
            }
        }

    }

}
