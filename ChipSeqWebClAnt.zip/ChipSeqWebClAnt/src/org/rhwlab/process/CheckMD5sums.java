/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import org.rhwlab.chipseqweb.ChipHelper;
import org.rhwlab.chipseqweb.ChipSequencingFile;
import org.rhwlab.chipseqweb.HibernateUtil;

/**
 *
 * @author gevirl
 */
public class CheckMD5sums {
    static public void main(String[] args) throws Exception{
        TreeMap<String,List<ChipSequencingFile>>  map = new TreeMap<>();
        for (Object obj : ChipHelper.getAll("ChipSequencingFile", "ExpID")){
            ChipSequencingFile file = (ChipSequencingFile)obj;
            String md5 = file.getMd5();
            List<ChipSequencingFile> fileList = map.get(md5);
            if (fileList == null){
                fileList = new ArrayList<>();
                map.put(md5,fileList);
            }
            fileList.add(file);
        }
        for (String md5 : map.keySet()){
            List<ChipSequencingFile> files = map.get(md5);
            if (files.size() > 1){
                System.out.println();
                for (ChipSequencingFile file : files){
                    System.out.printf("%s\t%d\t%d\t%s\n",file.getSeqType(),file.getReplicate(),file.getReadPair(),file.getLocalFilePath());
                }
            }
        }
        HibernateUtil.shutdown();
    }
}
