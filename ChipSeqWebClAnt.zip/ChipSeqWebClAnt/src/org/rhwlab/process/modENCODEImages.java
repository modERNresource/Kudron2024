/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonValue;
import javax.json.stream.JsonGenerator;
import org.rhwlab.chipseq.dcc.SubmitDCC;

/**
 *
 * @author gevirl
 */
// make scripts and json to upload old modENCODE images
public class modENCODEImages {

    static public void main(String[] args) throws Exception {
        File imageDir = new File("/net/waterston/vol9/ChipSeqPipeline/modENCODEImages");
        File sampleListFile = new File(imageDir, "modEncodeImageList");
        File submitAll = new File(imageDir, "submit.sh");
        
        TreeMap<String, List<String>> aliasMap = new TreeMap<>();
        BufferedReader reader = new BufferedReader(new FileReader(sampleListFile));
        String line = reader.readLine();
        while (line != null) {
            String alias = line.split(" ")[0];
            String[] tokens = alias.split(":|_");
            String strain = tokens[3];
            List<String> sampleList = aliasMap.get(strain);
            if (sampleList == null) {
                sampleList = new ArrayList<>();
                aliasMap.put(strain, sampleList);
            }
            sampleList.add(alias);
            line = reader.readLine();
        }
        reader.close();

        PrintStream allStream = new PrintStream(submitAll);
        for (File file : imageDir.listFiles()) {
            String jpg = file.getName();
            if (jpg.endsWith(".jpg")) {
                String[] tokens = jpg.split("_");
                String strain = tokens[0];
                List<String> aliases = aliasMap.get(strain);
                for (String biosampleAlias : aliases) {
                    String charactAlias = biosampleAlias + "_jpg";
                    JsonObjectBuilder builder = Json.createObjectBuilder();
                    builder.add("aliases", Json.createArrayBuilder().add(charactAlias));
                    SubmitDCC.award(builder);
                    SubmitDCC.yaleLab(builder);
                    builder.add("characterizes", biosampleAlias);
                    builder.add("attachment", Json.createObjectBuilder().add("path", file.getPath()));
                    JsonObject obj = builder.build();

                    File jsonOutFile = new File(imageDir, jpg.replace(".jpg", ".json"));
                    JsonGenerator gen = Json.createGenerator(new FileWriter(jsonOutFile));
                    gen.writeStartArray();
                    gen.write(obj);
                    gen.writeEnd();
                    gen.flush();
                    gen.close();

                    File submitScript = new File(imageDir, jpg.replace(".jpg", ".sh"));
                    PrintStream stream = new PrintStream(submitScript);
                    SubmitDCC.register(stream, "biosample_characterization", jsonOutFile);
                    stream.close();
                    
                    allStream.printf("source %s\n", submitScript.getPath());
                }

            }
        }
        allStream.close();
        int hasiduf = 0;
    }
}
