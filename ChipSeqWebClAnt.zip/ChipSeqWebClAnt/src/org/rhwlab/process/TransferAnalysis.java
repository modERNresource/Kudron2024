/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import java.io.File;
import java.io.PrintStream;
import java.nio.file.Files;
import javax.json.JsonArray;
import javax.json.JsonObject;
import org.rhwlab.encode.EncodeUrl;

/**
 *
 * @author gevirl
 */
// make the json and script files to transfer all the analysis files from one experiment to another
// args[0] -- source experiment
// args[1] - destination experiment
public class TransferAnalysis {

    public static void main(String[] args) throws Exception {
        File dir = new File("/net/waterston/vol9/ChipSeqPipeline");
//        String srcExp = "ENCSR865KPF";
//        String destExp = "ENCSR973FOX";
        String srcExp = "ENCSR440JLG";
        String srcAnal = "ENCAN155XKQ";
        String destExp = "ENCSR521RVI";

        File srcDir = new File(dir, srcExp);
        if (!srcDir.exists()) {
            Files.createDirectories(srcDir.toPath());
        }

        File srcSubmitFile = new File(dir, srcExp + ".submit.sh");
        PrintStream submitStream = new PrintStream(srcSubmitFile);

        String expURL = String.format("https://www.encodeproject.org/experiments/%s/?format=json", srcExp);
        EncodeUrl url = new EncodeUrl(expURL);
        url.getJson();
        JsonObject jsonObj = url.getJsonObject();
        JsonArray files = jsonObj.getJsonArray("files");

        for (int i = 0; i < files.size(); ++i) {
            JsonObject fileObj = (JsonObject) files.get(i);
            String format = fileObj.getJsonString("file_format").getString();
            if (!format.equals("fastq")) {
                JsonArray analyses = fileObj.getJsonArray("analyses");
                JsonObject analObj = (JsonObject) analyses.get(0);
                String analID = analObj.getString("@id");
                if (srcAnal == null | analID.contains(srcAnal)) {

                    File fmtDir = new File(srcDir, format);
                    if (!fmtDir.exists()) {
                        Files.createDirectories(fmtDir.toPath());
                    }
                    String fileAcc = fileObj.getString("accession");
                    File jsonFile = new File(fmtDir, fileAcc + ".json");
                    PrintStream stream = new PrintStream(jsonFile);
                    stream.printf("{\"record_id\":\"%s\",\"dataset\":\"%s\"}",
                            fileAcc, destExp);
                    stream.close();

                    File submitFile = new File(fmtDir, String.format("%s.submit.sh", fileAcc));
                    stream = new PrintStream(submitFile);

                    stream.println("export DCC_API_KEY=BXTSKHIS");
                    stream.println("export DCC_SECRET_KEY=vwhzube43dekyyc6");
                    stream.printf("cd %s\n", fmtDir.getPath());
                    stream.printf("eu_register.py --patch -m prod -p file -i %s\n",
                            jsonFile.getPath());

                    stream.close();

                    submitStream.printf("source %s\n", submitFile.getPath());
                    int inasdfjh = 0;
                }
            }
        }
        submitStream.close();
    }
}
