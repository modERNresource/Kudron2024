/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.Date;
import java.util.List;
import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import org.rhwlab.chipseq.pipeline.PipelineRun;
import org.rhwlab.chipseq.qa.Directories;
import org.rhwlab.chipseqweb.ChipHelper;
import org.rhwlab.chipseqweb.ChipRun;
import org.rhwlab.chipseqweb.HibernateUtil;

/**
 *
 * @author gevirl
 */
// clean up after rerun of pipeline 
public class CleanUpRerun {

    public static void main(String[] args) throws Exception {
        String origRunChipID = args[0];
        String reRunSubmitID = args[1];
        String species = args[2];
        boolean marked = args[3].equalsIgnoreCase("true");
        
        // associate the chipID with the submitID of the rerun
        String rerunExpID = PipelineRun.ExpID(reRunSubmitID);
        File expDir = new File(Directories.sourceDir, rerunExpID);
        FinishedRuns.finishExperimentRuns(species, expDir);

        // check that rerun has been successful      
        ChipRun chipRun = (ChipRun) ChipHelper.getEquals("ChipRun", "SubmitID", reRunSubmitID, "SubmitID").get(0);
        if (chipRun.getStatus().equalsIgnoreCase("Succeeded")) {
            // remove the original run
            PipelineRun.removeRun(origRunChipID);

            // mark the rerun for submission if the original is so marked
            if (marked){
                PipelineRun.markRun(reRunSubmitID);
            }
            
            // record that the job has finsihed 
            PrintStream stream = new PrintStream(new FileOutputStream(new File(Directories.sourceDir, "rerunsFinished"),true));
            stream.printf("%s\t%s\t%s\n", reRunSubmitID,new Date().toString(),origRunChipID);
        }
        HibernateUtil.shutdown();
    }
}
