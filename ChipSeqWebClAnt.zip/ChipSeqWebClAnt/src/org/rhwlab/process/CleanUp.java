/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import java.io.File;
import java.io.PrintStream;
import java.lang.ProcessBuilder.Redirect;
import java.nio.file.Files;
import java.nio.file.attribute.PosixFilePermission;
import java.util.HashSet;
import java.util.Set;
import org.rhwlab.chipseq.qa.Directories;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipHelper;
import org.rhwlab.chipseqweb.ChipRun;
import org.rhwlab.chipseqweb.ChipSequencingFile;
import org.rhwlab.chipseqweb.ChipTag;
import org.rhwlab.chipseqweb.HibernateUtil;

/**
 *
 * @author gevirl
 */
public class CleanUp {

    String expID;

    public CleanUp(String id) {
        this.expID = id;
    }

    // remove all the runs from an experiment, does not remove sequenceing files
    public void removeRuns(PrintStream stream) throws Exception {
        File expDir = new File(Directories.sourceDir, expID);
        File chipDir = new File(expDir, "chip");

        if (chipDir.exists()) {
            // clean up the epic directories
            for (File runDir : chipDir.listFiles()) {
                if (runDir.isDirectory()) {
                    File epicRunDir = new File(Directories.epicDir, runDir.getName());
                    String cmd = String.format("rm -rf %s", epicRunDir.getPath());
                    stream.println(cmd);

                }
            }

            // remove the chip and log directories
            String cmd = String.format("rm -rf %s", chipDir.getPath());
            stream.println(cmd);

            File logDir = new File(expDir, "cromwell-workflow-logs");
            cmd = String.format("rm -rf %s", logDir.getPath());
            stream.println(cmd);

        }

        // clean up the vol9 directories and the ChipRun table
        for (Object ob : ChipHelper.getEquals("ChipRun", "expID", expID, "SubmitID")) {
            ChipRun chipRun = (ChipRun) ob;
            String[] tokens = chipRun.getSubmitId().split("_");
            File dir = new File(expDir, tokens[tokens.length - 1]);
            String cmd = String.format("rm -rf %s", dir.getPath());
            stream.println(cmd);
            ChipHelper.remove(ob);
        }
    }

    public void removeSequenceFiles(PrintStream stream) throws Exception {
        // remove any sequence file from db
        for (Object obj : ChipHelper.getEquals("ChipSequencingFile", "ExpID", expID, "FileID")) {
            ChipSequencingFile f = (ChipSequencingFile) obj;
            System.out.printf("Removing file: %s\n", f.getFileId());
            ChipHelper.remove(obj);
        }

        // delete vol9 directory
        File expDir = new File(Directories.sourceDir, expID);
        String cmd = String.format("rm -rf %s", expDir.getPath());
        stream.println(cmd);
    }

    public void removeExperiment() throws Exception {

        // remove the experiment from db
        for (Object obj : ChipHelper.getEquals("ChipExperiment", "ExpID", expID, "ExpID")) {
            ChipExperiment e = (ChipExperiment) obj;
            System.out.printf("Removing exp %s\n", e.getExpId());
            ChipHelper.remove(obj);
        }

        // remove any tags 
        for (Object obj : ChipHelper.getEquals("ChipTag", "ExpID", expID, "Name")) {
            ChipTag tag = (ChipTag) obj;
            System.out.printf("removing tag %s\n", tag.getTagId());
            ChipHelper.remove(obj);
        }
    }

    // remove everything associated with an experiment, included fastq
    public void remove() throws Exception {
        File remDir = new File(Directories.sourceDir, "deleted");
        File script = new File(remDir, expID + ".sh");
        PrintStream stream = new PrintStream(script);
        removeRuns(stream);
        removeSequenceFiles(stream);
        removeExperiment();
        stream.close();

        Set<PosixFilePermission> exePerms = new HashSet<>();
        exePerms.add(PosixFilePermission.OWNER_READ);
        exePerms.add(PosixFilePermission.OWNER_WRITE);
        exePerms.add(PosixFilePermission.OWNER_EXECUTE);
        exePerms.add(PosixFilePermission.GROUP_READ);
        exePerms.add(PosixFilePermission.GROUP_WRITE);
        exePerms.add(PosixFilePermission.GROUP_EXECUTE);
        exePerms.add(PosixFilePermission.OTHERS_READ);
        exePerms.add(PosixFilePermission.OTHERS_EXECUTE);

        Files.setPosixFilePermissions(script.toPath(), exePerms);
        runScript(script);
    }

    public void runScript(File script) throws Exception {

        ProcessBuilder pb = new ProcessBuilder(script.getPath());

        File log = new File(script.getPath().replace(".sh", ".log"));
        pb.redirectErrorStream(true);
        pb.redirectOutput(Redirect.appendTo(log));
        Process p = pb.start();
        p.waitFor();

    }

    static void Clean(String expID) throws Exception {
        CleanUp clean = new CleanUp(expID);
        clean.remove();
    }

    // this must be run on epic to compltely remove an experiment
    // args = exp id
    static public void main(String[] args) throws Exception {
        for (String arg : args) {
            CleanUp clean = new CleanUp(arg);
            clean.remove();
        }
        HibernateUtil.shutdown();;
    }
}
