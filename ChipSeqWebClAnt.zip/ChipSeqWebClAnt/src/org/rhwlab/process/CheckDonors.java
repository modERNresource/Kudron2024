/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import java.io.File;
import java.io.FileWriter;
import java.util.List;
import java.util.TreeMap;
import java.util.TreeSet;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonString;
import javax.json.stream.JsonGenerator;
import org.rhwlab.chipseq.dcc.FlyDonor;
import org.rhwlab.chipseq.dcc.WormDonor;
import org.rhwlab.chipseq.qa.Directories;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipHelper;
import org.rhwlab.chipseqweb.ChipRun;
import org.rhwlab.chipseqweb.HibernateUtil;
import org.rhwlab.encode.EncodeUrl;

/**
 *
 * @author gevirl
 */
public class CheckDonors {

    TreeMap<String, JsonObject> donorMap = new TreeMap<>();
    TreeMap<String, JsonArray> allMap = new TreeMap<>();  //all donors indexed by strain
    TreeSet<String> noAlias = new TreeSet<>(); // donors with no alias, indexed by strain
    String species;

    public CheckDonors(String species, String urlString) throws Exception {
        this.species = species;
        EncodeUrl url = new EncodeUrl(urlString);
        url.getJson();
        JsonObject jsonObj = url.getJsonObject();
        JsonArray graphList = jsonObj.getJsonArray("@graph");
        for (int i = 0; i < graphList.size(); ++i) {
            JsonObject graphObj = graphList.getJsonObject(i);
            JsonArray aliases = graphObj.getJsonArray("aliases");
            JsonString stn = graphObj.getJsonString("strain_name");

            if (stn != null) {
                String strain = stn.getString();
                donorMap.put(strain, graphObj);
                allMap.put(strain, aliases);
                if (aliases.size() == 0) {
                    noAlias.add(strain);
                }
            }
        }
        
    }
    
    public JsonObject getDonorObject(String strain){
        return this.donorMap.get(strain);
    }

    public JsonArrayBuilder donorsWithoutAlias() throws Exception {
        JsonArrayBuilder jb = Json.createArrayBuilder();

        for (Object runObj : ChipHelper.getAll("ChipRun", "SubmitID")) {
            ChipRun chipRun = (ChipRun) runObj;
            if (chipRun.getMarkedForDcc() != null) {
                for (Object expObj : ChipHelper.getEquals("ChipExperiment", "ExpID", chipRun.getExpId(), "ExpID")) {
                    ChipExperiment chipExp = (ChipExperiment) expObj;
                    if (chipExp.getSpecies().equals(species)) {
                        String strain = chipExp.getStrain();
                        if (noAlias.contains(strain)) {
                            if (species.equals("Dmel")) {
                                jb.add(new FlyDonor().toJson(chipExp));
                            } else {
//                    jb.add(new WormDonor().toJson(exp));
                                jb.add(this.donorMap.get(strain));
                            }
                        }
                    }
                }
            }
        }
/*        
        TreeMap<String, List<ChipExperiment>> map = ChipHelper.allExperiments();
        for (ChipExperiment exp : map.get(species)) {
            String strain = exp.getStrain();
            if (noAlias.contains(strain)) {
                if (species.equals("Dmel")) {
                    jb.add(new FlyDonor().toJson(exp));
                } else {
//                    jb.add(new WormDonor().toJson(exp));
                    jb.add(this.donorMap.get(strain));
                }
            }
        }
*/
        HibernateUtil.shutdown();
        return jb;
    }

    public JsonArray getAliases(String strain) {
        return allMap.get(strain);
    }
    static public String wormUrl = "https://www.encodeproject.org/search/?type=WormDonor&limit=all&format=json";
    static String flyUrl = "https://www.encodeproject.org/search/?type=FlyDonor&limit=all&format=json";

    static public void main(String[] args) throws Exception {
        CheckDonors check = new CheckDonors("CElegans", wormUrl);

        JsonGenerator gen = Json.createGenerator(new FileWriter(new File(Directories.sourceDir, "wormDonorsMissingAlias.json")));
        gen.writeStartArray();
        gen.write(check.donorsWithoutAlias().build());
        gen.writeEnd();
        gen.flush();
        gen.close();
    }

    static public void main() throws Exception {

        TreeMap<String, List<ChipExperiment>> map = ChipHelper.allExperiments();
        for (String species : map.keySet()) {

            JsonArrayBuilder jb = Json.createArrayBuilder();
            System.out.println(species);
            CheckDonors check = null;
            if (species.equals("Dmel")) {
                check = new CheckDonors(species, flyUrl);
            } else {
                check = new CheckDonors(species, wormUrl);
            }
            for (ChipExperiment exp : map.get(species)) {

                if (exp.getDonorEmail() != null) {
                    JsonArray aliases = check.getAliases(exp.getStrain());
                    if (aliases == null) {
                        if (species.equals("Dmel")) {
                            FlyDonor donor = new FlyDonor();
                            jb.add(donor.toJson(exp));
                        }
                        System.out.printf("%s %s no donor %s\n", exp.getGene(), exp.getStrain(), exp.getDonorEmail().toLocaleString());
                    } else if (aliases.size() == 0) {
                        System.out.printf("%s  no alias\n", exp.getGene(), exp.getStrain());
                    }
                }

            }
            JsonGenerator gen = Json.createGenerator(new FileWriter(new File(Directories.sourceDir, "flyDonorsMissing.json")));
            gen.writeStartArray();
            gen.write(jb.build());
            gen.writeEnd();
            gen.flush();
            gen.close();
            int osidfhiosd = 0;
        }
        HibernateUtil.shutdown();
    }
}
