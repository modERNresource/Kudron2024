/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import java.io.File;

/**
 *
 * @author gevirl
 */
public class Test {
    public static void main(String[] args) throws Exception {
 //       BedClipping.findPeakFiles(new File("/net/waterston/vol9/ChipSeqPipeline/lin-29_RW12227_L4larva_1/chip/92e532da-e37c-4aba-b0fb-921bf525f821"));
        BedClipping.clipRun("CElegans", new File("/net/waterston/vol9/ChipSeqPipeline/arid-1_RW12194_L4larva_1/chip/e21a3962-6af6-406d-9e90-5b567b480334"));
    }
}
