/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseqweb;

import org.rhwlab.chipseq.pipeline.ExperimentPeakRecord;

/**
 *
 * @author gevirl
 */
public class CompletedExperiment extends ChipExperiment {

    ExperimentPeakRecord peakRecord;
    boolean openInTrackhub = false;

    public CompletedExperiment(ChipExperiment e) throws Exception {
        super(e.getExpId(), e.getStrain(), e.getGene(), e.getStage(), e.getEnteredBy(), e.getEnteredOn(), e.getDescription(),
                e.getStatus(), e.getSpecies(), e.getMethod(), e.getGuideSequence(), e.getAssembly(), e.getChromosome(), e.getStart(),
                e.getEnd(), e.getReagent(), e.getTreatment(), e.getBasesBeforeTag(), e.getGenotype(), e.getGeneticModDesc(),
                e.getWormSyncStage(), e.getAge(), e.getBackground(), e.getGeneType(), e.getExternalId(), e.getAgeUnits(),
                e.getExpIpdesc(), e.getExpCtlDesc(), e.getAccession(), e.getSubmissionStarted(), e.getDonorEmail(), e.getAntibody(), e.getToEpic(),
                e.getDomain(),e.isInAnalysis(),e.getAntibodyProduct(),e.getCorrection(),e.getBaseGene());
    }

    public void setTrackhub(boolean b) {
        this.openInTrackhub = b;
    }

    public void setPeakRecord(ExperimentPeakRecord r) {
        this.peakRecord = r;
    }

    public int getPeakCount() {
        if (peakRecord != null) {
            return peakRecord.getCount();
        }
        return 0;
    }

    public String getReportLink() {
        if (peakRecord != null) {
            return this.peakRecord.getReportLink();
        }
        return "";
    }

    public boolean getTrackhub() {
        return this.openInTrackhub;
    }

}
