/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseqweb;


import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonNumber;
import javax.json.JsonObject;
import javax.json.JsonString;
import javax.json.JsonStructure;
import javax.json.JsonValue;


/**
 *
 * @author gevirl
 */
public class PrettyWriter {

    public PrettyWriter() {
        builder = new StringBuilder();
    }

    public String getPrettyJson() {
        return builder.toString();
    }

    public List<String> getPrettyJsonAsList() {
        String[] lines = getPrettyJson().split("\n");
        List<String> ret = new ArrayList<>();
        for (String line : lines) {
            ret.add(line);
        }
        return ret;
    }

    public void write(String jsonStr) {
        StringReader stringReader = new StringReader(jsonStr);
        try {
            json = Json.createReader(stringReader).read();
        } catch (Exception exc) {
            int usaihdfi = 0;
        }
        if (json instanceof JsonObject) {
            writeObject((JsonObject) json, 0);
        } else if (json instanceof JsonArray) {
            writeArray((JsonArray) json, 0);
        }
    }

    public void write(JsonValue jsonValue, int indent) {
        if (jsonValue instanceof JsonArray) {
            writeArray((JsonArray) jsonValue, indent);
        } else if (jsonValue instanceof JsonObject) {
            writeObject((JsonObject) jsonValue, indent);
        } else if (jsonValue instanceof JsonString) {
            writeString((JsonString) jsonValue);
        } else if (jsonValue instanceof JsonNumber) {
            writeNumber((JsonNumber) jsonValue);
        } else {
            builder.append(jsonValue.getValueType().name());
            int iasdfuidfu = 0;
        }
    }

    public void writeString(JsonString jsonString) {
        builder.append(jsonString.getString());
    }

    public void writeNumber(JsonNumber jsonNumber) {
        builder.append(jsonNumber.doubleValue());
    }

    public void writeObject(JsonObject jsonObject, int indent) {
        TreeSet<String> sortedSet = new TreeSet<>(jsonObject.keySet());
        writeIndent(indent);
        builder.append("{\n");
        for (String key : sortedSet) {
            JsonValue jsonValue = jsonObject.get(key);
            writeIndent(indent);
            builder.append(key);
            builder.append(":  ");
            if (jsonValue instanceof JsonObject) {
                builder.append("\n");
                write(jsonValue, indent + inc);
            } else {
                write(jsonValue, indent);
                builder.append("\n");
            }
        }
        writeIndent(indent);
        builder.append("}\n");
    }

    public void writeArray(JsonArray jsonArray, int indent) {
        writeIndent(indent);
        builder.append("[");
        for (int i = 0; i < jsonArray.size(); ++i) {
            JsonValue jsonValue = jsonArray.get(i);
            if (!(jsonValue instanceof JsonStructure)) {
                writeIndent(indent);
            }
            write(jsonValue, indent);
            if (i < jsonArray.size() - 1) {
                builder.append(",");
            }
        }
        writeIndent(indent);
        builder.append("]\n");
    }

    private void writeIndent(int indent) {
        for (int i = 0; i < indent; ++i) {
            builder.append(' ');
        }
    }

    public JsonObject getJson() {
        return (JsonObject) this.json;
    }
    static int inc = 4;
    StringBuilder builder;
    JsonStructure json;
}
