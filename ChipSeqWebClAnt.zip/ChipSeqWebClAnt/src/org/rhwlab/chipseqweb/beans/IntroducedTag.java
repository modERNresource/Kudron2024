/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseqweb.beans;

import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.primefaces.event.RowEditEvent;
import org.rhwlab.chipseqweb.ChipHelper;
import org.rhwlab.chipseqweb.ChipTag;

/**
 *
 * @author gevirl
 */
@Named("tags")
@SessionScoped
public class IntroducedTag implements Serializable {
    HashMap<String,List<ChipTag>> expTagMap = new HashMap<>(); // indexd by the experiment id
    HashMap<String,ChipTag> tagMap = new HashMap<>();
    ChipTag selectedTag;
    
    public IntroducedTag() {
        loadAllTags();
    }
    public void loadAllTags()  {
        boolean notLoaded=true;
        
        List list = null;
        while (notLoaded) {
            try {
                list = ChipHelper.getAll("ChipTag", "TagID");
                notLoaded = false;
            } catch(Exception ex){
                try {
                    Thread.sleep(3000);
                } catch(Exception exx){
                    
                }
            } 
        }
        expTagMap.clear();
        tagMap.clear();
        for (Object obj : list){
            ChipTag tag = (ChipTag)obj;
            String tagID = tag.getTagId();
            tagMap.put(tagID,tag);
            String expId = tag.getExpId();
            List<ChipTag> expList = expTagMap.get(expId);
            if (expList == null){
                expList = new ArrayList<>();
                expTagMap.put(expId,expList);
            }
            expList.add(tag);
        }
    }
    
    public ChipTag getTag(String tagID){
        return tagMap.get(tagID);
    }
    public List<ChipTag> getTags(String expID){
        List<ChipTag> ret = expTagMap.get(expID);
        if (ret == null){
            ret = new ArrayList<>();
        }
        return ret;
    }
    
    public void onRowEdit(RowEditEvent event) throws Exception {
        ChipTag chipTag = (ChipTag) event.getObject();
        ChipHelper.update(chipTag);
    }

    public void onRowCancel(RowEditEvent event) {

    }    
    
    public String nextTag(String expID)throws Exception {
        return ChipHelper.nextID("ChipTag", "TagID", expID, "getTagId");
    }
    
    // create a new tag for an experiment
    public void newTag(String expID)throws Exception {
        ChipHelper.save(new ChipTag(nextTag(expID),expID,"eGFP","C-terminal"));
        this.loadAllTags();
    }
    
    public void setSelectedTag(ChipTag t){
        if (t != null){
            int iuashdfiusdh=0;
        }
        this.selectedTag = t;
    }
    public ChipTag getSelectedTag(){
        return this.selectedTag;
    }
    public HashMap<String, List<ChipTag>> getTagMap(){
        return this.expTagMap;
    }
    
    public void setRowTagSelected(String tagID){
        int iuashfiuhsdi=0;
    }
    
    static public void main(String[] args) throws Exception {
        IntroducedTag tags = new IntroducedTag();
        int asdf=0;
    }
}
