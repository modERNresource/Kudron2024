/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseqweb.beans;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import java.io.File;
import java.io.Serializable;
import org.rhwlab.chipseq.qa.Directories;
import org.rhwlab.chipseqweb.ChipRun;

/**
 *
 * @author gevirl
 */
@Named("directory")
@ApplicationScoped
public class Directory implements Serializable {
    String dir;
    String epicDir;
    String flyDir;
    String wormDir;
    String htmlDir;
    /**
     * Creates a new instance of Directory
     */
    public Directory() {
        dir = Directories.sourceDir.getPath();
        epicDir = Directories.epicDir.getPath();
        flyDir = Directories.epicFlyDir.getPath();
        wormDir = Directories.epicWormDir.getPath();
        htmlDir = Directories.epicHtmlDir.getPath();
    }
    
    public void setDirectory(String d){
        this.dir = d;
    }
    public String getDirectory(){
        return dir;
    }
    public void setEpicDirectory(String d){
        this.epicDir = d;
    }
    public String getEpicDirectory(){
        return epicDir;
    }    
    
    public String getEpicHtmlDir(){
        return this.htmlDir;
    }
    public File getEpicDirectory(String species){
        if (species.equals("Dmel") || species.equalsIgnoreCase("fly")){
            return new File(getFlyEpicDirectory());
        } else if (species.equals("CElegans") || species.equalsIgnoreCase("worm")){
            return new File(getWormEpicDirectory());
        } else {
            return null;
        }
    }
    public String getWormEpicDirectory(){
        return this.wormDir;
    }
    public String getFlyEpicDirectory(){
        return this.flyDir;
    }
    public File submitDirectory(ChipRun chipRun) {
        File expDir = experimentDir(chipRun);
        String submitID = chipRun.getSubmitId();
        String[] tokens = submitID.split("_");
        return new File(expDir, tokens[tokens.length - 1]);
    }

    public File experimentDir(ChipRun chipRun) {
        return new File(dir, chipRun.getExpId());
    } 
    
    public File chipDir(String expID,String runID){
        return new File(new File(new File(dir,expID),"chip"),runID);
    }
}
