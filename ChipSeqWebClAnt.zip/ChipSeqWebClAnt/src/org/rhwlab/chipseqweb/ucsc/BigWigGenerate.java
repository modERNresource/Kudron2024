/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseqweb.ucsc;

import java.io.File;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import org.rhwlab.UCSC.BigBinaryFile;
import org.rhwlab.chipseq.qa.Directories;
import org.rhwlab.chipseq.qa.SuccessfulRuns;
import org.rhwlab.chipseqweb.PipelineFiles;

/**
 *
 * @author gevirl
 */

public class BigWigGenerate {

    static public void processRun(File runDir) throws Exception {
        String runID = runDir.getName();
        System.out.println(runID);
        File epicRunDir = new File(Directories.epicDir, runID);
        if (!epicRunDir.exists()) {
            // make the epic directory
            Files.createDirectories(epicRunDir.toPath());
            epicRunDir.setReadable(true, false);
            epicRunDir.setWritable(true, false);
            epicRunDir.setExecutable(true, false);
            epicRunDir.getParentFile().setReadable(true, false);
            epicRunDir.getParentFile().setWritable(true, false);
            epicRunDir.getParentFile().setExecutable(true, false);
        }
        List<String> files = PipelineFiles.findFiles(runDir, "*.nodup.bam");
        for (String file : files) {
            if (file.contains("execution") && !file.contains("glob")) {
                File bam = new File(file);

                File bigWig = new File(epicRunDir, bam.getName().replace(".bam", ".bigwig"));
                if (!bigWig.exists()) {
                    System.out.printf("BigWigGenerate: %s\n", bigWig.getName());
                    ArrayList<String> cmds = new ArrayList<>();
                    cmds.add("bamCoverage");
                    cmds.add("-b");
                    cmds.add(file);
                    cmds.add("-o");
                    cmds.add(bigWig.getPath());
                    cmds.add("--binSize");
                    cmds.add("10");
                    cmds.add("--normalizeUsing");
                    cmds.add("CPM");
                    cmds.add("-p");
                    cmds.add("1");
                    cmds.add("-v");

                    ProcessBuilder pb = new ProcessBuilder(cmds);
                    Process p = pb.start();
                    p.waitFor();
                    BigBinaryFile bw = new BigBinaryFile(bigWig);
                    if (bw.getChromosomes().get(0).contains("chr")) {
                        System.out.println("To Wormbase chromosomes");
                        BigBinaryFile.toWormbaseChromosomes(bigWig, bigWig);
                    }
                    bigWig.setReadable(true, false);
                }
            }
        }

    }

    // must be run on epic machine
    // each arg is a run directory in /net/waterston/vol9/ChipSeqPipeline/"expID"/chip/"runID"
    // construct bigwig for the duplicate removed data files  (input and IP)
    public static void main(String[] args) throws Exception {
        if (args.length == 0) {
            TreeMap<String, List<File>> dirMap = SuccessfulRuns.successRuns();
            for (String genomeTSV : dirMap.keySet()) {
                if (genomeTSV.contains("WS")) {
                    List<File> runDirs = dirMap.get(genomeTSV);
                    for (File runDir : runDirs) {
                        String runID = runDir.getName();

                        File epicRunDir = new File(Directories.epicDir, runID);
                        if (!epicRunDir.exists()) {
                            processRun(runDir);
                            System.out.printf("Run dir = %s\n", runDir.getPath());
                        }
                    }
                }
            }
        } else {
            for (String arg : args) {
                File runDir = new File(arg);
                if (runDir.exists()) {
                    processRun(runDir);
                }
            }
        }

    }
}
