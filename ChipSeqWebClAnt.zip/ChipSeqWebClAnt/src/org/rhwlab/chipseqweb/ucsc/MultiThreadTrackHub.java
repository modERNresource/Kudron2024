/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseqweb.ucsc;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.TreeMap;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import org.rhwlab.chipseq.qa.SuccessfulRuns;

/**
 *
 * @author gevirl
 */
// multuthreaded build of all pending trackhubs and files 
// args[0] number of threads , default is 4
// must be run on epic machine
public class MultiThreadTrackHub {

    static public void main(String[] args) throws Exception {
        int nThreads = 4;
        if (args.length > 0) {
            nThreads = Integer.valueOf(args[0]);
        }

        ExecutorService service = Executors.newFixedThreadPool(nThreads);
        Collection<Callable<String>> workers = new ArrayList<>();

        TreeMap<String, List<File>> chipMap = SuccessfulRuns.successRuns();
        for (String genomeTSV : chipMap.keySet()) {
            if (genomeTSV.contains("WS245chr")) {
                System.out.printf("Genone: %s\n", genomeTSV);
                String genome = "dm6";
                if (genomeTSV.contains("WS")) {
                    genome = "ce11";
                }
                for (File runDir : chipMap.get(genomeTSV)) {
                    System.out.printf("Finding track hub files for %s\n", runDir.getName());
                    TrackHub hub = new TrackHub(genome, runDir);
                    workers.add(hub);

                }
            }
        }
        List<Future<String>> futures = service.invokeAll(workers);
        for (Future<String> future : futures){
            System.out.printf("Completed: %s\n", future.get());
        }
        service.shutdown();
        
    }
}
