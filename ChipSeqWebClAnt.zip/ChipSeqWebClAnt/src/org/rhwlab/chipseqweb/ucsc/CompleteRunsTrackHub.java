/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseqweb.ucsc;

import java.io.File;
import java.io.PrintWriter;
import org.rhwlab.chipseq.pipeline.FileTable;
import org.rhwlab.chipseq.pipeline.FileTableRecord;
import org.rhwlab.chipseqweb.beans.Directory;

/**
 *
 * @author gevirl
 */
public class CompleteRunsTrackHub {

    File hubDir;
    String expID;
    String genome;
    FileTable table;

    public CompleteRunsTrackHub(File runDir) throws Exception {
        hubDir = runDir;
        expID = hubDir.getName();
        String species = runDir.getParentFile().getName();   // fly or worm       
        if (species.equals("fly")) {
            genome = "dm6";
        } else if (species.equals("worm")) {
            genome = "ce11";
        }
        table = new FileTable(runDir);
    }

    public void buildHub() throws Exception {
        String genomeFileName = buildHubTxtFile();
        String trackFileName = buildGenomesTxtFile(genomeFileName);
        buildTrackDbFile(trackFileName);

    }

    private String buildHubTxtFile() throws Exception {
        File hubTxt = new File(hubDir, "hub.txt");
        PrintWriter writer = new PrintWriter(hubTxt);
        writer.printf("hub %s\n", expID);
        writer.printf("shortLabel %s\n", expID);
        writer.printf("longLabel %s\n", expID);
        String genomeFileName = "genomes.txt";
        writer.printf("genomesFile %s\n", genomeFileName);
        writer.println("email gevirl@uw.edu");
        writer.close();
        hubTxt.setReadable(true, false);
        return genomeFileName;
    }

    private String buildGenomesTxtFile(String fileName) throws Exception {
        File txt = new File(hubDir, fileName);
        PrintWriter writer = new PrintWriter(txt);
        writer.printf("genome %s\n", genome);
        String trackFileName = String.format("%s_trackDb.txt", genome);
        writer.printf("trackDb %s\n", trackFileName);
        writer.close();
        txt.setReadable(true, false);
        return trackFileName;
    }

    private void buildTrackDbFile(String fileName) throws Exception {
        File track = new File(hubDir, fileName);
        PrintWriter writer = new PrintWriter(track);

        String desc = "IDR";
        String vis = "full";
        String format = "bigBed";
        String trackID = buildCompositeTrack(writer, desc, vis,format);
        for (FileTableRecord rec : table.getRecords(desc, null, "bigBed", null)) {
            buildBigNarrowPeakTrack(writer, rec, trackID, vis);
        }
        desc = "Overlap";
        vis = "hide";
        trackID = buildCompositeTrack(writer, desc, vis,format);
        for (FileTableRecord rec : table.getRecords(desc, null, "bigBed", null)) {
            buildBigNarrowPeakTrack(writer, rec, trackID, vis);
        }

        desc = "signal-p";
        vis = "full";
        format = "bigWig";
        trackID = buildCompositeTrack(writer, desc, vis,format);
        for (FileTableRecord rec : table.getRecords(desc, null, "bigWig", null)) {
            buildBigWigTrack(writer, rec, trackID, vis);
        }

        writer.close();
        track.setReadable(true, false);
    }

    private String buildCompositeTrack(PrintWriter writer, String desc, String vis, String type) {
        String track = String.format("%s_%s", desc, expID);
        writer.printf("track %s\n", track);
        writer.println("compositeTrack on");
        writer.printf("shortLabel %s\n", desc);
        writer.printf("longLabel %s %s\n", desc,expID);
        writer.printf("visibility %s\n", vis);
        writer.printf("type %s\n",type);
        writer.println();
        return track;
    }

    private void buildBigNarrowPeakTrack(PrintWriter writer, FileTableRecord rec, String parent, String vis) {
        writer.printf("track %s_%s_%s_%s\n",expID,rec.getReplicates(), rec.getReplicateType(), rec.getDesc());
        writer.printf("parent %s\n", parent);
        writer.printf("shortLabel %s\n", rec.getReplicates());
        writer.printf("longLabel %s %s %s %s\n",expID, rec.getReplicates(), rec.getReplicateType(), rec.getDesc());
        writer.println("type bigNarrowPeak");
        writer.println("color 0,0,0");
        writer.println("maxHeightPixels 128:40:15");
        writer.printf("visibility %s\n", vis);
        writer.printf("bigDataUrl  %s\n", rec.asExternalURL());
        writer.println();

    }

    private void buildBigWigTrack(PrintWriter writer, FileTableRecord rec, String parent, String vis) {
        writer.printf("track %s_%s_%s\n",expID,rec.getReplicates(), rec.getDesc());
        writer.printf("parent %s\n", parent);
        writer.printf("shortLabel %s\n", rec.getReplicates());
        writer.printf("longLabel %s %s %s\n",expID, rec.getReplicates(), rec.getDesc());
        writer.println("type bigWig");
        writer.println("color 0,0,0");
        writer.println("maxHeightPixels 128:40:15");
        writer.printf("visibility %s\n", vis);
        writer.printf("bigDataUrl  %s\n", rec.asExternalURL());
        writer.println();

    }

    // build track hubs for all completed runs on epic
    // must be run on epic    
    static public void main(String[] args) throws Exception {
        Directory dir = new Directory();
        File wormDir = new File(dir.getWormEpicDirectory());
        for (File runDir : wormDir.listFiles()) {
            System.out.println(runDir.getPath());
            CompleteRunsTrackHub hub = new CompleteRunsTrackHub(runDir);
            hub.buildHub();
        }
        
        File flyDir = new File(dir.getFlyEpicDirectory());
        for (File runDir : flyDir.listFiles()) {
            System.out.println(runDir.getPath());
            CompleteRunsTrackHub hub = new CompleteRunsTrackHub(runDir);
            hub.buildHub();
        }        
    }
}
