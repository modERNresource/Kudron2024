/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseqweb.ucsc;

import java.io.File;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.Callable;
import org.rhwlab.UCSC.BigBinaryFile;
import org.rhwlab.chipseq.qa.Directories;
import org.rhwlab.chipseq.qa.SuccessfulRuns;
import org.rhwlab.chipseqweb.commandline.PipelineFiles;
import org.rhwlab.process.XferFiles;

/**
 *
 * @author gevirl
 */
public class TrackHub implements Callable<String> {

    String genome;
    File runDir;
    String expID;
    String runID;
    File hubDir;
    TreeMap<String, File> bigFileMap;

    public TrackHub(String genome, File rundir) throws Exception {
        this.genome = genome;
        this.runDir = rundir;
        this.runID = runDir.getName();
        this.expID = runDir.getParentFile().getParentFile().getName();
        this.hubDir = new File(Directories.epicDir, runDir.getName());
        this.bigFileMap = new TreeMap<>();
        TrackHub.mapFiles(runDir, "*bigwig", bigFileMap);
        TrackHub.mapFiles(runDir, "*conservative_peak.regionPeak.bb", bigFileMap);
        TrackHub.mapFiles(runDir, "*optimal_peak.regionPeak.bb", bigFileMap);
    }

    static public void mapFiles(File runDir, String suffix, TreeMap<String, File> bigwigMap) throws Exception {
        for (String bigwig : PipelineFiles.findFiles(runDir, suffix)) {
            File bigwigFile = new File(bigwig);
            bigwigMap.put(bigwigFile.getName(), bigwigFile);
        }

    }

    public void buildHub() throws Exception {
        File hubTxt = new File(hubDir, "hub.txt");
        if (!hubTxt.exists()){
        buildHubTxtFile();
        buildGenomesTxtFile();
        buildTrackDbFile();
        }
        /*        
        File hubs = new File(runDir.getParentFile().getParentFile(), "hubs");
        PrintWriter writer = new PrintWriter(new FileWriter(hubs, hubs.exists()));
        writer.printf("%s\n", runID);
        writer.close();
         */
    }

    private void buildHubTxtFile() throws Exception {
        File hubTxt = new File(hubDir, "hub.txt");
        PrintWriter writer = new PrintWriter(hubTxt);
        writer.printf("hub %s\n", hubDir.getName());
        writer.printf("shortLabel %s\n", hubDir.getName());
        writer.printf("longLabel %s\n", hubDir.getName());
        writer.println("genomesFile genomes.txt");
        writer.println("email gevirl@uw.edu");
        writer.close();
        hubTxt.setReadable(true, false);
    }

    private void buildGenomesTxtFile() throws Exception {
        File txt = new File(hubDir, "genomes.txt");
        PrintWriter writer = new PrintWriter(txt);
        writer.printf("genome %s\n", genome);
        writer.printf("trackDb %s_trackDb.txt\n", genome);
        writer.close();
        txt.setReadable(true, false);
    }

    private void buildTrackDbFile() throws Exception {
        File track = new File(hubDir, String.format("%s_trackDb.txt",genome));
        PrintWriter writer = new PrintWriter(track);
        buildSuperTrack(writer);
        writer.close();
        track.setReadable(true, false);
    }

    private void buildSuperTrack(PrintWriter writer) {
        writer.printf("track %s\n", expID);
        writer.println("superTrack on");
        writer.printf("shortLabel %s\n", expID);
        writer.printf("longLabel %s\n", expID);
        writer.println();

        buildBigWigCompositeTrack(writer);
        buildBigBedCompositeTrack(writer);
    }

    private void buildBigBedCompositeTrack(PrintWriter writer) {
        writer.printf("track bed_%s\n", expID);
        writer.printf("parent %s\n", expID);
        writer.println("compositeTrack on");
        writer.printf("shortLabel bed_%s\n", expID);
        writer.printf("longLabel bed_%s\n", expID);
        writer.println("visibility full");
        writer.println("subGroup1 view Views IDR=idr Overlap=overlap");
        writer.println("subGroup2 peak Peaks Optimal=optimal Conservative=conservative");
        writer.println("dimensions dimX=peak");
        writer.println("sortOrder peak=+ view=+");
        writer.println("type bigBed 3 ");
        writer.println();

        for (File bigbed : hubDir.listFiles()) {
            if (bigbed.getPath().endsWith("bb")) {
                String peak = null;
                String view = null;
                String src = bigbed.getName();
                if (src.contains("optimal")) {
                    peak = "Optimal";
                } else if (src.contains("conservative")) {
                    peak = "Conservative";
                }

                if (src.contains("idr")) {
                    view = "IDR";
                } else if (src.contains("overlap")) {
                    view = "Overlap";
                }
                buildBigbedTrack(writer, peak, view, bigbed.getName());
            }
        }
    }

    private void buildBigWigCompositeTrack(PrintWriter writer) {
        writer.printf("track wig_%s\n", expID);
        writer.printf("parent %s\n", expID);
        writer.println("compositeTrack on");
        writer.printf("shortLabel wig_%s\n", expID);
        writer.printf("longLabel wig_%s\n", expID);
        writer.println("visibility full");
        writer.println("subGroup1 view Views Positive=positive_strand Negative=negative_strand fc=fc_input_adjusted pval=pval_input_adjusted");
        writer.println("subGroup2 replicate Replicate Combined=combined_replicates Rep1=replicate1 Rep2=replicate2");
        writer.println("dimensions dimX=replicate");
        writer.println("sortOrder replicate=+ view=+");
        writer.println("type bigWig");
        writer.println();

        for (File bigwig : hubDir.listFiles()) {
            if (bigwig.getPath().endsWith("bigwig")) {
                String view = "pval";
                File srcBigwig = bigFileMap.get(bigwig.getName());
                if (srcBigwig != null) {
                    String src = srcBigwig.getPath();
                    if (src.contains("positive")) {
                        view = "Positive";
                    } else if (src.contains("negative")) {
                        view = "Negative";
                    } else if (src.contains("fc.signal")) {
                        view = "fc";
                    }

                    String rep = null;
                    if (src.contains("pooled")) {
                        rep = "Combined";
                    } else if (src.contains("shard-0")) {
                        rep = "Rep1";
                    } else if (src.contains("shard-1")) {
                        rep = "Rep2";
                    }
                    buildBigwigTrack(writer, rep, view, bigwig.getName());
                }
            }
        }
    }

    private void buildBigbedTrack(PrintWriter writer, String peak, String view, String fname) {
        writer.printf("track %s_%s_bigbed\n", peak, view);
        writer.printf("parent bed_%s\n", expID);
        writer.printf("subGroups peak=%s view=%s\n", peak, view);
        writer.printf("shortLabel %s_%s_%s\n", expID, peak, view);
        writer.printf("longLabel %s_%s_%s\n", expID, peak, view);
        writer.println("type bigBed 6 +");
        writer.println("color 0,0,0");
        writer.println("maxHeightPixels 128:40:15");
        writer.println("visibility dense");
        writer.println("autoScale on");
        writer.printf("bigDataUrl  http://waterston.gs.washington.edu/ChipSeqPipeline/%s/%s\n", runID, fname);
        writer.println();

    }

    private void buildBigwigTrack(PrintWriter writer, String rep, String view, String fname) {
        writer.printf("track %s_%s_bigwig\n", rep, view);
        writer.printf("parent wig_%s\n", expID);
        writer.printf("subGroups replicate=%s view=%s\n", rep, view);
        writer.printf("shortLabel %s_%s_%s\n", expID, rep, view);
        writer.printf("longLabel %s_%s_%s\n", expID, rep, view);
        writer.println("type bigWig 0 1000");
        writer.println("color 0,0,0");
        writer.println("maxHeightPixels 128:40:15");
        writer.println("visibility dense");
        writer.println("autoScale on");
        writer.printf("bigDataUrl  http://waterston.gs.washington.edu/ChipSeqPipeline/%s/%s\n", runID, fname);
        writer.println();

    }

    private void copyToEpic() throws Exception {
        File destDir = hubDir;
        System.out.println("TrackHub: copyToEpic");
        TreeSet<String> copied = new TreeSet<>();  // set of copied files - maintained so that a file gets copies only once
        for (File source : this.bigFileMap.values()) {

            if (!copied.contains(source.getName())) {
                File destFile = new File(destDir, source.getName());

                if (!destFile.exists()) {
                    System.out.printf("source  = %s\n", source.getPath());
                    System.out.printf("dest  = %s\n", destFile.getPath());

                    if (genome.equals("ce11")) {
                        BigBinaryFile.toWormbaseChromosomes(source, destFile);
                    } else {
                        Files.copy(source.toPath(), destFile.toPath());
                    }
                    copied.add(source.getName());
                    destFile.setReadable(true, false);
                }
                System.out.printf("Destination file exists: %s\n", destFile.getPath());
            }
        }
        
        // copy the metadata and qc files
        File qcJson = XferFiles.qcJsonFile(runDir);
        File destFile = new File(destDir, qcJson.getName());
        Files.copy(qcJson.toPath(),destFile.toPath(),StandardCopyOption.REPLACE_EXISTING );
        
        
        File qcHtml = XferFiles.qcHtmlFile(runDir);
        destFile = new File(destDir, qcHtml.getName());
        Files.copy(qcHtml.toPath(),destFile.toPath(),StandardCopyOption.REPLACE_EXISTING  );  
        
        File metaFile = XferFiles.metadataFile(runDir);
        destFile = new File(destDir,metaFile.getName());
        Files.copy(metaFile.toPath(),destFile.toPath(),StandardCopyOption.REPLACE_EXISTING );
      
        /*
        // copy the peak files
        for (String bb : PipelineFiles.findFiles(runDir, "*conservative_peak.regionPeak.bb")) {
            if (!bb.contains("glob")) {
                File source = new File(bb);
                File destFile = new File(destDir, source.getName());
                System.out.printf("bb: %s %s\n", source.getPath(), destFile.getPath());
                if (!destFile.exists()) {
                    if (genome.equals("ce11")) {
                        BigBinaryFile.toWormbaseChromosomes(source, destFile);
                    } else {
                        Files.copy(source.toPath(), destFile.toPath());
                    }
                    destFile.setReadable(true, false);
                }
            }
        }

        for (String bb : PipelineFiles.findFiles(runDir, "*optimal_peak.regionPeak.bb")) {
            File source = new File(bb);
            if (!bb.contains("glob")) {
                File destFile = new File(destDir, source.getName());
                if (!destFile.exists()) {
                    if (genome.equals("ce11")) {
                        BigBinaryFile.toWormbaseChromosomes(source, destFile);
                    } else {
                        Files.copy(source.toPath(), destFile.toPath());
                    }
                    destFile.setReadable(true, false);
                }
            }
        }
         */
    }

    @Override
    public String call() throws Exception {

        if (bigFileMap.size() > 0) {
            System.out.printf("Building TrackHub %s\n", runDir.getName());

            // create the hub directory
            Files.createDirectories(hubDir.toPath());
            hubDir.setReadable(true, false);
            hubDir.setWritable(true, false);
            hubDir.setExecutable(true, false);
            hubDir.getParentFile().setReadable(true, false);
            hubDir.getParentFile().setWritable(true, false);
            hubDir.getParentFile().setExecutable(true, false);

            // build the track hub
            copyToEpic();
            buildHub();
        }
        return this.runID;
    }

// builds a trackhub for  pipeline runs
// this is run on epic
// these are track hub for the analysis files from the new pipeline 
    // arg[0] - genome (dm6 or ce11)
    // arg[1} full path to run directory on /net/waterston/ChipSeqPipeline/
    public static void main(String[] args) throws Exception {
        if (args.length == 0) {
            System.out.println("TrackHub processing all successful runs");
            TreeMap<String, List<File>> chipMap = SuccessfulRuns.successRuns();
            for (String genomeTSV : chipMap.keySet()) {
                System.out.printf("Genone: %s\n", genomeTSV);
                for (File runDir : chipMap.get(genomeTSV)) {
                    System.out.printf("Run: %s\n", runDir.getPath());
                    String genome = "dm6";
                    if (genomeTSV.contains("WS")) {
                        genome = "ce11";
                    }

                        TrackHub hub = new TrackHub(genome, runDir);
                        hub.call();
                    

                }
            }
        } else {
            TrackHub hub = new TrackHub(args[0], new File(args[1]));
            hub.call();
        }
    }

}
