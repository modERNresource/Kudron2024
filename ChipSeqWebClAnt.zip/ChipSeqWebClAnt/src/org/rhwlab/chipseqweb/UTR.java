/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseqweb;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;

/**
 *
 * @author gevirl
 */
public class UTR {

    TreeMap<String, List<String[]>> map = new TreeMap<>();

    public UTR(File gff2) throws Exception {
        BufferedReader reader = new BufferedReader(new FileReader(gff2));
        String line = reader.readLine();
        while (line != null) {
            String[] tokens = line.split("\t");
            if (tokens.length == 9) {
                if (tokens[1].equals("Coding_transcript") && tokens[2].equals("three_prime_UTR")) {
                    String transcript = tokens[8].split(" ")[1].replace("\"", "");
                    List<String[]> utrList = map.get(transcript);
                    if (utrList == null) {
                        utrList = new ArrayList<>();
                        map.put(transcript, utrList);
                    }
                    utrList.add(tokens);
                }
            }
            line = reader.readLine();
        }
        reader.close();
    }

    public List<String[]> getLikeUTR(String transcript) {
        ArrayList<String[]> ret = new ArrayList<>();
        if (map.tailMap(transcript) != null) {
            Set<String> set = map.tailMap(transcript).keySet();
            if (set != null) {
                for (String key : set) {
                    if (key.equals(transcript)) {
                        ret.addAll(map.get(key));
                        break;
                    }
                    if (key.startsWith(transcript)) {
                        ret.addAll(map.get(key));

                    } else {
                        break;
                    }
                }
            }
        }
        return ret;
    }

    static public boolean sameUTR(List<String[]> utrs) {
        String[] utr0 = utrs.get(0);
        for (int i = 1; i < utrs.size(); ++i) {
            String[] utr = utrs.get(i);
            if (!utr[0].equals(utr0[0])) {
                return false;
            }
            if (!utr[3].equals(utr0[3])) {
                return false;
            }
            if (!utr[4].equals(utr0[4])) {
                return false;
            }
            if (!utr[6].equals(utr0[6])) {
                return false;
            }

        }
        return true;
    }

    public List<String[]> getUTR(String transcript) {
        return map.get(transcript);
    }

    static public void main(String[] args) throws Exception {
        File gff2 = new File("/net/waterston/vol9/References/WS235/c_elegans.WS235.annotations.UTR.gff2");
        UTR utr = new UTR(gff2);
        int iusdhfiushf = 0;
    }
}
