/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseqweb;

import java.math.BigDecimal;
import javax.json.Json;
import javax.json.JsonObjectBuilder;

/**
 *
 * @author gevirl
 */
public class JsonUtil {
    static public JsonObjectBuilder jsonBase(ChipExperiment exp){   
        JsonObjectBuilder builder = Json.createObjectBuilder();
        
        builder.add("chip.title", exp.getExpId());
        if (exp.getDescription() != null){
            builder.add("chip.description", exp.getDescription());
        } else  {
            builder.add("chip.description", exp.getExpId());
        }
        builder.add("chip.pipeline_type" , "tf");    
        builder.add("chip.always_use_pooled_ctl" , true);
        builder.add("chip.true_rep_only" , false);
        builder.add("chip.enable_count_signal_track" ,true);
        return builder;
    }
}
