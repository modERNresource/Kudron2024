/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseqweb;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.FileTime;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

/**
 *
 * @author gevirl
 */
public class PipelineFiles {

    
    static public File latestRun(File chipdir)throws Exception {
        TreeMap<FileTime,File> map = new TreeMap<>();
        for (File file : chipdir.listFiles()){
            map.put(Files.getLastModifiedTime(file.toPath()),file);
        }
        return map.lastEntry().getValue();
    }
    static public List<String> findFiles(File dir,String name)throws Exception {
        return findFiles(dir.toPath(),name);
    }
    static public List<String> findFiles(Path path,String name)throws Exception {
        ArrayList<String> ret = new ArrayList<>();
        ProcessBuilder pb = new ProcessBuilder("find",path.toAbsolutePath().toString(),"-name",name);
        Process p = pb.start();
        BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String line = reader.readLine();
        while (line != null){
            ret.add(line);
            line = reader.readLine();
        }
        return ret;
    }
    static public List<String> findLatestFiles(File dir,String name)throws Exception {
        return findFiles(latestRun(dir),name);
    }
    static public void main(String[] args)throws Exception {
         List<String> files = PipelineFiles.findFiles(new File("/net/waterston/vol9/ChipSeqPipeline/arid-1_RW12194_L4larva_1/chip"), "*.nodup.bam");
//       List<String> files = PipelineFiles.findLatestFiles(new File("/net/waterston/vol9/ChipSeqPipeline/arid-1_RW12194_L4larva_1/chip"),"*bigwig");        
 //      List<String> files = PipelineFiles.findLatestFiles(new File("/net/waterston/vol9/ChipSeqPipeline/arid-1_RW12194_L4larva_1/chip"),"*optimal_peak.regionPeak.bb");
//       List<String> files = PipelineFiles.findLatestFiles(new File("/net/waterston/vol9/ChipSeqPipeline/arid-1_RW12194_L4larva_1/chip"),"*conservative_peak.regionPeak.bb");
        for (String f : files){
//            if (!f.contains("glob")){
if (f.contains("execution") && !f.contains("glob")) {
                System.out.println(f);
}
///            }
        }
        int udhfuisdh=0;
    }
}
