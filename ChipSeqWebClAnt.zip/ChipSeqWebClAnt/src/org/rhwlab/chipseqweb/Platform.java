/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseqweb;

import java.util.Map;
import java.util.TreeMap;
import javax.json.JsonArray;
import javax.json.JsonObject;
import org.rhwlab.encode.EncodeUrl;

/**
 *
 * @author gevirl
 */
public class Platform {

    String platformURL = "https://www.encodeproject.org/platforms/?limit=all&format=json";
    Map<String,String> platformMap = new TreeMap<>();

    public Platform() throws Exception {
        EncodeUrl url = new EncodeUrl(platformURL);
        url.getJson();
        JsonObject jsonObj = url.getJsonObject();
        JsonArray graphList = jsonObj.getJsonArray("@graph");
        for (int i = 0; i < graphList.size(); ++i) {
            JsonObject graphObj = graphList.getJsonObject(i);
            platformMap.put(graphObj.getJsonString("title").getString(), graphObj.getJsonString("@id").getString());
        }
    }
    
    public String getPlatform(String machine){
        String title = dccMap.get(machine);
        if (title != null){
            return platformMap.get(title);
        }
        return "";
    }
    static public void main(String[] args)throws Exception {
        Platform plat = new Platform();
        for (String platform : plat.platformMap.keySet()){
            System.out.println(platform);
        }
    }
    
    static TreeMap<String,String> dccMap = new TreeMap<>();
    { 
        dccMap.put("A01519", "Illumina NovaSeq 6000");
        dccMap.put("A00127", "Illumina NovaSeq 6000");
        dccMap.put("A00124","Illumina NovaSeq 6000");
        dccMap.put("A00214R","Illumina NovaSeq 6000");
        dccMap.put("A00216R","Illumina NovaSeq 6000");
        
        dccMap.put("D00306","Illumina HiSeq 2500");
        dccMap.put("K00242", "Illumina Genome Analyzer IIx");
        
    }
}
