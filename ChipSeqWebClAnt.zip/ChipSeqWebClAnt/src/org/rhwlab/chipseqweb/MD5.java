/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseqweb;

import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Files;
import java.security.MessageDigest;

/**
 *
 * @author gevirl
 */
public class MD5 {

    public static String compute(File file) throws Exception {
        FileInputStream inputStream = new FileInputStream(file);
        MessageDigest digest = MessageDigest.getInstance("MD5");

        byte[] bytesBuffer = new byte[1024];
        int bytesRead = inputStream.read(bytesBuffer);

        while (bytesRead != -1) {
            digest.update(bytesBuffer, 0, bytesRead);
            bytesRead = inputStream.read(bytesBuffer);
        }
        inputStream.close();
        byte[] hashedBytes = digest.digest();

        return convertByteArrayToHexString(hashedBytes);

    }

    public static String convertByteArrayToHexString(byte[] arrayBytes) {
        StringBuilder stringBuffer = new StringBuilder();
        for (int i = 0; i < arrayBytes.length; i++) {
            stringBuffer.append(Integer.toString((arrayBytes[i] & 0xff) + 0x100, 16)
                    .substring(1));
        }
        return stringBuffer.toString();
    }

    // repair the file size and md5
    static public void main(String[] args) throws Exception {
        for (Object obj : ChipHelper.getAll("ChipSequencingFile", "FileID")) {
            ChipSequencingFile csf = (ChipSequencingFile) obj;

            if (csf.getMd5() == null) {
                File file = new File(csf.getLocalFilePath());
                long size = Files.size(file.toPath());
                
                csf.setFileSize(size);
                String md5 = MD5.compute(file);
                csf.setMd5(md5);
                ChipHelper.update(obj);
                
System.out.printf("%s : %d  %s\n", file.getPath(), size,md5);                
            }
        }
//        String md5 = MD5.compute(file);
        int klajsdhf = 0;
    }
}
