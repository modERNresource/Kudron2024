/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.pipeline;

import java.io.File;


/**
 *
 * @author gevirl
 */
public class Track {

    String size;
    File file;
    String desc="";

    public Track(File path) {
        file = path;
        long l = file.length();
        if (l > 1000000000) {
            size = String.format("%.2fG", l / 1000000000.0);
        } else if (l > 1000000) {
            size = String.format("%.2fM", l / 1000000.0);
        } else if (l > 1000) {
            size = String.format("%.2fK", l / 1000.0);
        } else {
            size = String.format("%d", l);
        }
        desc = pickDesc(file.getName());
    }

    public File getFile(){
        return file;
    }
    public String getFileName() {
        return file.getName();
    }

    public String getSize() {
        return size;
    }

    public String getDescription() {
        return desc;
    }
    
    static String pickDesc(String fName){
        if (fName.endsWith(".nodup.bigwig")){
            return "Full reads, single IP or input, both strands";
        } 
        else if (fName.endsWith(".nodup.negative.bigwig")){
            return "Read starts, single IP, neg strand";
        } 
        else if (fName.endsWith(".pooled.negative.bigwig")){
            return "Read starts, pooled IPs, neg strand";
        }
        else if(fName.endsWith(".nodup.positive.bigwig")){
            return "Read starts, single IP, pos strand";
        }
        else if(fName.endsWith(".pooled.positive.bigwig")){
            return "Read starts, pooled IPs, pos strand";
        }
        else if (fName.endsWith("fc.signal.bigwig")){
            if (fName.contains("pooled_x_")){
                return "Pooled IPs fold change over pooled input";
            }
            else {
                return "Single IP fold change over matched input";
            }
        }
        else if (fName.endsWith("pval.signal.bigwig")){
            if (fName.contains("pooled_x_")){
                return "Pooled IPs p-value relative to pooled input";
            }
            else {
                return "Single IP p-value relative to matched input";
            }            
        }
        return "";
    }
        
}
