/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.pipeline;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.json.JsonObject;

/**
 *
 * @author gevirl
 */
public class Reproduce implements Serializable  {
    String label;
    int nt;
    Integer n1=null;
    Integer n2=null;
    Integer n3=null;
    int np;
    int nOpt;
    int nConsv;
    double rescue;
    double consist;
    
    public Reproduce(String label,JsonObject replication){
        this.label = label;
        JsonObject obj = replication.getJsonObject("reproducibility").getJsonObject(label);
        nt = obj.getInt("Nt");
       
        if (obj.containsKey("N1")){
            n1 = obj.getInt("N1");
        }        
        if (obj.containsKey("N2")){
            n2 = obj.getInt("N2");
        }
        if (obj.containsKey("N3")){
            n3 = obj.getInt("N3");
        }   
        
        np = obj.getInt("Np");
        nOpt = obj.getInt("N_opt");
        nConsv = obj.getInt("N_consv");
        rescue = obj.getJsonNumber("rescue_ratio").doubleValue();
        consist = obj.getJsonNumber("self_consistency_ratio").doubleValue();
    }
    public Boolean getHasN1(){
        return true;
    }
    public Boolean getHasN2(){
        return n2 != null;
    }
    public Boolean getHasN3(){
        return n3 != null;
    }    
    public String getLabel(){
        return label;
    }
    public int getNt(){
        return nt;
    }
    public Integer getN1(){
        return n1;
    }
    public Integer getN2(){
        return n2;
    }
    public Integer getN3(){
        return n3;
    }    
    public int getNp(){
        return np;
    }
    public int getNopt(){
        return nOpt;
    }
    public int getNconsv(){
        return nConsv;
    }
    public String getRescue(){
        return String.format("%.2f", rescue);
    }
    public String getConsist(){
        return String.format("%.2f", consist);
    }

    static public List<Reproduce> formReproduce(JsonObject qc){
        ArrayList<Reproduce> list = new ArrayList<>();
        JsonObject replication = qc.getJsonObject("replication");
        for (String key : replication.getJsonObject("reproducibility").keySet()){
            list.add(new Reproduce(key,replication));
        }
        return list;
    }
            
}
