/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.pipeline;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.json.JsonObject;


/**
 *
 * @author gevirl
 */
public class Alignment implements Serializable {

    private String label;
    private int totalReads;
    private int mappedReads;
    private int dupRemovedReads;
    private double percentDups;

    public Alignment(String key, String label, JsonObject json) {
        this.label = label;
        JsonObject dup = json.getJsonObject("dup").getJsonObject(key);
        
        JsonObject samstatObj = json.getJsonObject("samstat");
        if (samstatObj != null) {
            JsonObject samstat = samstatObj.getJsonObject(key);
            totalReads = samstat.getInt("total_reads");
            mappedReads = samstat.getInt("mapped_reads");
        } else {
            totalReads = dup.getInt("unpaired_reads");
            mappedReads = totalReads;
        }
        
        percentDups = dup.getJsonNumber("pct_duplicate_reads").doubleValue();

        JsonObject nodup = json.getJsonObject("nodup_samstat").getJsonObject(key);
        dupRemovedReads = nodup.getInt("total_reads");
    }

    public int getTotalReads() {
        return totalReads;
    }

    public int getMappedReads() {
        return mappedReads;
    }

    public String getLabel() {
        return label;
    }

    public int getDupRemovedReads() {
        return this.dupRemovedReads;
    }

    public double getPercentDups() {
        return this.percentDups;
    }

    static public List<Alignment> formAlignments(JsonObject json, Map<String, String> keyMap) {
        List<Alignment> list = new ArrayList<>();
        JsonObject align = json.getJsonObject("align");

        for (String key : align.getJsonObject("dup").keySet()) {
            String maplabel = key;
            if (keyMap != null) {
                maplabel = keyMap.get(key);
            }
            list.add(new Alignment(key, maplabel, align));
        }
        return list;
    }
}
