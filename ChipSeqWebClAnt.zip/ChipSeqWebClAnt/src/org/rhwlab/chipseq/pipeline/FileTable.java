/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.pipeline;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.Serializable;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.zip.GZIPInputStream;
import javax.json.JsonObject;
import org.rhwlab.chipseq.dcc.DCCFile;
import org.rhwlab.chipseq.dcc.Experiment;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipRun;
import org.rhwlab.chipseqweb.ChipSequencingFile;
import org.rhwlab.chipseqweb.HibernateUtil;
import org.rhwlab.chipseqweb.beans.Directory;

/**
 *
 * @author gevirl
 */
public class FileTable implements Serializable {

    TreeMap<String, TreeMap<String, TreeMap<String, TreeMap<String, List<FileTableRecord>>>>> map = new TreeMap<>();  //desc -> replicateType -> format -> replicates -> rec
    File chipDir;
    File tableFile;

    // construct using the table file
    public FileTable(File file) throws Exception {
        File tableFile = file;
        if (file.isDirectory()) {
            String expID = file.getName();
            tableFile = new File(file, String.format("%s.table.tsv", expID));
        }
        BufferedReader reader = new BufferedReader(new FileReader(tableFile));
        String line = reader.readLine(); // header
        line = reader.readLine();
        while (line != null) {
            String[] tokens = line.split("\t");
            FileTableRecord rec = new FileTableRecord(tokens);
            this.addToMap(rec);
            line = reader.readLine();
        }
        reader.close();

        this.tableFile = tableFile;

    }

    public FileTable(ChipExperiment exp, ChipRun run) throws Exception {
        String expID = exp.getExpId();
        String runID = run.getChipId();
        String accession = exp.getAccession();
        System.out.printf("FileTable: %s\t%s\n", expID, runID);
        chipDir = new Directory().chipDir(expID, runID);

        call_idr(chipDir);
        call_idr_pr(chipDir);
        processShard(new File(chipDir, "call-idr_ppr"), RepTypes[0], Desc[1]);

        call_overlap_pr(chipDir);
        call_overlap(chipDir);
        processShard(new File(chipDir, "call-overlap_ppr"), RepTypes[0], Desc[0]);

        setOptimalConserve("bed", "IDR");
        setOptimalConserve("bigBed", "IDR");

        // do the signal files
        signal_track("call-macs2_signal_track", true);
        signal_track("call-macs2_signal_track_pooled", false);

        // do the sequence and bam files
        if (accession != null) {
            // link to the bam and fastq files in the dcc
            Experiment expDCC = new Experiment(accession);
            String assembly = expDCC.getAssembly();
            Experiment ctlExp = new Experiment(expDCC.getControlAccession());
            filesByAccession(expDCC, Formats[2], Desc[3], assembly, RepTypes[2]);  // IP bams          
            filesByAccession(ctlExp, Formats[2], Desc[3], assembly, RepTypes[3]); // control bams
            filesByAccession(expDCC, Formats[3], Desc[6], null, RepTypes[2]);     // IP fastq      
            filesByAccession(ctlExp, Formats[3], Desc[6], null, RepTypes[3]);   // control fastq  

        } else {

            // link to local fastq
            JsonObject inputs = PipelineRun.getPipelineRunInput(chipDir);
            Map<String, Map<Integer, Map<Integer, List<ChipSequencingFile>>>> mapFastq = PipelineRun.runPaths(inputs);// map of filetype -> replicate -> read -> files
            if (mapFastq != null) {
                if (mapFastq.get("fastqs") != null) {
                    localFastq(mapFastq.get("fastqs"), Formats[3], Desc[6], Experiment.getAssembly(exp.getSpecies()), RepTypes[2]);
                    localFastq(mapFastq.get("ctl_fastqs"), Formats[3], Desc[6], Experiment.getAssembly(exp.getSpecies()), RepTypes[3]);
                }
                localBam(chipDir, "call-align", Desc[3], RepTypes[2]);
                localBam(chipDir, "call-align_ctl", Desc[3], RepTypes[3]);
                localBam(chipDir, "call-filter", Desc[2], RepTypes[2]);
                localBam(chipDir, "call-filter_ctl", Desc[2], RepTypes[3]);
            } else {
                // local bam files, not fastq used in pipeline
            }
            
            int quwegf = 0;
        }
        int isudhf = 0;
    }

    final public void localBam(File chipDir, String bamStr, String desc, String repType) throws Exception {
        System.out.printf("chipDir=%s\n", chipDir.getPath());
        File bamDir = new File(chipDir, bamStr);
        System.out.printf("bamDir=%s\n", bamDir.getPath());
        int rep = 1;
        for (File shardDir : bamDir.listFiles()) {
            File exeDir = new File(shardDir, "execution");
            for (File bam : exeDir.listFiles()) {
                if (bam.getName().endsWith(".bam")) {
                    int sz = (int) (bam.length() / 1000000.0);
                    addToMap(new FileTableRecord(
                            bam.toURI().toURL(), bam.getName(), Formats[2], desc, String.format("rep%d", rep), repType, sz, Units[3]));
                    ++rep;
                }
            }
        }
    }

    static public File EpicDirectory(ChipExperiment exp) {
        Directory dir = new Directory();
        File epic = null;
        if (exp.getSpecies().equals("Dmel")) {
            epic = new File(dir.getFlyEpicDirectory());
        } else {
            epic = new File(dir.getWormEpicDirectory());
        }
        return new File(epic, exp.getExpId());
    }

    public File getMetadataFile() {
        String json = "metadata.json";
        if (this.chipDir != null) {
            return new File(chipDir, json);
        } else {
            return new File(tableFile.getParentFile(), json);
        }
    }

    final public void localFastq(Map<Integer, Map<Integer, List<ChipSequencingFile>>> repMap,
            String format, String desc, String assembly, String repType) throws Exception {
        for (Integer rep : repMap.keySet()) {
            Map<Integer, List<ChipSequencingFile>> readMap = repMap.get(rep);
            for (Integer read : readMap.keySet()) {
                List<ChipSequencingFile> list = readMap.get(read);
                for (ChipSequencingFile seqFile : list) {
                    URL url = new File(seqFile.getLocalFilePath()).toURI().toURL();
                    int sz = (int) (seqFile.getFileSize() / 1000000.0);
                    String name = new File(seqFile.getLocalFilePath()).getName();
                    addToMap(new FileTableRecord(url, name, format, desc, String.format("rep%d", rep), repType, sz, Units[3]));
                }
            }
        }
    }

    final public void filesByAccession(Experiment exp, String format, String desc, String assembly, String repType) throws Exception {

        TreeMap<Integer, List<DCCFile>> fileMap = new TreeMap<>();
        List<DCCFile> files = exp.getFiles(format, assembly);
        for (DCCFile file : files) {
            List<DCCFile> list = fileMap.get(file.getReplicate());
            if (list == null) {
                list = new ArrayList<>();
                fileMap.put(file.getReplicate(), list);
            }
            list.add(file);
        }
        int rep = 1;
        for (List<DCCFile> fileList : fileMap.values()) {
            for (DCCFile file : fileList) {
                URL url = new URL(file.getDownloadURL());
                addToMap(new FileTableRecord(url, file.getName(), format, desc, String.format("rep%d", rep), repType, file.getSize(), Units[3]));
            }
            ++rep;
        }
    }

    final public void signal_track(String trackDir, boolean shard) throws Exception {
        File sigDir = new File(chipDir, trackDir);
        if (shard) {
            for (File shardDir : sigDir.listFiles()) {
                processSignalShard(shardDir);
            }
        } else {
            processSignalShard(sigDir);
        }
    }

    public void processSignalShard(File shardDir) throws Exception {

        File exeDir = new File(shardDir, "execution");
        if (!processSignalShardAttempt(exeDir)) {
            exeDir = new File(new File(shardDir, "attempt-2"), "execution");
            processSignalShardAttempt(exeDir);
        }
    }

    public boolean processSignalShardAttempt(File attemptDir) throws Exception {
        FileTableRecord fcRec = null;
        FileTableRecord pvRec = null;
        for (File file : attemptDir.listFiles()) {
            String name = file.getName();
            if (name.endsWith(".fc.signal.bigwig")) {
                fcRec = new FileTableRecord(file, Formats[4], Desc[5], signalNameRep(name), RepTypes[1], fileSize(file), Units[3]);
            } else if (name.endsWith(".pval.signal.bigwig")) {
                pvRec = new FileTableRecord(file, Formats[4], Desc[4], signalNameRep(name), RepTypes[1], fileSize(file), Units[3]);
            }
        }
        boolean ret = (fcRec != null) && (pvRec != null);
        if (ret) {
            addToMap(fcRec);
            addToMap(pvRec);
        }
        return ret;
    }

    public String signalNameRep(String name) {
        String rep = "pooled";
        if (!name.contains(rep)) {
            String[] tokens = name.split("_|\\.");
            rep = tokens[tokens.length - 4];
        }
        return rep;
    }

    final public void setOptimalConserve(String format, String desc) {
        // get the pooled 
        FileTableRecord pooled = map.get(desc).get("pseudo").get(format).get("pool_vs_pool").get(0);

        // find the best true rep
        TreeMap<String, List<FileTableRecord>> trueReps = map.get(desc).get("true").get(format);
        int maxSize = 0;
        FileTableRecord best = null;
        for (String rep : trueReps.keySet()) {
            List<FileTableRecord> recList = trueReps.get(rep);
            FileTableRecord rec = recList.get(0);
            if (rec.size > maxSize) {
                maxSize = rec.size;
                best = rec;
            }
        }

        if (pooled.size > best.size) {
            pooled.setOptimal("*");
            best.setConservative("*");
        } else {
            best.setOptimal("*");
            best.setConservative("*");
        }
    }

    final public void call_overlap_pr(File chipDir) throws Exception {
        File pseudoRepDir = new File(chipDir, "call-overlap_pr");
        for (File shardDir : pseudoRepDir.listFiles()) {
            processShard(shardDir, RepTypes[0], Desc[0]);
        }
    }

    final public void call_idr_pr(File chipDir) throws Exception {
        File pseudoRepDir = new File(chipDir, "call-idr_pr");
        for (File shardDir : pseudoRepDir.listFiles()) {
            processShard(shardDir, RepTypes[0], Desc[1]);
        }
    }

    final public void call_overlap(File chipDir) throws Exception {
        File trueRepDir = new File(chipDir, "call-overlap");
        for (File shardDir : trueRepDir.listFiles()) {
            processShard(shardDir, RepTypes[1], Desc[0]);
        }
    }

    final public void call_idr(File chipDir) throws Exception {
        File trueRepDir = new File(chipDir, "call-idr");
        for (File shardDir : trueRepDir.listFiles()) {
            processShard(shardDir, RepTypes[1], Desc[1]);
        }
    }

    final public void processShard(File shardDir, String repType, String desc) throws Exception {

        File bfilt = null;
        File bigBed = null;
        File exeDir = new File(shardDir, "execution");
        for (File file : exeDir.listFiles()) {
            String name = file.getName();
            if (name.endsWith(".bfilt.regionPeak.bb")) {
                bigBed = file;
            } else if (name.endsWith(".bfilt.regionPeak.gz")) {
                bfilt = file;
            }
        }
        String reps = bigBed.getName().split("\\.")[0];
        if (reps.contains("pr")) {
            String rep = reps.split("\\-")[0];
            reps = String.format("%s_vs_%s", rep, rep);
        }
        if (reps.contains("pooled")) {
            reps = "pool_vs_pool";
        }

        // do the bigBed
        addToMap(new FileTableRecord(bigBed, Formats[1], desc, reps, repType, gzRecordCount(bfilt), Units[0]));

        // do the  bed    
        addToMap(new FileTableRecord(bfilt, Formats[0], desc, reps, repType, gzRecordCount(bfilt), Units[0]));
    }

    public void addToMap(FileTableRecord rec) {

        TreeMap<String, TreeMap<String, TreeMap<String, List<FileTableRecord>>>> typeMap = map.get(rec.desc);
        if (typeMap == null) {
            typeMap = new TreeMap<>();
            map.put(rec.desc, typeMap);
        }

        TreeMap<String, TreeMap<String, List<FileTableRecord>>> repTypeMap = typeMap.get(rec.replicateType);
        if (repTypeMap == null) {
            repTypeMap = new TreeMap<>();
            typeMap.put(rec.replicateType, repTypeMap);
        }

        TreeMap<String, List<FileTableRecord>> formatMap = repTypeMap.get(rec.format);
        if (formatMap == null) {
            formatMap = new TreeMap<>();
            repTypeMap.put(rec.format, formatMap);
        }
        List<FileTableRecord> list = formatMap.get(rec.replicates);
        if (list == null) {
            list = new ArrayList<>();
            formatMap.put(rec.replicates, list);
        }
        list.add(rec);
    }

    public static int gzRecordCount(File gzFile) throws Exception {
        int count;
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new GZIPInputStream(new FileInputStream(gzFile))))) {
            String line = reader.readLine();
            count = 0;
            while (line != null) {
                ++count;
                line = reader.readLine();
            }
        }
        return count;
    }

    public int fileSize(File file) throws Exception {
        String up = "BXTSKHIS:vwhzube43dekyyc6";
        URI uri = file.toURI();
        return (int) (file.toURI().toURL().openConnection().getContentLengthLong() / 1000000.0);
    }

    public void report(PrintStream stream) {
        stream.println(new FileTableRecord().reportHead());
        for (FileTableRecord r : this.getRecords()) {
            stream.println(r.report());
        }
    }

    public String getOptimalPeakFile() {
        for (FileTableRecord rec : getOptimalPeakRecords()) {
            if (rec.format.equals("bed")) {
                return rec.source.getPath();
            }
        }
        return null;
    }

    public ArrayList<FileTableRecord> getOptimalPeakRecords() {
        ArrayList<FileTableRecord> ret = new ArrayList<>();
        for (FileTableRecord rec : getRecords()) {
            if (rec.optimal.equals("*")) {
                ret.add(rec);
            }
        }
        return ret;
    }

    public ArrayList<FileTableRecord> getRecords() {
        ArrayList<FileTableRecord> records = new ArrayList<>();
        for (String desc : map.keySet()) {
            TreeMap<String, TreeMap<String, TreeMap<String, List<FileTableRecord>>>> outTypeMap = map.get(desc);
            for (String repType : outTypeMap.keySet()) {
                TreeMap<String, TreeMap<String, List<FileTableRecord>>> repTypeMap = outTypeMap.get(repType);
                for (String format : repTypeMap.keySet()) {
                    TreeMap<String, List<FileTableRecord>> repMap = repTypeMap.get(format);
                    for (String rep : repMap.keySet()) {
                        List<FileTableRecord> list = repMap.get(rep);
                        for (FileTableRecord rec : list) {
                            records.add(rec);
                        }
                    }
                }
            }
        }
        return records;
    }

    // gets records, if any input is null, gets all the records for that input
    public ArrayList<FileTableRecord> getRecords(String inDesc, String inRepType, String inFormat, String inRep) {
        ArrayList<FileTableRecord> records = new ArrayList<>();
        for (String desc : map.keySet()) {
            if (inDesc == null || inDesc.equals(desc)) {
                TreeMap<String, TreeMap<String, TreeMap<String, List<FileTableRecord>>>> outTypeMap = map.get(desc);
                for (String repType : outTypeMap.keySet()) {
                    if (inRepType == null || inRepType.equals(repType)) {
                        TreeMap<String, TreeMap<String, List<FileTableRecord>>> repTypeMap = outTypeMap.get(repType);
                        for (String format : repTypeMap.keySet()) {
                            if (inFormat == null || inFormat.equals(format)) {
                                TreeMap<String, List<FileTableRecord>> repMap = repTypeMap.get(format);
                                for (String rep : repMap.keySet()) {
                                    if (inRep == null || inRep.equals(rep)) {
                                        List<FileTableRecord> list = repMap.get(rep);
                                        for (FileTableRecord rec : list) {
                                            records.add(rec);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return records;
    }

    public static void main(String[] args) throws Exception {

        String expID = "elt-3_OP75_L3larva_1";
        String runID = "9df8238c-efe2-4d51-b9ca-84c1fb55e6d4";
        String acc = "ENCSR962VUP";
        /*
        String expID = "aptf-3_OP765_youngadult_1";
        String runID = "3584a201-0b32-4b09-a44d-5e4425d94c61";
        String acc = "ENCSR873YHI";
         */
        int yu = 0;
        FileTable table = new FileTable(new File("/net/waterston/vol6/nhr-85_OP539_L1larva_1.table.tsv"));
        for (FileTableRecord rec : table.getRecords()) {
            rec.asExternalURL();
        }
        ArrayList<FileTableRecord> rec = table.getRecords();

        table.report(System.out);
        HibernateUtil.shutdown();
    }

    static String[] Formats = {"bed", "bigBed", "bam", "fastq", "bigWig"};
    static String[] Desc
            = {"Overlap", "IDR", "alignment filtered", "alignment", "signal-p", "fold change over control", "sequence"};
    static String[] RepTypes = {"pseudo", "true", "IP", "control"};
    static String[] Units = {"peaks", "reads", "alignments", "Mbytes"};
}
