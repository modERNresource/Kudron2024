/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.qa;

import org.apache.commons.math3.ml.distance.DistanceMeasure;
import org.apache.commons.math3.stat.correlation.SpearmansCorrelation;

/**
 *
 * @author gevirl
 */
public class Spearmans implements DistanceMeasure {

    @Override
    public double compute(double[] a, double[] b) {
        return spear.correlation(a, b);
    }
    static SpearmansCorrelation spear = new SpearmansCorrelation();
}
