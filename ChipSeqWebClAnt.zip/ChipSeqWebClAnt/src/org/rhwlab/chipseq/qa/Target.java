/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.qa;

import java.io.PrintStream;

/**
 *
 * @author gevirl
 */
public class Target extends ChipExpGene {
    Double signalValue = null;
    Double qValue = null;
    Integer clusterSize = null;

    public Target(String[] tokens) {
        super(limitArray(tokens,3),null,null);

        if (tokens.length >= 4 && !tokens[3].equals("NA")) {
            setDistance(Double.valueOf(tokens[3]));
        }
        if (tokens.length >= 5 && !tokens[4].equals("NA")) {
            signalValue = Double.valueOf(tokens[4]);
        }
        if (tokens.length >= 6 && !tokens[5].equals("NA")) {
            qValue = Double.valueOf(tokens[5]);
        }
        if (tokens.length >= 7 && !tokens[6].equals("NA")) {
            clusterSize = Integer.valueOf(tokens[6]);
        }
        if (tokens.length >= 8 && !tokens[7].equals("NA")) {
            setExperiment(tokens[7]);
        }
    }

    public Target(String[] tokens, Double signalValue, Double qValue, Integer clusterSize,String exp) {
        super(limitArray(tokens,3));
        this.signalValue = signalValue;
        this.qValue = qValue;
        this.clusterSize = clusterSize;
        this.experiment = exp;
    }

    static String[] limitArray(String[] in,int limit){
        if (in.length == limit) return in;
        String[] ret = new String[3];
        for (int i=0 ; i<limit ; ++i){
            ret[i] = in[i];
        }
        return ret;
    }
    static void printHeading(PrintStream stream){
        stream.println("Sequence,Common,WBGene,Distance,SignalValue,QValue,ClusterSize,Experiment");
    }
    public void print(PrintStream stream) {
        stream.printf("%s,%s,%s", sequence, gene, wbGene);
        printDouble(distance, stream);
        printDouble(signalValue, stream);
        printDouble(qValue, stream);
        printInteger(clusterSize, stream);
        printString(experiment,stream);
        stream.println();
    }
    private void printInteger(Integer i, PrintStream stream) {
        if (i == null) {
            stream.print(",NA");
        } else {
            stream.printf(",%d", i);
        }
    }

    public Double getSignalValue() {
        return signalValue;
    }
}
