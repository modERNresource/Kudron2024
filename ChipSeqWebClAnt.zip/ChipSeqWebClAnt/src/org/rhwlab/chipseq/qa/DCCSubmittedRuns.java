/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.qa;

import java.io.File;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import org.rhwlab.chipseq.PeakClusters;
import org.rhwlab.chipseq.PeakFile;
import org.rhwlab.chipseq.PeakTargetQuality;
import static org.rhwlab.chipseq.PeakTargetQuality.peakFileQuality;
import org.rhwlab.chipseq.pipeline.PipelineRun;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipHelper;
import org.rhwlab.chipseqweb.ChipRun;
import org.rhwlab.chipseqweb.HibernateUtil;
import org.rhwlab.chipseqweb.commandline.PipelineFiles;
import org.rhwlab.gene.model.Annotation;
import org.rhwlab.gene.model.GeneIntervals;
import org.rhwlab.gene.model.ModelFromGFF;
import org.rhwlab.singlecell.expression.PrefixMaps;
import org.rhwlab.singlecell.expression.SingleCellExprMat;

/**
 *
 * @author gevirl
 */
public class DCCSubmittedRuns {

    public DCCSubmittedRuns() {

    }
    // all the pipeline runs marked for DCC submission for the species
    static public List<PeakFile> idrOptimalPeakFiles(String species) throws Exception {
        List<PeakFile> ret = new ArrayList<>();
        for (Object expObj : ChipHelper.allExperiments(species)) {
            ChipExperiment exp = (ChipExperiment) expObj;

            for (Object runObj : ChipHelper.getEquals("ChipRun", "ExpID", exp.getExpId(), "SubmitID")) {
                ChipRun run = (ChipRun) runObj;
                if (run.getMarkedForDcc() != null) {
                    File bb = PipelineRun.idrOptimalPeakFile(run);
                    ret.add(new PeakFile(bb, exp.getGene(), "chr", exp.getStage()));
                }
            }
        }
        return ret;
    }

    // return all the ChipRuns that have been marked for DCC submission
    static public List<ChipRun> markedForDCCSubmission(String species) throws Exception {
        ArrayList<ChipRun> ret = new ArrayList<>();

        for (Object expObj : ChipHelper.allExperiments(species)) {
            ChipExperiment exp = (ChipExperiment) expObj;

            for (Object runObj : ChipHelper.getEquals("ChipRun", "ExpID", exp.getExpId(), "SubmitID")) {
                ChipRun run = (ChipRun) runObj;
                if (run.getMarkedForDcc() != null) {
                    ret.add(run);
                }
            }
        }
        return ret;
    }

    static public void makeClustersForAllPeakFiles() throws Exception {
        int[] deltas = {50, 100, 200};
//        ModelFromGFF gff3 = new ModelFromGFF(new File("/net/waterston/vol9/References/WS245/AllWormBase.withTransposon.gff3"));
        ModelFromGFF gff3 = new ModelFromGFF(new File("/net/waterston/vol9/References/WS260/c_elegans.PRJNA13758.WS260.annotations.WormBase.gff3"));
        List<PeakFile> peakFiles = idrOptimalPeakFiles("CElegans");
        peakFiles.addAll(PeakClusters.PeakFiles(new File("/net/waterston/vol2/home/gevirl/ChipSeqPeaks/worm/ce11"), ""));

        for (int delta : deltas) {
            PeakClusters clusters = new PeakClusters(peakFiles, delta);
            clusters.locateInGenome(gff3,null);
            clusters.report(new File(String.format("/net/waterston/vol9/ChipSeqPipeline/peakClusters.%d", delta)));
        }
        HibernateUtil.shutdown();
    }


}
