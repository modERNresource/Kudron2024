/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.qa;

import java.util.Arrays;
import java.util.TreeMap;

/**
 *
 * @author gevirl
 */
public class MyMannWhitney {

    Element[] a;
    TreeMap<String, Integer> map = new TreeMap<>();

    public MyMannWhitney(String xLabel, double[] x, String yLabel, double[] y) {
        a = new Element[x.length + y.length];
        int n = 0;
        for (int i = 0; i < x.length; ++i) {
            a[n] = new Element(xLabel, x[i]);
            ++n;
        }
        for (int i = 0; i < y.length; ++i) {
            a[n] = new Element(yLabel, y[i]);
            ++n;
        }
        Arrays.parallelSort(a);
        map.put(xLabel, x.length);
        map.put(yLabel, y.length);
    }

    public double calc(String label) {
        double sum = 0.0;
        int curr = 0;

        while (curr < a.length) {
            // find the group of equal values
            int next = curr + 1;
            int rSum = curr;
            if (next != a.length) {
                while (a[curr].value == a[next].value) {
                    rSum = rSum + next;
                    ++next;
                    if (next == a.length) {
                        break;
                    }
                }
            }
            double delta = next - curr;
            double grpAvg = (rSum / delta) + 1.0;

            // add the group appropriate group values
            for (int g = curr; g < next; ++g) {
                if (a[g].label.equals(label)) {
                    sum = sum + grpAvg;
                }
            }
            curr = next;
        }
        int n = map.get(label);
        return sum - (n * (n + 1)) / 2.0;
    }

    public class Element implements Comparable {

        double value;
        double rank;
        String label;

        public Element(String l, double v) {
            label = l;
            value = v;
        }

        @Override
        public int compareTo(Object o) {
            return Double.compare(value, ((Element) o).value);
        }

    }


}
