/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.qa;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import org.apache.commons.math3.ml.distance.DistanceMeasure;
import org.rhwlab.singlecell.expression.PrefixMaps;
import org.rhwlab.singlecell.expression.SingleCellExprMat;
import org.rhwlab.tfs.TFResourceFile;

/**
 *
 * @author gevirl
 */
// based on single cell expression
// matrix of gene by tf expression distance
public class DistanceMatrix {

    File csv;
    String[] heads;
    TreeMap<String, double[]> geneMap = new TreeMap<>();
    static TFResourceFile tfFile = new TFResourceFile("/org/rhwlab/tfs/allTFs.tsv");

    public DistanceMatrix(File csv) throws Exception {
        this.csv = csv;
        BufferedReader reader = new BufferedReader(new FileReader(csv));
        String line = reader.readLine(); // read the header
        heads = line.split(",");
        line = reader.readLine();
        while (line != null) {
            String[] tokens = line.split(",");
            double[] vals = new double[tokens.length - 1];
            for (int i = 0; i < vals.length; ++i) {
                vals[i] = Double.valueOf(tokens[i + 1]);
            }
            geneMap.put(tokens[0], vals);
            line = reader.readLine();
        }
        reader.close();

    }

    private int tfIndex(String tf) throws Exception {
        String wbGene = tf;
        if (!tf.startsWith("WBGene")) {
            wbGene = wbGene(tf);
        }

        int tfIndex = -1;
        for (int h = 1; h < heads.length; ++h) {
            if (heads[h].equals(wbGene)) {
                tfIndex = h - 1;
                break;
            }
        }
        return tfIndex;
    }

    static public String wbGene(String tf) throws Exception {
        String wbGene = tf;
        if (!tf.startsWith("WBGene")) {
            wbGene = tfFile.getWBGene(tf);
        }
        return wbGene;
    }

    public String[] getHeads() {
        return heads;
    }

    public TreeMap<String, double[]> getGeneMap() {
        return geneMap;
    }

    // set the distance value in each target of this set
    public void setTargetDistance(ChipSeqTargets targets, String tf) throws Exception {
        int tfIndex = tfIndex(tf);
        if (tfIndex == -1) {
            return;
        }
        for (Target target : targets.getTargets()) {
            String wbGene = target.getWBGene();
            double[] v = geneMap.get(wbGene);
            if (v != null) {
                target.setDistance(v[tfIndex]);
            }
        }
    }

    // return the list of genes not in thegiven gene set
    public List<String> complementSet(List<String> geneSet) {
        ArrayList<String> ret = new ArrayList<>();
        for (String wbGene : this.geneMap.keySet()) {
            double[] v = geneMap.get(wbGene);
            if (!geneSet.contains(wbGene)) {
                ret.add(wbGene);
            }
        }
        return ret;
    }

    static public String convertScore(TreeMap<String, Object> mw) {
        return convertScore((Double) mw.get("Unorm"));
    }

    static public String convertScore(String score) {
        return convertScore(Double.valueOf(score));
    }

    static public String convertScore(Double score) {
        return String.format("%f", mwNormal(score));
    }

    static double mwNormal(double score) {
        return (score - 0.5) * 200.0;
    }

    public Double[] scoreIntervals(ChipSeqTargets targets, String tf, int[] intervals) throws Exception {
        Double[] ret = new Double[intervals.length];

        List<String> nonTargetList = complementSet(targets.wbGeneList());
        List<ChipSeqTargets> sets = targets.targetsClusterSizeIntervals(intervals);

        for (int i = 0; i < ret.length; ++i) {
            if (sets.get(i).getTargets().isEmpty()) {
                ret[i] = null;
            } else {
                List<String> targetList = sets.get(i).wbGeneList();
                TreeMap<String, Object> mw = this.scoreMannWhitney(targetList, nonTargetList, tf);
                if (mw == null) {
                    return null;
                }
                ret[i] = mwNormal((Double) mw.get("Unorm"));
            }
        }
        return ret;
    }

    public Double[] scoreTargetSets(String tf, List<ChipSeqTargets> sets, List<String> nonTargetList) throws Exception {
        Double[] ret = new Double[sets.size()];
        for (int i = 0; i < ret.length; ++i) {
            if (sets.get(i).getTargets().isEmpty()) {
                ret[i] = null;
            } else {
                List<String> targetList = sets.get(i).wbGeneList();
                TreeMap<String, Object> mw = this.scoreMannWhitney(targetList, nonTargetList, tf);
                if (mw == null) {
                    return null;
                }
                ret[i] = mwNormal((Double) mw.get("Unorm"));
            }
        }
        return ret;
    }

    public double[][] scoreCurve(ChipSeqTargets targets, String tf, int nBins) throws Exception {

        List<String> nonTargetList = complementSet(targets.wbGeneList());

        // divide the targets into bins, sorted by scoreValue
        List<ChipSeqTargets> sets = targets.divideTargets(nBins);
        double[][] ret = new double[sets.size()][];
        int i = 0;
        for (ChipSeqTargets set : sets) {
            ret[i] = new double[2];
            ret[i][0] = set.averageSignalValue();
            List<String> targetList = set.wbGeneList();
            TreeMap<String, Object> mw = this.scoreMannWhitney(targetList, nonTargetList, tf);
            ret[i][1] = mwNormal((Double) mw.get("Unorm"));
            ++i;
        }
        return ret;
    }

    public double[] getDistances(List<String> wbGenes, String tf) throws Exception {
        int tfIndex = tfIndex(tf);
        if (tfIndex == -1) {
            return null;
        }

        ArrayList<Double> xL = new ArrayList<>();
        for (String wbGene : wbGenes) {
            double[] v = geneMap.get(wbGene);
            if (v != null) {
                xL.add(Math.abs(v[tfIndex]));
            }
        }

        double[] x = new double[xL.size()];
        int ix = 0;
        for (Double X : xL) {
            x[ix] = X;
            ++ix;
        }
        return x;
    }

    public Double[] getAllDistance(List<String> wbGenes, String tf) throws Exception {
        int tfIndex = tfIndex(tf);
        if (tfIndex == -1) {
            return null;
        }
        Double[] ret = new Double[wbGenes.size()];
        int i = 0;
        for (String wbGene : wbGenes) {
            double[] v = geneMap.get(wbGene);
            if (v != null) {
                ret[i] = Double.valueOf(Math.abs(v[tfIndex]));
            } else {
                ret[i] = null;
            }
            ++i;
        }
        return ret;
    }

    public TreeMap<String, Object> scoreMannWhitney(List<String> geneSet, String tf) throws Exception {
        return scoreMannWhitney(geneSet, complementSet(geneSet), tf);
    }

    public TreeMap<String, Object> scoreMannWhitney(List<String> setX, List<String> setY, String tf) throws Exception {

        TreeMap<String, Object> ret = new TreeMap<>();
        double[] x = getDistances(setX, tf);
        double[] y = getDistances(setY, tf);

        MyMannWhitney mann = new MyMannWhitney("Targets", x, "NonTargets", y);
        double UTargets = mann.calc("Targets");
        double maxU = ((double) x.length) * ((double) y.length);
        double uNon = maxU - UTargets;
        double uNorm = UTargets / maxU;
        ret.put("Unorm", uNorm);
        ret.put("UTargets", UTargets);
        ret.put("Targets", x.length);
        ret.put("NonTargets", y.length);
        ret.put("UNonTargets", uNon);
        return ret;
    }

    // make a file of gene by TF based on the distance measure (measures distance from each gene to each TF)
    static public void geneByTF(TreeMap<String, double[]> geneMap, File outFile, DistanceMeasure meas) throws Exception {
        TFResourceFile tfFile = new TFResourceFile("/org/rhwlab/tfs/allTFs.tsv");

        // make the tf map
        TreeMap<String, double[]> tfMap = new TreeMap<>();
        for (String tf : tfFile.asWBGene()) {
            double[] values = geneMap.get(tf);
            if (values != null) {
                if (!allZero(values)) {
                    tfMap.put(tf, values);
                }
            }
        }

        PrintStream stream = new PrintStream(outFile);
        stream.print("Gene");
        for (String tf : tfMap.keySet()) {
            stream.printf(",%s", tf);
        }
        stream.println();

        for (String gene : geneMap.keySet()) {
            double[] expr = geneMap.get(gene);
            if (!allZero(expr)) {
                stream.printf("%s", gene);
                for (String tf : tfMap.keySet()) {
                    double[] tfExpr = tfMap.get(tf);
                    boolean[] use = nonZero(tfExpr);
                    double[] tfExprRed = reduce(tfExpr, use);
                    double[] exprRed = reduce(expr, use);

                    if (tfExprRed.length == 1) {
                        if (exprRed[0] > 0.0){
                            stream.print(",1.0");
                        } else {
                            stream.print(",0.0");
                        }
                    } else {
                        double d = meas.compute(exprRed, tfExprRed);
                        if (Double.isNaN(d)) {
                            // report any NaN for qa
                            System.out.println("NaN");
                        }
                        stream.printf(",%f", d);
                    }
                }
                stream.println();
            }
        }
        stream.close();
    }

    static private boolean allZero(double[] a) {
        for (double v : a) {
            if (v != 0.0) {
                return false;
            }
        }
        return true;
    }

    static boolean[] nonZero(double[] v) {
        boolean[] ret = new boolean[v.length];
        for (int i = 0; i < v.length; ++i) {
            ret[i] = v[i] > 0.0;
        }
        return ret;
    }

    static double[] reduce(double[] v, boolean[] b) {
        int n = 0;
        for (int i = 0; i < b.length; ++i) {
            if (b[i]) {
                ++n;
            }
        }
        if (n == 1) {
            int aisodhfioash = 0;
        }
        double[] ret = new double[n];
        int r = 0;
        for (int i = 0; i < v.length; ++i) {
            if (b[i]) {
                ret[r] = v[i];
                ++r;
            }
        }
        return ret;
    }

    // Outputs a distance matrix from an input gene,cellType expression matrix(.gz file)
    // Distance is from each gene to each TF
    // Computes some statistic on the distance matrix to output a second file (.stats file) 
    static public void main(String[] args) throws Exception {
        new PrefixMaps();
        for (String prefix : PrefixMaps.exprMatrixMap.keySet()) {

            File distFile = PrefixMaps.distMatrixMap.get(prefix);
            File signedDistFile = PrefixMaps.signdistMatrixMap.get(prefix);

            SingleCellExprMat expMat = PrefixMaps.getWormExpressionMatrices().get(prefix);
            DistanceMatrix.geneByTF(expMat.getGeneMap(), distFile, new AbsSpearmans());
            DistanceMatrix.geneByTF(expMat.getGeneMap(), signedDistFile, new Spearmans());

        }
    }

}
