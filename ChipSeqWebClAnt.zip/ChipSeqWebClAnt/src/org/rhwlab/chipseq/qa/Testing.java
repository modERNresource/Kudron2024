/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.qa;

import java.io.File;
import java.util.List;
import java.util.TreeMap;

/**
 *
 * @author gevirl
 */
public class Testing {
    static public void main(String[] args)throws Exception{
        ChipSeqTargets targets = new ChipSeqTargets(new File("/nfs/waterston/idr.optimal_peak.regionPeak.targets"));
        DistanceMatrix mat = new DistanceMatrix(new File("/nfs/waterston/L2_S14_geneByTF_SignSpearmans"));
        List<String> wbGeneTargets = targets.wbGeneList();
        String tf = "WBGene00001194";
        TreeMap<String, Object> mw = mat.scoreMannWhitney(wbGeneTargets, tf);
        double[][] x = mat.scoreCurve(targets, tf, 20);
        int ukhasdiufh=0;
    }
}
