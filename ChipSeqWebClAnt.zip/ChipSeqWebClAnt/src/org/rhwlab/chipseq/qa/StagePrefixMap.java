/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.qa;

import java.util.TreeMap;

/**
 *
 * @author gevirl
 */
public class StagePrefixMap {
    public String getPrefix(String stage){
        return stageMap.get(stage);
    }

    final static TreeMap<String, String> stageMap = new TreeMap<>();

    static {
        stageMap.put("earlyembryonic", "Emb");
        stageMap.put("midembryonic", "Emb");
        stageMap.put("lateembryonic", "Emb");
        stageMap.put("mixedstage", "Emb");
        stageMap.put("L1larva", "L2");
        stageMap.put("L2larva", "L2");
        stageMap.put("L3larva", "L2");
        stageMap.put("L4larva", "L2");
        stageMap.put("L4_youngadult", "L2");
        stageMap.put("youngadult", "");
        stageMap.put("dauer", "");
        
        stageMap.put("L1", "L2");
        stageMap.put("L2", "L2");
        stageMap.put("L3", "L2");
        stageMap.put("L4", "L2");  
        stageMap.put("Em", "Emb");
        stageMap.put("LE", "Emb");
        stageMap.put("EM", "Emb");
    }    
}
