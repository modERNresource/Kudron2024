/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.dcc;

import java.io.File;
import java.io.PrintStream;
import java.nio.file.Files;
import org.rhwlab.chipseq.qa.Directories;
import org.rhwlab.chipseqweb.ChipHelper;
import org.rhwlab.chipseqweb.ChipRun;
import org.rhwlab.chipseqweb.HibernateUtil;

/**
 *
 * @author gevirl
 */
public class SubmitAnalyses {

    public static void submitAnalysisScript(File expDir,String chipID) throws Exception {
        File submitAnalysisFile = new File(expDir, "submitAnalysis.sh");
        File accDir = new File(expDir, "accession");
        File chipDir = new File(expDir, "chip");
        File runDir = new File(chipDir, chipID);
        PrintStream accStream = new PrintStream(submitAnalysisFile);
        accStream.println("export DCC_API_KEY=BXTSKHIS");
        accStream.println("export DCC_SECRET_KEY=vwhzube43dekyyc6");
        accStream.println("export DCC_LAB=/labs/robert-waterston");
        accStream.println("export DCC_AWARD=U41HG007355");
        accStream.printf("cd %s\n", accDir.getPath());
        accStream.printf("accession -f -m %s/metadata.json --pipeline-type tf_chip_bwa_control_fastqs -s prod\n", runDir.getPath());
        accStream.close();
    }

    public static void main(String[] args) throws Exception {
        File flyAnalyses = new File(Directories.sourceDir, "flyAnalyses.sh");
        PrintStream flyStream = new PrintStream(flyAnalyses);
        File wormAnalyses = new File(Directories.sourceDir, "wormAnalyses.sh");
        PrintStream wormStream = new PrintStream(wormAnalyses);

        PrintStream stream = null;
        for (Object runObj : ChipHelper.getAll("ChipRun", "SubmitID")) {
            ChipRun chipRun = (ChipRun) runObj;
            if (chipRun.getMarkedForDcc() != null) {
                if (chipRun.getChipId() != null) {
                    File expDir = new File(Directories.sourceDir, chipRun.getExpId());
                    String alias = String.format("robert-waterston:%s", chipRun.getChipId());
                    File analysisAliasFile = new File(expDir, "analysisAlias");
                    PrintStream aliasStream = new PrintStream(analysisAliasFile);
                    aliasStream.println(alias);
                    aliasStream.close();

                    // check if analysis in DCC
                    File checkAnalysisScript = new File(expDir, "checkAnalysis.sh");

                    PrintStream checkAnalysisStream = new PrintStream(checkAnalysisScript);
                    SubmitDCC.checkAnalysis(checkAnalysisStream, analysisAliasFile);
                    checkAnalysisStream.close();
                    checkAnalysisScript.setExecutable(true, false);

                    Process process = Runtime.getRuntime().exec(checkAnalysisScript.getPath());
                    process.waitFor();

                    // check if the analysis notposted has an entry
                    File notPostedFile = new File(expDir, "analysisNotPosted");
                    if (notPostedFile.length() > 0) {
                        if (chipRun.getSpecies().equals("Dmel")) {
                            stream = flyStream;
                        } else {
                            stream = wormStream;
                        }

                        // write the submit analysis file
                        File accDir = new File(expDir, "accession");
                        if (!accDir.exists()) {
                            Files.createDirectories(accDir.toPath());
                        }
                        File chipDir = new File(expDir, "chip");
                        File runDir = new File(chipDir, chipRun.getChipId());
                        File submitAnalysisFile = new File(expDir, "submitAnalysis.sh");
                        PrintStream accStream = new PrintStream(submitAnalysisFile);
                        accStream.println("export DCC_API_KEY=BXTSKHIS");
                        accStream.println("export DCC_SECRET_KEY=vwhzube43dekyyc6");
                        accStream.println("export DCC_LAB=/labs/robert-waterston");
                        accStream.println("export DCC_AWARD=U41HG007355");
                        accStream.printf("cd %s\n", accDir.getPath());
                        accStream.printf("accession -f -m %s/metadata.json --pipeline-type tf_chip_bwa_control_fastqs -s prod\n", runDir.getPath());
                        accStream.close();
                        stream.printf("source %s\n", new File(expDir, "submitAnalysis.sh").getPath());
                    }
                }
            }
        }
        flyStream.close();
        wormStream.close();
        HibernateUtil.shutdown();
    }
}
