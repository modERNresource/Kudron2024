/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.dcc;

import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipRun;
import org.rhwlab.chipseqweb.ChipSequencingFile;
import org.rhwlab.lang.Greek;
import org.rhwlab.lang.GreekPlus;

/**
 *
 * @author gevirl
 */
public class Aliases {


    public static String analysisAlias(ChipRun run){
        return String.format("robert-waterston:%s", run.getChipId());
    }
    public static String characterizationAlias(String type, ChipExperiment exp, int rep) {
        return String.format("%s_jpg", biosampleAlias(type, exp, rep));
    }

    public static String fileAlias(ChipSequencingFile file) {
        return String.format("valerie-reinke:%s_fastq", file.getFileId());
    }

    public static String ipReplicateAlias(ChipExperiment exp, int rep) {
        return String.format("%s_rep", ipBiosampleAlias(exp, rep));
    }

    public static String ctlReplicateAlias(ChipExperiment exp, int rep) {
        return String.format("%s_rep", ctlBiosampleAlias(exp, rep));
    }

    public static String ipLibraryAlias(ChipExperiment exp, int rep) {
        return String.format("%s_lib", ipBiosampleAlias(exp, rep));
    }

    public static String ctlLibraryAlias(ChipExperiment exp, int rep) {
        return String.format("%s_lib", ctlBiosampleAlias(exp, rep));
    }

    public static String biosampleAlias(String fileType, ChipExperiment exp, int rep) {
        if (fileType.contains("ctl")) {
            return ctlBiosampleAlias(exp, rep);
        } else {
            return ipBiosampleAlias(exp, rep);
        }
    }

    public static String ipBiosampleAlias(ChipExperiment exp, int rep) {
        return String.format("%s_%d", ipExperimentAlias(exp), rep);
    }

    public static String ctlBiosampleAlias(ChipExperiment exp, int rep) {
        return String.format("%s_%d", ctlExperimentAlias(exp), rep);
    }

    public static String ipExperimentAlias(ChipExperiment exp) {
        return ipExperimentAlias(exp.getSpecies(),exp.getExpId());
    }

    public static String ipExperimentAlias(String species,String expID) {
        if (species.equals("CElegans")) {
            return String.format("valerie-reinke:%s_IP", expID);
        } else {
            return String.format("kevin-white:%s_IP", expID);
        }
    }

    public static String ctlExperimentAlias(ChipExperiment exp) {
        if (exp.getSpecies().equals("CElegans")) {
            return String.format("valerie-reinke:%s_INPUT", exp.getExpId());
        } else {
            return String.format("kevin-white:%s_INPUT", exp.getExpId());
        }
    }

    public static String geneticModAlias(ChipExperiment exp) {
        if (exp.getSpecies().equals("CElegans")) {
            return String.format("robert-waterston:%s-GFP-construct", exp.getGene());
        }else {
            Greek greek = new GreekPlus();
            return String.format("kevin-white:%s-GFP-construct", greek.translate(exp.getGene()));
        }
        
    }

    public static String donorAlias(ChipExperiment exp) {
        if (exp.getSpecies().equals("CElegans")) {
            return String.format("robert-waterston:%s", exp.getStrain());
        }
        if (exp.getExternalId() != null) {
            return String.format("bloomington:%s", exp.getExternalId());
        }
        return "";
    }
}
