/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.dcc;

import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonString;

/**
 *
 * @author gevirl
 */
public class Donor {

    JsonObject donorObj;

    public Donor(JsonObject obj) {
        this.donorObj = obj;
    }

    public String getStrain() {
        JsonString nameObj = donorObj.getJsonString("strain_name");
        if (nameObj != null) {
            return nameObj.getString().replaceAll(" ", "_");
        }
        return "";
    }

    public GeneticModification getGenMod() throws Exception {
        JsonArray ja = donorObj.getJsonArray("genetic_modifications");
        if (ja != null) {
            if (!ja.isEmpty()) {
                JsonString genMod = (JsonString) ja.get(0);
                return new GeneticModification(genMod.getString());
            }
        }
        return null;
    }

    public String getExternalID() {
        String ret = null;
        JsonArray ja = this.donorObj.getJsonArray("external_ids");
        if (ja != null) {
            if (!ja.isEmpty()) {
                JsonString idObj = ja.getJsonString(0);
                ret = idObj.getString();
            }
        }
        return ret;
    }
    
    public String getGenotype(){
        String ret = "";
        JsonString geneStr = donorObj.getJsonString("genotype");
        if (geneStr != null){
            ret = geneStr.getString();
        }
        return ret;
    }

}
