/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.dcc;

import java.io.File;
import java.io.PrintStream;
import java.util.List;
import java.util.Map;
import javax.json.JsonStructure;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipRun;
import org.rhwlab.chipseqweb.ChipSequencingFile;
import org.rhwlab.chipseqweb.ChipTag;
import org.rhwlab.chipseqweb.Species;

/**
 *
 * @author gevirl
 */
public interface Schema {
    public boolean isCompleted(File aliasFile) throws Exception;
    public void  submit(ChipExperiment chipExp,File aliasFile)throws Exception ;
    public boolean canSubmit(ChipExperiment chipExp,File aliasFile);
    public String getLabel();
    public void printSubmitScript(PrintStream stream,File jsonFile) throws Exception;
    public JsonStructure toJson(Species species, ChipExperiment exp, ChipRun run , List<ChipTag> tagList, Map<String, Map<Integer, Map<Integer, List<ChipSequencingFile>>>> fileMap) throws Exception ;
}
