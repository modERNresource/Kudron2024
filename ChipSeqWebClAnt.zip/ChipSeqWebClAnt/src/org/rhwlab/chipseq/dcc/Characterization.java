/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.dcc;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.json.Json;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObjectBuilder;
import javax.json.JsonStructure;
import org.rhwlab.chipseq.pipeline.PipelineRun;
import org.rhwlab.chipseq.qa.Directories;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipRun;
import org.rhwlab.chipseqweb.ChipSequencingFile;
import org.rhwlab.chipseqweb.ChipTag;
import org.rhwlab.chipseqweb.Species;

/**
 *
 * @author gevirl
 */
public class Characterization extends SchemaBase {

    public Characterization(){
        super("biosample_characterization");
    }


    @Override
    public JsonStructure toJson(Species species, ChipExperiment exp, ChipRun run,List<ChipTag> tagList, Map<String, Map<Integer, Map<Integer, List<ChipSequencingFile>>>> fileMap) throws Exception {
        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();

        for (String fileType : fileMap.keySet()){

            for (Integer rep : fileMap.get(fileType).keySet()){
                JsonObjectBuilder builder = Json.createObjectBuilder();
                builder.add("aliases", Json.createArrayBuilder().add(Aliases.characterizationAlias(fileType, exp, rep)));
                SubmitDCC.award(builder);
                SubmitDCC.yaleLab(builder);
                builder.add("characterizes",Aliases.biosampleAlias(fileType, exp, rep));
                File imagesDir = new File(Directories.epicDir,"images");
                File img = new File(imagesDir,exp.getExpId()+".jpeg");
                builder.add("attachment", Json.createObjectBuilder().add("path", img.getPath()));
                arrayBuilder.add(builder);
            }
        }
        return arrayBuilder.build();
    }



    
}
