/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.dcc;

import java.util.List;
import java.util.Map;
import javax.json.Json;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonStructure;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipRun;
import org.rhwlab.chipseqweb.ChipSequencingFile;
import org.rhwlab.chipseqweb.ChipTag;
import org.rhwlab.chipseqweb.Species;

/**
 *
 * @author gevirl
 */
public class Library extends SchemaBase {
    JsonObject libObj;
    
    public Library(){
        super("library");
    }

    public Library(JsonObject obj){
        this();
        this.libObj = obj;
    }

    public Biosample getBiosample(){
        return new Biosample(libObj.getJsonObject("biosample"));
    }
    

    @Override
    public JsonStructure toJson(Species species, ChipExperiment exp, ChipRun run,List<ChipTag> tagList, Map<String, Map<Integer, Map<Integer, List<ChipSequencingFile>>>> fileMap) throws Exception {
        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();

        // make a Library json for each control
        for (Integer rep : fileMap.get("ctl_fastqs").keySet()) {
            JsonObjectBuilder builder = Json.createObjectBuilder();
            libraryCommon(builder);
            builder.add("aliases", Json.createArrayBuilder().add(Aliases.ctlLibraryAlias(exp, rep)));
            builder.add("biosample", Aliases.ctlBiosampleAlias(exp, rep));
            arrayBuilder.add(builder);
        }

        // make a Library json for each IP
        for (Integer rep : fileMap.get("fastqs").keySet()) {
            JsonObjectBuilder builder = Json.createObjectBuilder();
            libraryCommon(builder);
            builder.add("aliases", Json.createArrayBuilder().add(Aliases.ipLibraryAlias(exp, rep)));
            builder.add("biosample", Aliases.ipBiosampleAlias(exp, rep));
            arrayBuilder.add(builder);
        }
        return arrayBuilder.build();
    }
    public void libraryCommon(JsonObjectBuilder builder) {
        SubmitDCC.award(builder);
        builder.add("fragmentation_methods", Json.createArrayBuilder().add("sonication (Bioruptor generic)"));
        builder.add("nucleic_acid_term_name", "DNA");
        builder.add("library_size_selection_method", "SPRI beads");
        builder.add("size_range", "200-800");
        SubmitDCC.yaleLab(builder);
    }    
}
