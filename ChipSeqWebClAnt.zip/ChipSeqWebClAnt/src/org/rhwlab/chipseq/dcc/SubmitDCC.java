/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.dcc;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonReader;
import javax.json.JsonStructure;
import javax.json.stream.JsonGenerator;
import org.rhwlab.chipseq.pipeline.PipelineRun;
import org.rhwlab.chipseq.qa.Directories;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipHelper;
import org.rhwlab.chipseqweb.ChipRun;
import org.rhwlab.chipseqweb.ChipSequencingFile;
import org.rhwlab.chipseqweb.ChipTag;
import org.rhwlab.chipseqweb.HibernateUtil;
import org.rhwlab.chipseqweb.Species;

/**
 *
 * @author gevirl
 */
public class SubmitDCC {

    LinkedHashMap<String, JsonStructure> map = new LinkedHashMap<>();
    Checks checks;
    List<String> aliases = new ArrayList<>();

    public SubmitDCC(Species species, ChipExperiment exp, List<ChipTag> tagList, PipelineRun run) throws Exception {
        checks = new Checks();
        checks.checkExperiment(exp, tagList);

        List<String> tabList = flyTabList;
        if (species.isWorm()) {
            tabList = wormTabList;
        }
        JsonObject inputs = PipelineRun.getPipelineRunInput(run.getDirectory());
        Map<String, Map<Integer, Map<Integer, List<ChipSequencingFile>>>> fileMap = run.runPaths(inputs);
        for (String label : tabList) {
            JsonStructure jsonStruct = schemaMap.get(label).toJson(species, exp, run.getRun(), tagList, fileMap);
            map.put(label, jsonStruct);
            aliases.addAll(aliases(jsonStruct));
        }
    }

    /*
    // pending submission are complete and have a run marked for DCC
    static public List<String> pendingSubmissions() throws Exception {
        List<String> accs = new ArrayList<>();
        for (Object obj : ChipHelper.getEquals("ChipExperiemnt", "Status", "Complete", "ExpID")) {
            ChipExperiment e = (ChipExperiment) obj;
            if (e.getAccession() != null) {
                accs.add(e.getAccession());
            }
        }
        return accs;
    }
     */
    // extract all the aliases from a DCC json submission structure
    public List<String> aliases(JsonStructure jsonStruct) {
        if (jsonStruct instanceof JsonObject) {
            return aliases((JsonObject) jsonStruct);
        } else {
            List<String> ret = new ArrayList<>();
            JsonArray jArray = (JsonArray) jsonStruct;
            for (int i = 0; i < jArray.size(); ++i) {
                ret.addAll(aliases(jArray.getJsonObject(i)));
            }
            return ret;
        }
    }

    public List<String> aliases(JsonObject jsonObj) {
        List<String> ret = new ArrayList<>();
        JsonArray aliasArray = jsonObj.getJsonArray("aliases");
        for (int i = 0; i < aliasArray.size(); ++i) {
            ret.add(aliasArray.getString(i));
        }
        return ret;
    }

    static public JsonObjectBuilder award(JsonObjectBuilder builder) {
        return builder.add("award", "U41HG007355");
    }

    static public JsonObjectBuilder uwLab(JsonObjectBuilder builder) {
        return builder.add("lab", "/labs/robert-waterston");
    }

    static public JsonObjectBuilder chiLab(JsonObjectBuilder builder) {
        return builder.add("lab", "/labs/kevin-white");
    }

    static public JsonObjectBuilder yaleLab(JsonObjectBuilder builder) {
        return builder.add("lab", "/labs/valerie-reinke");
    }

    static JsonObjectBuilder donorSource(JsonObjectBuilder builder, ChipExperiment exp) {
        if (exp.getSpecies().equals("CElegans")) {
            return builder.add("source", "/sources/robert-waterston");
        }
        return builder.add("source", "/sources/susan-celniker");
    }

    public JsonStructure getJson(String label) {
        return map.get(label);
    }

    public List<String> getErrors() {
        return checks.getErrors();
    }

    public List<String> getWarnings() {
        return checks.getWarnings();
    }

    public List<String> getAliases() {
        return this.aliases;
    }

    public Set getLabels() {
        return map.keySet();
    }

    static public void checkAliases(PrintStream stream, File aliasesFile) {
        stream.printf("cd %s\n", aliasesFile.getParentFile().getPath());
        authorization(stream);
        stream.printf("eu_check_not_posted.py -m prod -i %s -o notPosted\n", aliasesFile.getName());
    }

    static public void checkAnalysis(PrintStream stream, File analysisFile) {
        stream.printf("cd %s\n", analysisFile.getParentFile().getPath());
        authorization(stream);
        stream.printf("eu_check_not_posted.py -m prod -i %s -o analysisNotPosted\n", analysisFile.getName());
    }

    // write a script that will submit a json object 
    // this can be used to submit all but the donor
    static public void register(PrintStream stream, String label, File jsonOutFile) {

        authorization(stream);
        //       stream.println("conda activate encode-chip-seq-pipeline");
        stream.printf("cd %s\n", jsonOutFile.getParentFile().getPath());
        stream.printf("eu_register.py -m prod  -p %s -i %s\n", label, jsonOutFile.getPath());
    }

    static public void patch(PrintStream stream, String label, File jsonOutFile) {
        authorization(stream);
        stream.printf("cd %s\n", jsonOutFile.getParentFile().getPath());
        stream.printf("eu_register.py -m prod  -p %s -i %s --patch\n", label, jsonOutFile.getPath());
    }

    static public void authorization(PrintStream stream) {
        for (String auth : authorization()) {
            stream.println(auth);
        }
    }

    static public ArrayList<String> authorization() {
        ArrayList<String> ret = new ArrayList<>();
        ret.add("export DCC_API_KEY=BXTSKHIS");
        ret.add("export DCC_SECRET_KEY=vwhzube43dekyyc6");
        return ret;
    }

    static public List<String> getFlyTabs() {
        return flyTabList;
    }

    static public List<String> getWormTabs() {
        return wormTabList;
    }

    static public Schema getSchema(String tab) {
        return schemaMap.get(tab);
    }

    static List<File> findJsonFiles(File dir) {
        ArrayList<File> ret = new ArrayList<>();
        for (File file : dir.listFiles()) {
            if (file.getName().endsWith(".json")) {
                ret.add(file);
            }
        }
        return ret;
    }

    static TreeMap<String, JsonObject> getJsonObjects(File jsonFileList) throws Exception {
        TreeMap<String, JsonObject> ret = new TreeMap<>();

        BufferedReader reader = new BufferedReader(new FileReader(jsonFileList));
        String jsonFile = reader.readLine();
        while (jsonFile != null) {
            JsonReader jsonReader = Json.createReader(new FileReader(jsonFile));
            JsonObject jsonObject = jsonReader.readObject();
            jsonReader.close();

            String expId = new File(jsonFile).getParentFile().getParentFile().getName();
            ret.put(expId, jsonObject);
            jsonFile = reader.readLine();
        }
        reader.close();
        return ret;
    }

    static public JsonArray mergeJson(Collection<JsonObject> objs) throws Exception {

        JsonArrayBuilder builder = Json.createArrayBuilder();
        for (JsonObject obj : objs) {
            builder.add(obj);
        }
        return builder.build();
    }
    // ******************************************************************
    // ******* This must be run as user: waterston-jboss on epic ********
    // ******************************************************************

    // if no args - attempt to submit all experiments
    // otherwise each arg should be a runID
    //
    static public void main(String[] args) throws Exception {
        // clear the email lists
        FlyDonor.emailListFile().delete();
        FlyDonor.emailListFile().createNewFile();
        WormDonor.emailListFile().delete();
        WormDonor.emailListFile().createNewFile();

        File logFile = new File(Directories.sourceDir, "SubmitLog");
        File postScriptFile = new File(Directories.sourceDir, "PostSubmit.sh");
        File analysisPostScriptFile = new File(Directories.sourceDir, "AnalysisPostSubmit.sh");

        // save the old log file, if there is one
        if (logFile.exists()) {
            BufferedReader reader = new BufferedReader(new FileReader(logFile));
            reader.readLine();
            String line = reader.readLine();
            String suf = line.replace(" at ", "_").replace(" PST", "");
            File logSave = new File(String.format("%s.%s", logFile.getPath(), suf));
            Process proc = Runtime.getRuntime().exec(String.format("mv %s %s", logFile.getPath(), logSave.getPath()));
            proc.waitFor();
            reader.close();

            if (postScriptFile.exists()) {
                File postSave = new File(Directories.sourceDir, String.format("PostSubmit.%s", suf));
                proc = Runtime.getRuntime().exec(String.format("mv %s %s", postScriptFile.getPath(), postSave.getPath()));
                proc.waitFor();
            }

        }
        PrintStream logStream = new PrintStream(new FileOutputStream(logFile));
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd 'at' HH:mm:ss z");
        Date date = new Date(System.currentTimeMillis());
        logStream.printf("\n%s\n", formatter.format(date));

        PrintStream postStream = new PrintStream(postScriptFile); // submits the jpeg's , sends email , submits analysis objects
        PrintStream analysisPostStream = new PrintStream(analysisPostScriptFile);

        // get the runs to submit
        ArrayList<ChipRun> runList = new ArrayList<>();
        if (args.length == 0) {
            for (Object runObj : ChipHelper.getAll("ChipRun", "SubmitID")) {
                runList.add((ChipRun) runObj);
            }
        } else {
            for (String submitID : args) {
                for (Object runObj : ChipHelper.getEquals("ChipRun", "SubmitID", submitID, "SubmitID")) {
                    runList.add((ChipRun) runObj);
                }
            }
        }

        // try to submit aliases from experiments that are marked for submission and do not have a accession in the db
        for (ChipRun chipRun : runList) {
            if (chipRun.getMarkedForDcc() != null) {
                for (Object expObj : ChipHelper.getEquals("ChipExperiment", "ExpID", chipRun.getExpId(), "ExpID")) {
                    ChipExperiment chipExp = (ChipExperiment) expObj;
                    if (chipExp.getAccession() == null) {
                        // checking all the aliases for the experiment
                        logStream.printf("SubmitDCC: Checking %s aliases\n", chipExp.getExpId());
                        File expDir = new File(Directories.sourceDir, chipExp.getExpId());
                        File checkAliasesScript = new File(expDir, "checkAliases.sh");
                        if (checkAliasesScript.exists()) {
                            ProcessBuilder pb = new ProcessBuilder(checkAliasesScript.getPath());
                            Process p = pb.start();
                            p.waitFor();

                            // process the unposted aliases for the experiment
                            File notPosted = new File(expDir, "notPosted");
                            BufferedReader reader = new BufferedReader(new FileReader(notPosted));
                            String alias = reader.readLine();

                            if (alias == null) {
                                // all the objects have been posted , except the analysis objects
                                // make a script for the experiment to run the accession software to submit all the analysis files
                                /*
                                File accDir = new File(expDir, "accession");
                                if (!accDir.exists()) {
                                    Files.createDirectories(accDir.toPath());
                                }
                                File chipDir = new File(expDir, "chip");
                                File runDir = new File(chipDir, chipRun.getChipId());
                                File submitAnalysisFile = new File(expDir, "submitAnalysis.sh");
                                PrintStream accStream = new PrintStream(submitAnalysisFile);
                                accStream.println("export DCC_API_KEY=BXTSKHIS");
                                accStream.println("export DCC_SECRET_KEY=vwhzube43dekyyc6");
                                accStream.println("export DCC_LAB=/labs/robert-waterston");
                                accStream.println("export DCC_AWARD=U41HG007355");
                                accStream.printf("cd %s\n", accDir.getPath());
                                accStream.printf("accession -m %s/metadata.json --pipeline-type tf_chip_bwa_control_fastqs -s prod\n", runDir.getPath());
                                accStream.close();

                                // add this experiment accession script to the overall accessioning script
                                analysisPostStream.println(submitAnalysisFile.getPath());
                                 */
                            } else {
                                // try to submit all the objects currently not submitted
                                while (alias != null) {
                                    File aliasDir = new File(expDir, alias);
                                    List<File> jsonFiles = findJsonFiles(aliasDir);
                                    if (!jsonFiles.isEmpty()) {
                                        File aliasFile = jsonFiles.get(0);

                                        if (!alias.endsWith("jpg")) {  // do for all objects except the biosample_characterization
                                            // do the submition directly of the alias
                                            String schemaName = aliasFile.getName().replace(".json", "");
                                            logStream.printf("not posted: %s %s\n", aliasDir.getName(), schemaName);
                                            Schema schema = schemaMap.get(schemaName);
                                            if (schema.canSubmit(chipExp, aliasFile)) {
                                                logStream.printf("can submit: %s\n", aliasDir.getName());

                                                // this is where the submission actually happens
                                                schema.submit(chipExp, aliasFile);  // submits the alias
                                                if (!schema.isCompleted(aliasFile)) {
                                                    // report the failed alias 
                                                    logStream.printf("Failed to submit: %s\n", aliasDir.getName());
                                                    break; // don't try any more aliases for this experiment
                                                } else {
                                                    logStream.printf("Successful submit: %s\n", aliasDir.getName());
                                                }
                                            }
                                        } else {
                                            postStream.printf("%s/submit.sh\n", aliasDir.getPath());
                                        }
                                    }
                                    alias = reader.readLine();
                                }
                            }
                            reader.close();
                        }
                    }
                }
            }
        }
        logStream.close();

        // make jsons for email to Idan
        TreeMap<String, JsonObject> objMap = getJsonObjects(FlyDonor.emailListFile());
        if (!objMap.isEmpty()) {
            JsonArray flyEmailJsonArray = mergeJson(objMap.values());
            File attach = new File(Directories.sourceDir, "FlyAttachment.json");
            JsonGenerator gen = Json.createGenerator(new FileWriter(attach));
            gen.writeStartArray();
            gen.write(flyEmailJsonArray);
            gen.writeEnd();
            gen.flush();
            gen.close();
            postStream.printf(
                    "mail -s \"modERN fly donor\" -r \"Louis Gevirtzman<gevirl@uw.edu>\" -a %s -c gevirl@uw.edu gabdank@stanford.edu < %s \n",
                    attach.getPath(), FlyDonor.mailMsg.getPath());

            for (String expID : objMap.keySet()) {
                postStream.printf("java -cp /net/waterston/vol9/ChipSeqPipeline/prog/ChipSeqWebCL.jar org.rhwlab.chipseq.dcc.FlyDonor %s \n", expID);
            }
        }
        objMap = getJsonObjects(WormDonor.emailListFile());
        if (!objMap.isEmpty()) {
            JsonArray wormEmailJsonArray = mergeJson(objMap.values());
            File attach = new File(Directories.sourceDir, "WormAttachment.json");
            JsonGenerator gen = Json.createGenerator(new FileWriter(attach));
            gen.writeStartArray();
            gen.write(wormEmailJsonArray);
            gen.writeEnd();
            gen.flush();
            gen.close();
            postStream.printf(
                    "mail -s \"modERN worm donor\" -r \"Louis Gevirtzman<gevirl@uw.edu>\" -a %s -c gevirl@uw.edu gabdank@stanford.edu < %s \n",
                    attach.getPath(), WormDonor.mailMsg.getPath());

            for (String expID : objMap.keySet()) {
                postStream.printf("java -cp /net/waterston/vol9/ChipSeqPipeline/prog/ChipSeqWebCL.jar org.rhwlab.chipseq.dcc.WormDonor %s \n", expID);
            }
        }
        postStream.close();
        analysisPostStream.close();
        HibernateUtil.shutdown();
    }

    final static TreeMap<String, Schema> schemaMap = new TreeMap<>();
    final static List<String> wormTabList = new ArrayList<>();
    final static List<String> flyTabList = new ArrayList<>();
    final static TreeMap<String, List<String>> tabListMap = new TreeMap<>();

    static {
        Experiment e = new Experiment();
        schemaMap.put(e.getLabel(), e);
        wormTabList.add(e.getLabel());
        flyTabList.add(e.getLabel());

        GeneticModification gm = new GeneticModification();
        schemaMap.put(gm.getLabel(), gm);
        wormTabList.add(gm.getLabel());
        flyTabList.add(gm.getLabel());

        FlyDonor fd = new FlyDonor();
        schemaMap.put(fd.getLabel(), fd);
        flyTabList.add(fd.getLabel());

        WormDonor wd = new WormDonor();
        schemaMap.put(wd.getLabel(), wd);
        wormTabList.add(wd.getLabel());

        Biosample bs = new Biosample();
        schemaMap.put(bs.getLabel(), bs);
        wormTabList.add(bs.getLabel());
        flyTabList.add(bs.getLabel());

        Characterization bc = new Characterization();
        schemaMap.put(bc.getLabel(), bc);
        wormTabList.add(bc.getLabel());

        Library lib = new Library();
        schemaMap.put(lib.getLabel(), lib);
        wormTabList.add(lib.getLabel());
        flyTabList.add(lib.getLabel());

        Replicate rep = new Replicate();
        schemaMap.put(rep.getLabel(), rep);
        wormTabList.add(rep.getLabel());
        flyTabList.add(rep.getLabel());

        SequenceFile sq = new SequenceFile();
        schemaMap.put(sq.getLabel(), sq);
        wormTabList.add(sq.getLabel());
        flyTabList.add(sq.getLabel());
        /*
        Analysis analysis = new Analysis();
        schemaMap.put(analysis.getLabel(), analysis);
        wormTabList.add(analysis.getLabel());
        flyTabList.add(analysis.getLabel());        
         */
        tabListMap.put("CElegans", wormTabList);
        tabListMap.put("Dmel", flyTabList);
    }

    static public LinkedHashMap<String, String> getAllAliases(ChipExperiment exp, PipelineRun run) throws Exception {
        JsonObject inputs = PipelineRun.getPipelineRunInput(run.getDirectory());
        Map<String, Map<Integer, Map<Integer, List<ChipSequencingFile>>>> fileMap = run.runPaths(inputs);
        LinkedHashMap<String, String> ret = new LinkedHashMap<>();

        // control and IP experiments
        ret.put(Aliases.ctlExperimentAlias(exp), new Experiment().getLabel());
        ret.put(Aliases.ipExperimentAlias(exp), new Experiment().getLabel());

        // genetic mod
        ret.put(Aliases.geneticModAlias(exp), new GeneticModification().getLabel());

        // donor
        if (exp.getSpecies().equals("Dmel")) {
            ret.put(Aliases.donorAlias(exp), new FlyDonor().getLabel());
        } else {
            ret.put(Aliases.donorAlias(exp), new WormDonor().getLabel());
        }

        // control and ip biosamples for each replicate
        for (Integer rep : fileMap.get("ctl_fastqs").keySet()) {
            ret.put(Aliases.ctlBiosampleAlias(exp, rep), new Biosample().getLabel());
        }
        for (Integer rep : fileMap.get("fastqs").keySet()) {
            ret.put(Aliases.ipBiosampleAlias(exp, rep), new Biosample().getLabel());
        }

        // biosample characterizations for each sample
        if (exp.getSpecies().equals("CElegans")) {
            for (String fileType : fileMap.keySet()) {
                for (Integer rep : fileMap.get(fileType).keySet()) {
                    ret.put(Aliases.characterizationAlias(fileType, exp, rep), new Characterization().getLabel());
                }
            }
        }

        // library
        for (Integer rep : fileMap.get("ctl_fastqs").keySet()) {
            ret.put(Aliases.ctlLibraryAlias(exp, rep), new Library().getLabel());
        }
        for (Integer rep : fileMap.get("fastqs").keySet()) {
            ret.put(Aliases.ipLibraryAlias(exp, rep), new Library().getLabel());
        }

        // replicate
        for (Integer rep : fileMap.get("ctl_fastqs").keySet()) {
            ret.put(Aliases.ctlReplicateAlias(exp, rep), new Replicate().getLabel());
        }
        for (Integer rep : fileMap.get("fastqs").keySet()) {
            ret.put(Aliases.ipReplicateAlias(exp, rep), new Replicate().getLabel());
        }

        // sequence files
        for (String fileType : fileMap.keySet()) {
            Map<Integer, Map<Integer, List<ChipSequencingFile>>> repMap = fileMap.get(fileType);
            for (Integer rep : repMap.keySet()) {
                Map<Integer, List<ChipSequencingFile>> readMap = repMap.get(rep);
                for (Integer read : readMap.keySet()) {
                    for (ChipSequencingFile chipFile : readMap.get(read)) {
                        ret.put(Aliases.fileAlias(chipFile), new SequenceFile().getLabel());
                    }
                }
            }
        }
        return ret;
    }
}
