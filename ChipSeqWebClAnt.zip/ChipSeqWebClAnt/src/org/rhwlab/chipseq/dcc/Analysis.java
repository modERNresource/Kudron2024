/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.dcc;


import java.io.File;
import java.io.PrintStream;
import java.util.List;
import java.util.Map;
import javax.json.Json;
import javax.json.JsonObjectBuilder;
import javax.json.JsonStructure;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipRun;
import org.rhwlab.chipseqweb.ChipSequencingFile;
import org.rhwlab.chipseqweb.ChipTag;
import org.rhwlab.chipseqweb.Species;

/**
 *
 * @author gevirl
 */
public class Analysis implements Schema {

    @Override
    public boolean isCompleted(File aliasFile) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void submit(ChipExperiment chipExp, File aliasFile) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean canSubmit(ChipExperiment chipExp, File aliasFile) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getLabel() {
        return "Analysis";
    }

    @Override
    public void printSubmitScript(PrintStream stream, File jsonFile) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public JsonStructure toJson(Species species, ChipExperiment exp, ChipRun run, List<ChipTag> tagList, Map<String, Map<Integer, Map<Integer, List<ChipSequencingFile>>>> fileMap) throws Exception {
        JsonObjectBuilder builder = Json.createObjectBuilder();
        builder.add("aliases", Json.createArrayBuilder().add(Aliases.analysisAlias(run)));
        return builder.build();
    }
    
}
