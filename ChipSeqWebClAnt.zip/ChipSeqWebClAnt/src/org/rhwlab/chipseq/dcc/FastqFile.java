/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.dcc;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipException;


/**
 *
 * @author gevirl
 */
public class FastqFile {
    File fq;
    String machine;
    String flowcell;
    String barcode;
    int lane;
    int readLen;
    
    public FastqFile(File f) throws Exception {
        this.fq = f;
        FileInputStream inStream = new FileInputStream(fq);
        BufferedReader reader = null;
        try {
            GZIPInputStream gzipStream = new GZIPInputStream(inStream);
            reader = new BufferedReader(new InputStreamReader(gzipStream));
        } catch (ZipException exc2) {
            reader = new BufferedReader(new FileReader(fq));
        } 
        String line = reader.readLine();
        String[] tokens = line.split(":| ");
        machine = tokens[0].substring(1);
        flowcell = tokens[2];
        lane = Integer.valueOf(tokens[3]);
        barcode = tokens[10];
        
        readLen = reader.readLine().length();
        reader.close();
    }
    
    public String getMachine(){
        return this.machine;
    }
    public String getFlowcell(){
        return this.flowcell;
    }
    public String getBarcode(){
        return this.barcode;
    }
    public int getLane(){
        return this.lane;
    }
    public int getReadlen(){
        return this.readLen;
    }
    
    static public void main(String[] args) throws Exception {
        FastqFile f = new FastqFile(new File("/net/waterston/vol9/ChipSeqPipeline/aptf-3_OP765_youngadult_1/APT3inp4_007_186_S25_L002_R1_001.fastq.gz"));
        
    }
    
}
