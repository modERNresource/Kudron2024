/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.dcc;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonString;
import javax.json.JsonStructure;
import static org.rhwlab.chipseq.dcc.SubmitDCC.award;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipRun;
import org.rhwlab.chipseqweb.ChipSequencingFile;
import org.rhwlab.chipseqweb.ChipTag;
import org.rhwlab.chipseqweb.Species;
import org.rhwlab.encode.EncodeUrl;

/**
 *
 * @author gevirl
 */
public class Experiment extends SchemaBase {

    JsonObject expObj;

    public Experiment() {
        super("experiment");
    }

    public Experiment(String accession) throws Exception {
        this();
        if (accession != null) {
            String expURL = String.format("https://www.encodeproject.org/experiments/%s/?format=json", accession);
            EncodeUrl url = new EncodeUrl(expURL);
            url.getJson();
            expObj = url.getJsonObject();
        }
        int iuasdhf = 0;
    }

    public String getDate(){
        JsonString s = expObj.getJsonString("date_submitted");
        if (s != null){
            return s.getString();
        }
        return "";
    }
    public String getStage() {
        Replicate[] reps = this.getReplicates();
        String stage = reps[0].getLibrary().getBiosample().getStage();
        stage = stage.replaceAll("/", "");
        stage = stage.replaceAll(" ", "_");
       
        return stage;
    }

    public String getStrain() {
        Replicate[] reps = this.getReplicates();
        String ret = reps[0].getLibrary().getBiosample().getDonor().getStrain();
        if (ret.equals("")){
            ret = this.getGene() + "-GFP";
        }
        return ret;
    }

    public String getMethod() throws Exception {
        Replicate[] reps = this.getReplicates();
        Donor donor = reps[0].getLibrary().getBiosample().getDonor();
        GeneticModification genMod = donor.getGenMod();
        if (genMod != null) {
            return genMod.getMethod();
        }
        return "";
    }

    public Replicate[] getReplicates() {
        JsonArray reps = expObj.getJsonArray("replicates");
        Replicate[] ret = new Replicate[reps.size()];
        for (int i = 0; i < ret.length; ++i) {
            ret[i] = new Replicate(reps.getJsonObject(i));
        }
        return ret;
    }

    public String getSpecies() {
        JsonObject target = expObj.getJsonObject("target");
        JsonObject organism = target.getJsonObject("organism");
        String name = organism.getString("name");
        if (name.equals("celegans")) {
            return "CElegans";
        }
        return "Dmel";
    }

    public String getAssembly() {
        String species = getSpecies();
        return getAssembly(species);   
    }

    static public String getAssembly(String species) {
        String assembly = "ce11";
        if (species.equals("Dmel")) {
            assembly = "dm6";
        }
        return assembly;
    }
    public DCCFile[] getFiles() {
        JsonArray files = expObj.getJsonArray("files");
        DCCFile[] ret = new DCCFile[files.size()];
        for (int i = 0; i < files.size(); ++i) {
            ret[i] = new DCCFile((JsonObject) files.get(i));
        }
        return ret;
    }

    public List<DCCFile> getFiles(String format, String assembly) {
        ArrayList<DCCFile> ret = new ArrayList<>();
        for (DCCFile file : this.getFiles()) {
            if (file.getFormat().equals(format)) {
                if (assembly == null || file.getAssembly().equals(assembly)) {
                    ret.add(file);
                }
            }
        }
        return ret;
    }

    public List<DCCFile> getBAMFiles(String assembly) {
        return getFiles("bam", assembly);
    }

    public String getControlAccession() {
        JsonArray controls = expObj.getJsonArray("possible_controls");
        if (!controls.isEmpty()) {
            JsonObject ctlObj = controls.getJsonObject(0);
            return ctlObj.getString("accession");
        }
        return null;
    }

    public String getGene() {
        JsonObject targetObj = expObj.getJsonObject("target");
        JsonArray geneArray = targetObj.getJsonArray("genes");
        JsonObject geneObj = (JsonObject) geneArray.get(0);
        return geneObj.getString("symbol");
    }

    @Override
    public JsonStructure toJson(Species species, ChipExperiment exp, ChipRun run, List<ChipTag> tagList, Map<String, Map<Integer, Map<Integer, List<ChipSequencingFile>>>> fileMap) throws Exception {
        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();

        JsonObjectBuilder ctlBuilder = Json.createObjectBuilder();
        JsonObjectBuilder ipBuilder = Json.createObjectBuilder();
        experimentCommon(species, exp, ipBuilder);
        experimentCommon(species, exp, ctlBuilder);
        if (species.isFly()) {
            experimentFly(exp, ipBuilder);
            experimentFly(exp, ctlBuilder);
        } else {
            experimentWorm(exp, ipBuilder);
            experimentWorm(exp, ctlBuilder);
        }
        experimentCtl(exp, ctlBuilder);
        experimentIp(species, exp, ipBuilder);

        arrayBuilder.add(ctlBuilder);
        arrayBuilder.add(ipBuilder);
        return arrayBuilder.build();
    }

    final public void experimentCommon(Species species, ChipExperiment exp, JsonObjectBuilder builder) {
        award(builder);
        builder.add("assay_term_name", "ChIP-seq");
        builder.add("biosample_ontology", "/biosample-types/whole_organisms_UBERON_0000468");
    }

    final public void experimentWorm(ChipExperiment exp, JsonObjectBuilder builder) {
        SubmitDCC.yaleLab(builder);
        builder.add("documents", Json.createArrayBuilder().add("d89f19f3-31f8-4079-9635-5d3dd799471e"));
    }

    final public void experimentFly(ChipExperiment exp, JsonObjectBuilder builder) {
        SubmitDCC.chiLab(builder);
        builder.add("documents", Json.createArrayBuilder().add("f890fde6-924c-4265-a60f-c5810401066d"));
    }

    final public void experimentCtl(ChipExperiment exp, JsonObjectBuilder builder) {
        builder.add("aliases", Json.createArrayBuilder().add(Aliases.ctlExperimentAlias(exp)));
        builder.add("control_type", "input library");
        if (exp.getExpCtlDesc() != null) {
            builder.add("description", exp.getExpCtlDesc());
        }
    }

    final public void experimentIp(Species species, ChipExperiment exp, JsonObjectBuilder builder) {
        builder.add("aliases", Json.createArrayBuilder().add(Aliases.ipExperimentAlias(exp)));
        builder.add("target", species.getTarget(exp));
        if (exp.getExpIpdesc() != null) {
            builder.add("description", exp.getExpIpdesc());
        }
        builder.add("possible_controls", Json.createArrayBuilder().add(Aliases.ctlExperimentAlias(exp)));
    }
    
    
    // find all dcc experiments 
    public static void main(String[] args)throws Exception {
        String wormExpUrl = 
                "https://www.encodeproject.org/search/?type=Experiment&replicates.library.biosample.donor.organism.scientific_name=Caenorhabditis+elegans&control_type!=*&assay_slims=DNA+binding&assay_title=TF+ChIP-seq";
    }

}
