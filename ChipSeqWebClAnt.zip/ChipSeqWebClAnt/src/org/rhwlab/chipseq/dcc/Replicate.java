/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.dcc;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.json.Json;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonString;
import javax.json.JsonStructure;
import org.rhwlab.chipseq.pipeline.PipelineRun;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipRun;
import org.rhwlab.chipseqweb.ChipSequencingFile;
import org.rhwlab.chipseqweb.ChipTag;
import org.rhwlab.chipseqweb.Species;

/**
 *
 * @author gevirl
 */
public class Replicate extends SchemaBase {

    JsonObject repObj;

    public Replicate() {
        super("replicate");
    }

    public Replicate(JsonObject repObj) {
        this();
        this.repObj = repObj;
    }

    public Library getLibrary() {
        return new Library(repObj.getJsonObject("library"));
    }

    public String getAntibodyProduct() {
        String ret = "";
        JsonObject antibodyObj = repObj.getJsonObject("antibody");
        if (antibodyObj != null) {
            JsonString prodIDObj = antibodyObj.getJsonString("product_id");
            if (prodIDObj != null) {
                ret = prodIDObj.getString();
            }
        }
        return ret;
    }

    public String getAntibody() {
        String ret = "";
        JsonObject antibodyObj = repObj.getJsonObject("antibody");
        if (antibodyObj != null) {
            JsonString uuID = antibodyObj.getJsonString("uuid");
            if (uuID != null) {
                ret = uuID.getString();
            }
        }
        return ret;
    }
    
    @Override

    public JsonStructure toJson(Species species, ChipExperiment exp, ChipRun run, List<ChipTag> tagList, Map<String, Map<Integer, Map<Integer, List<ChipSequencingFile>>>> fileMap) throws Exception {
        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();

        // make a Replicate json for each control
        for (Integer rep : fileMap.get("ctl_fastqs").keySet()) {
            JsonObjectBuilder builder = Json.createObjectBuilder();
            replicateCommon(builder, exp.getAntibody(), rep);
            builder.add("aliases", Json.createArrayBuilder().add(Aliases.ctlReplicateAlias(exp, rep)));
            builder.add("library", Aliases.ctlLibraryAlias(exp, rep));
            builder.add("experiment", Aliases.ctlExperimentAlias(exp));
            arrayBuilder.add(builder);
        }

        // make a Replicate json for each IP
        for (Integer rep : fileMap.get("fastqs").keySet()) {
            JsonObjectBuilder builder = Json.createObjectBuilder();
            replicateCommon(builder, exp.getAntibody(), rep);
            builder.add("aliases", Json.createArrayBuilder().add(Aliases.ipReplicateAlias(exp, rep)));
            builder.add("library", Aliases.ipLibraryAlias(exp, rep));
            builder.add("experiment", Aliases.ipExperimentAlias(exp));
            arrayBuilder.add(builder);
        }
        return arrayBuilder.build();
    }

    public void replicateCommon(JsonObjectBuilder builder, String antibody, int rep) {
        builder.add("biological_replicate_number", rep);
        builder.add("technical_replicate_number", 1);
        builder.add("antibody", antibody);
    }
}
