/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.dcc;

import java.io.File;
import java.net.URL;
import java.net.URLConnection;
import javax.json.JsonArray;
import javax.json.JsonNumber;
import javax.json.JsonObject;
import javax.json.JsonValue;
import org.rhwlab.chipseqweb.beans.UtilsURL;

/**
 *
 * @author gevirl
 */
public class DCCFile {
    JsonObject fileObj;
    
    public DCCFile(JsonObject fileObj){
        this.fileObj = fileObj;
    }
    
    public int download(File outFile)throws Exception {
        URL url = new URL(this.getDownloadURL());
        long sz = UtilsURL.download(url, outFile);
        return (int) (sz/1000000.0);
    }
    public String getName(){
        return new File(this.fileObj.getString("submitted_file_name")).getName();
    }
    public String getDownloadURL(){
        String href = this.fileObj.getString("href");
        return String.format("%s%s", server,href);
    }
    
    public String getFormat(){
        return fileObj.getString("file_format");
    }
    
    public String getAssembly(){
        return fileObj.getString("assembly");
    }
    
    public int getReplicate(){
        JsonArray reps = fileObj.getJsonArray("biological_replicates");      
        JsonNumber jsonNum = (JsonNumber)(reps.get(0));
        return jsonNum.intValue();
    }
    
    // returns size in Mbytes
    public int getSize()throws Exception {
        int s = this.fileObj.getInt("file_size");
        int n = (int)(s/1000000.0);
/*        
        URL url = new URL(getDownloadURL());
        URLConnection connect = url.openConnection();
        long lg = connect.getContentLengthLong();
        int n = (int)(lg/1000000.0);
*/
        return n;
    }
    
    public String getAccession(){
        return this.fileObj.getString("accession");
    }
    public URL getMetaURL()throws Exception {
        return new URL(String.format("%s/files/%s", server,getAccession()));
    }
    
    static String server = "https://BXTSKHIS:vwhzube43dekyyc6@www.encodeproject.org";
}
