/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

import java.io.File;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.List;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 *
 * @author gevirl
 */
// vimpStage results by tissues in the resultModels done for the stage
public class VimpStage {

    ResultModels resultModels;
    TreeMap<String, Integer> modelIndex = new TreeMap<>();
    TreeMap<String, VimpModel> vimpMap = new TreeMap<>();  // model -> VimpModel

    public VimpStage(ResultModels models) throws Exception {
        this.resultModels = models;

        for (String model : models.getModels()) {
            File modelDir = models.modelDir(model);
            VimpModel vimpModel = new VimpModel(modelDir);
            vimpMap.put(model, vimpModel);

        }

        int index = 1;
        for (String model : vimpMap.keySet()) {
            modelIndex.put(model, index);
            ++index;
        }
    }

    public VimpModel getVimpModel(String model) {
        return this.vimpMap.get(model);
    }

    public int getCellCount() {
        return vimpMap.get(vimpMap.firstKey()).getCellCount();
    }

    public String getTissues() {
        return vimpMap.get(vimpMap.firstKey()).getTissuesAsString();
    }

    public TreeMap<String, TreeMap<Double, String>> allMSE() {  // cellType -> mse -> model 
        TreeMap<String, TreeMap< Double, String>> ret = new TreeMap<>();
        for (String model : vimpMap.keySet()) {
            VimpModel vimpModel = vimpMap.get(model);
            TreeMap<String, Double> mseMap = vimpModel.allMSE();
            for (String cellType : mseMap.keySet()) {
                TreeMap<Double, String> modelMseMap = ret.get(cellType);
                if (modelMseMap == null) {
                    modelMseMap = new TreeMap<>();
                    ret.put(cellType, modelMseMap);
                }
                Double mse = mseMap.get(cellType);
                modelMseMap.put(mse, model);
            }
        }
        return ret;
    }

    public TreeMap<String, int[]> score(List<String> models, int rankMax) {
        TreeMap<String, int[]> ret = new TreeMap<>(); // model -> cell counts
        for (String model : models) {
            ret.put(model, new int[rankMax]);
        }

        for (int rank = 1; rank <= rankMax; ++rank) {
            TreeMap<String, TreeMap<Double, String>> allMSE = allMSE();  // cellType -> mse -> model
            for (String cellType : allMSE.keySet()) {
                TreeMap<Double, String> mseModelMap = allMSE.get(cellType);

                for (int r = 0; r < rank; ++r) {
                    Entry<Double, String> e = mseModelMap.pollFirstEntry();
                    if (e != null) {
                        if (r == rank - 1) {
                            int[] counts = ret.get(e.getValue());
                            ++counts[rank - 1];
                        }
                    }
                }
            }
        }
        return ret;
    }

    public TreeMap<String, double[]> scoreMaxError(List<String> models, int rankMax) {
        TreeMap<String, double[]> ret = new TreeMap<>(); // model -> cell counts
        for (String model : models) {
            double[] errors = new double[rankMax];
            Arrays.fill(errors, 0.0);
            ret.put(model, errors);
        }

        for (int rank = 1; rank <= rankMax; ++rank) {
            TreeMap<String, TreeMap<Double, String>> allMSE = allMSE();  // cellType -> mse -> model
            for (String cellType : allMSE.keySet()) {
                TreeMap<Double, String> mseModelMap = allMSE.get(cellType);

                for (int r = 0; r < rank; ++r) {
                    Entry<Double, String> e = mseModelMap.pollFirstEntry();
                    if (e != null) {
                        if (r == rank - 1) {
                            String model = e.getValue();
                            double[] errors = ret.get(model);
                            Double error = e.getKey();
                            if (error > errors[rank - 1]) {
                                errors[rank - 1] = error;
                            }
                        }
                    }
                }
            }
        }
        return ret;
    }

    public void reportScoreCard(PrintStream stream, int rankMax) {
        List<String> models = resultModels.getModels();
        TreeMap<String, int[]> card = score(models, rankMax);
        TreeMap<String, double[]> errorCard = scoreMaxError(models, rankMax);

        int m = 1;
        stream.printf("Count of cells with lowest errors for top %d ranks as cellTypeCount:totalCellCount\n", rankMax);
        stream.print("Model#");
        for (int i = 1; i <= rankMax; ++i) {
            stream.printf("\trank%d", i);
        }
        stream.println("\tModelLabel");
        for (String model : card.keySet()) {
            stream.printf("%d", m);
            int[] scores = card.get(model);
            double[] errors = errorCard.get(model);
            int total = 0;
            for (int i = 0; i < scores.length; ++i) {
                total = total + scores[i];
                stream.printf("\t%d:%d", scores[i], total);
            }
            stream.printf("\t%s", model);
            stream.println();
            ++m;
        }

        m = 1;
        stream.println();
        stream.println("Maximum error for cell types at each rank - 0 means no cells at that rank");
        stream.print("Model#");
        for (int i = 1; i <= rankMax; ++i) {
            stream.printf("\trank%d", i);
        }
        stream.println("\tModelLabel");
        for (String model : card.keySet()) {
            stream.printf("%d", m);
            int[] scores = card.get(model);
            double[] errors = errorCard.get(model);
            for (int i = 0; i < scores.length; ++i) {
                stream.printf("\t%.0f", errors[i] / 1000.0);
            }
            stream.printf("\t%s", model);
            stream.println();
            ++m;
        }

    }

    public void reportAllMSE(PrintStream stream, int maxRank) {
        stream.println("Best models for each cell type as  modelNumber:meanSquareError");
        TreeMap<String, TreeMap<Double, String>> allMSE = allMSE();
        for (String cellType : allMSE.keySet()) {

            TreeMap<Double, String> modelErrors = allMSE.get(cellType);
            for (int i = 0; i < maxRank; ++i) {
                Entry<Double, String> e = modelErrors.pollFirstEntry();
                if (e != null) {
                    int hhh = 0;

                    String model = e.getValue();
                    Double error = e.getKey();
                    stream.printf("%d:%.0f\t", modelIndex.get(model), error / 1000.0);
                }
            }
            stream.printf("%s\n", cellType);
        }
        stream.println();
    }

    public static void report(String stage, File dir) throws Exception {
        PrintStream stream = System.out;
        int rankMax = 4;

        ResultModels stageModels = new ResultModels(dir, stage);
        VimpStage stageResults = new VimpStage(stageModels);
        stream.printf("\n%s : %d cell types \ntissues : %s\n", stage, stageResults.getCellCount(), stageResults.getTissues());
        stageResults.reportAllMSE(stream, rankMax);
        stageResults.reportScoreCard(stream, rankMax);
        /*
        ResultModels larvaModels = new ResultModels(dir, "larva");
        VimpStage larvaResults = new VimpStage(larvaModels);
        stream.printf("\nlarva : %d cell types \ntissues : %s\n", larvaResults.getCellCount(), larvaResults.getTissues());
        larvaResults.reportAllMSE(stream, rankMax);
        larvaResults.reportScoreCard(stream, rankMax);

        ResultModels adultModels = new ResultModels(dir, "adult");
        VimpStage adultResults = new VimpStage(adultModels);
        stream.printf("\nadult : %d cell types \ntissues : %s\n", adultResults.getCellCount(), adultResults.getTissues());
        adultResults.reportAllMSE(stream, rankMax);
        adultResults.reportScoreCard(stream, rankMax);
         */
        int sdf = 0;
    }

    static double entropyAdjust(String stage, String tf, ExpressionTF expr, double d) {
        double eMax = VimpTissue.entropyMax(expr.getCellCount(stage));
        double entr = VimpTissue.entropy(VimpTissue.normalize(expr.getExpression(stage, tf)));

        d = d * (eMax - entr);
        return d;
    }

    public static void formHeatmapMatrices( File dir,ModelParams params, String stage) throws Exception {

        ExpressionTF exprTF = new ExpressionTF(params);

        ResultModels embModels = new ResultModels(dir, stage);
        VimpStage vimpStage = new VimpStage(embModels);

        for (String model : embModels.getModels()) {
            TreeMap<String, TreeMap<String, Double>> map = new TreeMap<>();
            TreeSet<String> tfs = new TreeSet<>();

            VimpModel vimpModel = vimpStage.getVimpModel(model);
            for (String tissue : vimpModel.getTissues()) {
                VimpTissue vimpTissue = vimpModel.getVimpTissue(tissue);
                for (String cell : vimpTissue.getCells()) {
                    TreeMap<String, Double> tfMap = map.get(cell);
                    if (tfMap == null) {
                        tfMap = new TreeMap<>();
                        map.put(cell, tfMap);
                    }
                    for (Vimp vimp : vimpTissue.getVimp(cell)) {
                        Double value = vimp.v;

                        if (value == Double.NEGATIVE_INFINITY) {
                            value = Double.NaN;
                        }

                        tfMap.put(vimp.tf, value);
                        tfs.add(vimp.tf);
                    }

                }
            }

            File modelDir = embModels.modelDir(model);
            PrintStream stream = new PrintStream(new File(modelDir, "Cell_TF_Vimp_Matrix.tsv"));

            // header
            stream.print("CellType");
            for (String tf : tfs) {
                stream.printf("\t%s", tf);
            }
            stream.println();
            for (String cell : map.keySet()) {
                stream.print(cell);
                TreeMap<String, Double> tfMap = map.get(cell);
                for (String tf : tfs) {
                    double d = tfMap.get(tf);
                    stream.printf("\t%.0f", d);
                }
                stream.println();
            }
            stream.close();

            stream = new PrintStream(new File(modelDir, "Cell_TF_VimpEntropy_Matrix.tsv"));
            // header
            stream.print("CellType");
            for (String tf : tfs) {
                stream.printf("\t%s", tf);
            }
            stream.println();
            for (String cell : map.keySet()) {
                stream.print(cell);
                TreeMap<String, Double> tfMap = map.get(cell);
                for (String tf : tfs) {
                    double d = tfMap.get(tf);
                    stream.printf("\t%.0f", entropyAdjust(stage, tf, exprTF, d));
                }
                stream.println();
            }
            stream.close();
        }
        int jhhh = 0;
    }

    public static void main(String[] args) throws Exception {
        /*
        File dir = new File("/net/waterston/vol9/ChipSeqPipeline/RF_Model_larva_Results");
        String[] stages = {"larva1","larva2","larva3","larva4","larva3Hypo","larva3Seam","larva4Sperm"};
        ModelParams params = new ModelParams("worm");
*/
        File dir = new File("/net/waterston/vol9/ChipSeqPipeline/RF_Model_flyMotif_Results");
        String[] stages = {"flyemb5"};
        ModelParams params = new ModelParams("fly");
        for (String stage : stages) {
            formHeatmapMatrices(dir,params, stage);
            report(stage, dir);
        }
    }
}
