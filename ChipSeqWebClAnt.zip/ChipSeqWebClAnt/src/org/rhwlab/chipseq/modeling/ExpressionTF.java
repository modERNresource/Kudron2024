/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import java.nio.file.Files;
import java.util.Set;
import java.util.TreeMap;
import org.rhwlab.chipseq.PeakTargetQuality;
import org.rhwlab.chipseq.peaks.StageGroups;
import org.rhwlab.gene.model.ModelGFF;
import org.rhwlab.lang.Greek;
import org.rhwlab.singlecell.expression.SingleCellExprMat;
import org.rhwlab.singlecell.expression.Translation;

/**
 *
 * @author gevirl
 */
public class ExpressionTF {

    TreeMap<String, TreeMap<String, double[]>> map = new TreeMap<>();  // stage -> tf -> cell expression vector
    TreeMap<String, TreeMap<String, Integer>> index = new TreeMap<>(); // stage -> cell >. column index

    public ExpressionTF(ModelParams params) throws Exception {
        for (String groupLabel : params.getGroupLabels()) {
            TreeMap<String, double[]> tfMap = new TreeMap<>();
            map.put(groupLabel, tfMap);

            TreeMap<String, Integer> cellIndex = new TreeMap<>();
            index.put(groupLabel, cellIndex);
            File file = params.tfExpressionFile(groupLabel);
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String[] heads = reader.readLine().split("\t");
            for (int i = 2; i < heads.length; ++i) {
                cellIndex.put(heads[i], i - 2);
            }

            String line = reader.readLine();
            while (line != null) {
                String[] tokens = line.split("\t");
                String tf = tokens[0];

                double[] expr = new double[tokens.length - 2];
                for (int i = 2; i < tokens.length; ++i) {
                    expr[i - 2] = Double.valueOf(tokens[i]);
                }
                tfMap.put(tf, expr);
                line = reader.readLine();
            }
            reader.close();
        }
    }

    public int getCellCount(String stage) {
        return index.get(stage).size();
    }

    public double[] getExpression(String stage, String tf) {
        return map.get(stage).get(tf);
    }

    public int getCellIndex(String stage, String cell) {
        return index.get(stage).get(cell);
    }

    public double getExpression(String stage, String cell, String tf) {
        double[] v = map.get(stage).get(tf);
        TreeMap<String, Integer> indexMap = index.get(stage);
        if (indexMap == null) {
            int hsafd = 0;
        }
        Integer cellIndex = indexMap.get(cell);
        if (cellIndex == null) {
            int asdhf = 0;
        }
        return v[index.get(stage).get(cell)];
    }

    public Set<String> getAllTFs(String stage) {
        TreeMap<String, double[]> stageMap = this.map.get(stage);
        if (stageMap == null) {
            int kkk = 0;
        }
        return stageMap.keySet();
    }

    static public void formTSV(ModelParams params, String cellsStage) throws Exception {

        Greek greek = new Greek();

        StageGroups groups = params.getStageGroups();
        File stageDir = params.stageDir(cellsStage);
        Files.createDirectories(stageDir.toPath());

        String exprStage = groups.getExprStage(cellsStage);
        SingleCellExprMat expMat = new SingleCellExprMat(exprStage);
        String[] cellTypes = expMat.getAllTypes();
        PrintStream stream = new PrintStream(new File(stageDir, "allTFsExpr.tsv"));  // TF expression for all cells 

        String group = groups.getChipGroup(cellsStage);
        ClusterRankedPeaks rankedPeaks = new ClusterRankedPeaks(params, group);

        Translation translator = params.getTranslation();
        ModelGFF gff = params.getGFF();

        // print the header
        stream.print("TF\tBaseGeneID");
        for (int i = 0; i < cellTypes.length; ++i) {
            stream.printf("\t%s", cellTypes[i]);
        }
        stream.println();

        // print each tf expression
        for (String tf : rankedPeaks.getAllTFs()) {
            String tfAlias = PeakTargetQuality.nameMap.get(tf);
            if (tfAlias == null) {
                tfAlias = tf;
            }
            if (tf.equals("CkIIα-i1")) {
                int sdjfhf = 0;
            }

            String chipBaseID = gff.getBaseGene(greek.translate(tfAlias));
            String exprBaseID = translator.getTranslatedBaseGene(chipBaseID);
            double[] expr = expMat.getGeneExpression(exprBaseID);

            double sum = 0.0;
            for (double e : expr) {
                sum = sum + e;
            }
            if (sum > 0.0) {
                stream.printf("%s\t%s", tf, exprBaseID);
                for (int i = 0; i < expr.length; ++i) {
                    stream.printf("\t%.1f", expr[i]);
                }
                stream.println();
            }
        }
        stream.close();

    }

    static public void main(String[] args) throws Exception {
        ModelParams params = new ModelParams("fly");
        formTSV(params, "flyemb5");

        int sadf = 0;
    }
}
