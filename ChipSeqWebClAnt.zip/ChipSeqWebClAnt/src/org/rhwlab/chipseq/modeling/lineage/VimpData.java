/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling.lineage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 *
 * @author gevirl
 */
public class VimpData implements CellGeneData {

    TreeMap<String, TreeMap<String, Double>> map = new TreeMap<>();  // cell -> TF -> value
    TreeSet<String> tfs = new TreeSet<>();


    public VimpData(String resource) throws Exception {
        InputStream stream = this.getClass().getResourceAsStream(resource);
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
        String line = reader.readLine();
        String[] heads = line.split("\t");
        line = reader.readLine();
        while (line != null) {
            String[] tokens = line.split("\t");
            TreeMap<String, Double> tfMap = new TreeMap<>();
            map.put(tokens[0], tfMap);

            for (int i = 1; i < tokens.length; ++i) {
                tfs.add(heads[i]);
                tfMap.put(heads[i], Double.valueOf(tokens[i]));
            }
            line = reader.readLine();
        }
        reader.close();
    }

    @Override
    public Double getValue(String cell, String gene) {
        Double ret = null;
        TreeMap<String, Double> tfMap = map.get(cell);
        if (tfMap != null) {
            ret = tfMap.get(gene);
        }
        return ret;
    }

    @Override
    public Set<String> getAllGenes() {
        return this.tfs;
    }

    public Set<String> getCells(){
        return this.map.keySet();
    }
    
    @Override
    public boolean hasCell(String cell) {
        return this.map.get(cell) != null;
    }
    
    public String root(SulstonCell embryoCell) {

        List<SulstonCell> ancestors = embryoCell.getAncestors();
        for (SulstonCell ancestor : ancestors){
            String cell = ancestor.getName();
            if (this.hasCell(cell)){
                return cell;
            }
        }
        return null;
    }
    public static void main(String[] args) throws Exception {

    }

}
