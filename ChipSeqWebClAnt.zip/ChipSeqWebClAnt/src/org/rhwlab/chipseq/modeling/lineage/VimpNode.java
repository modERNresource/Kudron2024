/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling.lineage;

import java.util.TreeMap;

/**
 *
 * @author gevirl
 */
class VimpNode implements Comparable {

    String label;
    TreeMap<String, Double> data = new TreeMap<>();

    public VimpNode(String[] heads, String[] tokens) {
        label = tokens[0];
        for (int i = 1; i < tokens.length; ++i) {
            data.put(heads[i], Double.valueOf(tokens[i]));
        }
    }

    public String getLabel() {
        return this.label;
    }

    @Override
    public int compareTo(Object o) {
        int ret = -100;

        String other = ((VimpNode) o).label;

        int l = Math.min(label.length(), other.length());
        for (int i = 0; i < l; ++i) {
            int c = Character.compare(label.charAt(i), other.charAt(i));
            if (c != 0) {
                ret = c;
                break;
            }
        }
        if (ret == -100) {
            char ch;
            if (label.length() < other.length()) {
                ch = other.charAt(label.length());
                if (ch == 'd' | ch == 'l' | ch == 'a') {
                    ret = 1;
                } else {
                    ret = -1;
                }
            } else if (label.length() > other.length()) {
                ch = label.charAt(other.length());
                if (ch == 'd' | ch == 'l' | ch == 'a') {
                    ret = -1;
                } else {
                    ret = 1;
                }
            } else {
                ret = 0;
            }

        }
        if (label.equals("MSa") | other.equals("MSa")) {
            System.out.printf("%s\t%s\t%d\n", label, other, ret);
        }
        return ret;
    }

    public String toString() {
        return label;
    }

}
