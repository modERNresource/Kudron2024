/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling.lineage;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.Book;
import java.awt.print.PageFormat;
import java.awt.print.PrinterJob;
import java.util.Set;
import javax.imageio.ImageIO;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 *
 * @author gevirl
 */
public class VimpMultiFullTreeFrame extends JFrame {

    RootPanel[] rootPanels;

    public VimpMultiFullTreeFrame(SulstonTree sulston, CellGeneData data, String[] lineageRoots, String[] tfs, ExpressionCellNames exprNames) throws Exception {
        rootPanels = new RootPanel[lineageRoots.length];

        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem printItem = new JMenuItem("Print");
        printItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                printActionPerformed(evt);
            }
        });
        menuBar.add(fileMenu);
        fileMenu.add(printItem);
        this.setJMenuBar(menuBar);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        ColorRamp ramp = new ColorRamp();

        GeneMultiFullTreeImage image = new GeneMultiFullTreeImage(lineageRoots, sulston, data, ramp, exprNames);
        for (int i = 0; i < lineageRoots.length; ++i) {
            rootPanels[i] = new RootPanel(image, lineageRoots[i], tfs);
            mainPanel.add(rootPanels[i]);
        }
        JScrollPane scroll = new JScrollPane(mainPanel);
        setContentPane(scroll);
        pack();

    }

    public void printActionPerformed(java.awt.event.ActionEvent event) {

        PrinterJob printJob = PrinterJob.getPrinterJob();
        PageFormat pf = printJob.defaultPage();
        pf.setOrientation(PageFormat.PORTRAIT);
        Book book = new Book();
        for (int i = 0; i < rootPanels.length; ++i) {
            book.append(rootPanels[i], pf);
        }
        printJob.setPageable(book);

        if (printJob.printDialog()) {
            try {
                printJob.print();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    static public void main(final String[] args) throws Exception {
        String[] formats = ImageIO.getWriterFormatNames();

        SulstonTree sulston = new SulstonTree();
        ExpressionCellNames exprNames = new ExpressionCellNames();
        VimpDataMultiSource data = new VimpDataMultiSource();
        Set<String> tfSet = data.getAllGenes();
        String lineageRoot = "MSaapp";
        String[] roots = {"MSaa", "MSap", "MSpa", "MSpp"};
//        String[] roots = {"MSap", "MSpp", "MSaaaaa", "MSpaaaa", "MSaapp", "MSpapp"};
//        String[] roots = {"MSaapp","MSpapp"};
/*
        EmbryoCell cell = (EmbryoCell) sulston.getCell(lineageRoot);
        ArrayList<EmbryoCell> cells = cell.getAllCellsDepthFirst();

        ArrayList<String> tfsToUse = new ArrayList<>();
        for (String tf : tfSet) {
            for (EmbryoCell c : cells) {
                Double v = data.getValue(c.getName(), tf);
                if (v != null) {
                    if (v != -1) {
                        tfsToUse.add(tf);
                        break;
                    }
                }
            }
        }
*/
        String[] tfs = {"ceh-34", "ceh-13", "tbx-2", "T22C8.4"};
//        String[] tfs = {"hnd-1", "hlh-1", "unc-120", "mab-5", "pat-9", "M03D4.4", "rnt-1"}; // for Cap
//        String[] tfs = {"blmp-1","bed-3","elt-1","elt-3","tra-4","ham-2","cnd-1","nhr-28","mep-1"};  // for Caa
//       String[] tfs = {};  // does all the tfs
        StringBuilder builder = new StringBuilder();
        builder.append(lineageRoot);
        builder.append("     ");
        for (String tf : tfs) {
            builder.append(tf);
            builder.append(" ");
        }
        EventQueue.invokeLater(new Runnable() {

            @Override
            public void run() {
                try {

                    if (tfs.length > 0) {
                        VimpMultiFullTreeFrame frame = new VimpMultiFullTreeFrame(sulston, data, roots, tfs, exprNames);
                        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        frame.setSize(1200, 500);
                        frame.setVisible(true);
//                        frame.setTitle(root);
/*
                        CellGeneFrame cellFrame = new CellGeneFrame(data.getData(0));
                        cellFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        cellFrame.setVisible(true);
*/

                    } else {
/*
                        int n = 15;
                        int i = 0;
                        int count = 0;
                        ArrayList<String> tfList = new ArrayList<>();
                        for (String tf : tfsToUse) {
                            ++count;
                            tfList.add(tf);
                            ++i;
                            if (i == n || count == tfsToUse.size()) {
                                i = 0;
                                VimpTreeFrame frame = new VimpTreeFrame(sulston, data, lineageRoot, tfList.toArray(new String[0]));
                                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                                frame.setSize(1800, 500);
                                frame.setVisible(true);
                                frame.setTitle(lineageRoot);
                                tfList.clear();
                            }
                        }
*/                        
                    }
                } catch (Exception exc) {
                    exc.printStackTrace();
                }
            }
        });

    }
}
