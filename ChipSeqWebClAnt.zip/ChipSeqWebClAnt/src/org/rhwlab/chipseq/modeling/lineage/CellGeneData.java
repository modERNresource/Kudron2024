/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling.lineage;

import java.util.Set;

/**
 *
 * @author gevirl
 */
public interface CellGeneData {
    public Double getValue(String cell,String gene);
    public Set<String> getAllGenes();
    public boolean hasCell(String cell);
    public Set<String> getCells();
}
