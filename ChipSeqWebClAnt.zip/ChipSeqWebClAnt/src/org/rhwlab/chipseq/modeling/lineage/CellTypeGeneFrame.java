/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling.lineage;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 *
 * @author gevirl
 */
public class CellTypeGeneFrame extends JFrame {

    VimpTreeFrame frame;
    JList<String> sulstonList;
    JList<String> cellList;
    JList<String> geneList;
    SulstonTree sulston;
    VimpData data;
    MurraySulstonCellClass murray;

    public CellTypeGeneFrame(VimpTreeFrame frame, MurraySulstonCellClass murray, VimpData data, SulstonTree sulston) {
        this.frame = frame;
        this.sulston = sulston;
        this.data = data;
        this.murray = murray;

        JPanel sulstonPanel = new JPanel();
        sulstonPanel.setLayout(new BoxLayout(sulstonPanel, BoxLayout.Y_AXIS));
        sulstonList = new JList(data.getCells().toArray(new String[0]));
        JScrollPane sulstonScroll = new JScrollPane(sulstonList);
        JButton sulstonButton = new JButton("Submit Sulston");
        sulstonButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    sulstonSelection();
                } catch (Exception exc) {
                    exc.printStackTrace();
                }
            }
        });
        sulstonPanel.add(sulstonScroll);
        sulstonPanel.add(sulstonButton);

        JPanel cellPanel = new JPanel();
        cellPanel.setLayout(new BoxLayout(cellPanel, BoxLayout.Y_AXIS));
        cellList = new JList(murray.getAllCellTypes().toArray(new String[0]));
        JScrollPane cellScroll = new JScrollPane(cellList);
        JButton cellButton = new JButton("Submit CellType");
        cellButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    cellSelection();
                } catch (Exception exc) {
                    exc.printStackTrace();
                }
            }
        });
        cellPanel.add(cellScroll);
        cellPanel.add(cellButton);

        String[] genes = data.getAllGenes().toArray(new String[0]);
        geneList = new JList(genes);
        JScrollPane geneScroll = new JScrollPane(geneList);

        JPanel selectPanel = new JPanel();
        selectPanel.setLayout(new BoxLayout(selectPanel, BoxLayout.X_AXIS));
        selectPanel.add(sulstonPanel);
        selectPanel.add(cellPanel);
        selectPanel.add(geneScroll);

        setContentPane(selectPanel);
        pack();
    }

    public void sulstonSelection() throws Exception {
        String[] roots = sulstonList.getSelectedValuesList().toArray(new String[0]);

        if (roots.length > 0) {
            StringBuilder builder = new StringBuilder();
            builder.append(roots[0]);
            for (int i = 1; i < roots.length; ++i) {
                builder.append(" : ");
                builder.append(roots[i]);
            }
            frame.setParams(builder.toString(), roots, geneList.getSelectedValuesList().toArray(new String[0]));
        }
    }

    public void cellSelection() throws Exception {
        List<String> selected = cellList.getSelectedValuesList();
        if (!selected.isEmpty()) {
            String[] sels = selected.toArray(new String[0]);
            StringBuilder builder = new StringBuilder();
            builder.append(sels[0]);
            for (int i = 1; i < sels.length; ++i) {
                builder.append(" : ");
                builder.append(sels[i]);
            }            
            
            Set<String> forDisplay = new TreeSet<>();
            for (String sel : selected) {
                Set<String> terminals = murray.getTerminal(sel);
                for (String terminal : terminals) {
                    SulstonCell sulstonCell = sulston.getCell(terminal);
                    forDisplay.add(data.root(sulstonCell));
                }
            }
            String[] roots = forDisplay.toArray(new String[0]);
            frame.setParams(builder.toString(), roots, geneList.getSelectedValuesList().toArray(new String[0]));
        }
    }
}
