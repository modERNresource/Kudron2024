/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling.lineage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.TreeMap;

/**
 *
 * @author gevirl
 */
public class SulstonCellClass {
    TreeMap<String,String> map = new TreeMap<>(); // Sulston -> CellClassLabels
    
    public SulstonCellClass()throws Exception {
        File file = new File("/net/waterston/vol9/ChipSeqPipeline/RF_Model_heatmaps/SulstonCellClass.tsv");
        BufferedReader reader = new BufferedReader(new FileReader(file));
        String line = reader.readLine(); // the headers
        line = reader.readLine();
        while(line != null){
            String[] tokens = line.split("\t");
            StringBuilder builder = new StringBuilder();
            boolean first = true;
            for (int i=1 ; i<tokens.length ; ++i){
                if (!tokens[i].equals("NA")){
                    if (!first){
                        builder.append(":");
                    }                    
                    builder.append(tokens[i]);
                    first = false;
                }
            }
            map.put(tokens[0], builder.toString());
            
            line = reader.readLine();
        }
        reader.close();
    }
    
    public String getLabel(String sulston){
        return map.get(sulston);
    }
    public static void main(String[] args) throws Exception {
        SulstonCellClass s = new SulstonCellClass();
        int hh=0;
    }
}
