/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling.lineage;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

/**
 *
 * @author gevirl
 */
public class GeneMultiFullTreeImage {

    CellGeneData data;
    ColorRamp ramp;
    String gene;
    SulstonTree sulston;

    int treeWidth;
    int maxDepth;
    int earliest;
    MurraySulstonCellClass cellClasses;
    int leafCellHeight = 15;  // the number of pixels to use for each leaf cell - determines the size of the tree in the vertical direction 
    int horizontalPixelsPerGene = 12; // deterimnes horizontal size of the image
    int verticalPixelsPerGene = 8;
    Graphics2D g2;
    Font boldFont;
    Font font;
    boolean labelLeaves = true;
    int labelSize = 300;

    ExpressionCellNames exprNames;

    public GeneMultiFullTreeImage(String[] lineageRoots, SulstonTree sulston, CellGeneData data, ColorRamp ramp, ExpressionCellNames exprNames) throws Exception {
        this.data = data;
        this.ramp = ramp;
        this.sulston = sulston;
        cellClasses = new MurraySulstonCellClass();
        this.exprNames = exprNames;
        maxDepth = 0;
        earliest = Integer.MAX_VALUE;
        for (String root : lineageRoots) {

            SulstonCell sulstonCell = sulston.getCell(root);
            int depth = sulstonCell.depth();
            if (depth < earliest) {
                earliest = depth;
            }
            int n = sulstonCell.maxDescendents();
            System.out.printf("%s\t%d\n", root, depth);
            if (n > maxDepth) {
                maxDepth = n;
            }
        }
        treeWidth = (maxDepth + 1) * (horizontalPixelsPerGene + 1);
    }

    public BufferedImage getImage(String root, String gene, boolean labels) throws Exception {

        int offset = 10;
        this.gene = gene;
        this.labelLeaves = labels;

        SulstonCell sulstonCell = sulston.getCell(root);
        int n = sulstonCell.depth();
        int start = (n - earliest) * (horizontalPixelsPerGene + 1);
        System.out.printf("%s\t%s\t%d\t%d\n", root, gene, n, start);

        // calculate the vertical size of the image        
        int nLeaves = sulstonCell.getLeaves().length;
        int h = nLeaves * leafCellHeight;

        int labelPixels = 0;
        if (labelLeaves) {
            labelPixels = labelSize;
        }

        // create the image
        BufferedImage image = new BufferedImage(treeWidth + labelPixels, h + 2 * offset, BufferedImage.TYPE_INT_ARGB);
        g2 = image.createGraphics();
        BasicStroke stroke = new BasicStroke(1);
        font = g2.getFont();
        boldFont = font.deriveFont(Font.BOLD);
        g2.setStroke(stroke);

        drawCell(sulstonCell, start, offset, h);

        return image;
    }

    private double drawCell(SulstonCell sulstonCell, double xLeft, double yUpper, double height) throws Exception {
        //       System.out.println(sulstonCell.getName());
        double horizontalLength = horizontalPixelsPerGene + 1;  // width for just this cell
        SulstonCell[] sulstonChildren = sulstonCell.getChildren().toArray(new SulstonCell[0]);
        double x = xLeft;
        double y = yUpper + height / 2;  // midpoint of the  height  of the image 

//        if (data.hasCell(sulstonCell.getName())) {
        if (sulstonChildren.length > 0) {
            // divide up the area based on the number of terminal children 
            int nLeaves0 = sulstonChildren[0].getLeaves().length;
            int nLeaves1 = sulstonChildren[1].getLeaves().length;
            int nTotal = nLeaves0 + nLeaves1;
            int h0 = (int) (height * (double) nLeaves0 / (double) nTotal);
            double h1 = height - h0;
            double nextX = x + horizontalLength;

            // draw the children
            double y0 = drawCell(sulstonChildren[0], nextX, yUpper, h0);
            double y1 = drawCell(sulstonChildren[1], nextX, yUpper + h0, h1);

            // draw the vertical segment that connects the children
            g2.setColor(Color.BLACK);
            g2.drawLine((int) nextX, (int) y0, (int) nextX, (int) y1);

        } else {
            // it is a leaf
            if (this.labelLeaves) {
                g2.setFont(font);
                String terminal = sulstonCell.getName();
                Double v = data.getValue(sulstonCell.getName(), gene);
                if (v == null & exprNames != null) {
                    String other = this.exprNames.getExprName(sulstonCell.getName());
                    if (other != null) {
                        if (data.getValue(other, gene) != null) {
                            g2.setFont(boldFont);
                        }
                    }
                }
                String label = String.format("%s : %s : %s", sulstonCell.getName(), cellClasses.getCellType(terminal), cellClasses.getTissueLabel(terminal));
                g2.setColor(Color.black);
                g2.drawString(label, treeWidth, (int) y + verticalPixelsPerGene);

            }
        }
        // draw the cell's rectangle      
        int xr = (int) x;
        int yr = (int) y;

        Double v = data.getValue(sulstonCell.getName(), gene);
        if (v == null & exprNames != null) {
            String other = this.exprNames.getExprName(sulstonCell.getName());
            if (other != null) {
                v = data.getValue(other, gene);
            }
        }
        Color c = Color.white;
        if (v != null) {
            c = ramp.getColor(v);
        }
        g2.setColor(c);
        Rectangle2D.Double r = new Rectangle2D.Double(xr, yr, horizontalPixelsPerGene, verticalPixelsPerGene);

        g2.fill(r);
        g2.setColor(Color.black);
        g2.drawRect(xr, yr, horizontalPixelsPerGene, verticalPixelsPerGene);

        if (v == null) {
            g2.drawLine(xr, yr, xr + horizontalPixelsPerGene, yr + verticalPixelsPerGene);
            g2.drawLine(xr, yr + verticalPixelsPerGene, xr + horizontalPixelsPerGene, yr);
        }
        xr = xr + horizontalPixelsPerGene;

        //       }
        return y;
    }

    public Double getData(SulstonCell sulstonCell) {
        Double v = data.getValue(sulstonCell.getName(), gene);
        if (v == null & exprNames != null) {
            String other = this.exprNames.getExprName(sulstonCell.getName());
            v = data.getValue(other, gene);
        }
        return v;
    }
}
