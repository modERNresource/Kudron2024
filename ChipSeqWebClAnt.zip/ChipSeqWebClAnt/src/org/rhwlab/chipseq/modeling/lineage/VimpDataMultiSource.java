/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling.lineage;

import java.io.File;
import java.util.Set;
import java.util.TreeSet;

/**
 *
 * @author gevirl
 */
public class VimpDataMultiSource implements CellGeneData {

    VimpData[] vimpSources;

    public VimpDataMultiSource() throws Exception {
        this(wormEmbryonicFiles);
    }

    public VimpDataMultiSource(String[] files) throws Exception {
        vimpSources = new VimpData[files.length];
        for (int i = 0; i < files.length; ++i) {
            vimpSources[i] = new VimpData(files[i]);
        }
    }

    public VimpData getData(int i) {
        return vimpSources[i];
    }

    @Override
    public Double getValue(String cell, String gene) {
        for (int i = 0; i < vimpSources.length; ++i) {
            Double v = vimpSources[i].getValue(cell, gene);
            if (v != null) {
                return v;
            }
        }
        return null;
    }

    @Override
    public Set<String> getAllGenes() {
        Set<String> ret = new TreeSet<>();
        for (int i = 0; i < vimpSources.length; ++i) {
            ret.addAll(vimpSources[i].getAllGenes());
        }
        return ret;
    }

    public Set<String> getCells() {
        Set<String> ret = new TreeSet<>();
        for (int i = 0; i < vimpSources.length; ++i) {
            ret.addAll(vimpSources[i].getCells());
        }
        return ret;
    }

    @Override
    public boolean hasCell(String cell) {
        for (int i = 0; i < vimpSources.length; ++i) {
            if (vimpSources[i].hasCell(cell)) {
                return true;
            }
        }
        return false;
    }

    static public void main(String[] args) throws Exception {
        VimpDataMultiSource vimp = new VimpDataMultiSource();
        int hh = 0;
    }

    static String[] wormEmbryonicFiles = {"/org/rhwlab/chipseq/modeling/lineage/lineage.tsv",
        "/org/rhwlab/chipseq/modeling/lineage/emb.tsv"};
}
