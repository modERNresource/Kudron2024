/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

import java.io.PrintStream;
import java.util.TreeMap;
import org.rhwlab.gene.model.ModelGFF;

/**
 *
 * @author gevirl
 */
public class FlyTargetGenes {
    static public void main(String[] args) throws Exception {
        TreeMap<String,String> map = new TreeMap<>();
        ModelParams params = new ModelParams("fly");
        
        ModelGFF gff = params.getGFF();
        TreeMap<String, TargetDescription> targetDescMap = params.getTargetDescMap();
        for (TargetDescription desc : targetDescMap.values()){
            String gene = desc.getGene();
            String baseGene = gff.getBaseGene(gene);
            String current = map.get(gene);
            if (current == null){
                map.put(gene, baseGene);
            } else if (!current.equals(baseGene)){
                System.out.printf("%s -> %s\t%s",gene, current,baseGene);
            }
        }
        PrintStream stream = new PrintStream("/net/waterston/vol9/ChipSeqPipeline/flyTargetFBGenes.tsv");
        for (String gene : map.keySet()){
            stream.printf("%s\t%s\n", gene,map.get(gene));
        }
        stream.close();
    }
}
