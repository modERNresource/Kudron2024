/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

/**
 *
 * @author gevirl
 */
public class Clusters_2_30 implements FilterCluster {

    @Override
    public boolean accept(TargetedCluster cluster) {
        int nPeaks = cluster.getPeakCount();
        return 2<=nPeaks && nPeaks<=30;
    }

    @Override
    public String getLabel() {
        return "cluster_2_30";
    }
    
}
