/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

import java.io.PrintStream;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 *
 * @author gevirl
 */
public class Predictor {

    String clusterID;
    String targetGene;  
    String baseGene;  // base name for target gene
    TreeMap<String, Number> values;  // tf -> value

    public Predictor() {
        values = new TreeMap<>();
    }

    public Predictor(String[] heads, String[] tokens) {
        this();
        this.clusterID = tokens[0];
        this.targetGene = tokens[1];
        this.baseGene = tokens[2];
        for (int i = 3; i < heads.length; ++i) {
            if (!tokens[i].equals("0")) {
                values.put(heads[i], Double.valueOf(tokens[i]));
            }
        }
    }

    public void setClusterID(String id) {
        this.clusterID = id;
    }

    public void setTargetGene(String gene) {
        this.targetGene = gene;
    }

    public String getTargetGene() {
        return targetGene;
    }

    public void setBaseGene(String baseGene) {
        this.baseGene = baseGene;
    }

    public void setValue(String tf, Number Value) {
        values.put(tf, Value);
    }

    public int getCount() {
        return values.size();
    }

    static public void printHeader(PrintStream stream, TreeSet<String> allTFs) {
        stream.print("cluster\tgene\tBaseGene");
        for (String tf : allTFs) {
            stream.printf("\t%s", tf);
        }
        stream.println();
    }

    public void print(PrintStream stream, TreeSet<String> allTFs) {
        stream.printf("%s\t%s\t%s", clusterID, targetGene, baseGene);
        for (String tf : allTFs) {
            Number value = values.get(tf);
            if (value != null) {
                printValue(stream, value);
            } else {
                stream.print("\t0");
            }
        }
        stream.println();
    }

    static public void printValue(PrintStream stream, Number value) {
        if (value instanceof Double) {
            stream.printf("\t%f", (Double) value);
        } else if (value instanceof Integer) {
            stream.printf("\t%d", (Integer) value);
        } else {
            stream.print("\tunk");
        }
    }
}
