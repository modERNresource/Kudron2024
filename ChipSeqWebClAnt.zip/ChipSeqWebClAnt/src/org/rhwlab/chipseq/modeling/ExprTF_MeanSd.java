/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

import org.apache.commons.math3.stat.StatUtils;

/**
 *
 * @author gevirl
 */
public class ExprTF_MeanSd implements FilterTF {
    ExpressionTF expr;
    double nsd; // number of sd above mean to use as threshhold 
    
    public ExprTF_MeanSd(ExpressionTF expr,double nsd) {
        this.expr = expr;
        this.nsd = nsd;
    }
    @Override
    public boolean accept(String stage, String cell, String tf) {
        double[] v = expr.getExpression(stage, tf);
        double mu = StatUtils.mean(v);
        double sd = Math.sqrt(StatUtils.variance(v, mu));
        int index = expr.getCellIndex(stage, cell);
        return v[index] >= mu + nsd*sd;
    }

    @Override
    public String getLabel() {
        return String.format("ExprTF_MeanSd_%.1f",nsd);
    }
    
}
