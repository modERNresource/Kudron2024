/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

import org.rhwlab.bedformat.BedBase;

/**
 *
 * @author gevirl
 */
public class RankedPeak extends BedBase {
    public RankedPeak(String[] tokens){
        super(tokens);
    }
    
    public Double getRank(){
        return Double.valueOf(this.getValue(7));
    }
    public String getClusterID(){
        return this.getValue(10);
    }
    public String getTF(){
        return this.getName().split("_")[0];
    }
    public String getStage(){
        return this.getName().split("_")[2];
    }
}
