/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 *
 * @author gevirl
 */
public class VimpComparisonMatrix_1 {

    List<String> models;
    File dir;
    String stage;
    String tissue;

    int nModels = 4;
    TreeMap<String, Integer> cellIndex = new TreeMap<>();

    public VimpComparisonMatrix_1(ResultModels resultModels, String tissue) throws Exception {

        this.models = resultModels.models;
        this.tissue = tissue;
        this.dir = resultModels.dir;
        this.stage = resultModels.stage;

        //find a model that has been run for the tissue
        String modelToUse = null;
        for (String model : resultModels.getModels()) {
            File resultFile = vimpFile(model);
            if (resultFile.exists()) {
                modelToUse = model;
                break;
            }
        }

        // get a result file to build the celltype headings index
        File resultFile = vimpFile(modelToUse);
        BufferedReader reader = new BufferedReader(new FileReader(resultFile));
        String[] heads = reader.readLine().split("\t");
        reader.close();

        for (int i = 1; i < heads.length; ++i) {
            cellIndex.put(heads[i], i);
        }
    }

    public static List<VimpComparisonMatrix_1> allTissueMatrices(ResultModels resultModels) throws Exception {
        List<VimpComparisonMatrix_1> ret = new ArrayList<>();

        // build a list of tissues that have been run for at least on model
        TreeSet<String> tissues = new TreeSet<>();
        for (String model : resultModels.getModels()) {
            File modelDir = resultModels.modelDir(model);
            for (File tsv : modelDir.listFiles()) {
                if (tsv.getName().endsWith(".vimp.tsv")) {
                    tissues.add(tsv.getName().replace(".vimp.tsv", ""));

                }
            }
        }
        // build all the matrices by tissue
        for (String tissue : tissues) {
            ret.add(new VimpComparisonMatrix_1(resultModels, tissue));
        }
        return ret;
    }

    public Set<String> getCellTypes() {
        return this.cellIndex.keySet();
    }

    public File vimpFile(String m) {
        return new File(String.format("%s/%s/%s/%s.vimp.tsv", dir.getPath(), stage, m, tissue));
    }

    public File errorFile(String m) {
        return new File(String.format("%s/%s/%s/%s.err.tsv", dir.getPath(), stage, m, tissue));
    }

    public TreeMap<String, Double> readErrorFile(String model) throws Exception {
        File errFile = errorFile(model);
        if (!errFile.exists()) {
            return null;
        }

        TreeMap<String, Double> cellMap = new TreeMap<>();   // cellType-> model error 

        BufferedReader reader = new BufferedReader(new FileReader(errFile));
        String[] heads = reader.readLine().split("\t");
        String line = reader.readLine();
        while (line != null) {
            String[] tokens = line.split("\t");
            cellMap.put(tokens[0], Double.valueOf(tokens[1]));
            line = reader.readLine();
        }
        reader.close();
        return cellMap;
    }

    public Vimp[] readVimpFile(String model, String cell, ExpressionTF expr, boolean entropyAdjustment) throws Exception {
        Vimp[] vimps = null;
        int c = this.cellIndex.get(cell);
        double eMax = entropyMax(expr.getCellCount(stage));
        ArrayList<String[]> rows = new ArrayList<>();
        File vimpFile = vimpFile(model);
        if (!vimpFile.exists()) {
            System.out.printf("Not found: %s\n", vimpFile.getPath());
        } else {
            BufferedReader reader = new BufferedReader(new FileReader(vimpFile));
            String[] heads = reader.readLine().split("\t");
            String line = reader.readLine();
            while (line != null) {
                rows.add(line.split("\t"));
                line = reader.readLine();
            }
            reader.close();

            vimps = new Vimp[rows.size()];
            int i = 0;
            for (String[] row : rows) {
                String tf = row[0];
                String v = row[c];
                Double d = Double.NEGATIVE_INFINITY;
                if (!v.equals("NA")) {
                    d = Double.valueOf(v);
                }
                double entr = entropy(normalize(expr.getExpression(stage, tf)));
                if (entropyAdjustment) {
//                        d = d / (1.0 + entr);
                    d = d * (eMax - entr);
                }
                vimps[i] = new Vimp(tf, d);
                ++i;
            }
            Arrays.sort(vimps);
        }
        return vimps;
    }

    public void reportCell(PrintStream stream, String cell, int nToReport, int report, ExpressionTF expr, boolean entropy) throws Exception {

        TreeMap<String, Vimp[]> vimpMap = new TreeMap<>(); // model -> vimp vector
        TreeMap<String, TreeMap<String, Double>> errorMap = new TreeMap<>(); // model -> cell -> error

        stream.printf("\nStage: %s\tTissue: %s\tCellType: %s\n", stage, tissue, cell);

        // read the vimp files and find the best model
        List<String> cellModels = new ArrayList<>();
        double mn = Double.MAX_VALUE;
        String mnModel = null;
        for (String model : models) {
            TreeMap<String, Double> errMap = readErrorFile(model);
            if (errMap != null) {
                cellModels.add(model);
                errorMap.put(model, errMap);
                double e = errorMap.get(model).get(cell);
                if (e < mn) {
                    mnModel = model;
                    mn = e;
                }
                Vimp[] vimps = readVimpFile(model, cell, expr, entropy);
                vimpMap.put(model, vimps);
            }
        }

        // add the best model to the end of the list of models
        cellModels.add(mnModel);

        // print the headers
        for (int i = 0; i < nModels; ++i) {
            boolean first = true;
            for (String model : cellModels) {
                String[] tokens = model.split("/");
                if (!first) {
                    stream.print("\t");
                }
                stream.printf("%s", tokens[i]);
                first = false;
            }
            stream.println();
        }

        // print the errors
        stream.println();
        boolean first = true;
        for (String model : cellModels) {
            TreeMap<String, Double> em = errorMap.get(model);
            if (em == null) {
                int iasdf = 0;
            }
            Double d = errorMap.get(model).get(cell);
            if (d == null) {
                int jj = 0;
            }
            double e = errorMap.get(model).get(cell);
            if (!first) {
                stream.print("\t");
            }
            if (mnModel.equals(model)) {
                stream.printf("*%.0f", e / 1000.0);
            } else {
                stream.printf("%.0f", e / 1000.0);
            }
            first = false;
        }
        stream.print("\n\n");

        // print the top n
        TreeMap<String, Integer> tfCountMap = new TreeMap<>();
        for (int i = 0; i < nToReport; ++i) {

            first = true;
            for (String model : cellModels) {
                Vimp[] vimps = vimpMap.get(model);
                String tf = vimps[i].tf;
                Double v = vimps[i].v;
                Integer count = tfCountMap.get(tf);
                if (count == null) {
                    tfCountMap.put(tf, 1);
                } else {
                    tfCountMap.put(tf, count + 1);
                }
                if (!first) {
                    stream.print("\t");
                }
                if (report == 2) {
                    double ent = entropy(normalize(expr.getExpression(stage, tf)));
                    stream.printf("%s:%.3f", tf, ent);
                } else if (report == 1) {
                    stream.printf("%s:%.0f", tf, v / 1000);
                } else {
                    stream.printf("%s", tf);
                }
                first = false;
            }
            stream.println();
        }
    }

    public String getStage() {
        return this.stage;
    }

    static double entropy(double[] p) {
        double e = 0.0;
        for (int i = 0; i < p.length; ++i) {
            if (p[i] > 0.0) {
                e = e - p[i] * Math.log(p[i]);
            }
        }
        return e;
    }

    static double entropyMax(int n) {
        return Math.log(n);
    }

    static double[] normalize(double[] x) {
        double[] r = new double[x.length];

        double sum = 0.0;
        for (int i = 0; i < x.length; ++i) {
            sum = sum + x[i];
        }
        for (int i = 0; i < x.length; ++i) {
            r[i] = x[i] / sum;
        }
        return r;
    }

    class ModelError implements Comparable {

        String model;
        Double error;

        public ModelError(String model, Double error) {
            this.model = model;
            this.error = error;
        }

        @Override
        public int compareTo(Object o) {
            ModelError oe = (ModelError) o;
            return error.compareTo(oe.error);
        }

    }

    public static void main(String[] args) throws Exception {

        String species = "worm";
        ModelParams params = new ModelParams(species);
        ExpressionTF expr = new ExpressionTF(params);

        File dir = new File("/net/waterston/vol9/ChipSeqPipeline/RF_Model_3_Results");
        List<VimpComparisonMatrix_1> list;

        //       ResultModels embModels = new ResultModels(dir, "emb");

        list = allTissueMatrices(new ResultModels(dir, "emb"));
        list.addAll(allTissueMatrices(new ResultModels(dir, "larva")));
        list.addAll(allTissueMatrices(new ResultModels(dir, "lineage")));
        list.addAll(allTissueMatrices(new ResultModels(dir, "adult"))); 

/*        
        ResultModels flyembModels = new ResultModels(dir, "flyemb");
        list = allTissueMatrices(flyembModels);
 */       
         
        VimpComparisonMatrix_1[] mat = list.toArray(new VimpComparisonMatrix_1[0]);
        PrintStream stream = new PrintStream(String.format("/net/waterston/vol9/ChipSeqPipeline/RF_Model_Submit/Vimp_%s.txt",species));
        for (VimpComparisonMatrix_1 m : mat) {
            for (String cellType : m.getCellTypes()) {
                m.reportCell(stream, cellType, 20, 1, expr, false);
            }
        }
        stream.close();

        stream = new PrintStream(String.format("/net/waterston/vol9/ChipSeqPipeline/RF_Model_Submit/Entropy_%s.txt",species));
        for (VimpComparisonMatrix_1 m : mat) {
            for (String cellType : m.getCellTypes()) {
                m.reportCell(stream, cellType, 20, 2, expr, false);
            }
        }
        stream.close();

        stream = new PrintStream(String.format("/net/waterston/vol9/ChipSeqPipeline/RF_Model_Submit/VimpEntropy_%s.txt",species));
        for (VimpComparisonMatrix_1 m : mat) {
            for (String cellType : m.getCellTypes()) {
                m.reportCell(stream, cellType, 20, 1, expr, true);
            }
        }
        stream.close();

        int sadf = 0;
    }
}
