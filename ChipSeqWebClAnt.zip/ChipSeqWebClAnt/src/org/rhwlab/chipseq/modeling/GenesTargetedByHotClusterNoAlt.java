/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

import java.io.PrintStream;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 *
 * @author gevirl
 */
public class GenesTargetedByHotClusterNoAlt {

    TreeMap<String, TargetDescription> targetDescMap;
    Set<String> hotTargetGenes = new TreeSet<>();  // these are the hot target hotTargetGenes
    Set<String> primaryGenes = new TreeSet<>();
    Set<String> primaryHotGenes = new TreeSet<>();

    public GenesTargetedByHotClusterNoAlt(ModelParams params) throws Exception {

        this.targetDescMap = params.getTargetDescMap();
        TreeMap<String, TargetedCluster> primClustersMap = PredictorMatrix_1.asCluster(PredictorMatrix_1.readFile(params.getPrimaryTargetFile(), false, 3));

        int maxPeaks = 277;
        if (params.isWorm()) {
            maxPeaks = 84;
        }
        for (TargetedCluster cluster : primClustersMap.values()) {
            int nPeaks = cluster.getPeakCount();
            String gene = getGene(cluster);
            primaryGenes.add(gene);

            if (nPeaks > maxPeaks) {
                hotTargetGenes.add(gene);
                this.primaryHotGenes.add(gene);
            }
        }
    }

    public boolean hotTarget(TargetedCluster cluster) {
        String gene = getGene(cluster);
        return hotTargetGenes.contains(gene);
    }

    public String getGene(TargetedCluster cluster) {
        String targetID = cluster.getTargetID();
        TargetDescription desc = targetDescMap.get(targetID);
        return desc.getGene();
    }

    public Set<String> getGenes() {
        return hotTargetGenes;
    }

    static public void main(String[] args) throws Exception {
        PrintStream stream = new PrintStream("/net/waterston/vol9/ChipSeqPipeline/FlyPrimaryTargetGenesWithHot");
        ModelParams params = new ModelParams("fly");


        TreeMap<String, TargetDescription> targetDescMap = PredictorMatrix_1.asTarget(PredictorMatrix_1.readFile(params.getTargetDescFile(), true, 0));
        Set<String> genes = new GenesTargetedByHotClusterNoAlt(params).getGenes();
        for (String gene : genes){
            stream.println(gene);
        }
        stream.close();
        
        int asdf = 0;
    }
}
