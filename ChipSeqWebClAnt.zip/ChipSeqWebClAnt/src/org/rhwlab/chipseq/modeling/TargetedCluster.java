/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

import org.rhwlab.bedformat.BedBase;

/**
 *
 * @author gevirl
 */
public class TargetedCluster extends BedBase{
    public TargetedCluster(String[] tokens){
        super(tokens);
    }
    
    public String getClusterID(){
        return this.getValue(11);
    }
    
    public int getDistanceToTarget(){
        return Integer.valueOf(this.getValue(10));
    }
    
    public String getTargetID(){
        return this.getValue(9);
    }
    
    public int getPeakCount(){
        return Integer.valueOf(this.getValue(4));
    }    
    
}
