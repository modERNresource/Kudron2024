/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Set;
import java.util.TreeMap;

/**
 *
 * @author gevirl
 */
// matrix of vimp values for cells of a stage/tissue
public class VimpTissue {

    File tsv;
    TreeMap<String, Vimp[]> cellMap = new TreeMap<>();

    public VimpTissue(File tsv) throws Exception {
 //       System.out.println(tsv.getPath());
        this.tsv = tsv;
        ArrayList<String[]> rows = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new FileReader(tsv));
        String[] heads = reader.readLine().split("\t");
        String line = reader.readLine();
        while (line != null) {
            rows.add(line.split("\t"));
            line = reader.readLine();
        }
        reader.close();

        for (int c = 1; c < heads.length; ++c) {
//            System.out.println(c);
            Vimp[] vimps = new Vimp[rows.size()];
            int i = 0;
            for (String[] row : rows) {
                String tf = row[0];
                String v = row[c];
                double d = Double.NEGATIVE_INFINITY;
                if (!v.equals("NA")) {
                    d = Double.valueOf(v);
                }
                vimps[i] = new Vimp(tf, d);
                ++i;
            }
            Arrays.sort(vimps);
            cellMap.put(heads[c],vimps);
        }
    }
    
    public Set<String> getCells(){
        return this.cellMap.keySet();
    }

    public Vimp[] getVimp(String cell){
        return cellMap.get(cell);
    }
    public String getTissue() {
        return tsv.getName().replace(".vimp.tsv", "");
    }

    static double entropy(double[] p) {
        double e = 0.0;
        for (int i = 0; i < p.length; ++i) {
            if (p[i] > 0.0) {
                e = e - p[i] * Math.log(p[i]);
            }
        }
        return e;
    }

    static double entropyMax(int n) {
        return Math.log(n);
    }

    static double[] normalize(double[] x) {
        double[] r = new double[x.length];

        double sum = 0.0;
        for (int i = 0; i < x.length; ++i) {
            sum = sum + x[i];
        }
        for (int i = 0; i < x.length; ++i) {
            r[i] = x[i] / sum;
        }
        return r;
    }    
}
