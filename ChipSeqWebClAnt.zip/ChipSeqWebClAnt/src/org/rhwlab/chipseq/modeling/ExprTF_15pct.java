/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.rhwlab.chipseq.modeling;

/**
 *
 * @author gevirl
 */
public class ExprTF_15pct extends ExprTF_pct{
    public ExprTF_15pct(ExpressionTF expr) throws Exception {
        super(expr, 0.15);
    }

    @Override
    public String getLabel() {
        return "expressing_15pct";
    }    
}
