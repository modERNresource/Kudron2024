/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

/**
 *
 * @author gevirl
 */
public interface FilterTF {
    public boolean accept(String stage,String cell,String tf);
    public String getLabel();
    
    static public FilterTF[] allFilters(ExpressionTF exprTF)throws Exception {
        FilterTF[] ret = {new NonZeroExpressingTFs(exprTF), new ExprTF_5pct(exprTF)};
        return ret;
    }
    
    
}
