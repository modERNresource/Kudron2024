/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

import java.util.TreeMap;

/**
 *
 * @author gevirl
 */
public class Clusters_2_30_Strict extends Clusters_2_30 {
    TreeMap<String, TargetDescription> map;
    
    public Clusters_2_30_Strict(TreeMap<String, TargetDescription> targetDescMap){
        this.map = targetDescMap;
    }
    
    @Override
    public boolean accept(TargetedCluster cluster) {
        boolean ret = super.accept(cluster);
        if (ret){
            ret = cluster.getDistanceToTarget() >= -2000 ;
            if (ret){
                TargetDescription desc = map.get(cluster.getTargetID());
                String loc = desc.getGenLoc();
                ret = loc.equals("5P") || loc.equals("E1") || loc.equals("I1") ;
            }               
        }
        return ret;
    }
    
    @Override
    public String getLabel() {
        return super.getLabel() + "_Strict";
    }
}
