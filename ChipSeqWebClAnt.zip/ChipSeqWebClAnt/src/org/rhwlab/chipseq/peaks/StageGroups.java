/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.peaks;

import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 *
 * @author gevirl
 */
abstract public class StageGroups {

  
    TreeMap<String, String> chipToGroup = new TreeMap<>();
    TreeMap<String, String> cellToGroup = new TreeMap<>();

    public TreeSet<String> getGroups() {
        return new TreeSet(this.chipToGroup.values());
    }

    public String getGroup(String chipStage) {
        return chipToGroup.get(chipStage);
    }
    
    public String getChipGroup(String cell){
        return cellToGroup.get(cell);
    }
    
    public Set<String> getCellStages(){
        return cellToGroup.keySet();
    }
    
    abstract public String getExprStage(String cellsStage);
        
    
}
