/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.peaks;

import java.util.List;
import org.rhwlab.chipseq.pipeline.ExperimentPeakRecord;
import org.rhwlab.chipseq.pipeline.OptimalPeaks;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipHelper;
import org.rhwlab.chipseqweb.HibernateUtil;

/**
 *
 * @author gevirl
 */
public class OptimalPeaksSummary {
    public static void main(String[] args)throws Exception {
        OptimalPeaks opPeaks = new OptimalPeaks();
        int i=1;
        System.out.println("Gene\tStrain\tStage\tPeaks");
        for (ExperimentPeakRecord rec : opPeaks.getFlyPeaks()){
            List list = ChipHelper.getEquals("ChipExperiment", "ExpID", rec.getID(), "ExpID");
            ChipExperiment exp = (ChipExperiment)list.get(0);
            System.out.printf("%s\t%s\t%s\t%d\n", exp.getGene(),exp.getStrain(),exp.getStage(),rec.getCount());
            ++i;
        }
        HibernateUtil.shutdown();
    }
}
