/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.peaks;

/**
 *
 * @author gevirl
 */
public class FlyStageGroups extends StageGroups {
    public FlyStageGroups(){
        chipToGroup.put("embryonic", "flyemb");
        chipToGroup.put("pupa", "pupa");
        chipToGroup.put("prepupa", "pupa");
        chipToGroup.put("wanderingthirdinstarlarva", "flylarva");
        chipToGroup.put("larva", "flylarva");
        chipToGroup.put("adult", "flyadult");
        
        cellToGroup.put("flyemb", "flyemb");
        cellToGroup.put("flyemb2", "flyemb");
        cellToGroup.put("flyemb3", "flyemb");
        cellToGroup.put("flyemb4", "flyemb");
        cellToGroup.put("flyemb5", "flyemb");
    }

    @Override
    public String getExprStage(String cellsStage) {
        if (cellsStage.equals("flyemb2")){
            return "FlyEmb2";
        }
        if (cellsStage.equals("flyemb3")){
            return "FlyEmb3";
        }       
        if (cellsStage.equals("flyemb4")){
            return "FlyEmb4";
        }        
        if (cellsStage.equals("flyemb5")){
            return "FlyEmb5";
        }           
        return "FlyEmb";
    }
}
