
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author gevirl
 */
public class Test {
    static public void main(String[] args) throws Exception{
        URL url = 
      new URL("http://fcb.ycga.yale.edu:3010/AtfGiMpdxK5PBrrsAf2mvQhJh2_1Y/sample_dir_000002849/Sample_LN38IP1_312_265/LN38IP1_312_265_S25_L002_R2_001.fastq.gz");
        URLConnection conn = url.openConnection();
        long l = conn.getContentLengthLong();
        InputStream stream = conn.getInputStream();
        
    }
}
