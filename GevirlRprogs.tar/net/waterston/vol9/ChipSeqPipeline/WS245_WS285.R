library(tidyverse)

tsv <- read_tsv(file="/net/waterston/vol9/WS245_WS285.tsv",col_names = TRUE)

nrow(distinct(filter(tsv,Biotype245=="protein_coding"),WBGene245))
nrow(distinct(filter(tsv,Biotype285=="protein_coding"),WBGene285))

nrow(distinct(filter(tsv,WBGene245!="null"),WBGene245))
nrow(distinct(filter(tsv,WBGene285!="null"),WBGene285))

nrow(filter(tsv,WBGene245=="null"))
nrow(filter(tsv,WBGene285=="null"))
nrow(filter(tsv,WBGene245!=WBGene285))

nrow(filter(tsv,WBGene245==WBGene285,Common245!=Common285))

View(filter(tsv,Biotype245!=Biotype285))
View(filter(tsv,WBGene245!=WBGene285))
View(filter(tsv,WBGene245=="null"))
View(filter(tsv,WBGene285=="null"))