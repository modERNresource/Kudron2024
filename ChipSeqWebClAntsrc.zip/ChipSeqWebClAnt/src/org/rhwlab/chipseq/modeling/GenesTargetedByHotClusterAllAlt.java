/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

import java.io.PrintStream;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 *
 * @author gevirl
 */
public class GenesTargetedByHotClusterAllAlt {

    TreeMap<String, TargetDescription> targetDescMap;
    Set<String> hotTargetGenes = new TreeSet<>();  // these are the hot target hotTargetGenes
    Set<String> primaryGenes = new TreeSet<>();
    Set<String> altGenes = new TreeSet<>();
    Set<String> bothGenes = new TreeSet<>();
    Set<String> primaryHotGenes = new TreeSet<>();
    Set<String> altHotGenes = new TreeSet<>();
    Set<String> altNotPrimHotGenes = new TreeSet<>();
    Set<String> bothHotGenes = new TreeSet<>();

    public GenesTargetedByHotClusterAllAlt(ModelParams params, TreeMap<String, TargetDescription> targetDescMap) throws Exception {

        this.targetDescMap = targetDescMap;
        TreeMap<String, TargetedCluster> altClustersMap = PredictorMatrix_1.asCluster(PredictorMatrix_1.readFile(params.getAlternateTargetFile(), false, 3));
        TreeMap<String, TargetedCluster> primClustersMap = PredictorMatrix_1.asCluster(PredictorMatrix_1.readFile(params.getPrimaryTargetFile(), false, 3));

        int maxPeaks = 277;
        if (params.isWorm()) {
            maxPeaks = 84;
        }
        for (TargetedCluster cluster : primClustersMap.values()) {
            int nPeaks = cluster.getPeakCount();
            String gene = getGene(cluster);
            primaryGenes.add(gene);

            if (nPeaks > maxPeaks) {
                hotTargetGenes.add(gene);
                this.primaryHotGenes.add(gene);
            }
        }

        for (TargetedCluster altCluster : altClustersMap.values()) {

            int nPeaks = altCluster.getPeakCount();
            String gene = getGene(altCluster);
            altGenes.add(gene);

            if (primaryGenes.contains(gene)) {
                bothGenes.add(gene);
            }
            if (nPeaks > maxPeaks) {
                hotTargetGenes.add(gene);
                this.altHotGenes.add(gene);
                if (this.primaryHotGenes.contains(gene)) {
                    this.bothHotGenes.add(gene);
                } else {
                    this.altNotPrimHotGenes.add(gene);
                }
            }

        }

    }

    public boolean hotTarget(TargetedCluster cluster) {
        String gene = getGene(cluster);
        return hotTargetGenes.contains(gene);
    }

    public String getGene(TargetedCluster cluster) {
        String targetID = cluster.getTargetID();
        TargetDescription desc = targetDescMap.get(targetID);
        return desc.getGene();
    }

    public Set<String> getGenes() {
        return hotTargetGenes;
    }

    static public void main(String[] args) throws Exception {
        ModelParams params = new ModelParams("worm");

        TreeMap<String, TargetDescription> targetDescMap = PredictorMatrix_1.asTarget(PredictorMatrix_1.readFile(params.getTargetDescFile(), true, 0));
        Set<String> genes = new GenesTargetedByHotClusterCloseAlt(params, targetDescMap).getGenes();
        int asdf = 0;
    }
}
