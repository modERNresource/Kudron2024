/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

import java.io.File;
import java.util.Set;
import java.util.TreeMap;

/**
 *
 * @author gevirl
 */
// vimp data for a model 
public class VimpModel {

    File modelDir;
    TreeMap<String,VimpTissue> vimpMap = new TreeMap<>(); //tissue -> VimpTissue
    TreeMap<String,Mse> mseMap = new TreeMap<>();  // tissue -> MSE for each cell

    public VimpModel(File modelDir) throws Exception {
        this.modelDir = modelDir;
        for (File tsv : modelDir.listFiles()) {
            if (tsv.getName().contains("vimp.tsv")) {
                VimpTissue mat = new VimpTissue(tsv);
                String tissue = mat.getTissue();
                vimpMap.put(tissue, mat);
                File errTSV = new File(tsv.getPath().replace(".vimp.", ".err."));
                Mse mse = new Mse(errTSV);
                mseMap.put(tissue, mse);
            }
        }
    }
    
    public VimpTissue getVimpTissue(String tissue){
        return vimpMap.get(tissue);
    }
    public TreeMap<String,Double> allMSE(){
        TreeMap<String,Double> allMseMap = new TreeMap<>();  // cellType -> mse
        for (String tissue : mseMap.keySet() ){
            Mse mse = mseMap.get(tissue);
            for (String cellType : mse.getCellTypes()){
                allMseMap.put(cellType, mse.getMSE(cellType));
            }
        }
        return allMseMap;
    }
    
    public int getCellCount(){
        int count = 0;
        for (String tissue : mseMap.keySet() ){
            Mse mse = mseMap.get(tissue);
            count = count + mse.getCellTypes().size();
        }        
        return count;
    }
    
    public Set<String> getTissues(){
        return this.vimpMap.keySet();
    }
    
    public String getTissuesAsString(){
        StringBuilder builder = new StringBuilder();
        boolean first = true;
        for (String tissue : this.mseMap.keySet()){                       
            if (!first){
                builder.append("/");
            }
             builder.append(tissue);
            first = false;
        }
        return builder.toString();
    }
}
