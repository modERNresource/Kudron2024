/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

import java.io.File;
import java.util.TreeMap;
import org.rhwlab.chipseq.peaks.FlyStageGroups;
import org.rhwlab.chipseq.peaks.StageGroups;
import org.rhwlab.chipseq.peaks.WormStageGroups;
import org.rhwlab.gene.model.ModelGFF;
import org.rhwlab.gene.model.ModelGFF_Fly;
import org.rhwlab.gene.model.ModelGFF_Worm;
import org.rhwlab.singlecell.expression.FBgnTranslation;
import org.rhwlab.singlecell.expression.Translation;
import org.rhwlab.singlecell.expression.WBGeneTranslation;

/**
 *
 * @author gevirl
 */
public class ModelParams {

    String species;  // "worm" or "fly"
    String speciesUC;   // species label with upper case first character - "Worm" or "Fly"
    ModelGFF gff;
    StageGroups groups;
    Translation translation;
    TreeMap<String, TargetDescription> targetDescMap;

    public ModelParams(String species) throws Exception {
        this.species = species;
        char[] c = species.toCharArray();
        c[0] = Character.toUpperCase(c[0]);
        speciesUC = String.valueOf(c, 0, c.length);
        if (isWorm()) {
            gff = new ModelGFF_Worm(wormGFF);
            groups = new WormStageGroups();
            translation = new WBGeneTranslation();
        } else {
            gff = new ModelGFF_Fly(flyGFF);
            groups = new FlyStageGroups();
            translation = new FBgnTranslation();
        }
        targetDescMap = PredictorMatrix_1.asTarget(PredictorMatrix_1.readFile(getTargetDescFile(), true, 0));
    }

    final public boolean isWorm() {
        return species.equals("worm");
    }

    public Translation getTranslation() {
        return translation;
    }

    public StageGroups getStageGroups() {
        return groups;
    }

    public ModelGFF getGFF() {
        return gff;
    }

    public File stageDir(String stage) {
        return new File(getModelDir(), stage);
    }

    public File tfExpressionFile(String stage) {
        return new File(new File(getModelDir(), stage), "allTFsExpr.tsv");
    }

    public String[] getGroupLabels() {
        if (species.equals("worm")) {
            return wormGroupLabels;
        }
        return flyGroupLabels;
    }

    public File getModelDir() {
        if (species.equals("worm")) {
            return wormDir;
        }
        return flyDir;
    }

    public File getRankedPeakFile() {
        return new File(String.format(rankedPeak, speciesUC));
    }

    public File getPrimaryTargetFile() {
        return new File(String.format(primaryTarget, speciesUC));
    }

    public File getAlternateTargetFile() {
        return new File(String.format(alternateTarget, speciesUC));
    }

    public File getTargetDescFile() {
        return new File(String.format(targetDesc, speciesUC));
    }

    public TreeMap<String, TargetDescription> getTargetDescMap() throws Exception {
        return this.targetDescMap;
    }

    public static void main(String[] args) throws Exception {
//        ModelParams params = new ModelParams("worm");
        ModelParams params = new ModelParams("fly");
        int asdoi = 0;
    }
    public static String[] wormGroupLabels = {"larva1","larva2","larva3","larva4", "larva3Seam", "larva3Hypo","larva4Sperm"};
//    public static String[] wormGroupLabels = {"emb", "larva", "adult", "lineage"};
//    private  static String[] wormGroupLabels = {"adult"};   
//    private  static String[] flyGroupLabels = {"flyemb2"};   
    //   private  static String[] flyGroupLabels = {"flyemb3"}; 
//    private static String[] flyGroupLabels = {"flyemb4"};
    private static String[] flyGroupLabels = {"flyemb5"};

    private static File wormDir = new File("/net/waterston/vol9/ChipSeqPipeline/RF_Model_larva");
//    private static File flyDir = new File("/net/waterston/vol9/ChipSeqPipeline/RF_Model_fly2");
//    private static File flyDir = new File("/net/waterston/vol9/ChipSeqPipeline/RF_Model_fly3");
 //   private static File flyDir = new File("/net/waterston/vol9/ChipSeqPipeline/RF_Model_fly4");
 //   private static File flyDir = new File("/net/waterston/vol9/ChipSeqPipeline/RF_Model_fly5");
    private static File flyDir = new File("/net/waterston/vol9/ChipSeqPipeline/RF_Model_flyMotif");

//    String rankedPeak = "/net/waterston/vol9/ChipSeqPipeline/All%sPeaks.TF.noDups.ranked.bed";
    String rankedPeak = "/net/waterston/vol9/ChipSeqPipeline/All%sPeaks.TF.noDups.ranked.withMotif.bed";
    String primaryTarget = "/net/waterston/vol9/ChipSeqPipeline/All%sPeaks.TF.noDups.clusters.distance.bed";
    String alternateTarget = "/net/waterston/vol9/ChipSeqPipeline/All%sPeaks.TF.noDups.clusters.altdist.bed";
    String targetDesc = "/net/waterston/vol9/ChipSeqPipeline/All%sPeaks.TF.noDups.clusters.peakTSSs";

    private static File wormGFF = new File("/net/waterston/vol9/WS285/c_elegans.PRJNA13758.WS285.annotations.allwormbase.gff3");
    private static File flyGFF = new File("/net/waterston/vol9/dm6/dmel-all-r6.49.flybase.gff3");
}
