/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

import java.io.File;
import java.io.PrintStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;
import org.rhwlab.singlecell.expression.CellTypeGroups;
import org.rhwlab.singlecell.expression.PrefixMaps;
import org.rhwlab.singlecell.expression.SingleCellExprMat;

/**
 *
 * @author gevirl
 */
public class SetupModelInputs {

    static public void main(String[] args) throws Exception {
//        ModelParams params = new ModelParams("worm");
        ModelParams params = new ModelParams("fly");
        for (String group : params.getGroupLabels()) {
            ExpressionTF.formTSV(params, group);
        }
        ExpressionTF exprTF = new ExpressionTF(params);

        TreeMap<String, TargetDescription> targetDescMap = params.getTargetDescMap();
/*
        FilterTF[] filterTFs = {new NonZeroExpressingTFs(exprTF), new ExprTF_5pct(exprTF)};
        FilterCluster[] clusterFilters
                = {new Clusters_2_30(), new Clusters_2_84(), new Clusters_2_30_Strict(targetDescMap), new Clusters_2_84_Strict(targetDescMap),
                    new ClusterNotHotNoAlt(params, targetDescMap)};
        UseTarget[] alternates = {new CloseAlternates(), new NoAlternates()};
        PredictorValue[] predictorValues = {new SignalPredictor(), new DistanceSignal()};
*/

 //       FilterTF[] filterTFs = { new ExprTF_10pct(exprTF) ,new ExprTF_MeanPct100(exprTF)};      
 //       FilterTF[] filterTFs = { new ExprTF_MeanPct100(exprTF)};   
 //       FilterTF[] filterTFs = {new ExprTF_MeanPct100(exprTF), new ExprTF_MeanSd(exprTF,1.0)}; 
//         FilterTF[] filterTFs = { new ExprTF_5pct(exprTF))
//        FilterTF[] filterTFs = { new ExprTF_10pct(exprTF),new ExprTF_15pct(exprTF)};
        FilterTF[] filterTFs = {new ExprTF_MeanPct100(exprTF), new ExprTF_MeanSd(exprTF,1.0)};        
        UseTarget[] alternates = {new CloseAlternates()};
        PredictorValue[] predictorValues = {new DistanceSignal()};
        FilterCluster[] clusterFilters = {new ClusterNotHotNoAlt(params)};        
        
 //       FilterCluster[] clusterFilters = {new ClusterNotHotNoAlt(params),new ClusterNotHotNoAlt84max(params)};
        PrefixMaps maps = new PrefixMaps();
        TreeMap<String, File> cellTypeMap = maps.getCellTypeMap();

        // form the gene by cell type expression matrices for each tissue/subtissue and all genes
        for (String cellStage : params.getGroupLabels()) {
            System.out.printf("cellStage = %s\n", cellStage);
            String exprStage = params.getStageGroups().getExprStage(cellStage);
            System.out.printf("exprStage = %s\n", exprStage);
            File stageDir = params.stageDir(cellStage);
            File tissuesDir = new File(stageDir, "tissues");
            Files.createDirectories(tissuesDir.toPath());

            SingleCellExprMat expMat = new SingleCellExprMat(exprStage);
 //           FilterCluster[] clusterFilters = {new ClusterNotHotNoAlt(params),new EntropyFilter(params,expMat,4.0),new EntropyFilterNotHot(params,expMat,4.0)};
            Set<String> allGenes = expMat.getAllGenes();
            File file = cellTypeMap.get(exprStage);
            CellTypeGroups cellTypeGroups = new CellTypeGroups(file);

            // save the expression for each tissue 
            for (String tissue : cellTypeGroups.getGroups()) {
                File tissueDir = new File(tissuesDir, tissue.replaceAll(" ", "_"));
                Files.createDirectories(tissueDir.toPath());

                for (String subTissue : cellTypeGroups.getSubGroupsForGroup(tissue)) {
                    File subTissueFile = new File(tissueDir, subTissue.replaceAll(" ", "_") + ".tsv");
                    PrintStream stream = new PrintStream(subTissueFile);
                    List<String> cells = cellTypeGroups.getCellTypesForSubGroup(subTissue);
                    List<double[]> exprList = new ArrayList<>();

                    // saving expression for each cell in the subtissue
                    for (String cell : cells) {
                        exprList.add(expMat.getExpression(cell));  // get expression of all genes for the cell
                    }

                    // print the header
                    stream.print("BaseGene");
                    for (String cell : cells) {
                        stream.printf("\t%s", cell);
                    }
                    stream.println();

                    // print the expr values
                    int row = 0;
                    for (String wbGene : allGenes) {
                        stream.print(wbGene);
                        for (double[] expr : exprList) {
                            stream.printf("\t%.1f", expr[row]);
                        }
                        stream.println();
                        ++row;
                    }
                    stream.close();

                    // making the individual cell directories
                    File subTissueDir = new File(tissueDir, subTissue.replaceAll(" ", "_"));
                    Files.createDirectories(subTissueDir.toPath());
                    for (String cell : cells) {
                        File cellDir = new File(subTissueDir, cell);
                        Files.createDirectories(cellDir.toPath());

                        // creating the tf filter directories for the cell
                        for (FilterTF filterTF : filterTFs) {
                            File tfFilterDir = new File(cellDir, filterTF.getLabel());
                            Files.createDirectories(tfFilterDir.toPath());

                            // making the file of tfs for the cell and tf filter cvombination
                            File cellTF_File = new File(tfFilterDir, "TFs.txt");
                            PrintStream tfstream = new PrintStream(cellTF_File);
                            for (String tf : exprTF.getAllTFs(cellStage)) {
                                if (filterTF.accept(cellStage, cell, tf)) {
                                    tfstream.println(tf);
                                }
                            }
                            tfstream.close();
                        }
                    }
                }
            }

            String group = params.getStageGroups().getChipGroup(cellStage);
            ClusterRankedPeaks rankedPeaks = new ClusterRankedPeaks(params, group);
            for (FilterCluster filter : clusterFilters) {
                File filterDir = new File(stageDir, filter.getLabel());
                PredictorMatrix_1 primaryMat = new PredictorMatrix_1(params, expMat, params.getPrimaryTargetFile(), rankedPeaks, targetDescMap, filter);
                TreeMap<String, TargetedCluster> primaryClusterMap = primaryMat.getClusterMap();

                for (PredictorValue predictorValue : predictorValues) {
                    File predictorDir = new File(filterDir, predictorValue.getLabel());
                    Files.createDirectories(predictorDir.toPath());
                    PrintStream stream = new PrintStream(new File(predictorDir, "predictor.tsv"));
                    primaryMat.reportMatrix(stream, predictorValue);
                    stream.close();

                    for (UseTarget alt : alternates) {

                        File altDir = new File(predictorDir, alt.getLabel());
                        Files.createDirectories(altDir.toPath());
                        PredictorMatrix_1 altMat = new PredictorMatrix_1(params, expMat, params.getAlternateTargetFile(), rankedPeaks, targetDescMap, filter);
                        stream = new PrintStream(new File(altDir, "predictor.tsv"));
                        altMat.reportMatrix(stream, primaryClusterMap, alt, predictorValue);
                        stream.close();
                    }
                }
            }

        }

    }
}
