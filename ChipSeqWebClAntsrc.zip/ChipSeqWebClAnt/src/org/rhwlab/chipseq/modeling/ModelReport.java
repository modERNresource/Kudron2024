/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.TreeMap;
import static org.rhwlab.chipseq.modeling.PredictorMatrix_1.asCluster;
import static org.rhwlab.chipseq.modeling.PredictorMatrix_1.readFile;

/**
 *
 * @author gevirl
 */
public class ModelReport {

    int nClusters = 0;
    int nPeaks = 0;

    public ModelReport(File file) throws Exception {

        BufferedReader reader = new BufferedReader(new FileReader(file));
        reader.readLine();
        String line = reader.readLine();
        while (line != null) {
            ++nClusters;
            String[] tokens = line.split("\t");
            for (int i=3 ; i<tokens.length ; ++i){
                double v = Double.valueOf(tokens[i]);
                if (v > 0.0){
                    ++nPeaks;
                }
            }
            line = reader.readLine();
        }
        reader.close();

    }

    static int CountLines(File file)throws Exception {
        int n = 0;
        BufferedReader reader = new BufferedReader(new FileReader(file));
        String line = reader.readLine();
        while (line != null){
            ++n;
            line = reader.readLine();
        }
        reader.close();
        
        return n;
    }
    // report model characteristics
    static public void main(String[] args) throws Exception {
        TreeMap<String,TreeMap<String,int[]>> resultMap = new TreeMap<>();
 //       PrintStream stream = new PrintStream("/net/waterston/vol9/ChipSeqPipeline/ModelReport.tsv");
        PrintStream stream = stream = System.out;

        String species = "worm";
        ModelParams params = new ModelParams(species);
//        String[] stages = {"emb", "larva", "adult"};
        String[] stages = {"lineage"};
        String[] filters = {"cluster_2_30", "cluster_2_30_Strict", "cluster_2_84", "cluster_2_84_Strict", "noHotClusterTargets"};

        stream.println("stage\tprimCl\tcloseCl\ttotCl\tprimPk\tclosePk\ttotPk\tfilter");
        File dir = params.getModelDir();
        for (String stage : stages) {
            File stageDir = new File(dir, stage);
            for (String filter : filters) {
                File filterDir = new File(stageDir, filter);
                File signalDir = new File(filterDir, "distanceModified");
                File primPred = new File(signalDir, "predictor.tsv");
                ModelReport primClusters = new ModelReport(primPred);
                File closeDir = new File(signalDir, "closeAlternates");
                File closePred = new File(closeDir, "predictor.tsv");
                ModelReport closeClusters = new ModelReport(closePred);
                int totCl = primClusters.nClusters + closeClusters.nClusters;
                int totPk = primClusters.nPeaks + closeClusters.nPeaks;
                stream.printf("%s\t%d\t%d\t%d\t%d\t%d\t%d\t%s\n", 
                        stage, primClusters.nClusters, closeClusters.nClusters,totCl,
                        primClusters.nPeaks,closeClusters.nPeaks, totPk, filter);
            }
            stream.println();
            
            
            
            TreeMap<String,int[]> cellMap = new TreeMap<>();
            resultMap.put(stage,cellMap);
            File tissueDir = new File(stageDir,"tissues");
            for (File groupDir : tissueDir.listFiles()){
                String group = groupDir.getName();
                for (File subgroupDir : groupDir.listFiles()){
                    if (!subgroupDir.getName().endsWith("tsv")){
                        for (File cellDir : subgroupDir.listFiles()){
                            String cell = cellDir.getName();
                            File exprDir = new File(cellDir,"expressing5pct");
                            File exprFile = new File(exprDir,"TFs.txt");
                            File nonzeroDir = new File(cellDir,"nonZeroExpr");
                            File nonzeroFile = new File(nonzeroDir,"TFs.txt");
                            int[] v = new int[2];
                            v[0] = CountLines(nonzeroFile);
                            v[1] = CountLines(exprFile);
                            cellMap.put(cell,v);
                            
                        }
                    }                                        
                }                                
            }            
        }
        stream.println("");
        
        for (String stage : resultMap.keySet()){
            stream.println("\nstage\t>0\t>5pct\tcell");
            TreeMap<String,int[]> cellMap = resultMap.get(stage);
            for (String cell : cellMap.keySet()){
                int[] v = cellMap.get(cell);
                stream.printf("%s\t%d\t%d\t%s\n", stage,v[0],v[1],cell);
            }
        }
        
        
        
        

        /*        
        TreeMap<String, TargetDescription> targetDescMap = PredictorMatrix_1.asTarget(PredictorMatrix_1.readFile(params.getTargetDescFile(), true, 0));
        FilterCluster[] clusterFilters
                = {new Clusters_2_30(), new Clusters_2_84(), new Clusters_2_30_Strict(targetDescMap), new Clusters_2_84_Strict(targetDescMap),
                    new ClusterNotHot(params, targetDescMap)};

        ClusterRankedPeaks rankedPeaks = new ClusterRankedPeaks(params, stage);  // all ranked peaks for the stage

        TreeMap<String, TargetedCluster> allClustersMap = asCluster(readFile(params.getPrimaryTargetFile(), false, 3));
        for (FilterCluster filter : clusterFilters) {
            TreeMap<String, TargetedCluster> clusterMap = new TreeMap<>();
            for (TargetedCluster cluster : allClustersMap.values()) {
                String clusterID = cluster.getName();
                if (filter.accept(cluster)) {
                    clusterMap.put(clusterID, cluster);
                }

            }
            
            
            
            int sdf = 0;
         */
    }
}
