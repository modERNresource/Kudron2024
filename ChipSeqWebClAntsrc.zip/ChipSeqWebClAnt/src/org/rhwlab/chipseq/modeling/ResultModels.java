/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author gevirl
 */
public class ResultModels {
    File dir;
    String stage;
    List<String> models;  // all potential result models for a given stage
        
    public ResultModels(File dir,String stage){
        this.dir = dir;
        this.stage = stage;        
        models = new ArrayList<>();
        File stageDir = new File(dir, stage);
        for (File tfFilterDir : stageDir.listFiles()) {
            for (File clusterFilterDir : tfFilterDir.listFiles()) {
                for (File predictorDir : clusterFilterDir.listFiles()) {
                    for (File altDir : predictorDir.listFiles()) {
                        models.add(String.format("%s/%s/%s/%s", tfFilterDir.getName(), clusterFilterDir.getName(), predictorDir.getName(), altDir.getName()));
                    }
                }
            }
        }        
    }
    public List<String> getModels(){
        return this.models;
    }
    
    public File modelDir(String model){
        File stageDir = new File(dir,stage);
        return new File(stageDir,model);        
    }
    
   
}
