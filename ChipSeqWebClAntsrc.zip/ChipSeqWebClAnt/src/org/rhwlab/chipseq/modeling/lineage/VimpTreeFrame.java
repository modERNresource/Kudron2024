/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling.lineage;

import java.awt.EventQueue;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.TitledBorder;

/**
 *
 * @author gevirl
 */
public class VimpTreeFrame extends JFrame {

    SulstonTree sulston;
    CellGeneData data;

    ColorRamp ramp;
    JPanel mainPanel;

    ExpressionCellNames exprNames;

    public VimpTreeFrame(SulstonTree sulston, CellGeneData data) throws Exception {
        exprNames = new ExpressionCellNames();
        this.sulston = sulston;
        this.data = data;

        mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        ramp = new ColorRamp();

        JScrollPane scroll = new JScrollPane(mainPanel);
        setContentPane(scroll);
        pack();

    }

    public void setParams(String title,String[] lineageRoots, String[] tfs) throws Exception {
        mainPanel.removeAll();
        GeneMultiFullTreeImage image = new GeneMultiFullTreeImage(lineageRoots, sulston, data, ramp, exprNames);
        for (String root : lineageRoots) {
//            RootPanel rootPanel = new RootPanel( image,  root, tfs);

            int i = 0;
            JPanel rootPanel = new JPanel();
            rootPanel.setBorder(new TitledBorder(root));
            rootPanel.setLayout(new BoxLayout(rootPanel, BoxLayout.X_AXIS));
            for (String tf : tfs) {
                boolean labelIt = i == tfs.length - 1;
                BufferedImagePanel panel = new BufferedImagePanel(image.getImage(root, tf, labelIt));
                TitledBorder border = new TitledBorder(tf);
                panel.setBorder(border);
                rootPanel.add(panel);
                ++i;
            }

            mainPanel.add(rootPanel);
        }
        this.setTitle(title);
        pack();
    }

    static public void main(final String[] args) throws Exception {

        SulstonTree sulston = new SulstonTree();
        VimpDataMultiSource data = new VimpDataMultiSource();
        MurraySulstonCellClass murray = new MurraySulstonCellClass();
        EventQueue.invokeLater(new Runnable() {

            @Override
            public void run() {
                try {

                    VimpTreeFrame frame = new VimpTreeFrame(sulston, data);
                    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    frame.setSize(1200, 500);
                    frame.setVisible(true);


                    CellTypeGeneFrame cellTypeFrame = new CellTypeGeneFrame(frame, murray, data.getData(0), sulston);
                    cellTypeFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    cellTypeFrame.setVisible(true);

                } catch (Exception exc) {
                    exc.printStackTrace();
                }
            }
        });

    }
}
