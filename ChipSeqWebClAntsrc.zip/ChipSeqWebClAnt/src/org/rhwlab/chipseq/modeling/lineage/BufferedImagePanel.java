/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling.lineage;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import javax.swing.JPanel;

/**
 *
 * @author gevirl
 */
public class BufferedImagePanel extends JPanel{
    public BufferedImagePanel(BufferedImage image){
        useImage(image);
    }
    final public void useImage(BufferedImage image){
        this.image = image;
        int h = this.image.getHeight();
        int w = this.image.getWidth();
        this.setSize(w, h);
        this.setPreferredSize(new Dimension(w,h));
        this.setMinimumSize(new Dimension(w,h));
    }
    public void paint(Graphics g) {
        super.paint(g);
        Graphics2D g2 = (Graphics2D) g;
        
        g2.drawImage(image,new AffineTransformOp(new AffineTransform(),
                AffineTransformOp.TYPE_NEAREST_NEIGHBOR),0,0);        

    } 
    BufferedImage image;
}
