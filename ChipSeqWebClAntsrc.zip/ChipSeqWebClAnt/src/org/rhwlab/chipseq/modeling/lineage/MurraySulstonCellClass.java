/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling.lineage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 *
 * @author gevirl
 */
public class MurraySulstonCellClass {

    TreeMap<String, String[]> terminalMap = new TreeMap<>(); // Terminal -> record
    TreeMap<String, Set<String>> cellTypeMap = new TreeMap<>(); // Celltype >- List of Terminal Sulston
    int sulstonIndex = 1;
    int terminalIndex = 2;
    int cellTypeIndex = 3;
    int cellClassIndex = 4;
    int firstTissueIndex = 5;

    public MurraySulstonCellClass() throws Exception {


        InputStream stream = this.getClass().getResourceAsStream("/org/rhwlab/chipseq/modeling/lineage/MurraySulstonCellClass.tsv");
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
        String line = reader.readLine(); // the headers
        line = reader.readLine();
        while (line != null) {
            String[] tokens = line.split("\t");
            String terminal = tokens[terminalIndex];
            String cellType = tokens[cellTypeIndex];
            String cellClass = tokens[cellClassIndex];
            
            if (!cellClass.equals("cell death") & !cellClass.equals("tail spike cell death")) {
                Set<String> set = cellTypeMap.get(cellType);
                if (set == null) {
                    set = new TreeSet<>();
                    cellTypeMap.put(cellType, set);
                }
                set.add(terminal);
            }

            terminalMap.put(terminal, tokens);
            line = reader.readLine();
        }
        reader.close();
    }

    public String getTissueLabel(String terminal) {
        StringBuilder builder = new StringBuilder();
        String[] tokens = terminalMap.get(terminal);
        if (tokens == null) {
            return null;
        }
        boolean first = true;
        for (int i = firstTissueIndex; i < tokens.length; ++i) {
            if (!tokens[i].equals("NA")) {
                if (!first) {
                    builder.append(":");
                }
                builder.append(tokens[i]);
                first = false;
            }
        }
        return builder.toString();
    }

    public String getCellType(String terminal) {
        String[] types = this.terminalMap.get(terminal);
        if (types != null) {
            return this.terminalMap.get(terminal)[this.cellTypeIndex];
        }
        return null;
    }

    public Set<String> getTerminal(String cellType) {
        return this.cellTypeMap.get(cellType);
    }

    public Set<String> getAllCellTypes() {
        return this.cellTypeMap.keySet();
    }

    public static void main(String[] args) throws Exception {
        MurraySulstonCellClass s = new MurraySulstonCellClass();
        int hh = 0;
    }
}
