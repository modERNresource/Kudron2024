/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling.lineage;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import static java.awt.print.Printable.PAGE_EXISTS;
import java.awt.print.PrinterException;
import javax.swing.BoxLayout;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

/**
 *
 * @author gevirl
 */
public class RootPanel extends JPanel implements Printable {
    public static final Dimension A4_SIZE = new Dimension(595, 842);
    public static final Dimension A3_SIZE = new Dimension(842, 595 * 2);
    public static final Dimension A2_SIZE = new Dimension(595 * 2, 842 * 2);
    public static Dimension DEFAULT_SIZE = A4_SIZE;        
    public RootPanel(GeneMultiFullTreeImage image, String root, String[] tfs) throws Exception {
        this.setMaximumSize(DEFAULT_SIZE);
        this.setMinimumSize(DEFAULT_SIZE);
        this.setPreferredSize(DEFAULT_SIZE);
        this.setBackground(Color.white);
        this.setSize(DEFAULT_SIZE);       
    
            int i = 0;

            this.setBorder(new TitledBorder(root));
            this.setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
            for (String tf : tfs) {
                boolean labelIt = (i == tfs.length - 1);
                BufferedImagePanel panel = new BufferedImagePanel(image.getImage(root, tf, labelIt));
                TitledBorder border = new TitledBorder(tf);
                panel.setBorder(border);
                this.add(panel);
                ++i;
            }
    }

    @Override
    public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) throws PrinterException {
        Graphics2D g2d = (Graphics2D) graphics;
        g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());      
        g2d.scale(.75,.75);
        this.paint(g2d);
        return (PAGE_EXISTS);    
    }
    
}
