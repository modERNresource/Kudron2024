/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling.lineage;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 *
 * @author gevirl
 */
public class SulstonTree {

    SulstonCell root;

    public SulstonTree() throws Exception {
        InputStream stream = this.getClass().getResourceAsStream("/org/rhwlab/chipseq/modeling/lineage/Sulston.tsv");
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream));

        String line = reader.readLine();
        root = new SulstonCell(line.split("\t")[0]);

        line = reader.readLine();
        while (line != null) {
            String[] tokens = line.split("\t");
            String name = tokens[0];
            SulstonCell node = new SulstonCell(name);
            String parent = tokens[1];
            SulstonCell parentNode = getCell(parent);
            parentNode.add(node);
            line = reader.readLine();
        }
        reader.close();
    }

    final public SulstonCell getCell(String name) {
        return root.find(name);
    }


    public static void main(String[] args) throws Exception {
        SulstonTree tree = new SulstonTree();
        int hh=0;
    }
}
