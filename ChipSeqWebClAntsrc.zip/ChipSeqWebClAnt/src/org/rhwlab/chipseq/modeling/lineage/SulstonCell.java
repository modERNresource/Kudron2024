/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling.lineage;

import java.util.ArrayList;
import java.util.List;
import javax.swing.tree.DefaultMutableTreeNode;

/**
 *
 * @author gevirl
 */
public class SulstonCell extends DefaultMutableTreeNode {

    public SulstonCell(String name) {
        super(name);
    }
    // get a list of all the ancestors of this cell
    //the list does not include the cell itself
    public ArrayList<SulstonCell> getAncestors() {
        ArrayList<SulstonCell> ret = new ArrayList<>();
        SulstonCell parent = (SulstonCell)this.getParent();
        if (parent != null){
            ret.addAll(parent.getAncestors());
            ret.add(parent);            
        }

        return ret;
    }
        // returns all the leaves of this cell
    // returns this cell if it is a leaf
    public SulstonCell[] getLeaves() {
        ArrayList<SulstonCell> leaves = getLeaves(this);

        SulstonCell[] ret = new SulstonCell[leaves.size()];
        return leaves.toArray(ret);
    }

    // gets all the leaves of the given cell
    public static ArrayList<SulstonCell> getLeaves(SulstonCell cell) {
        ArrayList<SulstonCell> leaves = new ArrayList<>();
        if (cell.isLeaf()) {
            leaves.add(cell);
            return leaves;
        }
        for (SulstonCell child : cell.getChildren()){
            leaves.addAll(getLeaves(child));
        }

        return leaves;
    }
    public int depth() {
        if (this.getParent() == null){
            return 0;
        }
        SulstonCell parentCell = (SulstonCell)this.getParent();
        return 1 + parentCell.depth();
    }


    public int maxDescendents() {
        if (this.isLeaf()) {
            return 0;
        } else {
            int max = 0;
            for (SulstonCell childCell : this.getChildren()) {
                int n = childCell.maxDescendents();
                if (n > max) {
                    max = n;
                }
            }
            return max + 1;
        }
    }

    public List<SulstonCell> getChildren() {
        ArrayList<SulstonCell> ret = new ArrayList<>();
        for (int i = 0; i < this.getChildCount(); ++i) {
            ret.add(this.getChildAt(i));
        }
        return ret;
    }

    public String getName() {
        return (String) getUserObject();
    }

    @Override
    public SulstonCell getChildAt(int i) {
        return (SulstonCell) super.getChildAt(i);
    }

    public SulstonCell find(String name) {
        if (this.getName().equals(name)) {
            return this;
        }
        SulstonCell ret = null;
        for (int i = 0; i < this.getChildCount(); ++i) {
            ret = this.getChildAt(i).find(name);
            if (ret != null) {
                break;
            }
        }
        return ret;
    }
}
