/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling.lineage;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

/**
 *
 * @author gevirl
 */
public class ColorRamp {
    Color[] colors;
    double min;
    double max;
    double f;
    
    public ColorRamp() throws Exception {
        this("/org/rhwlab/chipseq/modeling/lineage/colorRamp",-1.0,1.0);
    }
    
    public ColorRamp(String resource,double min,double max)throws Exception {
        ArrayList<Color> list = new ArrayList<>();
        InputStream stream = this.getClass().getResourceAsStream(resource);
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream));   
        String line = reader.readLine();
        line= reader.readLine();
        while (line != null){
            int[] c = new int[3];
            for (int i=0 ; i<3 ; ++i) {
                String s = line.substring(2 * i + 1, 2 * i + 3);
                c[i] = Integer.parseInt(s, 16);
            }
            list.add(new Color(c[0],c[1],c[2]));
            line = reader.readLine();
        }
        reader.close();
        
        colors = list.toArray(new Color[0]);
        this.min = min;
        this.max = max;
        f = (colors.length/(max - min));        
    }
    
    public ColorRamp(Color[] colors,double min,double max){
        this.colors = colors;
        this.min = min;
        this.max = max;
        f = (colors.length/(max - min));
    }
    
    public Color getColor(double x){
        if (x <= min){
            return colors[0];
        }
        if (x >= max){
            return colors[colors.length-1];
        }
        int i = (int)(f*(x-min));
        return colors[i];
    }
    
    public Color[] getColors(){
        return this.colors;
    }

    public static void main(String[] args)throws Exception {
        
        ColorRamp ramp = new ColorRamp();
        int i=1;
        for (double x = -1.0 ; x<=1.0 ; x = x +.01){
            Color c = ramp.getColor(x);
            System.out.printf("%d\t%f\t%s\n",i,x,c.toString());
            ++i;
        }
        int adf=0;
    }
}
