/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

import java.util.TreeMap;

/**
 *
 * @author gevirl
 */
public class ClusterNotHotNoAlt implements FilterCluster {
    GenesTargetedByHotClusterNoAlt hotGenes;

    public ClusterNotHotNoAlt(ModelParams params)throws Exception {
        hotGenes = new GenesTargetedByHotClusterNoAlt(params);
    }
    
    @Override
    public boolean accept(TargetedCluster cluster) {
        if (cluster.getPeakCount() > 1 ) {
            return !hotGenes.hotTarget(cluster);
        }
        return false;
    }

    @Override
    public String getLabel() {
        return "noHotClusterTargetsNoAlt";
    }
    
}
