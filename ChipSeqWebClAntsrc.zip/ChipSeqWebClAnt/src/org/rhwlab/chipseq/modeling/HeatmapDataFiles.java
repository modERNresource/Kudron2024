/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.rhwlab.chipseq.modeling;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.io.File;
import java.io.FileInputStream;
import org.primefaces.model.DefaultStreamedContent;
import org.rhwlab.chipseqweb.beans.Directory;

/**
 *
 * @author gevirl
 */
@Named("heatmapDataFile")
@ApplicationScoped
public class HeatmapDataFiles {
    @Inject Directory dir;
    public HeatmapDataFiles(){
        
    }

    public DefaultStreamedContent getFlyEmb()throws Exception {  
        FileInputStream stream = new FileInputStream(new File(new File(dir.getDirectory(),"RF_Model_heatmaps"),"flyemb5.tsv"));
        DefaultStreamedContent.Builder builder = DefaultStreamedContent.builder()
                .name("FlyEmbryonicVimp.tsv")
                .contentType("text/plain")
                .stream(() -> stream);
        return builder.build();
    }
    
    public DefaultStreamedContent getWormEmb()throws Exception {  
        FileInputStream stream = new FileInputStream(new File(new File(dir.getDirectory(),"RF_Model_heatmaps"),"emb.tsv"));
        DefaultStreamedContent.Builder builder = DefaultStreamedContent.builder()
                .name("WormEmbryonicVimp.tsv")
                .contentType("text/plain")
                .stream(() -> stream);
        return builder.build();
    }

        public DefaultStreamedContent getWormLineage()throws Exception {  
        FileInputStream stream = new FileInputStream(new File(new File(dir.getDirectory(),"RF_Model_heatmaps"),"lineageSulston.tsv"));
        DefaultStreamedContent.Builder builder = DefaultStreamedContent.builder()
                .name("WormLineageVimp.tsv")
                .contentType("text/plain")
                .stream(() -> stream);
        return builder.build();
    }
    public DefaultStreamedContent getWormLarva()throws Exception {  
        FileInputStream stream = new FileInputStream(new File(new File(dir.getDirectory(),"RF_Model_heatmaps"),"larva.tsv"));
        DefaultStreamedContent.Builder builder = DefaultStreamedContent.builder()
                .name("WormLarvaVimp.tsv")
                .contentType("text/plain")
                .stream(() -> stream);
        return builder.build();
    }
    public DefaultStreamedContent getWormAdult()throws Exception {  
        FileInputStream stream = new FileInputStream(new File(new File(dir.getDirectory(),"RF_Model_heatmaps"),"adult.tsv"));
        DefaultStreamedContent.Builder builder = DefaultStreamedContent.builder()
                .name("WormAdultVimp.tsv")
                .contentType("text/plain")
                .stream(() -> stream);
        return builder.build();
    }    
}
