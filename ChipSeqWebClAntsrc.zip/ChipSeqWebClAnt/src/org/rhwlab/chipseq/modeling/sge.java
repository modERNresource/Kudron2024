/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

import java.io.File;
import java.io.PrintStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author gevirl
 */
public class sge {

    public sge(PrintStream submitStream, File resultsDir, File sourceDir, String stage, String tissue, String tfFilter, String clusterFilter) throws Exception {

        File stageDir = new File(sourceDir, stage);
        File clusterDir = new File(stageDir, clusterFilter);
        for (File predValueFile : clusterDir.listFiles()) {
            if (!predValueFile.getName().equals("predictor.tsv")) {
                for (File altTargetFile : predValueFile.listFiles()) {
                    if (!altTargetFile.getName().equals("predictor.tsv")) {
                        File destDir
                                = new File(new File(new File(new File(new File(resultsDir, stage), tfFilter), clusterFilter), predValueFile.getName()), altTargetFile.getName());
                        File sgeFile = new File(destDir, String.format("%s.sge", tissue));
                        Files.createDirectories(destDir.toPath());
                        PrintStream stream = new PrintStream(sgeFile);
                        stream.println("source /net/waterston/vol6/activateConda.sh");
                        stream.println("conda activate rstudio");
                        stream.println("cd /net/waterston/vol9/ChipSeqPipeline");
                        stream.printf("Rscript RandomForestFlyWorm.R %s %s %s %s %s %s %s \n",
                                stage, tissue, tfFilter, clusterFilter, predValueFile.getName(), altTargetFile.getName(),sourceDir.getName());
                        stream.close();

                        submitStream.printf("qsub -pe serial 9 -l mfree=3G -o %s -e %s %s \n", destDir.getPath(), destDir.getPath(), sgeFile.getPath());
                    }
                }
            }
        }

    }

    // construct sge files to run random forest on cluster
    static public void main(String[] args) throws Exception {
        ModelParams params = new ModelParams("fly");
        String[] tfFiltersToUse = {"ExprTF_Mean","ExprTF_MeanSd_1.0"};
        File sourceDir = params.getModelDir();
        File resultsDir = new File("/net/waterston/vol9/ChipSeqPipeline/RF_Model_Submit_flyMotif");
        Files.createDirectories(resultsDir.toPath());
        File submitAll = new File(resultsDir,"submitAll.sh");
        PrintStream allStream = new PrintStream(submitAll);


        File[] stageDirs = sourceDir.listFiles();
        for (File stageDir : stageDirs) {
            String stage = stageDir.getName();

            List<String> clusterFilterList = new ArrayList<>();
            for (File file : stageDir.listFiles()) {
                if (file.isDirectory() && !file.getName().equals("tissues")) {
                    clusterFilterList.add(file.getName());
                }
            }

            File tissuesDir = new File(stageDir, "tissues");
            for (File tissueDir : tissuesDir.listFiles()) {
                String tissue = tissueDir.getName();
                File outFile = new File(resultsDir, String.format("submit_%s_%s.sh", stage, tissue));
                PrintStream submitStream = new PrintStream(outFile);
                for (String tfFilter : tfFiltersToUse) {
                     
                    for (String clFilter : clusterFilterList) {
                        new sge(submitStream, resultsDir, sourceDir, stage, tissue, tfFilter, clFilter);
                    }
                }
                submitStream.close();
                allStream.printf("source %s\n", outFile.getPath());
            }
        }
        allStream.close();
        
        
        
    }
}
