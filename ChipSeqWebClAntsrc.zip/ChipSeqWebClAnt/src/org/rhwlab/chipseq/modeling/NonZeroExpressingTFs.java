/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

/**
 *
 * @author gevirl
 */
public class NonZeroExpressingTFs implements FilterTF{
    ExpressionTF expr;
    public NonZeroExpressingTFs(ExpressionTF expr) throws Exception {
        this.expr = expr;
    }

    @Override
    public String getLabel() {
        return "nonZeroExpr";
    }


    @Override
    public boolean accept(String stage, String cell, String tf) {
        return expr.getExpression(stage, cell, tf) > 0.0 ;
    }
}
