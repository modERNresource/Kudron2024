/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

import java.util.TreeMap;
import java.util.TreeSet;
import org.rhwlab.gene.model.ModelGFF;
import org.rhwlab.singlecell.expression.SingleCellExprMat;
import org.rhwlab.singlecell.expression.Translation;

/**
 *
 * @author gevirl
 */
public class EntropyFilter implements FilterCluster {

    ModelGFF gff;
    Translation translation;
    TreeMap<String, TargetDescription> targetDescMap;
    SingleCellExprMat expMat;
    double thresh;

    TreeSet<String> xlated = new TreeSet<String>();
    public EntropyFilter(ModelParams params, SingleCellExprMat expMat, double thresh) throws Exception {
        this.gff = params.getGFF();
        this.translation = params.getTranslation();
        this.expMat = expMat;
        this.thresh = thresh;
        this.targetDescMap = params.getTargetDescMap();
    }

    @Override
    public boolean accept(TargetedCluster cluster) {
        Double e = clusterEntropy(cluster);
        if (e != null){
            return  e <= thresh;
        }
        return false;
    }

    public Double clusterEntropy(TargetedCluster cluster) {
        String targetID = cluster.getTargetID();
        String gene = targetDescMap.get(targetID).getGene();
        String baseGene = gff.getBaseGene(gene);
        double[] expr = expMat.getGeneExpression(baseGene);
        if (expr == null) {
            int hh = 9;
            String translatedBaseGene = translation.getTranslatedBaseGene(baseGene);
            expr = expMat.getGeneExpression(translatedBaseGene);
            if (expr != null) {
                xlated.add(baseGene);
                int asdf = 0;
            }
        }
        
        if (expr == null){
//           System.out.println(baseGene);
            return null;
        }
        return entropy(normalize(expr));
    }

    public TreeSet<String> getXlated(){
        return xlated;
    }
    // values input must be >= 0.0
    static double[] normalize(double[] vs) {
        double[] ret = new double[vs.length];
        double sum = 0.0;
        for (double v : vs) {
            sum = sum + v;
        }
        for (int i = 0; i < vs.length; ++i) {
            ret[i] = vs[i] / sum;
        }
        return ret;
    }

    static double entropy(double[] p) {
        double e = 0.0;
        for (int i = 0; i < p.length; ++i) {
            if (p[i] > 0.0) {
                e = e - p[i] * Math.log(p[i]);

            }
        }
        return e;
    }

    @Override
    public String getLabel() {
        return String.format("Entropy_%f", thresh);
    }

}
