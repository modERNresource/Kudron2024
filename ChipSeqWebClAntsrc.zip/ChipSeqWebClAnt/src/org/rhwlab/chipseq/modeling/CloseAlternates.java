/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;


/**
 *
 * @author gevirl
 */
public class CloseAlternates implements UseTarget  {


    @Override
    public String getLabel() {
        return "closeAlternates";
    }

    @Override
    public boolean useAlternate(TargetedCluster primary, TargetedCluster alternate) {
        int primaryDist = Math.abs(primary.getDistanceToTarget());
        int altDist = Math.abs(alternate.getDistanceToTarget());
        return altDist <= 2 * primaryDist;
    }
    
}
