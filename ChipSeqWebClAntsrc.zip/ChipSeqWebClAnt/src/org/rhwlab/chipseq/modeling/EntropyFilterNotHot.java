/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

import java.io.File;
import java.io.PrintStream;
import java.util.TreeMap;
import java.util.TreeSet;
import static org.rhwlab.chipseq.modeling.PredictorMatrix_1.asCluster;
import static org.rhwlab.chipseq.modeling.PredictorMatrix_1.readFile;
import org.rhwlab.singlecell.expression.SingleCellExprMat;

/**
 *
 * @author gevirl
 */
public class EntropyFilterNotHot extends EntropyFilter {

    GenesTargetedByHotClusterNoAlt hotGenes;

    public EntropyFilterNotHot(ModelParams params, SingleCellExprMat expMat, double thresh) throws Exception {
        super(params, expMat, thresh);
        hotGenes = new GenesTargetedByHotClusterNoAlt(params);
    }

    @Override
    public boolean accept(TargetedCluster cluster) {
        if (super.accept(cluster)) {
            if (cluster.getPeakCount() > 1) {
                return !hotGenes.hotTarget(cluster);
            }
        }
        return false;
    }

    @Override
    public String getLabel() {
        return String.format("EntropyNotHot_%f", thresh);
    }

    static public void main(String[] args) throws Exception {
        
        ModelParams params = new ModelParams("worm");
        String[] cellStages = {"emb", "larva", "adult", "lineage"};
        for (String cellStage : cellStages) {
            PrintStream stream = new PrintStream(String.format("/net/waterston/vol9/ChipSeqPipeline/Entropy/worm_%s_Entropy.tsv",cellStage));
            String exprStage = params.getStageGroups().getExprStage(cellStage);
            SingleCellExprMat expMat = new SingleCellExprMat(exprStage);
            File clusterFile = params.getPrimaryTargetFile();
            TreeMap<String, TargetedCluster> allClustersMap = asCluster(readFile(clusterFile, false, 3));

            EntropyFilter entropyFilter = new EntropyFilter(params, expMat, 0.8);
            ClusterNotHotNoAlt notHot = new ClusterNotHotNoAlt(params);

            TreeSet<String> notFound = new TreeSet<>();
            double maxE = 0.0;
            double minE = Double.MAX_VALUE;
            TreeMap<String, Double> entropyMap = new TreeMap<>();
            TreeMap<String, Boolean> notHotMap = new TreeMap<>();
            for (TargetedCluster cluster : allClustersMap.values()) {

                String targetID = cluster.getTargetID();
                String gene = params.getTargetDescMap().get(targetID).getGene();
                String baseGene = params.getGFF().getBaseGene(gene);
                if (entropyMap.get(baseGene) == null) {
                    Double e = entropyFilter.clusterEntropy(cluster);
                    if (e != null) {
                        if (e == 0.0) {
                            double[] v = expMat.getGeneExpression(baseGene);
                            int suidfh = 0;
                        }
                        entropyMap.put(baseGene, e);
                        notHotMap.put(baseGene, notHot.accept(cluster));
                        if (e > maxE) {
                            maxE = e;
                        }
                        if (e < minE) {
                            minE = e;
                        }
                    } else {

                        notFound.add(baseGene);
                    }
                    int jjj = 0;
                }
            }
            for (String s : entropyMap.keySet()) {
                if (notHotMap.get(s)) {
                    stream.printf("%s\t%f\t-\n", s, entropyMap.get(s));
                } else {
                    stream.printf("%s\t%f\t+\n", s, entropyMap.get(s));
                }
            }
            stream.close();
        }
        int huiasd = 0;
    }
}
