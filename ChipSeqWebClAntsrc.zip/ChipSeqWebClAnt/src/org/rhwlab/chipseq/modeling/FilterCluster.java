/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

/**
 *
 * @author gevirl
 */
public interface FilterCluster {
    public boolean accept(TargetedCluster cluster);
    public String getLabel();
}
