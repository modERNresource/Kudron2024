/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

import java.util.TreeMap;

/**
 *
 * @author gevirl
 */
public class ClusterNotHotAllAlt implements FilterCluster {
    GenesTargetedByHotClusterAllAlt hotGenes;

    public ClusterNotHotAllAlt(ModelParams params,TreeMap<String, TargetDescription> targetDescMap)throws Exception {
        hotGenes = new GenesTargetedByHotClusterAllAlt(params,targetDescMap);
    }
    
    @Override
    public boolean accept(TargetedCluster cluster) {
        if (cluster.getPeakCount() > 1 ) {
            return !hotGenes.hotTarget(cluster);
        }
        return false;
    }

    @Override
    public String getLabel() {
        return "noHotClusterTargetsAllAlt";
    }
    
}
