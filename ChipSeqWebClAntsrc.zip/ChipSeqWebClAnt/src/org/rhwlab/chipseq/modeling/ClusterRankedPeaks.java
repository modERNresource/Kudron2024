/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.TreeMap;
import java.util.TreeSet;
import org.rhwlab.chipseq.peaks.StageGroups;

/**
 *
 * @author gevirl
 */


public class ClusterRankedPeaks {

    TreeSet<String> allTFs = new TreeSet<>();  // all the tfs in the group
    TreeMap<String, TreeMap<String, RankedPeak>> rankedPeakMap = new TreeMap<>(); // clusterID -> TF -> highest rank peak in cluster for the TF
    int nPeaks;
    
    // all the peaks for a given stage group
    public ClusterRankedPeaks(ModelParams params, String group) throws Exception {
        nPeaks = 0;
        StageGroups groups = params.getStageGroups();
        File rankedPeakFile = params.getRankedPeakFile();

        BufferedReader reader = new BufferedReader(new FileReader(rankedPeakFile));
        String line = reader.readLine();
        while (line != null) {
            RankedPeak peak = new RankedPeak(line.split("\t"));
            String clusterID = peak.getClusterID();

            String tf = peak.getTF();
            String stage = peak.getStage();

            TreeMap<String, RankedPeak> tfMap = rankedPeakMap.get(clusterID);
            if (tfMap == null) {
                tfMap = new TreeMap<>();
                rankedPeakMap.put(clusterID, tfMap);
            }
            String stageGroup = groups.getGroup(stage);
            if (stageGroup != null) {
                if (stageGroup.equals(group)) {
                    RankedPeak currentPeak = tfMap.get(tf);
                    if (currentPeak == null) {
                        tfMap.put(tf, peak);
                        ++nPeaks;
                        allTFs.add(tf);
                    } else if (currentPeak.getRank() < peak.getRank()) {
                        ++nPeaks;
                        tfMap.put(tf, peak);
                    }
                }
            }

            line = reader.readLine();
        }
        reader.close();
    }

    public TreeSet<String> getAllTFs() {
        return this.allTFs;
    }

    public TreeMap<String, TreeMap<String, RankedPeak>> getRankedPeaks() {
        return this.rankedPeakMap;
    }

    public int getPeakCount(){
        return nPeaks;
    }
    // form the cluster by tf ranked signals matrix (all clusters by all tfs)
    static public void main(String[] args) throws Exception {
        ModelParams params = new ModelParams("worm");
        for (String stage : params.getGroupLabels()) {
            ClusterRankedPeaks rankedPeaks = new ClusterRankedPeaks(params, stage);

        }

    }
}
