/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

/**
 *
 * @author gevirl
 */
public abstract class ExprTF_pct implements FilterTF{
    ExpressionTF expr;
    double pct;
    public ExprTF_pct(ExpressionTF expr,double pct) throws Exception {
        this.expr = expr;
        this.pct = pct;
    }
    @Override
    public boolean accept(String stage, String cell, String tf) {
        double[] v = expr.getExpression(stage, tf);
        double mx = 0.0;
        for (int i=0 ; i<v.length ; ++i){
            if (mx < v[i]){
                mx = v[i];
            }
        }
        int index = expr.getCellIndex(stage, cell);
        return v[index] >= pct*mx;
    }    
}
