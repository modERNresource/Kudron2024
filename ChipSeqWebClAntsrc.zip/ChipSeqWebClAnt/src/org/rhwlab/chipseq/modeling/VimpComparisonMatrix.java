/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;

/**
 *
 * @author gevirl
 */
public class VimpComparisonMatrix {

    File dir;
    String stage;
    String tissue;

    TreeMap<String, Integer> cellIndex = new TreeMap<>();

    public VimpComparisonMatrix(File dir, String stage, String tissue) throws Exception {
        this.dir = dir;
        this.stage = stage;
        this.tissue = tissue;

        // get a result file
        File resultFile = new File(String.format("%s/%s/binary/allAlternates/%s.tsv", dir.getPath(), stage, tissue));
        BufferedReader reader = new BufferedReader(new FileReader(resultFile));
        String[] heads = reader.readLine().split("\t");
        reader.close();

        for (int i = 1; i < heads.length; ++i) {
            cellIndex.put(heads[i], i);
        }
    }

    public Set<String> getCellTypes() {
        return this.cellIndex.keySet();
    }

    public void reportCell(PrintStream stream, String cell, int nToReport) throws Exception {
        int c = this.cellIndex.get(cell);
        TreeMap<String, Vimp[]> map = new TreeMap<>();

        stream.printf("\nStage: %s\tCellType: %s\n", stage, cell);
        File stageDir = new File(dir, stage);
        for (File stageFile : stageDir.listFiles()) {
            if (stageFile.isDirectory() && !stageFile.getName().equals("response")) {
                File predictorDir = stageFile;
                for (File predictorFile : predictorDir.listFiles()) {
                    if (predictorFile.isDirectory()) {
                        ArrayList<String[]> rows = new ArrayList<>();

                        File altDir = predictorFile;
                        File vimpFile = new File(altDir, tissue + ".tsv");
                        if (!vimpFile.exists()) {
                            System.out.printf("Not found: %s\n", vimpFile.getPath());
                        } else {
                            BufferedReader reader = new BufferedReader(new FileReader(vimpFile));
                            String[] heads = reader.readLine().split("\t");
                            String line = reader.readLine();
                            while (line != null) {
                                rows.add(line.split("\t"));
                                line = reader.readLine();
                            }
                            reader.close();

                            Vimp[] vimps = new Vimp[rows.size()];
                            int i = 0;
                            for (String[] row : rows) {
                                String tf = row[0];
                                String v = row[c];
                                Double d = Double.NEGATIVE_INFINITY;
                                if (!v.equals("NA")) {
                                    d = Double.valueOf(v);
                                }
                                vimps[i] = new Vimp(tf, d);
                                ++i;
                            }
                            Arrays.sort(vimps);
                            String predictor = predictorDir.getName();
                            String alternate = altDir.getName();
                            map.put(String.format("%s/%s", predictor, alternate), vimps);
                        }
                    }

                    int hh = 0;
                }
            }
        }
        // print the headers
        for (int i = 0; i < 2; ++i) {
            boolean first = true;
            for (String label : map.keySet()) {
                String[] tokens = label.split("/");
                if (first) {
                    stream.printf("%-17s",tokens[i]);
                    first = false;
                } else {
                    stream.printf("%-17s", tokens[i]);
                }
            }
            stream.println();
        }

        // print the top n
        TreeMap<String, Integer> tfCountMap = new TreeMap<>();
        for (int i = 0; i < nToReport; ++i) {
            boolean first = true;
            for (String label : map.keySet()) {
                Vimp[] vimps = map.get(label);
                String tf = vimps[i].tf;
                Integer count = tfCountMap.get(tf);
                if (count == null) {
                    tfCountMap.put(tf, 1);
                } else {
                    tfCountMap.put(tf, count + 1);
                }
                if (first) {
                    first = false;
                    stream.printf("%-17s", tf);
                } else {
                    stream.printf("%-17s", tf);
                }
            }
            stream.println();
        }
        List<Vimp> list = new ArrayList<>();
        for (String tf : tfCountMap.keySet()) {
            Double d = tfCountMap.get(tf).doubleValue();
            list.add(new Vimp(tf, d));
        }

        // add up score for each label
        stream.print("Score");
        for (String label : map.keySet()) {
            int score = 0;
            Vimp[] vimps = map.get(label);
            for (int i = 0; i < nToReport; ++i) {
                score = score + tfCountMap.get(vimps[i].tf);
            }
 //           stream.printf("\t%d", score);
        }
        stream.println();

        stream.printf("Total TFs = %d\n", list.size());
        Collections.sort(list);
        for (Vimp vimp : list) {
//            stream.printf("%s\t%.0f\n", vimp.tf, vimp.v);
        }
    }

    class Vimp implements Comparable {

        String tf;
        Double v;

        public Vimp(String tf, Double v) {
            this.v = v;
            this.tf = tf;
        }

        @Override
        public int compareTo(Object o) {
            Vimp other = (Vimp) o;
            return -v.compareTo(other.v);
        }

    }

    public static void main(String[] args) throws Exception {
        PrintStream stream = System.out;
        File dir = new File("/net/waterston/vol9/ChipSeqPipeline/RF_Results");
        VimpComparisonMatrix mat = new VimpComparisonMatrix(dir, "larva", "Germline");
        for (String cellType : mat.getCellTypes()) {
            mat.reportCell(stream, cellType, 20);
        }
        int sadf = 0;
    }
}
