/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import org.rhwlab.bedformat.BedBase;
import org.rhwlab.chipseq.peaks.StageGroups;
import org.rhwlab.chipseq.peaks.WormStageGroups;
import org.rhwlab.gene.model.ModelGFF_Worm;
import org.rhwlab.singlecell.expression.WBGeneTranslation;

/**
 *
 * @author gevirl
 */
public class PredictorMatrix {
/*
    ArrayList<Predictor> predictorList;
    TreeSet<String> allTFs = new TreeSet<>();

    File clusterFile;
    TreeMap<String, TargetedCluster> clusterMap = new TreeMap<>();
    TreeMap<String, TargetDescription> targetDescMap;
    ClusterRankedPeaks rankedPeaks;

    StageGroups groups;
    int minSize;
    int maxSize;

    WBGeneTranslation translator;
    ModelGFF_Worm gff;

    public PredictorMatrix(File file) throws Exception {
        predictorList = new ArrayList<>();

        BufferedReader reader = new BufferedReader(new FileReader(file));
        String[] heads = reader.readLine().split("\t");
        for (int i = 3; i < heads.length; ++i) {
            allTFs.add(heads[i]);
        }
        String line = reader.readLine();
        while (line != null) {
            predictorList.add(new Predictor(heads, line.split("\t")));
            line = reader.readLine();
        }
        reader.close();
    }

    public PredictorMatrix(File clusterFile, ClusterRankedPeaks rankedPeaks, TreeMap<String, TargetDescription> targetDescMap, StageGroups groups, ModelGFF_Worm gff,
            WBGeneTranslation translator, int minSize, int maxSize) throws Exception {

        this.targetDescMap = targetDescMap;
        this.clusterFile = clusterFile;
        this.rankedPeaks = rankedPeaks;
        this.allTFs = rankedPeaks.getAllTFs();
        this.groups = groups;
        this.minSize = minSize;
        this.maxSize = maxSize;
        this.translator = translator;
        this.gff = gff;

        // subset clusters by size
        TreeMap<String, TargetedCluster> fileMap = asCluster(readFile(clusterFile, false, 3));
        for (TargetedCluster cluster : fileMap.values()) {
            int nPeaks = cluster.getPeakCount();
            String clusterID = cluster.getName();
            if ((minSize <= nPeaks) && (nPeaks <= maxSize)) {
                clusterMap.put(clusterID, cluster);
            }
        }
    }

    public TreeMap<String, TargetedCluster> getClusterMap() {
        return this.clusterMap;
    }

    // reports all the clusters
    public void reportMatrix(PrintStream stream, PredictorValue predValue) throws Exception {
        Predictor.printHeader(stream, allTFs);
        reportPredictors(stream, targetDescMap, clusterMap, rankedPeaks.getRankedPeaks(), predValue);
    }

    // reports filtered clusters filter by comparing to primary clusters 
    public TreeMap<String, TargetedCluster> reportMatrix(PrintStream stream,
            TreeMap<String, TargetedCluster> compareMap, UseTarget altUse, PredictorValue predValue) throws Exception {

        TreeMap<String, TargetedCluster> subsetMap = this.subsetClusters(compareMap, altUse);
        Predictor.printHeader(stream, allTFs);
        reportPredictors(stream, targetDescMap, subsetMap, rankedPeaks.getRankedPeaks(), predValue);

        return clusterMap;
    }

    public void reportPredictors(PrintStream stream, TreeMap<String, TargetDescription> targetDescMap, TreeMap<String, TargetedCluster> targetMap,
            TreeMap<String, TreeMap<String, RankedPeak>> rankedPeakMap, PredictorValue predValue) {

        for (TargetedCluster targeted : targetMap.values()) {
            String clusterID = targeted.getClusterID();
            TreeMap<String, RankedPeak> tfMap = rankedPeakMap.get(clusterID);
            Predictor p = makePredictor(targetDescMap, targeted, tfMap, predValue);
            if (p != null) {
                String gene = p.getTargetGene();
                String wbgene = gff.getBaseGene(gene);

                double[] expr = translator.getExpression(wbgene);
                if (expr != null && p.getCount() > 0) {
                    p.setBaseGene(translator.getTranslatedBaseGene(wbgene));
                    p.print(stream, allTFs);
                }
            }
        }
    }

    public Predictor makePredictor(TreeMap<String, TargetDescription> targetDescMap, TargetedCluster cluster, TreeMap<String, RankedPeak> peakMap, PredictorValue predValue) {
        Predictor ret = new Predictor();
        ret.setClusterID(cluster.getClusterID());
        String targetID = cluster.getTargetID();
        String gene = targetDescMap.get(targetID).getGene();
        ret.setTargetGene(gene);
        for (RankedPeak peak : peakMap.values()) {
            String tf = peak.getTF();
            Number num = predValue.getValue(peak, cluster);
            ret.setValue(tf, num);
        }
        return ret;
    }

    public TreeMap<String, TargetedCluster> subsetClusters(TreeMap<String, TargetedCluster> compareMap, UseTarget use) throws Exception {
        TreeMap<String, TargetedCluster> ret = new TreeMap<>();
        for (TargetedCluster cluster : clusterMap.values()) {
            String clusterID = cluster.getName();
            TargetedCluster compareCluster = compareMap.get(clusterID);
            if (compareCluster != null) {
                if (use.useAlternate(compareCluster, cluster)) {
                    ret.put(clusterID, cluster);
                }
            } else {
                ret.put(clusterID, cluster);
            }
        }
        return ret;
    }

    static public TreeMap<String, String[]> readFile(File file, boolean head, int idCol) throws Exception {
        TreeMap<String, String[]> map = new TreeMap<>();
        BufferedReader reader = new BufferedReader(new FileReader(file));
        if (head) {
            String[] heads = reader.readLine().split("\t");
        }
        String line = reader.readLine();
        while (line != null) {
            String[] tokens = line.split("\t");
            map.put(tokens[idCol], tokens);
            line = reader.readLine();
        }
        reader.close();
        return map;
    }

    static public TreeMap<String, TargetDescription> asTarget(TreeMap<String, String[]> map) {
        TreeMap<String, TargetDescription> ret = new TreeMap<>();
        for (String key : map.keySet()) {
            ret.put(key, new TargetDescription(map.get(key)));
        }
        return ret;
    }

    static public TreeMap<String, TargetedCluster> asCluster(TreeMap<String, String[]> map) {
        TreeMap<String, TargetedCluster> ret = new TreeMap<>();
        for (String key : map.keySet()) {
            ret.put(key, new TargetedCluster(map.get(key)));
        }
        return ret;
    }

    static public TreeMap<String, BedBase> asBed(TreeMap<String, String[]> map) {
        TreeMap<String, BedBase> ret = new TreeMap<>();
        for (String key : map.keySet()) {
            ret.put(key, new BedBase(map.get(key)));
        }
        return ret;
    }

    static public void main(String[] args) throws Exception {
/*
        File dir = new File("/net/waterston/vol9/ChipSeqPipeline");
        File rfModelDir = new File(dir, "RF_Model");

        String prefix = "AllWormPeaks.TF.noDups";
        File rankedPeakFile = new File(dir, String.format("%s.ranked.bed", prefix));
        File primaryTargetFile = new File(dir, String.format("%s.clusters.distance.bed", prefix));
        File alternateTargetFile = new File(dir, String.format("%s.clusters.altdist.bed", prefix));
        File targetDescFile = new File(dir, String.format("%s.clusters.peakTSSs", prefix));

        int minClusterSize = 2;
        int maxClusterSize = 84;

        File gffFile = new File("/net/waterston/vol9/WS285/c_elegans.PRJNA13758.WS285.annotations.allwormbase.gff3");
        ModelGFF_Worm gff = new ModelGFF_Worm(gffFile);

        String[] groupLabels = {"emb", "larva"};
        StageGroups stageGroups = new WormStageGroups();

        UseTarget[] alternates = {new NoAlternates(), new CloseAlternates(), new AllAlternates()};
        PredictorValue[] predictorValues = {new BinaryPredictor(), new SignalPredictor(), new DistanceSignal()};

        TreeMap<String, TargetDescription> targetDescMap = PredictorMatrix.asTarget(PredictorMatrix.readFile(targetDescFile, true, 0));

        for (String groupLabel : groupLabels) {
            File stageDir = new File(rfModelDir, groupLabel);
            File tfFile = new File(stageDir, "allTFs.tsv");
            PrintStream stream = new PrintStream(tfFile);
            stream.println("TF\twbGene245");
            WBGeneTranslation translator = new WBGeneTranslation(groupLabel);
            ClusterRankedPeaks rankedPeaks = new ClusterRankedPeaks(rankedPeakFile, stageGroups, groupLabel);
            TreeSet<String> allTFs = rankedPeaks.getAllTFs();
            System.out.printf("%d %s TFs\n", allTFs.size(), groupLabel);
            for (String tf : allTFs) {
                String wbGene285 = gff.getBaseGene(tf);
                String wbGene245 = translator.getTranslatedBaseGene(wbGene285);
                stream.printf("%s\t%s\n", tf, wbGene245);
            }
            stream.close();

            PredictorMatrix primaryMat = new PredictorMatrix(primaryTargetFile, rankedPeaks, targetDescMap, stageGroups, gff, translator, minClusterSize, maxClusterSize);
            TreeMap<String, TargetedCluster> primnaryClusterMap = primaryMat.getClusterMap();

            for (PredictorValue predictorValue : predictorValues) {
                File predictorDir = new File(stageDir, predictorValue.getLabel());
                Files.createDirectories(predictorDir.toPath());
                stream = new PrintStream(new File(predictorDir, "predictor.tsv"));
                primaryMat.reportMatrix(stream, predictorValue);
                stream.close();

                for (UseTarget alt : alternates) {
                    File altDir = new File(predictorDir, alt.getLabel());
                    Files.createDirectories(altDir.toPath());
                    PredictorMatrix altMat = new PredictorMatrix(alternateTargetFile, rankedPeaks, targetDescMap, stageGroups, gff, translator, minClusterSize, maxClusterSize);
                    stream = new PrintStream(new File(altDir, "predictor.tsv"));
                    altMat.reportMatrix(stream, primnaryClusterMap, alt, predictorValue);
                    stream.close();
                }
            }
        }

        /*       
        TreeSet<String> set = new TreeSet<>();
        for (TargetDescription desc : predMat.targetDescMap.values()) {
            String gene = desc.getTargetGene();
            String wbgene = gff.getBaseGene(gene);
            double[] expr = translator.getExpression(wbgene);
            if (expr == null) {
                set.add(String.format("%s\t%s",wbgene,gene));               
            }
            int sadf=0;
        }
        for (String s : set){
            System.out.println(s);
        }
*/
        //       ct.clusters(2, 83, null);
    
        
    }


