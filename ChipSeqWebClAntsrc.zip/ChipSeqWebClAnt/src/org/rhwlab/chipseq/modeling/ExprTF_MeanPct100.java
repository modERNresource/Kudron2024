/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

/**
 *
 * @author gevirl
 */
public class ExprTF_MeanPct100 extends ExprTF_MeanPct{
    public ExprTF_MeanPct100(ExpressionTF expr){
        super(expr,1.0);
    }
    @Override
    public String getLabel() {
        return "ExprTF_Mean";
    }
    
}
