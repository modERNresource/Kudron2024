/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.modeling;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Set;
import java.util.TreeMap;

/**
 *
 * @author gevirl
 */
public class Mse {
    File tsv;
    TreeMap<String, Double> errorMap = new TreeMap<>(); // celltype -> mse of a model run on the celltype

    public Mse(File tissueTSV) throws Exception {
        this.tsv = tissueTSV;        
        BufferedReader reader = new BufferedReader(new FileReader(tsv));
        String[] heads = reader.readLine().split("\t");  // skip the headings
        String line = reader.readLine();
        while (line != null) {
            String[] tokens = line.split("\t");
            errorMap.put(tokens[0], Double.valueOf(tokens[1]));
            line = reader.readLine();
        }
        reader.close();       
    }
    
    public String getTissue(){
        return tsv.getName().replace(".err.tsv", "");
    }
    
    public Set<String> getCellTypes(){
        return errorMap.keySet();
    }
    public Double getMSE(String cellType){
        return errorMap.get(cellType);
    }

}
