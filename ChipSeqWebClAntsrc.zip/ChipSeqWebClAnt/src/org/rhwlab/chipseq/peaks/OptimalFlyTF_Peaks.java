/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.peaks;

import org.rhwlab.chipseq.pipeline.OptimalPeaks;

/**
 *
 * @author gevirl
 */
public class OptimalFlyTF_Peaks extends OptimalTF_Peaks {
    public OptimalFlyTF_Peaks()throws Exception {
        super(OptimalPeaks.FlyTFBed());
    }   
}
