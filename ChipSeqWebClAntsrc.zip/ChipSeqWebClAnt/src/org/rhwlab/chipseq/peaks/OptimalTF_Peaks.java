/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.peaks;

import jakarta.json.Json;
import jakarta.json.JsonObject;
import jakarta.json.JsonReader;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import java.util.TreeSet;
import org.rhwlab.bedformat.BedBase;
import org.rhwlab.chipseq.pipeline.FileTable;
import org.rhwlab.chipseq.pipeline.OptimalPeaks;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipHelper;
import org.rhwlab.chipseqweb.HibernateUtil;
import org.rhwlab.lang.GreekPlus;

/**
 *
 * @author gevirl
 */
public class OptimalTF_Peaks {

    File bedFile;
    TreeMap<String, List<BedBase>> peakMap;  // TF -> list of peaks
    TreeMap<String, TreeMap<String, ChipExperiment>> expMap;  // TF -> ExpID -> ChipExperiment
    TreeMap<String, TreeMap<String, List<ChipExperiment>>> stageMap; //TF -> stage -> list of ChipExperiment
    TreeMap<String, TreeMap<String, ChipExperiment>> domainMap; // domain -> expID -> ChipExperiment ;

    public OptimalTF_Peaks(File bedFile) throws Exception {
        this.bedFile = bedFile;
        peakMap = readBed(bedFile);
        expMap = buildExperimentMap(peakMap);
        domainMap = buildDomainMap(expMap);
        stageMap = tfStages(expMap);

        int hh = 0;
    }

    // reads a aggregated TF peaks file and return index by TF
    public final TreeMap<String, List<BedBase>> readBed(File bedFile) throws Exception {

        TreeMap<String, List<BedBase>> peakMap = new TreeMap<>();
        BufferedReader reader = new BufferedReader(new FileReader(bedFile));
        String line = reader.readLine();
        while (line != null) {
            BedBase bed = new BedBase(line);
            String name = bed.getName();
            String[] tokens = name.split("_");
            String tf = tokens[0];
            List<BedBase> beds = peakMap.get(tf);
            if (beds == null) {
                beds = new ArrayList<>();
                peakMap.put(tf, beds);
            }
            beds.add(bed);
            line = reader.readLine();
        }
        reader.close();
        return peakMap;
    }

    public TreeMap<String, TreeMap<String, ChipExperiment>> buildDomainMap(TreeMap<String, TreeMap<String, ChipExperiment>> expMap) {
        TreeMap<String, TreeMap<String, ChipExperiment>> ret = new TreeMap<>();
        for (String TF : expMap.keySet()) {
            TreeMap<String, ChipExperiment> chipExpMap = expMap.get(TF);
            for (String expID : chipExpMap.keySet()) {
                ChipExperiment exp = chipExpMap.get(expID);
                String domain = exp.getDomain();
                if (domain != null) {
                    TreeMap<String, ChipExperiment> domMap = ret.get(domain);
                    if (domMap == null) {
                        domMap = new TreeMap<>();
                        ret.put(domain, domMap);
                    }
                    domMap.put(expID, exp);
                }
            }
        }
        return ret;
    }

    public final TreeMap<String, TreeMap<String, ChipExperiment>> buildExperimentMap(TreeMap<String, List<BedBase>> peakMap) throws Exception {
        TreeMap<String, TreeMap<String, ChipExperiment>> retMap = new TreeMap<>();
        for (String tf : peakMap.keySet()) {
            TreeMap<String, ChipExperiment> expMap = retMap.get(tf);
            if (expMap == null) {
                expMap = new TreeMap<>();
                retMap.put(tf, expMap);
            }

            List<BedBase> beds = peakMap.get(tf);
            for (BedBase bed : beds) {
                String expID = bed.getName();
                ChipExperiment exp = expMap.get(expID);
                if (exp == null) {
                    expID = expID.replace("ceh-38", "ceh-28");
                    expID = expID.replace("nhr-270", "nhr-27");
                    List exps = ChipHelper.getEquals("ChipExperiment", "ExpID", expID, "ExpID");
                    if (!exps.isEmpty()) {
                        exp = (ChipExperiment) exps.get(0);
                        expMap.put(expID, exp);
                    }

                }
            }
        }

        return retMap;
    }

    public TreeMap<String, TreeMap<String, List<ChipExperiment>>> tfStages(TreeMap<String, TreeMap<String, ChipExperiment>> expMap) {
        TreeMap<String, TreeMap<String, List<ChipExperiment>>> retMap = new TreeMap<>();

        for (String tf : expMap.keySet()) {
            TreeMap<String, ChipExperiment> tfMap = expMap.get(tf);
            for (String expID : tfMap.keySet()) {
                ChipExperiment exp = tfMap.get(expID);

                TreeMap<String, List<ChipExperiment>> stageMap = retMap.get(tf);
                if (stageMap == null) {
                    stageMap = new TreeMap<>();
                    retMap.put(tf, stageMap);
                }

                List<ChipExperiment> expList = stageMap.get(exp.getStage());
                if (expList == null) {
                    expList = new ArrayList<>();
                    stageMap.put(exp.getStage(), expList);
                }
                expList.add(exp);
            }
        }
        return retMap;
    }

    public void reportTFCounts(PrintStream stream) {
        GreekPlus greek = new GreekPlus();
        stream.println("TF\tTotalPeaks\tnExps\tAvgPeaks");
        for (String tf : this.peakMap.keySet()) {
            TreeSet<String> exps = new TreeSet<>();
            List<BedBase> beds = peakMap.get(tf);
            for (BedBase bed : beds) {
                exps.add(bed.getName());
            }
            stream.printf("%s\t%d\t%d\t%d\n", greek.reverseTranslate(tf), beds.size(), exps.size(), beds.size() / exps.size());
        }
    }

    // report those experiments for which there is more than one experiment for a TF and stage
    public void reportTFStages(PrintStream stream) throws Exception {
        GreekPlus greek = new GreekPlus();
        stream.println("TF\tStage\tStrain\tnExps\tRescueRatio\tConsistencyRatio\tnPeaks\tDCC");
        for (String tf : stageMap.keySet()) {
            TreeMap<String, List<ChipExperiment>> tfStageMap = stageMap.get(tf);
            for (String stage : tfStageMap.keySet()) {
                List<ChipExperiment> list = tfStageMap.get(stage);
                if (list.size() > 1) {
                    for (ChipExperiment exp : list) {
                        File dir = FileTable.EpicDirectory(exp);
                        File qcFile = new File(dir, "qc.json");
                        if (qcFile.exists()) {
                            JsonReader reader = Json.createReader(new FileReader(qcFile));
                            JsonObject qcObj = reader.readObject();
                            reader.close();

                            JsonObject replic = qcObj.getJsonObject("replication");
                            JsonObject repro = replic.getJsonObject("reproducibility");
                            JsonObject idr = repro.getJsonObject("idr");
                            double rescue = idr.getJsonNumber("rescue_ratio").doubleValue();
                            double consist = idr.getJsonNumber("self_consistency_ratio").doubleValue();
                            int nOpt = idr.getJsonNumber("N_opt").intValue();
                            String url = String.format("https://www.encodeproject.org/experiments/%s", exp.getAccession());
                            stream.printf("%s\t%s\t%s\t%d\t%f\t%f\t%d\t%s\n", greek.reverseTranslate(tf), stage, exp.getStrain(), list.size(), rescue, consist, nOpt, url);
                        }
                    }

                }
            }
        }
    }

    // returns cluster  set of TFs
    public void reportBinaryMatrix(PrintStream stream, int thresh) {
        // print the tf headings
        stream.print("cluster");
        for (String tf : this.peakMap.keySet()) {
            stream.printf("\t%s", tf);
        }
        stream.println();

        TreeMap<String, TreeSet<String>> clusterToTF_Map = new TreeMap<>();

        for (String tf : peakMap.keySet()) {
            System.out.printf("TF = %s\n", tf);
            for (BedBase bed : peakMap.get(tf)) {
                String cluster = bed.getValue(9);
                TreeSet<String> tfSet = clusterToTF_Map.get(cluster);
                if (tfSet == null) {
                    tfSet = new TreeSet<>();
                    clusterToTF_Map.put(cluster, tfSet);
                }
                tfSet.add(tf);
            }
        }

        // report the cluster by tf matrix
        for (String cluster : clusterToTF_Map.keySet()) {
            System.out.printf("Cluster = %s\n", cluster);
            TreeSet<String> tfSet = clusterToTF_Map.get(cluster);
            if (tfSet.size() <= thresh) {
                stream.print(cluster);
                for (String tf : peakMap.keySet()) {
                    int value = 0;
                    if (tfSet.contains(tf)) {
                        value = 1;
                    }
                    stream.printf("\t%d", value);
                }
                stream.println();
            }
        }
        int jj = 0;
    }

    public void reportBinaryMatrixByStage(PrintStream stream, int thresh) {

        TreeMap<String, TreeSet<String>> clusterToTF_Map = new TreeMap<>();
        TreeSet<String> tfStages = new TreeSet<>();
        for (String tf : peakMap.keySet()) {
            System.out.printf("TF = %s\n", tf);
            for (BedBase bed : peakMap.get(tf)) {
                String tfStage = String.format("%s_%s", tf, bed.getName().split("_")[2]);
                String cluster = bed.getValue(9);
                TreeSet<String> tfStageSet = clusterToTF_Map.get(cluster);
                if (tfStageSet == null) {
                    tfStageSet = new TreeSet<>();
                    clusterToTF_Map.put(cluster, tfStageSet);
                }
                tfStageSet.add(tfStage);
                tfStages.add(tfStage);
            }
        }

        // print the tf headings
        stream.print("cluster");
        for (String tfStage : tfStages) {
            stream.printf("\t%s", tfStage);
        }
        stream.println();

        // report the cluster by tf stage matrix
        for (String cluster : clusterToTF_Map.keySet()) {
            System.out.printf("Cluster = %s\n", cluster);
            TreeSet<String> tfStageSet = clusterToTF_Map.get(cluster);
            if (tfStageSet.size() <= thresh) {
                stream.print(cluster);
                for (String tfStage : tfStages) {
                    int value = 0;
                    if (tfStageSet.contains(tfStage)) {
                        value = 1;
                    }
                    stream.printf("\t%d", value);
                }
                stream.println();
            }
        }
        int jj = 0;
    }

    // returns cluster  set of TFs
    public void reportRankMatrix(PrintStream stream, int thresh) {
        // print the tf headings
        stream.print("cluster");
        for (String tf : this.peakMap.keySet()) {
            stream.printf("\t%s", tf);
        }
        stream.println();

        TreeMap<String, TreeMap<String, Double>> clusterToTF_Map = new TreeMap<>();

        for (String tf : peakMap.keySet()) {
            System.out.printf("TF = %s\n", tf);
            for (BedBase bed : peakMap.get(tf)) {
                String cluster = bed.getValue(10);
                TreeMap<String, Double> tfMap = clusterToTF_Map.get(cluster);
                if (tfMap == null) {
                    // new cluster
                    tfMap = new TreeMap<>();
                    clusterToTF_Map.put(cluster, tfMap);
                    tfMap.put(tf, Double.valueOf(bed.getValue(7)));
                } else {
                    Double v = Double.valueOf(bed.getValue(7));
                    Double current = tfMap.get(tf);
                    if (current == null) {
                        // new tf for the cluster
                        tfMap.put(tf, v);
                    } else if (v > current) {
                        tfMap.put(tf, v);
                    }
                }

            }
        }

        // report the cluster by tf matrix
        for (String cluster : clusterToTF_Map.keySet()) {
            System.out.printf("Cluster = %s\n", cluster);
            TreeMap<String, Double> tfMap = clusterToTF_Map.get(cluster);
            if (tfMap.size() <= thresh) {
                stream.print(cluster);
                for (String tf : peakMap.keySet()) {
                    Double v = tfMap.get(tf);
                    if (v == null) {
                        v = 0.0;
                    }
                    stream.printf("\t%f", v);
                }
                stream.println();
            }
        }
        int jj = 0;
    }

    public void reportBinaryMatrixByStageGroup(StageGroups groups) throws Exception {

        TreeMap<String, TreeSet<String>> groupTFs = new TreeMap<>();   // stageGroup -> tfs
        TreeMap<String, TreeMap<String, TreeSet<String>>> groupClusterTFMap = new TreeMap<>(); // stageGroup -> cluster >- set of TFa

        // build the above maps
        for (String tf : peakMap.keySet()) {
            System.out.printf("TF = %s\n", tf);
            for (BedBase bed : peakMap.get(tf)) {
                String[] tokens = bed.getName().split("_");
                String stageGroup = groups.getGroup(tokens[2]);
                if (stageGroup != null) {

                    TreeSet<String> tfSet = groupTFs.get(stageGroup);
                    if (tfSet == null) {
                        tfSet = new TreeSet<>();
                        groupTFs.put(stageGroup, tfSet);
                    }
                    tfSet.add(tf);

                    TreeMap<String, TreeSet<String>> clusterTFMap = groupClusterTFMap.get(stageGroup);
                    if (clusterTFMap == null) {
                        clusterTFMap = new TreeMap<>();
                        groupClusterTFMap.put(stageGroup, clusterTFMap);
                    }

                    String cluster = bed.getValue(9);
                    TreeSet<String> tfs = clusterTFMap.get(cluster);
                    if (tfs == null) {
                        tfs = new TreeSet<>();
                        clusterTFMap.put(cluster, tfs);
                    }
                    tfs.add(tf);
                }
            }
        }

        // output files
        for (String group : groups.getGroups()) {
            File outFile = new File(bedFile.getPath().replace(".bed", String.format(".ClusterBinaryMatrix_%s.tsv", group)));
            PrintStream stream = new PrintStream(outFile);

            // print the tf headings
            stream.print("cluster");
            for (String tf : groupTFs.get(group)) {
                stream.printf("\t%s", tf);
            }
            stream.println();

            // report the cluster by tf matrix
            TreeMap<String, TreeSet<String>> clusterTFMap = groupClusterTFMap.get(group);
            for (String cluster : clusterTFMap.keySet()) {
                System.out.printf("Cluster = %s\n", cluster);
                TreeSet<String> tfs = clusterTFMap.get(cluster);
                stream.print(cluster);
                for (String tf : groupTFs.get(group)) {
                    int value = 0;
                    if (tfs.contains(tf)) {
                        value = 1;
                    }
                    stream.printf("\t%d", value);
                }
                stream.println();

            }
            stream.close();
        }

        int jj = 0;
    }
/*
    public static void domains() throws Exception {
        PrintStream stream = new PrintStream("/data/www/site/waterston/html/ChipSeqPipeline/WormExpDomains.tsv");
        OptimalPeaks.destination = "epic";
        OptimalTF_Peaks wormPeaks = new OptimalWormTF_Peaks();
        for (String domain : wormPeaks.domainMap.keySet()) {
            stream.printf("%s\t%d\n", domain, wormPeaks.domainMap.get(domain).size());
        }
        stream.close();
    }
*/
    public static void main(String[] args) throws Exception {

        //       File bed = OptimalPeaks.WormTFClusteredBed();
        File bed = OptimalPeaks.FlyTFClusteredBed();
        StageGroups groups = new FlyStageGroups();
        /*        
        File bed = OptimalPeaks.WormTFClusteredBed();
        StageGroups groups = new WormStageGroups();
         */
        OptimalTF_Peaks optPeaks = new OptimalTF_Peaks(bed);
        optPeaks.reportBinaryMatrixByStageGroup(groups);

//        File outFile = new File(bed.getPath().replace(".bed", ".ClusterBinaryMatrixByStage.tsv"));
//        PrintStream stream = new PrintStream(outFile);
//        stream.close();
//        wormPeaks.reportTFStages(System.out);
        //       System.out.println("\n\nFly");
        //       wormPeaks.reportTFCounts(System.out);
//        OptimalTF_Peaks flyPeaks = new OptimalFlyTF_Peaks();
//        flyPeaks.reportTFStages(System.out);
        HibernateUtil.shutdown();
    }
}
