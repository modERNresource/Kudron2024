/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.rhwlab.chipseq.peaks;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.TreeSet;

/**
 *
 * @author gevirl
 */
// no dups ranked peak file 
// same as used in random forest modeing
public class RankedPeakFile {
    File peakFile;
    
    public RankedPeakFile(File peakFile){
        this.peakFile = peakFile;
    }
    
    // selects a set of peaks from the full file
    public void cullPeaks(File peakIDsFile,File outFile)throws Exception {
        TreeSet<String> ids = new TreeSet<>();
        BufferedReader reader = new BufferedReader(new FileReader(peakIDsFile));
        String id = reader.readLine();
        while(id != null){
            ids.add(id);
            id = reader.readLine();
        }
        reader.close();
        
        PrintStream stream = new PrintStream(outFile);
        reader = new BufferedReader(new FileReader(peakFile));
        String line = reader.readLine();
        while (line != null){
            String[] tokens = line.split("\t");
            String peakid = String.format("%s_%s_%s_%s", tokens[0], tokens[1], tokens[2], tokens[3]);
            if (ids.contains(peakid)){
                stream.println(line);
            }
            line = reader.readLine();
        }
        reader.close();
        stream.close();
    }
    
    static public void main(String[] args)throws Exception {
        File peakFile = new File("/net/waterston/vol9/ChipSeqPipeline/AllFlyPeaks.TF.noDups.ranked.bed");
        File outFile = new File("/net/waterston/vol9/ChipSeqPipeline/AllFlyPeaks.TF.noDups.ranked.withMotif.bed");
        File peakIdFile = new File("/net/waterston/vol2/home/gevirl/Downloads/FlyTFPeaksPrimaryTargetsWithMotif");
        
        RankedPeakFile ranked = new RankedPeakFile(peakFile);
        ranked.cullPeaks(peakIdFile, outFile);
    }
}
