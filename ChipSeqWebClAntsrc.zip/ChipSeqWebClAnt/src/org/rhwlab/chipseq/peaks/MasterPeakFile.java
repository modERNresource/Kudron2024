
package org.rhwlab.chipseq.peaks;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Set;
import java.util.TreeMap;

/**
 *
 * @author gevirl
 */
public class MasterPeakFile {
    File peakFile;
    String idColumn;
    String[] columns;
    
    TreeMap<String,String[]> dataMap = new TreeMap<>(); // peakID -> data values
    TreeMap<String,Integer> indexMap = new TreeMap<>(); // data column label -> array index
    ArrayList<String> peakIDs = new ArrayList<>();
    
    public MasterPeakFile(File peakFile,String idColumn,String[] columns) throws Exception{
        this.peakFile = peakFile;
        this.idColumn = idColumn;
        this.columns = columns;
        
        TreeMap<String, Integer> headMap = new TreeMap<>();
        BufferedReader reader = new BufferedReader(new FileReader(peakFile));
        String[] heads = reader.readLine().split("\t");
        for (int i = 0; i < heads.length; ++i) {
            headMap.put(heads[i], i);
        }
        if (columns == null){
            columns = heads;
        }
        int idIndex = headMap.get(idColumn);
        for (int i=0 ; i<columns.length ; ++i){
            indexMap.put(columns[i], i);
        }
        
        String line = reader.readLine();
        while (line != null) {
            String[] tokens = line.split("\t");   
            String[] data = new String[columns.length];
            String id = tokens[idIndex];
            peakIDs.add(id);
            for (int i=0 ; i<columns.length ; ++i){
                data[i] = tokens[headMap.get(columns[i])];
            }
            dataMap.put(id,data);
            line = reader.readLine();
        }
        reader.close();
    }

    public String get(String id,String column){
        return dataMap.get(id)[indexMap.get(column)];
    }
    
    public Set<String> getIDs(){
        return dataMap.keySet();
    }

    
    public static void main(String[] args)throws Exception{
        String[] columns = {"TF"};
        File peakFile = new File("/net/waterston/vol2/home/gevirl/Downloads/FlyTFPeaksPrimaryTargets.tsv");
        MasterPeakFile master = new MasterPeakFile(peakFile,"peakID",columns);
        int hh=0;
    }
}
