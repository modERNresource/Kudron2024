/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.peaks;

import java.util.TreeSet;
import org.rhwlab.singlecell.expression.SingleCellExprMat;

/**
 *
 * @author gevirl
 */
public class WormStageGroups extends StageGroups {

    public WormStageGroups() {
        chipToGroup.put("earlyembryonic", "emb");
        chipToGroup.put("mixedstage", "emb");
        chipToGroup.put("midembryonic", "emb");
        chipToGroup.put("lateembryonic", "emb");
        chipToGroup.put("L1larva", "larva");
        chipToGroup.put("L2larva", "larva");
        chipToGroup.put("L3larva", "larva");
        chipToGroup.put("dauer", "larva");
        chipToGroup.put("youngadult", "adult");
        chipToGroup.put("L4larva", "adult");
        chipToGroup.put("L4youngadult", "adult");
        
        cellToGroup.put("emb", "emb");
        cellToGroup.put("lineage", "emb");
        cellToGroup.put("adult", "adult");
        cellToGroup.put("larva", "larva");
        
        cellToGroup.put("larva1", "larva");
        cellToGroup.put("larva2", "larva");
        cellToGroup.put("larva3", "larva");
        cellToGroup.put("larva4", "adult");
        cellToGroup.put("larva3Seam", "larva");
        cellToGroup.put("larva3Hypo", "larva");
        cellToGroup.put("larva4Sperm", "adult");
        
        
    }

    public String getExprStage(String cellsStage) {
        return SingleCellExprMat.stageMap(cellsStage);
    }
 /*       
        String exprStage = null;
        if (cellsStage.equals("emb")) {
            exprStage = "Emb";
        }
        if (cellsStage.equals("larva")) {
            exprStage = "L2";
        }
        if (cellsStage.equals("adult")) {
            exprStage = "Adult";
        }
        if (cellsStage.equals("lineage")) {
            exprStage = "Lineage";
        }
        return exprStage;
    }
*/
}
