/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.qa;

import org.apache.commons.math3.ml.distance.DistanceMeasure;
import org.apache.commons.math3.stat.correlation.PearsonsCorrelation;
import org.apache.commons.math3.stat.correlation.SpearmansCorrelation;
import org.apache.commons.math3.stat.ranking.NaturalRanking;

/**
 *
 * @author gevirl
 */
public class AbsSpearmans implements DistanceMeasure {

    @Override
    public double compute(double[] a, double[] b) {
        int ishdfiusdhf=0;
        double c = Math.abs(spear.correlation(a, b));
        Double d = Correlation.spearman(a, b);
        if (Double.isNaN(c)){
            NaturalRanking rank = new NaturalRanking();
            double[] ar = rank.rank(a);
            double[] br = rank.rank(b);
            PearsonsCorrelation pc = new PearsonsCorrelation();
            double pear = pc.correlation(ar, br);
            int uisdgiufhda=0;
        }
        return c;
    }
    static SpearmansCorrelation spear = new SpearmansCorrelation();
}
