/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.qa;

import java.util.Comparator;

/**
 *
 * @author gevirl
 */
    
    public class TargetComparator implements Comparator {

        @Override
        public int compare(Object o1, Object o2) {
            Target t1 = (Target)o1;
            Target t2 = (Target)o2;
            
            double d1 = Math.abs(t1.getDistance());
            double d2 = Math.abs(t2.getDistance());
            
            return Double.compare(d2,d1);
        }


        
    } 
