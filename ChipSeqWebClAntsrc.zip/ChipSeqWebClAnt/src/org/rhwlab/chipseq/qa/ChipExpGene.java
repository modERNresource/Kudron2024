/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.qa;

import java.io.PrintStream;

/**
 *
 * @author gevirl
 */
public class ChipExpGene {
    String sequence;
    String gene;
    String wbGene;
    Double distance = null;  // the distance of this gene to the TF of the experiment based on single cell expression (Spearmans)
    String experiment = null;    
    
    public ChipExpGene(String[] tokens){
        this(tokens,null,null);
        if (tokens.length >= 4 && !tokens[3].equals("NA")) {
            setDistance(Double.valueOf(tokens[3]));
        }
        if (tokens.length >= 5 && !tokens[4].equals("NA")) {
            setExperiment(tokens[4]);
        }        
    }
    public ChipExpGene(String[] geneTripleID,Double dist,String exp){
        this.sequence = geneTripleID[0];
        this.gene = geneTripleID[1];
        this.wbGene = geneTripleID[2];  
        this.distance = dist;
        this.experiment = exp;
    }
        static void printHeading(PrintStream stream){
        stream.println("Sequence,Common,WBGene,Distance,Experiment");
    }
    public void print(PrintStream stream) {
        stream.printf("%s,%s,%s", sequence, gene, wbGene);
        printDouble(distance, stream);
        printString(experiment,stream);
        stream.println();
    }    
    final public void setDistance(double d) {
        this.distance = d;
    }
    final public void setExperiment(String exp){
        this.experiment = exp;
    }
    
    public void printString(String s, PrintStream stream) {
        if (s == null) {
            stream.print(",NA");
        } else {
            stream.printf(",%s", s);
        }
    }    

    public void printDouble(Double d, PrintStream stream) {
        if (d == null) {
            stream.print(",NA");
        } else {
            stream.printf(",%f", d);
        }
    }

    public String getWBGene() {
        return wbGene;
    }

    public String getGene() {
        return gene;
    }

    public Double getDistance() {
        return distance;
    }    
}
