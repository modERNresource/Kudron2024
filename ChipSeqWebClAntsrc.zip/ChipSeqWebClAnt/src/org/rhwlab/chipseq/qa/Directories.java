/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.qa;

import java.io.File;

/**
 *
 * @author gevirl
 */
public class Directories {
    final public static File epicHtmlDir = new File("/data/www/site/waterston/html");
    final public static File epicDir = new File(epicHtmlDir,"ChipSeqPipeline");
    public static File sourceDir = new File("/net/waterston/vol9/ChipSeqPipeline"); 
    public static File epicWormDir = new File(epicDir,"worm");
    public static File epicFlyDir = new File(epicDir,"fly");
}
