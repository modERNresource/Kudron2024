/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.qa;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.TreeMap;
import java.util.TreeSet;
import org.apache.commons.math3.stat.StatUtils;
import org.jfree.data.statistics.HistogramDataset;
import org.rhwlab.chipseq.Peak;
import org.rhwlab.chipseq.PeakFile;
import org.rhwlab.gene.model.Annotation;
import org.rhwlab.gene.model.GeneIntervals;
import org.rhwlab.gene.model.ModelFromGFF;
import org.rhwlab.gene.model.Neighborhood;

/**
 *
 * @author gevirl
 */
// finds the gene targets of a set of peaks in a bigBed
public class ChipSeqTargets {

    File targetCSV;
    ArrayList<Target> targets;
    TreeMap<String, Target> wbGeneIndex;

    public ChipSeqTargets() {
        targets = new ArrayList<>();
        wbGeneIndex = new TreeMap<>();
    }

    public ChipSeqTargets(File targetCSV) throws Exception {
        this();
        this.targetCSV = targetCSV;
        if (targetCSV.exists()) {
            BufferedReader reader = new BufferedReader(new FileReader(targetCSV));
            String line = reader.readLine();
            while (line != null) {
                String[] tokens = line.split(",");
                addTarget(new Target(tokens));
                line = reader.readLine();
            }
            reader.close();
        }
    }

    public boolean hasDistance(){
        for (Target target : targets){
            if (target.distance != null){
                return true;
            }
        }
        return false;
    }
    public void addAll(ChipSeqTargets set) {
        for (Target target : set.getTargets()) {
            this.addTarget(target);
        }
    }

    public double averageSignalValue() {
        double sum = 0.0;
        for (Target target : targets) {
            sum = sum + target.getSignalValue();
        }
        return sum / targets.size();
    }
    public double averageDistanceValue() {
        double sum = 0.0;
        for (Target target : targets) {
            sum = sum + Math.abs(target.getDistance());
        }
        return sum / targets.size();
    }
    public void addTarget(Target target) {
        targets.add(target);
        wbGeneIndex.put(target.wbGene, target);
    }

    // saves all target , overwrites existing file
    public void saveTargets(File csv) throws Exception {
        saveTargets(csv,false,false);
    }
    public void saveTargets(File csv,boolean append,boolean dist) throws Exception {
        targetCSV = csv;
        PrintStream stream = new PrintStream(new FileOutputStream(targetCSV,append));

        for (Target target : targets) {
            if (!dist || (dist && target.getDistance()!=null)  ){
                target.print(stream);
            }
        }
        stream.close();
    }

    static public File outFile(File bigBed) {
        return new File(bigBed.getPath().replace(".bb", ".targets"));
    }

    static public ChipSeqTargets targetsFromBedPeaks(File bed, ModelFromGFF gff) throws Exception {
        TreeMap<String, String> chrMap = new TreeMap<>();

        chrMap.put("CHROMOSOME_I", "I");
        chrMap.put("CHROMOSOME_II", "II");
        chrMap.put("CHROMOSOME_III", "III");
        chrMap.put("CHROMOSOME_IV", "IV");
        chrMap.put("CHROMOSOME_V", "V");
        chrMap.put("CHROMOSOME_X", "X");
        chrMap.put("CHROMOSOME_M", "MtDNA");

        chrMap.put("ChrI", "I");
        chrMap.put("ChrII", "II");
        chrMap.put("ChrIII", "III");
        chrMap.put("ChrIV", "IV");
        chrMap.put("ChrV", "V");
        chrMap.put("ChrX", "MtDNA");
        chrMap.put("ChrM", "X");

        TreeMap<String, GeneIntervals> chromoMap = new TreeMap<>();
        TreeSet<String> targetSet = new TreeSet<>();

        BufferedReader reader = new BufferedReader(new FileReader(bed));
        String line = reader.readLine();
        while (line != null) {
            String[] tokens = line.split("\t|,");

            String chromo = tokens[0];
            String chr = chrMap.get(chromo);
            if (chr != null) {
                chromo = chr;
            }
            GeneIntervals geneIntervals = chromoMap.get(chromo);
            if (geneIntervals == null) {
                geneIntervals = new GeneIntervals(chromo, gff);
            }
            int mid = (Integer.valueOf(tokens[1]) + Integer.valueOf(tokens[2])) / 2;
            Neighborhood neigh = new Neighborhood(chromo, mid);
            neigh.locateInGenome(geneIntervals.getMap(), geneIntervals.getTree());
            List<String> targetList = neigh.pickPossibleTargets();
            for (String target : targetList) {
                targetSet.add(target);
            }
            line = reader.readLine();
        }
        reader.close();
        ChipSeqTargets ret = new ChipSeqTargets();
        for (String target : targetSet) {
            String[] triplet = gff.geneNameTriplet(target);  //triplet -> sequence,gene,wbGene
            ret.addTarget(new Target(triplet));
        }
        return ret;
    }

    // input bigbed of called peaks to determine the targets
    static public ChipSeqTargets targetsFromPeaks(String label,PeakFile peakFile, ModelFromGFF gff, TreeMap<String, GeneIntervals> chromoMap) throws Exception {
        ChipSeqTargets ret = new ChipSeqTargets();

        TreeMap<String, String> chrMap = new TreeMap<>();

        chrMap.put("CHROMOSOME_I", "I");
        chrMap.put("CHROMOSOME_II", "II");
        chrMap.put("CHROMOSOME_III", "III");
        chrMap.put("CHROMOSOME_IV", "IV");
        chrMap.put("CHROMOSOME_V", "V");
        chrMap.put("CHROMOSOME_X", "X");
        chrMap.put("CHROMOSOME_M", "MtDNA");

        chrMap.put("chrI", "I");
        chrMap.put("chrII", "II");
        chrMap.put("chrIII", "III");
        chrMap.put("chrIV", "IV");
        chrMap.put("chrV", "V");
        chrMap.put("chrM", "MtDNA");
        chrMap.put("chrX", "X");

        for (String ch : peakFile.getChromosomes()) {
            String chromo = chrMap.get(ch);
            if (chromo == null) {
                chromo = ch;
            }
            GeneIntervals geneIntervals = chromoMap.get(chromo);
            if (geneIntervals == null) {
                geneIntervals = new GeneIntervals(chromo, gff);
                chromoMap.put(chromo, geneIntervals);
            }
            for (Peak peak : peakFile.getChromosomePeaks(ch)) {
                Neighborhood neigh = new Neighborhood(chromo, peak.getApex());
                neigh.locateInGenome(geneIntervals.getMap(), geneIntervals.getTree());
                List<String> targetList = neigh.pickPossibleTargets();
                for (String targetID : targetList) {
                    String[] triplet = gff.geneNameTriplet(targetID);
                    Target target
                            = new Target(triplet, peak.getBedRecord().getSignalValue(), peak.getBedRecord().getQValue(), peak.getBedRecord().getClusterSize(),label);
                    ret.addTarget(target);
                }
            }
        }
        return ret;
    }

    public void sortByDistance(){
        Collections.sort(targets, new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                Target t1 = (Target) o1;
                Target t2 = (Target) o2;
                return t1.distance.compareTo(t2.distance);
            }
        });        
    }
    public void sortBySignalValue() {
        Collections.sort(targets, new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                Target t1 = (Target) o1;
                Target t2 = (Target) o2;
                return t1.signalValue.compareTo(t2.signalValue);
            }
        });
    }

    public void sortByClusterSize() {
        Collections.sort(targets, new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                Target t1 = (Target) o1;
                Target t2 = (Target) o2;
                return t1.clusterSize.compareTo(t2.clusterSize);
            }
        });
    }

    // return the set of targets as wbgene names
    public List<String> wbGeneList() throws Exception {
        ArrayList<String> wbGenes = new ArrayList<>();
        for (Target target : targets) {
            wbGenes.add(target.wbGene);
        }
        return wbGenes;
    }

    // divide the set of targets into D sets
    public List<ChipSeqTargets> divideTargets(int D) {
        List<ChipSeqTargets> ret = new ArrayList<>();
        int n = (targets.size() / D) + 1;
        ChipSeqTargets current = new ChipSeqTargets();
        int i = 0;
        for (Target target : targets) {
            if (i == n) {
                ret.add(current);
                current = new ChipSeqTargets();
                i = 0;
            }
            current.addTarget(target);
            ++i;
        }
        if (!current.targets.isEmpty()) {
            ret.add(current);
        }
        return ret;
    }

    public List<ChipSeqTargets> targetsClusterSizeIntervals(int[] intervals) {
        List<ChipSeqTargets> ret = new ArrayList<>();
        for (int i=0 ; i<intervals.length ; ++i){
            ret.add(new ChipSeqTargets());
        }

        for (Target target : targets) {
            int size = target.clusterSize;
            for (int i=0 ; i<intervals.length ; ++i){
                if (size <= intervals[i]){
                    ret.get(i).addTarget(target);
                    break;
                }
            }
        }
        return ret;
    }

// split the set of targets based on the sign of the target in a distance matrix for a given tf
    public TreeMap<String, ChipSeqTargets> splitTargets(double zThresh) throws Exception {

        // compute the mean and std deviation of the distances
        double[] da = getDistances();
        double mean = StatUtils.mean(da);
        double stdDev = Math.sqrt(StatUtils.variance(da, mean));

        TreeMap<String, ChipSeqTargets> ret = new TreeMap<>();
        ChipSeqTargets enh = new ChipSeqTargets();
        ret.put("enhance", enh);
        ChipSeqTargets rep = new ChipSeqTargets();
        ret.put("repress", rep);

        for (Target target : targets) {
            Double d = target.getDistance();
            if (d != null) {
                double z = (d - mean) / stdDev;
                if (Math.abs(z) > zThresh) {

                    if (d > 0 && z > 0) {
                        enh.addTarget(target);
                    } else if (d < 0 && z < 0) {
                        rep.addTarget(target);
                    }
                }
            }
        }
        Collections.sort(enh.targets, new TargetComparator());
        Collections.sort(rep.targets, new TargetComparator());
        return ret;
    }

    public double[] getDistances() {
        List<Double> list = new ArrayList<>();
        for (Target target : targets) {
            if (target.getDistance() != null) {
                list.add(target.getDistance());
            }
        }
        double[] ret = new double[list.size()];
        int i = 0;
        for (Double d : list) {
            ret[i] = d;
            ++i;
        }
        return ret;
    }

    public HistogramDataset formHistogram(int nBins) {
        HistogramDataset ret = new HistogramDataset();
        List<Double> valueList = new ArrayList<>();
        for (Target target : targets) {
            if (target.getDistance() != null) {
                valueList.add(target.getDistance());
            }
        }
        int i = 0;
        double[] x = new double[valueList.size()];
        for (Double d : valueList) {
            x[i] = d;
            ++i;
        }
        ret.addSeries(this.targetCSV.getName(), x, nBins, -1.0, 1.0);
        return ret;
    }

    public List<Target> getTargets() {
        return targets;
    }

    // finds the genes targets for successful runs for the idr filtered peaks (optimal and conservative)
    // will overwrite existing files only if args.length > 0
    // only does worm runs at this time
    public static void main(String[] args) throws Exception {
        File gffFile = new File("/net/waterston/vol9/References/WS260/c_elegans.PRJNA13758.WS260.annotations.WormBase.gff3");
        Annotation.remapChromo = false;
        ModelFromGFF gff = new ModelFromGFF(gffFile);
        TreeMap<String, GeneIntervals> chromoMap = new TreeMap<>();

        TreeMap<String, List<File>> map = SuccessfulRuns.successRuns();
        for (String genomeTSV : map.keySet()) {
            if (genomeTSV.contains("WS")) {  // only doing worm
                for (File runDir : map.get(genomeTSV)) {
                    File hubDir = new File(Directories.epicDir, runDir.getName());
                    System.out.printf("Hub directory: %s\n",hubDir.getPath());
                    // find targets for the called peaks
                    for (File f : hubDir.listFiles()) {
                        if (f.getName().endsWith(".bb")) {
                            if (f.getName().contains("idr")) {
                                System.out.printf("Hub file: %s\n",f.getPath());
                                File outFile = ChipSeqTargets.outFile(f);
                                
                                
                                if (!outFile.exists() || args.length > 0) {
                                    System.out.printf("Finding targets for: %s\n", f.getPath());
                                    String tf = SuccessfulRuns.getTF(hubDir);
                                    ChipSeqTargets targets = ChipSeqTargets.targetsFromPeaks(null,new PeakFile(f, tf), gff, chromoMap);
                                    targets.sortBySignalValue();
                                    targets.saveTargets(ChipSeqTargets.outFile(f));
                                } else {
                                    System.out.printf("outfile: %s \n", outFile.getPath());
                                }
                            }
                        }
                    }
                }
            }
        }
    }

}
