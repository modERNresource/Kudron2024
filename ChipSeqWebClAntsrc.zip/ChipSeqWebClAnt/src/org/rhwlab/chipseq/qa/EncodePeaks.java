/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.qa;

import java.io.File;
import java.io.PrintStream;
import java.util.List;
import java.util.TreeMap;
import org.rhwlab.chipseq.PeakFile;
import org.rhwlab.gene.model.Annotation;
import org.rhwlab.gene.model.GeneIntervals;
import org.rhwlab.gene.model.ModelFromGFF;
import org.rhwlab.singlecell.expression.PrefixMaps;
import org.rhwlab.tfs.AllTFs;

/**
 *
 * @author gevirl
 */
public class EncodePeaks {

    static public void findTargets() throws Exception {
        AllTFs tfs = new AllTFs();

        File mainDir = new File("/net/waterston/vol9/testpeak");
        File bedDir = new File(mainDir, "beds");
        File targetDir = new File(mainDir, "targets");

        File allDistTargets = new File(mainDir, "All_targets.csv");
        PrintStream allTargetStream = new PrintStream(allDistTargets);
        Target.printHeading(allTargetStream);
        allTargetStream.close();
        
        File allNonTargets = new File(mainDir, "All_nontargets.csv");
        PrintStream allNonTargetStream = new PrintStream(allNonTargets);
        ChipExpGene.printHeading(allNonTargetStream);
        
        StagePrefixMap stageMap = new StagePrefixMap();
        PrefixMaps prefixMap = new PrefixMaps();
        TreeMap<String, DistanceMatrix> distMatMap = new TreeMap<>();

        File gffFile = new File("/net/waterston/vol9/References/WS260/c_elegans.PRJNA13758.WS260.annotations.WormBase.gff3");
        Annotation.remapChromo = false;
        ModelFromGFF gff = new ModelFromGFF(gffFile);
        TreeMap<String, GeneIntervals> chromoMap = new TreeMap<>();

        for (File bed : bedDir.listFiles()) {
            if (bed.getName().endsWith("bed")) {

                String tf = tfFromFileName(bed.getName(), 12);

                if (tfs.containsGeneName(tf)) {
                    String stage = stageFromFileName(bed.getName(), 12);
                    String prefix = stageMap.getPrefix(stage);
                    String exp = experimentLabel(bed.getName(), 12);

                    PeakFile peakFile = new PeakFile(bed, tf);
                    ChipSeqTargets targets = ChipSeqTargets.targetsFromPeaks(exp, peakFile, gff, chromoMap);

                    if (prefix != null) {
                        DistanceMatrix mat = distMatMap.get(prefix);
                        if (mat == null) {
                            mat = new DistanceMatrix(prefixMap.getSignedDistanceMatrixMap().get(prefix));
                            distMatMap.put(prefix, mat);
                        }
                        mat.setTargetDistance(targets, tf);
                        targets.saveTargets(allDistTargets, true, true);

                        // save the non targets
                        List<String> nonTargetList = mat.complementSet(targets.wbGeneList());
                        Double[] nonTargetDist = mat.getAllDistance(nonTargetList, tf);
                        if (nonTargetDist != null) {
                            PrintStream nonTargetStream = new PrintStream(new File(targetDir, String.format("%s.nontargets", exp)));
                            ChipExpGene.printHeading(nonTargetStream);
                            int i = 0;
                            for (String nonTarget : nonTargetList) {
                                if (nonTargetDist[i] != null) {
                                    String[] triplet = gff.geneNameTriplet(nonTarget);

                                    // save the nontarget
                                    ChipExpGene non = new ChipExpGene(triplet);
                                    non.setDistance(nonTargetDist[i]);
                                    non.setExperiment(exp);
                                    non.print(nonTargetStream);
                                    non.print(allNonTargetStream);
                                }
                                ++i;
                            }
                        }
                        else {
                            System.out.printf("No expression: %s\n",tf);
                        }
                        File targetFile = new File(targetDir, String.format("%s.targets", exp));
                        targets.saveTargets(targetFile,false,true);
                    } 
                    else {
                        System.out.printf("No expression for stage %s\n", tf);
                    }
                }
                else {
                    System.out.printf("Not a tf: %s\n",tf);
                }
            }
        }
    }


    static public void main(String[] args) throws Exception {
 //       findTargets();

        StagePrefixMap stageMap = new StagePrefixMap();
        PrefixMaps prefixMap = new PrefixMaps();
        TreeMap<String, DistanceMatrix> distMatMap = new TreeMap<>();
        File mainDir = new File("/net/waterston/vol9/testpeak");
        File targetDir = new File(mainDir, "targets");

        PrintStream signalValueScoresStream = new PrintStream(new File(mainDir,"SignalValueScores.csv"));
        signalValueScoresStream.println("Experiment,SignalValue,Score");
        
        PrintStream spearScoresStream = new PrintStream(new File(mainDir,"SpearmanScores.csv"));
        spearScoresStream.println("Experiment,Spearman,Score");
        
        PrintStream stream = new PrintStream(new File(mainDir, "ClusterIntervalScores.csv"));
        stream.println("Experiment,Size,Score");
        
        PrintStream distStream = new PrintStream(new File(mainDir, "ClusterIntervalDistance.csv"));
        distStream.println("Experiment,Size,Distance");
        
        PrintStream expStream = new PrintStream(new File(mainDir,"ExperimentScores.csv"));
        expStream.println("Experiment,Score");
        
        for (File targetFile : targetDir.listFiles()) {
            if (targetFile.getName().endsWith(".targets")) {
                ChipSeqTargets targets = new ChipSeqTargets(targetFile);
                if (targets.hasDistance()) {
                    String fname = targetFile.getName();
                    System.out.println(fname);
                    String tf = tfFromFileName(fname, 0);
                    String stage = stageFromFileName(fname, 0).replace(".targets", "");
                    String prefix = stageMap.getPrefix(stage);
                    String label = experimentLabel(fname, 0).replace(".targets", "");

                    DistanceMatrix mat = distMatMap.get(prefix);
                    if (mat == null) {
                        mat = new DistanceMatrix(prefixMap.getSignedDistanceMatrixMap().get(prefix));
                        distMatMap.put(prefix, mat);
                    }
                    
                    List<String> nonTargetList = mat.complementSet(targets.wbGeneList());
                    
                    String expScore = DistanceMatrix.convertScore(mat.scoreMannWhitney(targets.wbGeneList(), nonTargetList, tf));
                    expStream.printf("%s,%s\n", label,expScore);
                    
                    // compute the Mannwhitney scores by cluster size
                    targets.sortByClusterSize();
                    List<ChipSeqTargets> sets = targets.targetsClusterSizeIntervals(intervals);
                    Double[] scores = mat.scoreTargetSets(tf, sets, nonTargetList);
                    if (scores != null) {
                        for (int i = 0; i < scores.length; ++i) {

                            if (scores[i] != null) {
                                stream.printf("%s,%03d,%f\n", label, intervals[i], scores[i]);
                                double[] d = mat.getDistances(sets.get(i).wbGeneList(), tf);
                                for (int j = 0; j < d.length; ++j) {
                                    distStream.printf("%s,%03d,%f\n", label, intervals[i], d[j]);
                                }
                            }
                        }
                    }
                    
                    // compute Mann Whitney by signal value
                    int nBins = 50;
                    targets.sortBySignalValue();
                    List<ChipSeqTargets> targetsList = targets.divideTargets(nBins);
                    scores = mat.scoreTargetSets(tf,targetsList, nonTargetList);
                    for (int i=0 ; i<scores.length ; ++i){
                        if (scores[i] != null){
                            ChipSeqTargets binTargets = targetsList.get(i);
                            double signal = binTargets.averageSignalValue();
                            signalValueScoresStream.printf("%s,%f,%f\n", label,signal,scores[i]);
                        }
                    }
                    
                    // compute Man Whitney by spearman value
                    targets.sortByDistance();
                    targetsList = targets.divideTargets(nBins);
                    scores = mat.scoreTargetSets(tf,targetsList, nonTargetList);
                    for (int i=0 ; i<scores.length ; ++i){
                        if (scores[i] != null){
                            ChipSeqTargets binTargets = targetsList.get(i);
                            double spear = binTargets.averageDistanceValue();
                            spearScoresStream.printf("%s,%f,%f\n", label,spear,scores[i]);
                        }
                    }                    
                    
                }
            }
        }
        stream.close();
        expStream.close();
        distStream.close();
        signalValueScoresStream.close();
        spearScoresStream.close();

    }

    static public String experimentLabel(String fname, int start) {
        String[] tokens = fname.substring(start).split("_");
        return String.format("%s_%s_%s_%s", tokens[0], tokens[1], tokens[2], tokens[3]);
    }

    static public String tfFromFileName(String name, int start) {
        String tf = name.substring(start, name.indexOf("_"));
        if (tf.contains("-")) {
            String[] tokens = tf.split("-");
            tf = String.format("%s-%s",tokens[0].toLowerCase(),tokens[1]);
        }
        return tf;
    }

    static public String stageFromFileName(String name, int start) {
        return name.substring(start).split("_")[3];
    }
//    static int[] intervals
 //           = {1, 2, 3, 4, 5, 10, 15, 20, 25, 30, 40, 50, 60, 70, 80, 130, 180, 230, 400};
    static int[] intervals
            = {5, 10, 20, 30, 40, 50, 60, 70, 80, 130, 180, 230, 400};
}
