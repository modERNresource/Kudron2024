/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.qa;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.TreeMap;

/**
 *
 * @author gevirl
 */
// matrix of sorted distances to all genes
// tf in each row
public class TFdistMatrix {

    TreeMap<String, double[]> map = new TreeMap<>();  // tf -> sorted distances
    // construct from a gene by tf expr distance matrix

    public TFdistMatrix(DistanceMatrix expMat) {
        // sort the columns and output each column as a row in an output file
        TreeMap<String, double[]> geneMap = expMat.getGeneMap();
        String[] tfs = expMat.getHeads();
        int n = tfs.length - 1;
        for (int i = 0; i < n; ++i) {
            double[] colVals = new double[geneMap.size()];
            int j = 0;
            for (double[] vals : geneMap.values()) {
                colVals[j] = vals[i];
                ++j;
            }
            Arrays.parallelSort(colVals);
            map.put(tfs[i+1],colVals);
        }
    }

    public TFdistMatrix(File inFile)throws Exception {
        BufferedReader reader = new BufferedReader(new FileReader(inFile));
        String line = reader.readLine();
        while (line != null){
            String[] tokens = line.split(",");
            double[] vals = new double[tokens.length-1];
            for (int i=0 ; i<vals.length ; ++i){
                vals[i] = Double.valueOf(tokens[i+1]);
            }
            map.put(tokens[0],vals);
            line = reader.readLine();
        }
        reader.close();
    }
    
    public void save(File outFile) throws Exception {
        PrintStream stream = new PrintStream(outFile);
        for (String tf : map.keySet()) {
            double[] vals = map.get(tf);
            stream.print(tf);
            for (int c = 0; c < vals.length; ++c) {
                stream.printf(",%.5f", vals[c]);
            }
            stream.println();
        }
        stream.close();
    }
    
    public double[] getDistances(String tf){
        return map.get(tf);
    }
}

