/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.qa;

import com.google.common.io.Files;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonString;
import org.rhwlab.chipseq.pipeline.Metadata;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipHelper;
import org.rhwlab.singlecell.expression.PrefixMaps;

/**
 *
 * @author gevirl
 */
public class SuccessfulRuns {

    public static TreeMap<String, List<File>> successRunsNotInEpic() throws Exception {
        TreeMap<String, List<File>> allSuccessRuns = successRuns();
        for (String species : allSuccessRuns.keySet()) {
            List<File> list = allSuccessRuns.get(species);
            List<File> toRemove = new ArrayList<>();
            for (File runDir : list) {
                File expDir = runDir.getParentFile().getParentFile();
                String expID = expDir.getName();
                ChipExperiment exp = (ChipExperiment) ChipHelper.getEquals("ChipExperiment", "ExpID", expID, "ExpID").get(0);
                if (exp.getToEpic() != null) {
                    if (exp.getToEpic()) {
                        toRemove.add(runDir);
                    }
                }

            }
            for (File f : toRemove) {
                list.remove(f);
            }
        }
        return allSuccessRuns;
    }

    // returns the run directory of all successful(did not fail) runs separated by species
    public static TreeMap<String, List<File>> successRuns() throws Exception {
        TreeMap<String, List<File>> ret = new TreeMap<>();

        for (File expDir : Directories.sourceDir.listFiles()) {
            if (expDir.isDirectory()) {
                File chipDir = new File(expDir, "chip");
                if (chipDir.exists()) {
                    for (File runDir : chipDir.listFiles()) {
                        if (runDir.isDirectory()) {
                            // check that the run succeeded
                            System.out.printf("Successfulruns: run directory = %s\n", runDir.getPath());
                            if (runDir.getPath().contains("arid")) {
                                int iashdfiuh = 0;
                            }
                            File metaFile = new File(runDir, "metadata.json");
                            if (metaFile.exists()) {
                                JsonReader reader = Json.createReader(new FileReader(metaFile));
                                JsonObject metadata = reader.readObject();
                                reader.close();

                                String status = metadata.getString("status");
                                if (status.equalsIgnoreCase("Succeeded")) {
                                    JsonObject inputs = metadata.getJsonObject("inputs");
                                    JsonString genometsv = inputs.getJsonString("chip.genome_tsv");
                                    if (genometsv == null) {
                                        genometsv = inputs.getJsonString("genome_tsv");
                                    }
                                    String genome = genometsv.getString();

                                    List<File> list = ret.get(genome);
                                    if (list == null) {
                                        list = new ArrayList<>();
                                        ret.put(genome, list);
                                    }
                                    list.add(runDir);
                                }
                            }
                        }
                    }
                }
            }
        }
        return ret;
    }

    public static String getTF(File hubDir) throws Exception {
        File trackFile = new File(hubDir, "ce11_trackDb.txt");
        BufferedReader read = new BufferedReader(new FileReader(trackFile));
        String exp = read.readLine().split(" ")[1];
        String tf = exp.substring(0, exp.indexOf("_"));
        read.close();
        return tf;
    }

    // copy the html report to epic for all succesful runs 
    static public void main(String[] args) throws Exception {
        new PrefixMaps();
        new StagePrefixMap();
        double thresh = 1.0;

        TreeMap<String, List<File>> runsDirMap = new TreeMap<>();  // stage prefix -> list of run directories
        TreeMap<String, List<File>> runsMap = successRuns();  // species TSV -> list of run directories

        for (String genomeTSV : runsMap.keySet()) {
            for (File runDir : runsMap.get(genomeTSV)) {
                // copy the metadata.json, qc report html and json to epic
                System.out.printf("Copy: %s json and html\n", runDir.getPath());
                File hubDir = new File(Directories.epicDir, runDir.getName());
                if (hubDir.exists()){
                File metaFile = new File(runDir, "metadata.json");
                Metadata meta = new Metadata(metaFile);
                File destMetaFile = new File(hubDir, metaFile.getName());
                if (!destMetaFile.exists()) {
                    Files.copy(metaFile, destMetaFile);
                    destMetaFile.setReadable(true, false);
                }

                File source = meta.getReportHtml();
                File dest = new File(hubDir, source.getName());
                if (!dest.exists()) {
                    Files.copy(source, dest);
                    dest.setReadable(true, false);
                }

                source = meta.getQcJson();
                dest = new File(hubDir, source.getName());
                if (!dest.exists()){
                Files.copy(source, dest);
                dest.setReadable(true, false);
                }
                

                // sort the worm runs by stage
                if (genomeTSV.contains("WS")) {
                    String stage = meta.getStage();
                    String prefix = StagePrefixMap.stageMap.get(stage);
                    if (prefix != null && !prefix.equals("")) {
                        List<File> dirs = runsDirMap.get(prefix);
                        if (dirs == null) {
                            dirs = new ArrayList<>();
                            runsDirMap.put(prefix, dirs);
                        }
                        dirs.add(runDir);
                    }
                }
                }
            }
        }
        /*
        // process the worm stages
        for (String prefix : runsDirMap.keySet()) {
            System.out.printf("Prefix=%s\n", prefix);
            System.out.printf("Dist Mat file=%s\n", PrefixMaps.signdistMatrixMap.get(prefix).getPath());
            DistanceMatrix signedDistMatrix = new DistanceMatrix(PrefixMaps.signdistMatrixMap.get(prefix));
            SingleCellExprMat ssExpMatrix = new SingleCellExprMat(PrefixMaps.exprMatrixMap.get(prefix), 1, 2, 3);
            CellTypeGroups groups = new CellTypeGroups(PrefixMaps.cellTypeMap.get(prefix), 0, 1, 2);

            // process the runs for the worm stage
            for (File runDir : runsDirMap.get(prefix)) {
                File hubDir = new File(Directories.epicDir, runDir.getName());

                String tf = SuccessfulRuns.getTF(hubDir);                
                String wbGene = DistanceMatrix.wbGene(tf);

                // make the express profile png
                File exppng = new File(hubDir,String.format("%s.%s.express.png",wbGene,tf));
                System.out.println(exppng.getPath());
                JFreeChart expchart = ssExpMatrix.formBarChart("Expression Profile",String.format("Expression for %s",tf), wbGene, groups);
                BufferedImage expbi = expchart.createBufferedImage(500, 1000);
                ImageIO.write(expbi, "png", exppng);

                File mannWhit = new File(hubDir, String.format("%s.%s.%s.MannWhitney", wbGene, tf, prefix));
                System.out.println(mannWhit.getPath());
                TreeMap<String, TreeMap<String, Object>> scoreMap = new TreeMap<>();
                for (File targetFile : hubDir.listFiles()) {
                    if (targetFile.getName().endsWith("regionPeak.targets")) {
                        ChipSeqTargets targets = new ChipSeqTargets(targetFile);
                        List<String> wbGeneTargets = targets.wbGeneList();
                        String fname = targetFile.getName();

                        // compute the Mannwhitney scores
                        scoreMap.put(fname, signedDistMatrix.scoreMannWhitney(wbGeneTargets, tf));

                        // print the Mannwhitneyheadings
                        PrintStream stream = new PrintStream(mannWhit);
                        Set<String> heads = scoreMap.firstEntry().getValue().keySet();
                        stream.print("File");
                        for (String head : heads) {
                            stream.printf(",%s", head);
                        }
                        stream.println();
                        // print the Mannwhitney results
                        for (String fName : scoreMap.keySet()) {
                            stream.print(fName);
                            TreeMap<String, Object> fnameMap = scoreMap.get(fName);
                            for (String head : heads) {
                                Object v = fnameMap.get(head);
                                if (v instanceof Integer) {
                                    stream.printf(",%d", v);
                                } else if (v instanceof Double) {
                                    stream.printf(",%e", v);
                                }
                            }
                            stream.println();
                        }
                        stream.close();

                        // annotate the target with distance
                        signedDistMatrix.setTargetDistance(targets, tf);
                        File annotTargets = new File(targetFile.getPath().replace(".targets", ".dist.targets"));
                        System.out.println(annotTargets.getPath());
                        targets.saveTargets(annotTargets);

                        // form a histogram of targets distances
                        HistogramDataset hist = targets.formHistogram(200);
                        JFreeChart histChart = ChartFactory.createHistogram(String.format(""), "Spearmans", "Count", hist, PlotOrientation.VERTICAL, false, false, false);
                        File histFile = new File(targetFile.getPath().replace(".targets", ".hist.png"));
                        System.out.println(histFile.getPath());
                        BufferedImage histImage = histChart.createBufferedImage(1000, 500);
                        ImageIO.write(histImage, "png", histFile);

                        // split the targets into possible enhancer and repressor target files
                        TreeMap<String, ChipSeqTargets> splitMap = targets.splitTargets(thresh);

                        // build the profile pngs
                        // split the targets into potential enhancers and repressors using correlation values
                        for (String label : splitMap.keySet()) {
                            //save the targets
                            File splitFile = new File(hubDir, String.format("%s.%s.%s.%s.%s.targets", wbGene, tf, prefix, fname.replace(".targets", ""), label));
                            System.out.println(splitFile.getPath());
                            splitMap.get(label).saveTargets(splitFile);
                            // make the express profile png
                            File png = new File(splitFile.getPath().replace(".targets", ".png"));
                            System.out.println(png.getPath());
                            JFreeChart chart = ssExpMatrix.formBarChart("Expression Profile","Mean Expression of Targets - NonTargets", splitMap.get(label).wbGeneList(), groups);
                            BufferedImage bi = chart.createBufferedImage(1000, 1000);
                            ImageIO.write(bi, "png", png);
                        }
                    }
                }
            }
        }
         */
    }
}
