/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.pipeline;

import htsjdk.samtools.util.Interval;
import htsjdk.samtools.util.IntervalTreeMap;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import org.rhwlab.bedformat.NarrowPeakBedRecord;
import org.rhwlab.chipseqweb.beans.Directory;

/**
 *
 * @author gevirl
 */
public class ExperimentIntervalTree {

    TreeMap<String, IntervalTreeMap> map = new TreeMap<>();

    public ExperimentIntervalTree(File bedFile, Set<String> exceptChromo) throws Exception {
        BufferedReader reader = new BufferedReader(new FileReader(bedFile));
        String line = reader.readLine();
        while (line != null) {
            NarrowPeakBedRecord rec = new NarrowPeakBedRecord(line);
            if (!exceptChromo.contains(rec.getChromosome())) {
                String expID = rec.getName();
                IntervalTreeMap expMap = map.get(expID);
                if (expMap == null) {
                    expMap = new IntervalTreeMap();
                    map.put(expID, expMap);
                }

                Interval interval = new Interval(rec.getChromosome(), rec.getStart(), rec.getEnd());
                ArrayList<NarrowPeakBedRecord> bedList = (ArrayList<NarrowPeakBedRecord>) expMap.get(interval);
                if (bedList == null) {
                    bedList = new ArrayList<>();
                    expMap.put(interval, bedList);
                }
                bedList.add(rec);
            }
            line = reader.readLine();
        }
        reader.close();
    }

    public TreeMap<String, IntervalTreeMap> getTree(){
        return this.map;
    }
    static public void briefDisplay(NarrowPeakBedRecord rec) {
        System.out.printf("%s\t%d\t%d\t%d\n", rec.getChromosome(), rec.getStart(), rec.getEnd(), rec.getPeakOffset());
    }

    static public void briefDisplay(ArrayList<NarrowPeakBedRecord> recs) {
        System.out.println();
        for (NarrowPeakBedRecord rec : recs) {
            briefDisplay(rec);
        }
    }


}
