/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.pipeline;


import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.io.Serializable;
import java.net.URL;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonNumber;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonString;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.rhwlab.chipseqweb.ChipHelper;
import org.rhwlab.chipseqweb.ChipRun;
import org.rhwlab.chipseqweb.ChipSequencingFile;
import org.rhwlab.chipseqweb.PipelineFiles;
import org.rhwlab.chipseqweb.PrettyWriter;
import org.rhwlab.chipseqweb.Species;
import org.rhwlab.chipseqweb.ZipThread;
import org.rhwlab.chipseqweb.beans.Directory;

/**
 *
 * @author gevirl
 */
public class PipelineRun implements Serializable {

    File dir;
    String status;
    String started = "";
    String submittedBy = "";
    String overlap = "";
    String idr = "";
    String expID = "";
    String submitID = "";
    String chipID = "";
    String optimalScore = "";
    String consvScore = "";
    String optimalEnhProfile = "";
    String consvEnhProfile = "";
    String optimalRepProfile = "";
    String consvRepProfile = "";
    JsonNumber idrThreshold;

    List<Alignment> alignments;
    List<Peaks> peaks;
    List<Reproduce> reproduce;
    List<Complexity> complexity;

    String optimalHistPng;
    String consvHistPng;

    File enhanceOptimalTargetFile;
    File repressOptimalTargetFile;
    File enhanceConservlTargetFile;
    File repressConservTargetFile;

    File expressPng;

    File runDir;
    List<Track> tracks = new ArrayList<>();
    String prefix = "";
    ChipRun chipRun;
    JsonObject inputs;
    File qcHtml;  // qc html report file
    File qcJson;

    String version;
    FileTable fileTable;

    // run built from the metadata.json and the qc.json in the given chip run directory
    public PipelineRun(File dir) throws Exception {
        this.dir = dir;
        chipID = dir.getName();
        status = "Started";
        File metaFile = new File(dir, "metadata.json");
        if (metaFile.exists()) {
            JsonReader reader = Json.createReader(new FileReader(metaFile));
            JsonObject metadata = reader.readObject();
            reader.close();
            loadMetaFile(metadata, metaFile);
        }

        runDir = new File(hubDir, chipID);  // run directory on epic
        System.out.printf("PipelineRun.constructor: runDir = %s", runDir.getPath());
        if (runDir.exists()) {
            TreeMap<String, Track> bbNames = new TreeMap<>();
            TreeMap<String, Track> bwNames = new TreeMap<>();
            TreeMap<String, Track> targetNames = new TreeMap<>();

            String[] expIDTokens = expID.split("_");
            if (expIDTokens.length >= 3) {
                prefix = stageMap.get(expIDTokens[2]);
            }
            String toReport = "Unorm";
            int col = -1;
            for (File file : runDir.listFiles()) {
                System.out.printf("PipelineRun.constructor: file = %s", file.getPath());
                String fName = file.getName();
                if (fName.endsWith("MannWhitney")) {

                } else if (fName.endsWith(".bb")) {
                    bbNames.put(fName, new Track(file));
                } else if (fName.endsWith("bigwig")) {
                    bwNames.put(fName, new Track(file));
                } else if (fName.endsWith(".png")) {
                    if (fName.contains("express")) {
                        this.expressPng = file;
                    } else if (fName.contains("optimal")) {
                        if (fName.contains("enhance")) {
                            this.optimalEnhProfile = fName;
                        } else if (fName.contains("repress")) {
                            this.optimalRepProfile = fName;
                        } else if (fName.contains(".hist.")) {
                            this.optimalHistPng = fName;
                        }
                    } else if (fName.contains("conservative")) {
                        if (fName.contains("enhance")) {
                            this.consvEnhProfile = fName;
                        } else if (fName.contains("repress")) {
                            this.consvRepProfile = fName;
                        } else if (fName.contains(".hist.")) {
                            this.consvHistPng = fName;
                        }
                    }
                } else if (fName.endsWith(".targets")) {
                    targetNames.put(fName, new Track(file));
                    if (fName.contains("optimal")) {
                        if (fName.contains("enhance")) {
                            this.enhanceOptimalTargetFile = file;
                        } else if (fName.contains("repress")) {
                            this.repressOptimalTargetFile = file;
                        }
                    } else if (fName.contains("conservative")) {
                        if (fName.contains("enhance")) {
                            this.enhanceConservlTargetFile = file;
                        } else if (fName.contains("repress")) {
                            this.repressConservTargetFile = file;
                        }
                    }
                }
            }
            tracks.addAll(bwNames.values());
            tracks.addAll(bbNames.values());
            tracks.addAll(targetNames.values());
        }
    }

    public PipelineRun(JsonObject metadata, ChipRun cr, File xferDir) throws Exception {
        this.chipRun = cr;
        chipID = chipRun.getChipId();
        File tableFile = new File(xferDir, String.format("%s.table.tsv", cr.getExpId()));
        System.out.printf("PipelineRun: tableFile = %s\n", tableFile.getPath());
        fileTable = new FileTable(tableFile);
        this.loadMetaFile(metadata, fileTable.getMetadataFile());
    }

    public PipelineRun(String sid, String subBy, String subOn, String chip) {
        status = "Started";
        started = subOn;
        submittedBy = subBy;
        chipID = chip;
        submitID = sid;

    }

    public PipelineRun(String sid, String subBy, String subOn) {
        status = "Submitted";
        started = subOn;
        submittedBy = subBy;
        submitID = sid;
    }

    public final void loadMetaFile(JsonObject metadata, File metaFile) throws Exception {

        status = metadata.getString("status");
        started = metadata.getJsonString("start").getString();
        inputs = metadata.getJsonObject("inputs");

        if (inputs != null) {
            idrThreshold = inputs.getJsonNumber("chip.idr_thresh");
            if (idrThreshold == null) {
                idrThreshold = inputs.getJsonNumber("idr_thresh");
            }
            if (inputs.getJsonString("chip.description") != null) {
                submittedBy = inputs.getString("chip.description");
            }
            if (inputs.getJsonString("description") != null) {
                submittedBy = inputs.getString("description");
            }

            if (inputs.getJsonString("chip.title") != null) {
                submitID = inputs.getString("chip.title");
            }
            if (inputs.getJsonString("title") != null) {
                submitID = inputs.getString("title");
            }
            List l = ChipHelper.getEquals("ChipRun", "SubmitID", submitID, "SubmitID");
            if (l.size() > 0) {
                chipRun = (ChipRun) l.get(0);
            }

            expID = submitID.substring(0, submitID.lastIndexOf("_"));

            File metasDir = metaFile.getParentFile();

            qcHtml = new File(metasDir, "qc.html");
            if (!qcHtml.exists()) {
                JsonObject outputs = metadata.getJsonObject("outputs");
                JsonString reportStr = outputs.getJsonString("chip.report");
                if (reportStr != null) {
                    qcHtml = new File(reportStr.getString());
                } else {
                    qcHtml = null;
                }
            }

            qcJson = new File(metasDir, "qc.json");
            if (!qcJson.exists()) {
                JsonObject outputs = metadata.getJsonObject("outputs");
                JsonString qcStr = outputs.getJsonString("chip.qc_json");
                if (qcStr != null) {
                    qcJson = new File(qcStr.getString());
                } else {
                    qcJson = null;
                }
            }

            if (qcJson != null) {
                JsonReader qcreader = Json.createReader(new FileReader(qcJson));
                JsonObject qcObj = qcreader.readObject();
                qcreader.close();

                JsonObject replic = qcObj.getJsonObject("replication");

                JsonObject repro = replic.getJsonObject("reproducibility");
                overlap = repro.getJsonObject("overlap").getJsonString("reproducibility").getString();
                idr = "";
                if (repro.getJsonObject("idr") != null) {
                    idr = repro.getJsonObject("idr").getJsonString("reproducibility").getString();
                }

                this.reproduce = Reproduce.formReproduce(qcObj);

                Map<String, String> seqFileMap = expFilesLabelMap(expID);
                Map<String, String> repMap = titleMapping(inputs, seqFileMap);
                this.alignments = Alignment.formAlignments(qcObj, repMap);
                this.peaks = Peaks.formPeaks(qcObj, repMap);
                this.complexity = Complexity.formComplexity(qcObj, repMap);

                version = qcObj.getJsonObject("general").getString("pipeline_ver");
            }
        }

    }

    public static boolean runSucceeded(File runDir) throws Exception {
        boolean ret = false;
        File metaFile = new File(runDir, "metadata.json");
        if (metaFile.exists()) {
            JsonReader reader = Json.createReader(new FileReader(metaFile));
            JsonObject metadata = reader.readObject();
            reader.close();
            JsonString status = metadata.getJsonString("status");
            if (status != null) {
                return status.getString().equals("Succeeded");
            }
        }
        return ret;
    }

    public static JsonObject getPipelineRunInput(File chipDir) throws Exception {
        File metaFile = new File(chipDir, "metadata.json");
        if (metaFile.exists()) {
            JsonReader reader = Json.createReader(new FileReader(metaFile));
            JsonObject metadata = reader.readObject();
            reader.close();
            return metadata.getJsonObject("inputs");
        }
        return null;
    }

    public FileTable getFileTable() {
        return this.fileTable;
    }

    public static String ExpID(String submitID) {
        return submitID.substring(0, submitID.lastIndexOf("_"));
    }

    public static void markRun(String submitID) throws Exception {
        String expID = ExpID(submitID);

        for (Object ob : ChipHelper.getEquals("ChipRun", "ExpID", expID, "SubmitID")) { // all runs for the experiment
            ChipRun r = (ChipRun) ob;
            if (submitID.equals(r.getSubmitId())) {
                r.setMarkedForDcc(new java.sql.Date(new java.util.Date().getTime()));
            } else {
                r.setMarkedForDcc(null);  // clear all other runs if marked for submission
            }
            ChipHelper.update(r);
        }
    }

    public static void removeRun(String chipID) throws Exception {
        List l = ChipHelper.getEquals("ChipRun", "ChipID", chipID, "SubmitID");
        System.out.printf("list size: %d\n", l.size());
        if (!l.isEmpty()) {
            ChipRun chipRun = (ChipRun) l.get(0);

            // remove the submit directory
            Directory dir = new Directory();
            File submitDir = dir.submitDirectory(chipRun);
            String cmd = String.format("rm -rf %s", submitDir);
            System.out.println(cmd);
            Process proc = Runtime.getRuntime().exec(cmd);
            proc.waitFor();

            // remove the chip run directory
            File expDir = submitDir.getParentFile();
            File chipDir = new File(expDir, "chip");
            File runDir = new File(chipDir, chipRun.getChipId());
            cmd = String.format("rm -rf %s", runDir.getPath());
            proc = Runtime.getRuntime().exec(cmd);
            System.out.println(cmd);
            proc.waitFor();

            // remove the db entry
            ChipHelper.remove(chipRun);
        }
    }

    // return map of filetype -> replicate -> files
    static public Map<String, Map<Integer, Map<Integer, List<ChipSequencingFile>>>> runPaths(JsonObject inputs) throws Exception {
        Map<String, Map<Integer, Map<Integer, List<ChipSequencingFile>>>> ret = new TreeMap<>();
        for (String label : fileTypeLabels) {
            for (int rep = 1; rep <= 10; ++rep) {
                for (int read = 1; read <= 2; ++read) {
                    JsonArray ja = inputs.getJsonArray(String.format("chip.%s_rep%d_R%d", label, rep, read));
                    if (ja == null) {
                        ja = inputs.getJsonArray(String.format("%s_rep%d_R%d", label, rep, read));
                    }
                    if (!ja.isEmpty()) {
                        Map<Integer, Map<Integer, List<ChipSequencingFile>>> typeMap = ret.get(label);
                        if (typeMap == null) {
                            typeMap = new TreeMap<>();
                            ret.put(label, typeMap);
                        }
                        Map<Integer, List<ChipSequencingFile>> repMap = typeMap.get(rep);
                        if (repMap == null) {
                            repMap = new TreeMap<>();
                            typeMap.put(rep, repMap);
                        }
                        List<ChipSequencingFile> fileList = repMap.get(read);
                        if (fileList == null) {
                            fileList = new ArrayList<>();
                            repMap.put(read, fileList);
                        }
                        for (int k = 0; k < ja.size(); ++k) {
                            String localPath = ja.getJsonString(k).getString();
                            fileList.add((ChipSequencingFile) ChipHelper.getEquals("ChipSequencingFile", "LocalFilePath", localPath, "FileID").get(0));
                        }
                    }

                }

            }
        }
        return ret;
    }

    // map all local filePaths in the experiment of this run to a display replicate/control label
    static final public Map<String, String> expFilesLabelMap(String expID) throws Exception {
        Map<String, String> fileMap = new TreeMap<>();
        for (Object obj : ChipHelper.filesFor(expID)) {
            ChipSequencingFile seqFile = (ChipSequencingFile) obj;
            if (seqFile.getSeqType() != null && seqFile.getReplicate() != null) {
                if (seqFile.getSeqType().equalsIgnoreCase("input")) {
                    fileMap.put(seqFile.getLocalFilePath(), String.format("ctl%d", seqFile.getReplicate()));
                } else {
                    fileMap.put(seqFile.getLocalFilePath(), String.format("rep%d", seqFile.getReplicate()));
                }
            }
        }
        return fileMap;
    }

    private static String setToString(Set<String> set) {
        boolean first = true;
        StringBuilder builder = new StringBuilder();
        for (String s : set) {
            if (!first) {
                builder.append(",");
            }
            builder.append(s);
            first = false;
        }
        return builder.toString();
    }

    // expFileMap - maps the file path to the rep labeling done by the user
    final public Map<String, String> titleMapping(JsonObject inputs, Map<String, String> expFileMap) {
        HashMap<String, Set<String>> setMap = new HashMap<>();

        // are the input files bams?
        JsonArray chipBams = inputs.getJsonArray("chip.bams");
        if (chipBams == null || chipBams.isEmpty()) {
            titleMapping(PipelineRun.fileTypeLabels[0], PipelineRun.reportPrefix[0], inputs, expFileMap, setMap);
            titleMapping(PipelineRun.fileTypeLabels[1], PipelineRun.reportPrefix[1], inputs, expFileMap, setMap);
        } else {
            titleMappingBams(PipelineRun.bamLabels[0], PipelineRun.reportPrefix[0], inputs, expFileMap, setMap);
            titleMappingBams(PipelineRun.bamLabels[1], PipelineRun.reportPrefix[1], inputs, expFileMap, setMap);
        }

        Map<String, String> ret = new HashMap<>();
        for (String key : setMap.keySet()) {
            ret.put(key, setToString(setMap.get(key)));
        }
        return ret;
    }

    public void titleMappingBams(String label, String prefix, JsonObject inputs, Map<String, String> expFileMap, HashMap<String, Set<String>> ret) {
        JsonArray ja = inputs.getJsonArray(label);
        for (int i = 0; i < ja.size(); ++i) {
            String title = String.format("%s%d", prefix, i + 1);  // how the run labels the file
            Set<String> expTitles = ret.get(title);
            if (expTitles == null) {
                expTitles = new TreeSet<>();
                ret.put(title, expTitles);  // maps the run replicates to the user experiment replicate ids
            }
            String filePath = ja.getString(i);
            String lab = expFileMap.get(filePath);  // how the user labelled the replicate 
            expTitles.add(lab);
        }
    }

    // maps replicate labeling from run to the SequenceFile labels
    public void titleMapping(String label, String prefix, JsonObject inputs, Map<String, String> expFileMap, HashMap<String, Set<String>> ret) {
        for (int i = 1; i <= 10; ++i) {  // replicate
            String title = String.format("%s%d", prefix, i);  // how the run labels the file
            for (int j = 1; j <= 2; ++j) {  // read pair
                JsonArray ja = inputs.getJsonArray(String.format("chip.%s_rep%d_R%d", label, i, j));
                if (ja == null) {
                    ja = inputs.getJsonArray(String.format("%s_rep%d_R%d", label, i, j));
                }

                if (!ja.isEmpty()) {
                    Set<String> expTitles = ret.get(title);
                    if (expTitles == null) {
                        expTitles = new TreeSet<>();
                        ret.put(title, expTitles);  // maps the run replicates to the user experiment replicate ids
                    }
                    for (int k = 0; k < ja.size(); ++k) {
                        JsonString js = ja.getJsonString(k);
                        String filePath = js.getString();
                        String lab = expFileMap.get(filePath);
                        if (lab == null) {
                            System.out.printf("titleMapping not found: %s\n", filePath);
                        } else {
                            expTitles.add(lab);
                        }
                    }
                }
            }
        }
    }

    public List<Track> getTrackNames() {
        return this.tracks;
    }

    public String getPrefix() {
        return this.prefix;
    }

    // the wbgene id of the tf
    public String getWBGene() throws Exception {
        String[] tokens = expID.split("_");
        return Species.getWBGene(tokens[0]);
    }

    public String getReportLink() {
        return String.format("http://waterston.gs.washington.edu/ChipSeqPipeline/%s/qc.html", chipID);
    }

    public String getReportJsonLink() {
        return String.format("http://waterston.gs.washington.edu/ChipSeqPipeline/%s/qc.json", chipID);
    }

    public String getMetaJsonLink() {
        return String.format("http://waterston.gs.washington.edu/ChipSeqPipeline/%s/metadata.json", chipID);
    }

    public String getOptimalScore() {
        return this.optimalScore;
    }

    public String getConserveScore() {
        return this.consvScore;
    }

    public String getIdrThreshold() {
        if (idrThreshold == null) {
            return "";
        }
        return String.format("%.2f", idrThreshold.doubleValue());
    }

    public String getExpID() {
        return this.expID;
    }

    public File getDirectory() {
        return dir;
    }

    public List<Alignment> getAlignments() {
        return alignments;
    }

    public List<Peaks> getPeaks() {
        return this.peaks;
    }

    public List<Reproduce> getReproduce() {
        return this.reproduce;
    }

    public List<Complexity> getComplexity() {
        return this.complexity;
    }

    public String getSubmitID() {
        System.out.printf("PipelineRun.getSubmitID: submitID = %s\n", submitID);
        return submitID;
    }

    public String getSubmitDirectory() {
        String[] tokens = submitID.split("_");
        return tokens[tokens.length - 1];
    }

    public String getID() {
        return chipID;
    }

    public String getStatus() {
        return status;
    }

    public String getStarted() {
        return started;
    }

    public String getSubmittedBy() {
        return submittedBy;
    }

    public StreamedContent getResultURL() throws Exception {
        if (qcHtml != null) {
            FileInputStream stream = new FileInputStream(qcHtml);
            DefaultStreamedContent.Builder builder = DefaultStreamedContent.builder();
            builder.name(dir.getName());
            builder.contentType("text/html");
            builder.stream(() -> stream);
            return builder.build();
//            return new DefaultStreamedContent(new FileInputStream(qcHtml), "text/html", dir.getName());
        }
        return null;
    }

    public StreamedContent getJson() {
        PrettyWriter pw = new PrettyWriter();
        pw.writeObject(inputs, 0);
        String s = pw.getPrettyJson();

        ByteArrayInputStream stream = new ByteArrayInputStream(s.getBytes());
        DefaultStreamedContent.Builder builder = DefaultStreamedContent.builder();
        builder.name("InputParameters");
        builder.contentType("text/plain");
        builder.stream(() -> stream);
        return builder.build();
//        return new DefaultStreamedContent(new ByteArrayInputStream(s.getBytes()), "text/plain", "InputParameters");
    }

    public String getOverlap() {
        return overlap;
    }

    public String getIdr() {
        return idr;
    }

    private Reproduce getIdrReproduce() {
        if (reproduce != null) {
            for (Reproduce re : this.reproduce) {
                if (re.getLabel().equalsIgnoreCase("idr")) {
                    return re;
                }
            }
        }
        return null;
    }

    private Reproduce getOverlapReproduce() {
        for (Reproduce re : this.reproduce) {
            if (re.getLabel().equalsIgnoreCase("overlap")) {
                return re;
            }
        }
        return null;
    }

    public String getIdrOptimal() {
        Reproduce r = getIdrReproduce();
        if (r != null) {
            return getOptimal(r);
        }
        return "";
    }

    public String getOverlapOptimal() {
        Reproduce r = getOverlapReproduce();
        if (r != null) {
            return getOptimal(r);
        }
        return "";
    }

    public String getOptimal(Reproduce r) {
        return Integer.toString(r.getNopt());
    }

    public String getIdrConserve() {
        Reproduce r = getIdrReproduce();
        if (r != null) {
            return getConserve(r);
        }
        return "";
    }

    public String getOverlapConserve() {
        Reproduce r = getOverlapReproduce();
        if (r != null) {
            return getConserve(r);
        }
        return "";
    }

    public String getConserve(Reproduce r) {
        return Integer.toString(r.getNconsv());
    }

    public String getIdrRescue() {
        for (Reproduce re : this.reproduce) {
            if (re.getLabel().equalsIgnoreCase("idr")) {
                return re.getRescue();
            }
        }
        return "";
    }

    public String getIdrConsist() {
        for (Reproduce re : this.reproduce) {
            if (re.getLabel().equalsIgnoreCase("idr")) {
                return re.getConsist();
            }
        }
        return "";
    }

    public String getOverlapRescue() {
        for (Reproduce re : this.reproduce) {
            if (re.getLabel().equalsIgnoreCase("overlap")) {
                return re.getRescue();
            }
        }
        return "";
    }

    public String getOverlapConsist() {
        for (Reproduce re : this.reproduce) {
            if (re.getLabel().equalsIgnoreCase("overlap")) {
                return re.getConsist();
            }
        }
        return "";
    }

    public StreamedContent getTracks() throws Exception {
        Map<String, URL> urls = new TreeMap<>();

        List<String> bigwigs = PipelineFiles.findFiles(dir, "*bigwig");
        for (String bigwig : bigwigs) {
            File file = new File(bigwig);
            urls.put(file.getName(), file.toURI().toURL());
        }

        List<String> opts = PipelineFiles.findFiles(dir, "*optimal_peak.regionPeak.bb");
        for (String opt : opts) {
            File file = new File(opt);
            urls.put(file.getName(), file.toURI().toURL());
        }

        List<String> cons = PipelineFiles.findFiles(dir, "*conservative_peak.regionPeak.bb");
        for (String con : cons) {
            File file = new File(con);
            urls.put(file.getName(), file.toURI().toURL());
        }

        ZipThread zipThread = new ZipThread(urls);
        new Thread(zipThread).start();
            InputStream stream = zipThread.getStream();
            DefaultStreamedContent.Builder builder = DefaultStreamedContent.builder();
            builder.name(submitID);
            builder.contentType("application/zip");
            builder.stream(() -> stream);
            return builder.build();        
//        return new DefaultStreamedContent(zipThread.getStream(), "application/zip", submitID);
    }

    public boolean getNoHub() {
        File hubFile = new File(hubDir, chipID);
        return !hubFile.exists();
    }

    public String getUcscLink() {
//        String exp = dir.getParentFile().getParentFile().getName();
        File track = new File(runDir, "dm6_trackDb.txt");

        String s;
        if (track.exists()) {
            s = String.format("http://genome.ucsc.edu/cgi-bin/hgTracks?db=dm6&hubClear=http://waterston.gs.washington.edu/ChipSeqPipeline/%s/hub.txt", chipID);
        } else {
            s = String.format("http://genome.ucsc.edu/cgi-bin/hgTracks?db=ce11&hubClear=http://waterston.gs.washington.edu/ChipSeqPipeline/%s/hub.txt", chipID);
        }
        return s;

    }

    public String getOptimalEnhanceProfile() {
        return optimalEnhProfile;
    }

    public String getOptimalRepressProfile() {
        return optimalRepProfile;
    }

    public String getConservativeEnhanceProfile() {
        return consvEnhProfile;
    }

    public String getConservativeRepressProfile() {
        return consvRepProfile;
    }

    public File getOptimalEnhanceFile() {
        return this.enhanceOptimalTargetFile;
    }

    public File getOptimalRepressFile() {
        return this.repressOptimalTargetFile;
    }

    public File getConservativeEnhanceFile() {
        return this.enhanceConservlTargetFile;
    }

    public File getConservativeRepressFile() {
        return this.repressConservTargetFile;
    }

    public File getExpressProfile() {
        return this.expressPng;
    }

    public String getOptimalHistogram() {
        return this.optimalHistPng;
    }

    public String getConservativeHistogram() {
        return this.consvHistPng;
    }

    public Date getMarked() {
        if (chipRun != null) {
            return chipRun.getMarkedForDcc();
        }
        return null;
    }

    public ChipRun getRun() {
        return this.chipRun;
    }

    public String getVersion() {
        return version;
    }

    public static File idrOptimalPeakFile(ChipRun run) {
        File ret = null;
        if (run.getChipId() != null) {
            ret = new File(String.format(
                    "/net/waterston/vol9/ChipSeqPipeline/%s/chip/%s/call-reproducibility_idr/execution/idr.optimal_peak.regionPeak.bb", run.getExpId(), run.getChipId()));
        }
        return ret;
    }
    static File hubDir = new File("/data/www/site/waterston/html/ChipSeqPipeline");
    final static TreeMap<String, String> stageMap = new TreeMap<>();
    static String[] fileTypeLabels = {"ctl_fastqs", "fastqs"};
    static String[] bamLabels = {"chip.ctl_bams", "chip.bams"};
    static String[] reportPrefix = {"ctl", "rep"};

    static {
        stageMap.put("earlyembryonic", "Emb");
        stageMap.put("midembryonic", "Emb");
        stageMap.put("lateembryonic", "Emb");
        stageMap.put("mixedstage", "Emb");
        stageMap.put("L1larva", "L2");
        stageMap.put("L2larva", "L2");
        stageMap.put("L3larva", "L2");
        stageMap.put("L4larva", "L2");
        stageMap.put("L4_youngadult", "L2");
        stageMap.put("youngadult", "");
        stageMap.put("dauer", "");
    }

    static public void main(String[] args) {
        Date date = new Date();
        Locale[] locales = DateFormat.getAvailableLocales();
        DateFormat dateFormat = DateFormat.getInstance();
        String dataString = dateFormat.format(date);
        int sdf = 0;
    }
}
