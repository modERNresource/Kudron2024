/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.pipeline;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.json.JsonObject;

/**
 *
 * @author gevirl
 */
public class Peaks implements Serializable {
    String label;
    int totalPeaks;

    public Peaks(String key,String label,JsonObject replication){
        this.label = label;
        totalPeaks = replication.getJsonObject("num_peaks").getJsonObject(key).getInt("num_peaks");
    }
    
    public String getLabel(){
        return this.label;
    }
    public int getTotalPeaks(){
        return this.totalPeaks;
    }
    
    static public List<Peaks> formPeaks(JsonObject qc,Map<String,String> keyMap){
        ArrayList<Peaks> ret = new ArrayList<>();
        JsonObject replication = qc.getJsonObject("replication");
        for (String key : replication.getJsonObject("num_peaks").keySet()){
            String maplabel = key;
            if (keyMap != null){
                maplabel = keyMap.get(key);
            }                
            ret.add(new Peaks(key,maplabel,replication));
        }
        return ret;
    }
}
