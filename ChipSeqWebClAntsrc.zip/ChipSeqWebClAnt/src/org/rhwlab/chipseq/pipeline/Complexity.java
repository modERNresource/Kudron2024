/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.pipeline;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.json.JsonObject;



/**
 *
 * @author gevirl
 */
public class Complexity implements Serializable {
    String label;
    int totalFrags;
    int distinctFrags;
    int oneReadPositions;
    double nrf;
    double pbc1;
    double pbc2;
    
    public Complexity(String key,String label,JsonObject complexity){
        this.label = label;
        JsonObject comp = complexity.getJsonObject(key);
        totalFrags = comp.getInt("total_fragments");
        distinctFrags = comp.getInt("distinct_fragments");
        oneReadPositions = comp.getInt("positions_with_one_read");
        nrf = comp.getJsonNumber("NRF").doubleValue();
        pbc1 = comp.getJsonNumber("PBC1").doubleValue();
        pbc2 = comp.getJsonNumber("PBC2").doubleValue();
    }
    public String getLabel(){
        return this.label;
    }       
    public int getTotalFrags(){
        return this.totalFrags;
    }
    public int getDistinctFrags(){
        return this.distinctFrags;
    }
    public double getNrf(){
        return this.nrf;
    }
    public double getPbc1(){
        return this.pbc1;
    }
    public double getPbc2(){
        return this.pbc2;
    }
    public int getOneRead(){
        return this.oneReadPositions;
    }
    
    static public List<Complexity> formComplexity(JsonObject qc,Map<String,String> keyMap){
        List<Complexity> list = new ArrayList<>();
        JsonObject complexity = qc.getJsonObject("lib_complexity").getJsonObject("lib_complexity");
        for (String key : complexity.keySet()){
            String maplabel = key;
            if (keyMap != null){
                maplabel = keyMap.get(key);
            }             
            list.add(new Complexity(key,maplabel,complexity));
        }
        return list;
    }
}
