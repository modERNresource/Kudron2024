/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.pipeline;

import java.io.File;
import java.io.PrintStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import org.rhwlab.chipseq.dcc.DCCFile;
import org.rhwlab.chipseq.dcc.Experiment;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipHelper;
import org.rhwlab.chipseqweb.HibernateUtil;
import org.rhwlab.chipseqweb.beans.Directory;

/**
 *
 * @author gevirl
 */
public class PooledWig {

    static public void updateFromLocal(String acc,File expDir) {
        
    }

    static public void updateFromDCC(String expAcc, File expDir) throws Exception {
        DCCFile fcSignal = null;
        DCCFile pvalSignal = null;

        Experiment dccExp = new Experiment(expAcc);
        DCCFile[] files = dccExp.getFiles();
        for (DCCFile dccFile : files) {
            String name = dccFile.getName();
            if (name.contains("pooled") && name.contains("bigwig")) {
                if (name.contains("fc.signal")) {
                    fcSignal = dccFile;
                }
                if (name.contains("pval.signal")) {
                    pvalSignal = dccFile;
                }
            }
        }
        File fcFile = new File(expDir, fcSignal.getName());
        fcSignal.download(fcFile);
        File pvalFile = new File(expDir, pvalSignal.getName());
        pvalSignal.download(pvalFile);    
        
        updateTable(expDir,fcFile,pvalFile);
    }

    static public void updateTable(File dir, File fc, File pval) throws Exception {
        String expID = dir.getName();
        File tableFile = new File(dir, expID + ".table.tsv");
        FileTable table = new FileTable(tableFile);

        table.addToMap(new FileTableRecord(
                fc, "bigWig", "fold change over control", "pooled", "true", (int) (Files.size(fc.toPath()) / 1000000.0), "MBytes"));

        table.addToMap(new FileTableRecord(
                pval, "bigWig", "signal-p", "pooled", "true", (int) (Files.size(pval.toPath()) / 1000000.0), "MBytes"));

        PrintStream stream = new PrintStream(tableFile);
        table.report(stream);
        stream.close();
    }

    // report the missing pooled wigs and those already in Epic
    public static void reportPooledWigs(File speciesDir) throws Exception {
        Directory dir = new Directory();
        File hasPooledFile = new File(dir.getDirectory(), "hasPooled");
        File fromBamsFile = new File(dir.getDirectory(), "noPooledFromBam");
        File notFromBamsFile = new File(dir.getDirectory(), "noPooledNotFromBam");

        ArrayList<String> hasPooled = new ArrayList<>();
        ArrayList<String> fromBam = new ArrayList<>();
        ArrayList<String> notBams = new ArrayList<>();
        for (File expDir : speciesDir.listFiles()) {
            String expID = expDir.getName();

            // is there a pooled wig file
            if (!hasPooledBigwig(expDir)) {
                // is the experiment not from ENCODE bams and has been accessioned                
                List list = ChipHelper.getEquals("ChipExperiment", "ExpID", expID, "ExpID");
                if (!list.isEmpty()) {
                    ChipExperiment exp = (ChipExperiment) list.get(0);
                    String expAcc = exp.getAccession();
                    if (expAcc != null) {
                        if (!exp.getDescription().contains("ENCODE bams")) {
                            notBams.add(expAcc);
                        } else {
                            fromBam.add(expAcc);
                        }
                    } else {
                        System.out.printf("No accession: %s\n", expID);
                    }
                }
            } else {
                hasPooled.add(expID);
            }
        }
        PrintStream stream = new PrintStream(hasPooledFile);
        for (String id : hasPooled) {
            stream.println(id);
        }
        stream.close();

        stream = new PrintStream(fromBamsFile);
        for (String id : fromBam) {
            stream.println(id);
        }
        stream.close();

        stream = new PrintStream(notFromBamsFile);
        for (String id : notBams) {
            stream.println(id);
        }
        stream.close();
    }

    public static boolean hasPooledBigwig(File dir) {
        for (File file : dir.listFiles()) {
            if (file.getName().contains("pooled") && file.getName().endsWith("bigwig")) {
                return true;
            }
        }
        return false;
    }

    public static void updateAll(File speciesDir) throws Exception {
        for (File expDir : speciesDir.listFiles()) {
            String expID = expDir.getName();
            // is there a pooled wig file
            if (!hasPooledBigwig(expDir)) {
                List list = ChipHelper.getEquals("ChipExperiment", "ExpID", expID, "ExpID");
                if (!list.isEmpty()) {
                    ChipExperiment exp = (ChipExperiment) list.get(0);
                    String expAcc = exp.getAccession();
                    if (expAcc != null) {
                        if (exp.getDescription().contains("ENCODE bams")) {
                            updateFromLocal(expAcc,expDir);
                        } else {
                            System.out.printf("%s\t%s\n",expID,expAcc);
                            updateFromDCC(expAcc,expDir);
                        }
                    } else {
                        System.out.printf("No accession: %s\n", expID);
                    }
                }
            }
        }
    }

    public static void main(String[] args) throws Exception {
        Directory dir = new Directory();
        File speciesDir = new File(dir.getWormEpicDirectory());
        if (args[0].equals("report")){
            reportPooledWigs(speciesDir);
        }
        if (args[0].equals("update")){
            updateAll(speciesDir);
        }
        HibernateUtil.shutdown();
    }
}
