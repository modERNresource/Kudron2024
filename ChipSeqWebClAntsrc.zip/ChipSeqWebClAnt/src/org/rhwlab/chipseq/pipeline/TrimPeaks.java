/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.pipeline;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import org.rhwlab.bedformat.NarrowPeakBedRecord;
import org.rhwlab.chipseqweb.beans.Directory;

/**
 *
 * @author gevirl
 */
public class TrimPeaks {
    static public void main(String[] args)throws Exception{
        int thresh = 700;
        int pad = 350;
        
        Directory dir = new Directory();
        File peakBed = new File(new File(dir.getDirectory(),"macs2"),"AllWormPeaks.bed");
        File outBed = new File(peakBed.getPath().replace(".bed", ".trim.bed"));
        
        PrintStream stream = new PrintStream(outBed);
        BufferedReader reader = new BufferedReader(new FileReader(peakBed));
        String line = reader.readLine();
        while (line != null){
            NarrowPeakBedRecord rec = new NarrowPeakBedRecord(line);
            int len = rec.getEnd() - rec.getStart();
            if (len > thresh){
                rec.setEnd(Integer.min(rec.getEnd(), rec.getPeakLocation() + pad));
                rec.setStart(Integer.max(rec.getStart(), rec.getPeakLocation() - pad));
            }
            stream.println(rec.toString());
            line = reader.readLine();
        }
        stream.close();
    }
}
