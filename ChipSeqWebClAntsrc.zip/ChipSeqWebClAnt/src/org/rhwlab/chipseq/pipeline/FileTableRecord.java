/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.pipeline;

import java.io.File;
import java.io.Serializable;
import java.net.URL;

/**
 *
 * @author gevirl
 */
public class FileTableRecord implements Serializable {

    String name;
    String optimal = "";
    String conservative = "";
    String format;
    String desc;
    String replicates;
    String replicateType;
    int size;
    String units;
    URL source;  // the source of the file
    URL meta; // link to metadata in DCC

    public FileTableRecord() {


    }
    public FileTableRecord(String[] tokens)throws Exception {
        source = new URL(tokens[0]);
        name = tokens[1]; 
        optimal = tokens[2];
        conservative = tokens[3];
        replicates = tokens[4];
        replicateType = tokens[5];
        desc = tokens[6];
        format = tokens[7];
        size = Integer.parseInt(tokens[8]);
        units = tokens[9];
        if (tokens.length==10 || tokens[10].equals("")){
            meta = null;
        } else {
            meta = new URL(tokens[10]);
        }
                
    }

    public FileTableRecord(File file, String format, String desc, String rep, String type, int sz, String units) throws Exception {
        this(format, desc, rep, type, sz, units);
        setSource(file);
    }

    public FileTableRecord(URL url, String name, String format, String desc, String rep, String type, int sz, String units) {
        this(format, desc, rep, type, sz, units);
        this.name = name;
        this.source = url;
    }

    public FileTableRecord(String format, String desc, String rep, String type, int sz, String units) {
        this.format = format;
        this.desc = desc;
        this.replicateType = type;
        this.replicates = rep;
        this.size = sz;
        this.units = units;

    }
    
    public String getName(){
        return this.name;
    }
    public String getUnits(){
        return this.units;
    }
    public int getSize(){
        return this.size;
    }

    public String getDesc(){
        return this.desc;
    }
    public String getConservative() {
        return this.conservative;
    }

    public String getOptimal() {
        return this.optimal;
    }

    public String getReplicateType() {
        return this.replicateType ;
    }

    public String getReplicates() {
        return this.replicates;
    }

    public URL getSource() {
        return this.source;
    }

    public String getFormat() {
        return this.format;
    }

    public void setOptimal(String s) {
        this.optimal = s;
    }

    public void setConservative(String s) {
        this.conservative = s;
    }

    final public void setSource(File file) throws Exception {
        this.source = file.toURI().toURL();
        this.name = file.getName();
    }

    public void setMeta(URL m){
        this.meta = m;
    }
    public String reportHead() {
        return String.format("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s",
                "source", "name", "optimal", "conserved", "replicate", "repType", "description", "format", "size", "units", "meta");
    }

    public String report() {
        String metaVal = "";
        if (meta != null){
            metaVal = meta.toExternalForm();
        }
        return String.format("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%d\t%s\t%s",
                source.toExternalForm(), name, optimal, conservative, replicates, replicateType, desc, format, size, units, metaVal);
    }
    
    public String asExternalURL(){
        String s = source.getPath();
        s = s.replace("/data/www/site/waterston/html/", "http://waterston.gs.washington.edu/");
        return s;
    }
    
    

}
