/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.pipeline;


import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import org.rhwlab.chipseqweb.beans.Directory;

/**
 *
 * @author gevirl
 */
public class ExperimentPeakRecord implements java.io.Serializable {

    String expID;
    int nPeaks;
    String link;
    double idrRescue;
    double idrConsist;
    double overRescue;
    double overConsist;
    int nOpt;

    public ExperimentPeakRecord() {

    }

    public ExperimentPeakRecord(String expID, int nPeaks, String species) throws Exception {
        this.expID = expID;
        this.nPeaks = nPeaks;
        link = String.format("http://waterston.gs.washington.edu/ChipSeqPipeline/%s/%s/qc.html", species, expID);

        Directory dir = new Directory();
        File epicDir = dir.getEpicDirectory(species);
        File epicExpDir = new File(epicDir,expID);
        File qcFile = new File(epicExpDir, "qc.json");
        if (qcFile.exists()) {
            JsonReader reader = Json.createReader(new FileReader(qcFile));
            JsonObject qcObj = reader.readObject();
            reader.close();

            JsonObject replic = qcObj.getJsonObject("replication");
            JsonObject repro = replic.getJsonObject("reproducibility");
            JsonObject overlap = repro.getJsonObject("overlap");
            overRescue = overlap.getJsonNumber("rescue_ratio").doubleValue();
            overConsist = overlap.getJsonNumber("self_consistency_ratio").doubleValue();            
            JsonObject idr = repro.getJsonObject("idr");
            idrRescue = idr.getJsonNumber("rescue_ratio").doubleValue();
            idrConsist = idr.getJsonNumber("self_consistency_ratio").doubleValue();
            nOpt = idr.getJsonNumber("N_opt").intValue();

        }

    }

    public ExperimentPeakRecord(String[] tokens) {
        expID = tokens[0];
        nPeaks = Integer.valueOf(tokens[1]);
        link = tokens[2];
    }

    public void save(PrintStream stream) {
        stream.printf("%s\t%s\t%s\n", expID, nPeaks, link);
    }

    public String getID() {
        return expID;
    }

    public void setID(String s) {
        this.expID = s;
    }

    public int getCount() {
        return nPeaks;
    }

    public void setCount(int c) {
        this.nPeaks = c;
    }

    public String getReportLink() {
        return link;
    }
    public double getRescueRatio(){
        return this.idrRescue;
    }
    public double getConsistencyRatio(){
        return this.idrConsist;
    }
    public double getOverlapRescueRatio(){
        return this.overRescue;
    }
    public double getOverlapConsistencyRatio(){
        return this.overConsist;
    }
}
