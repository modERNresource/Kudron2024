/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.pipeline;

import htsjdk.samtools.util.Interval;
import htsjdk.samtools.util.IntervalTree;
import htsjdk.samtools.util.IntervalTree.Node;
import htsjdk.samtools.util.IntervalTreeMap;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import org.rhwlab.bedformat.NarrowPeakBedRecord;
import org.rhwlab.chipseqweb.beans.Directory;

/**
 *
 * @author gevirl
 */
public class PeakIntervalTree {

    TreeMap<String, IntervalTree> chromoMap = new TreeMap<>();

    public PeakIntervalTree(File bedFile) throws Exception {
        // build the interval tree for each chromosome
        // the value stored in the node is a map , expID -> list of bed records
        BufferedReader reader = new BufferedReader(new FileReader(bedFile));
        String line = reader.readLine();
        while (line != null) {
            NarrowPeakBedRecord bedRec = new NarrowPeakBedRecord(line);
            String chromo = bedRec.getChromosome();
            IntervalTree tree = chromoMap.get(chromo);
            if (tree == null) {
                tree = new IntervalTree<>();
                chromoMap.put(chromo, tree);
            }
            Node node = tree.find(bedRec.getStart(), bedRec.getEnd());
            if (node == null) {
                Map expMap = new TreeMap<>();
                List list = new ArrayList<>();
                list.add(bedRec);
                expMap.put(bedRec.getName(), list);
                tree.put(bedRec.getStart(), bedRec.getEnd(), expMap);
            } else {
                Map expMap = (Map) node.getValue();
                List list = (List) expMap.get(bedRec.getName());
                if (list == null) {
                    list = new ArrayList<>();
                    expMap.put(bedRec.getName(), list);
                }
                list.add(bedRec);
            }
            line = reader.readLine();
        }
        reader.close();
    }


    public IntervalTreeMap dupsByInterval() {
        IntervalTreeMap ret = new IntervalTreeMap<>();

        for (String chromo : chromoMap.keySet()) {
            IntervalTree tree = chromoMap.get(chromo);
            for (Object obj : tree) {
                Node node = (Node) obj;
                TreeMap<String, List> expMap = (TreeMap<String, List>) node.getValue();
                for (String expID : expMap.keySet()) {

                    List<NarrowPeakBedRecord> list = (List<NarrowPeakBedRecord>) expMap.get(expID);
                    if (list.size() > 1) {
                        NarrowPeakBedRecord rec = list.get(0);
                        Interval interval = new Interval(rec.getChromosome(), rec.getStart(), rec.getEnd());
                        TreeMap<String, List> map = (TreeMap<String, List>) ret.get(interval);
                        if (map == null) {
                            map = new TreeMap<>();
                            ret.put(interval, map);
                        }
                        map.put(expID, list);
                    }
                }
            }
        }
        return ret;
    }

    public TreeMap<String, IntervalTreeMap> dupsByExper() {
        TreeMap<String, IntervalTreeMap> ret = new TreeMap<>();

        for (String chromo : chromoMap.keySet()) {
            IntervalTree tree = chromoMap.get(chromo);
            for (Object obj : tree) {
                Node node = (Node) obj;
                TreeMap<String, List> expMap = (TreeMap<String, List>) node.getValue();
                for (String expID : expMap.keySet()) {

                    List<NarrowPeakBedRecord> list = (List<NarrowPeakBedRecord>) expMap.get(expID);
                    if (list.size() > 1) {
                        NarrowPeakBedRecord rec = list.get(0);
                        Interval interval = new Interval(rec.getChromosome(), rec.getStart(), rec.getEnd());
                        IntervalTreeMap treeMap = ret.get(expID);
                        if (treeMap == null) {
                            treeMap = new IntervalTreeMap<>();
                            ret.put(expID, treeMap);
                        }
                        treeMap.put(interval, list);
                    }
                }
            }
        }
        return ret;
    }

    public void reportDups(File dupFile, File nodupFile) throws Exception {
        // traverse each interval tree
        PrintStream dupsStream = new PrintStream(dupFile);
        PrintStream nodupsStream = new PrintStream(nodupFile);
        int i = 1;
        int minD = Integer.MAX_VALUE;
        for (String chromo : chromoMap.keySet()) {
            IntervalTree tree = chromoMap.get(chromo);
            Iterator iter = tree.iterator();
            while (iter.hasNext()) {
                Node node = (Node) iter.next();
                Map expMap = (Map) node.getValue();
                for (Object expName : expMap.keySet()) {
                    List list = (List) expMap.get(expName);
                    if (list.size() > 1) {
                        for (Object rec : list) {
                            NarrowPeakBedRecord bedRec = (NarrowPeakBedRecord) rec;
                            int d = bedRec.getEnd() - bedRec.getStart() + 1;
                            if (d < minD) {
                                minD = d;
                            }
                            String bedStr = bedRec.toString();
                            System.out.printf("%d\t%d\t%s\n", i, d, rec.toString());
                            dupsStream.println(bedStr);
                            ++i;
                        }
                    } else {
                        NarrowPeakBedRecord bedRec = (NarrowPeakBedRecord) list.get(0);
                        String bedStr = bedRec.toString();
                        nodupsStream.println(bedStr);
                    }
                }

            }
        }
        dupsStream.close();
        nodupsStream.close();
        System.out.println(minD);
    }

    public static void main(String[] args) throws Exception {

        Directory dir = new Directory();
        File bedFile = new File(new File(dir.getDirectory(), "macs2"), "AllWormPeaks.bed");
        File dupFile = new File(bedFile.getPath().replace(".bed", ".dups.bed"));
        File nodupFile = new File(bedFile.getPath().replace(".bed", ".nodups.bed"));

        PeakIntervalTree cull = new PeakIntervalTree(bedFile);
//        TreeMap<String, IntervalTreeMap> map = cull.dupsByExper();
//        IntervalTreeMap map = cull.dupsByInterval();
        
        int asdlkf = 0;
               cull.reportDups(dupFile, nodupFile);

    }
}
