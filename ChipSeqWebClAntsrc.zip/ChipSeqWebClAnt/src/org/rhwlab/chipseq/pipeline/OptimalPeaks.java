/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.pipeline;

import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.PrintStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.TreeSet;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.primefaces.model.charts.ChartData;
import org.primefaces.model.charts.axes.cartesian.CartesianScaleTitle;
import org.primefaces.model.charts.axes.cartesian.CartesianScales;
import org.primefaces.model.charts.axes.cartesian.linear.CartesianLinearAxes;
import org.primefaces.model.charts.axes.cartesian.linear.CartesianLinearTicks;
import org.primefaces.model.charts.bar.BarChartDataSet;
import org.primefaces.model.charts.bar.BarChartModel;
import org.primefaces.model.charts.bar.BarChartOptions;
import org.primefaces.model.charts.optionconfig.title.Title;
import org.rhwlab.chipseq.PeakFile;
import org.rhwlab.chipseqweb.beans.Directory;
import org.rhwlab.bedformat.NarrowPeakBedRecord;
import org.rhwlab.chipseq.PeakClusters;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipHelper;
import org.rhwlab.chipseqweb.HibernateUtil;
import org.rhwlab.chipseqweb.beans.BindingDomainGroups;
import org.rhwlab.process.TrimDuplicatedPeaks;

/**
 *
 * @author gevirl
 */
@Named("optimalPeaks")
@SessionScoped
public class OptimalPeaks implements Serializable {

    Map<String, ExperimentPeakRecord> wormPeaks;
    Map<String, ExperimentPeakRecord> flyPeaks;
    TreeMap<Integer, Integer> wormDist;
    TreeMap<Integer, Integer> flyDist;
    TreeMap<Integer, Integer> wormNoDupTFDist;
    TreeMap<Integer, Integer> flyNoDupTFDist;
    Directory dir = new Directory();

    public OptimalPeaks() throws Exception {

        wormPeaks = ReadPeakCounts(WormTSV());
        flyPeaks = ReadPeakCounts(FlyTSV());
        wormDist = ReadPeakDist(WormPeakDist());
        flyDist = ReadPeakDist(FlyPeakDist());
        wormNoDupTFDist = ReadPeakDist(WormNoDupPeakDist());
        flyNoDupTFDist = ReadPeakDist(FlyNoDupPeakDist());

    }

    public ExperimentPeakRecord getRecord(String expID) {
        ExperimentPeakRecord ret = wormPeaks.get(expID);
        if (ret == null) {
            ret = flyPeaks.get(expID);
        }
        return ret;
    }

    public StreamedContent getWormOptimalPeaks(String dataset) throws Exception {
        File bedFile = null;

        switch (dataset) {
            case "All":
                bedFile = OptimalPeaks.WormBed();
                break;
            case "Published":
                bedFile = OptimalPeaks.WormTFOnlyBed();
                break;
            case "Additional":
                bedFile = OptimalPeaks.WormNoAnalysisTFOnlyBed();
                break;
            case "NonTF":
                bedFile = OptimalPeaks.WormNonTFOnlyBed();
                break;
            default:
                break;
        }
        FileInputStream stream = new FileInputStream(bedFile);
        DefaultStreamedContent.Builder builder = DefaultStreamedContent.builder();
        builder.name(String.format("%sOptimalWormPeaks", dataset));
        builder.contentType("text/plain");
        builder.stream(() -> stream);
        return builder.build();
//        return new DefaultStreamedContent(stream, "text/plain", String.format("%sOptimalWormPeaks",dataset));
    }

    public StreamedContent getWormPeaksPrimary() throws Exception {
        FileInputStream stream = new FileInputStream(new File(dir.getDirectory(), "AllWormPeaks.TF.noDups.ranked.primary.tsv"));
        DefaultStreamedContent.Builder builder = DefaultStreamedContent.builder()
                .name("WormTFPeaksPrimaryTargets.tsv")
                .contentType("text/plain")
                .stream(() -> stream);
        return builder.build();
//        return new DefaultStreamedContent(stream, "text/plain", "WormTFPeaksPrimaryTargets.tsv");
    }

    public StreamedContent getWormPeaksAlternate() throws Exception {
        FileInputStream stream = new FileInputStream(new File(dir.getDirectory(), "AllWormPeaks.TF.noDups.ranked.alternate.tsv"));
        DefaultStreamedContent.Builder builder = DefaultStreamedContent.builder();
        builder.name("WormTFPeaksAlternateTargets.tsv");
        builder.contentType("text/plain");
        builder.stream(() -> stream);
        return builder.build();
//        return new DefaultStreamedContent(stream, "text/plain", "WormTFPeaksAlternateTargets.tsv");
    }

    public StreamedContent getWormMetaPeaksPrimary() throws Exception {
        FileInputStream stream = new FileInputStream(new File(dir.getDirectory(), "AllWormPeaks.TF.noDups.clusters.primary.tsv"));
        DefaultStreamedContent.Builder builder = DefaultStreamedContent.builder();
        builder.name("WormMetaPeaksPrimaryTargets.tsv");
        builder.contentType("text/plain");
        builder.stream(() -> stream);
        return builder.build();
        //       return new DefaultStreamedContent(stream, "text/plain", "WormMetaPeaksPrimaryTargets.tsv");
    }

    public StreamedContent getWormMetaPeaksAlternate() throws Exception {
        FileInputStream stream = new FileInputStream(new File(dir.getDirectory(), "AllWormPeaks.TF.noDups.clusters.alternate.tsv"));
        DefaultStreamedContent.Builder builder = DefaultStreamedContent.builder();
        builder.name("WormMetaPeaksAlternateTargets.tsv");
        builder.contentType("text/plain");
        builder.stream(() -> stream);
        return builder.build();
//        return new DefaultStreamedContent(stream, "text/plain", "WormMetaPeaksAlternateTargets.tsv");
    }

    public StreamedContent getFlyOptimalPeaks(String dataset) throws Exception {
        File bedFile = null;

        switch (dataset) {
            case "All":
                bedFile = OptimalPeaks.FlyBed();
                break;
            case "Published":
                bedFile = OptimalPeaks.FlyTFOnlyBed();
                break;
            case "Additional":
                bedFile = OptimalPeaks.FlyNoAnalysisTFOnlyBed();
                break;
            case "NonTF":
                bedFile = OptimalPeaks.FlyNonTFOnlyBed();
                break;
            default:
                break;
        }
        FileInputStream stream = new FileInputStream(bedFile);
        DefaultStreamedContent.Builder builder = DefaultStreamedContent.builder();
        builder.name(String.format("%sOptimalFlyPeaks", dataset));
        builder.contentType("text/plain");
        builder.stream(() -> stream);
        return builder.build();
//        return new DefaultStreamedContent(stream, "text/plain", String.format("%sOptimalFlyPeaks",dataset));
    }

    public StreamedContent getFlyPeaksPrimary() throws Exception {
        FileInputStream stream = new FileInputStream(new File(dir.getDirectory(), "AllFlyPeaks.TF.noDups.ranked.primary.tsv"));
        DefaultStreamedContent.Builder builder = DefaultStreamedContent.builder();
        builder.name("FlyTFPeaksPrimaryTargets.tsv");
        builder.contentType("text/plain");
        builder.stream(() -> stream);
        return builder.build();
//        return new DefaultStreamedContent(stream, "text/plain", "FlyTFPeaksPrimaryTargets.tsv");
    }

    public StreamedContent getFlyPeaksAlternate() throws Exception {
        FileInputStream stream = new FileInputStream(new File(dir.getDirectory(), "AllFlyPeaks.TF.noDups.ranked.alternate.tsv"));
        DefaultStreamedContent.Builder builder = DefaultStreamedContent.builder();
        builder.name("FlyTFPeaksAlternateTargets.tsv");
        builder.contentType("text/plain");
        builder.stream(() -> stream);
        return builder.build();
//        return new DefaultStreamedContent(stream, "text/plain", "FlyTFPeaksAlternateTargets.tsv");
    }

    public StreamedContent getFlyMetaPeaksPrimary() throws Exception {
        FileInputStream stream = new FileInputStream(new File(dir.getDirectory(), "AllFlyPeaks.TF.noDups.clusters.primary.tsv"));
        DefaultStreamedContent.Builder builder = DefaultStreamedContent.builder();
        builder.name("FlyMetaPeaksPrimaryTargets.tsv");
        builder.contentType("text/plain");
        builder.stream(() -> stream);
        return builder.build();

//        return new DefaultStreamedContent(stream, "text/plain", "FlyMetaPeaksPrimaryTargets.tsv");
    }

    public StreamedContent getFlyMetaPeaksAlternate() throws Exception {
        FileInputStream stream = new FileInputStream(new File(dir.getDirectory(), "AllFlyPeaks.TF.noDups.clusters.alternate.tsv"));
        DefaultStreamedContent.Builder builder = DefaultStreamedContent.builder();
        builder.name("FlyMetaPeaksAlternateTargets.tsv");
        builder.contentType("text/plain");
        builder.stream(() -> stream);
        return builder.build();
//        return new DefaultStreamedContent(stream, "text/plain", "FlyMetaPeaksAlternateTargets.tsv");
    }

    static final public Map<String, ExperimentPeakRecord> ReadPeakCounts(File tsv) throws Exception {
        Map<String, ExperimentPeakRecord> ret = new TreeMap<>();
        if (tsv.exists()) {
            BufferedReader reader = new BufferedReader(new FileReader(tsv));
            String line = reader.readLine();
            while (line != null) {
                ExperimentPeakRecord rec = new ExperimentPeakRecord(line.split("\t"));
                ret.put(rec.getID(), rec);
                line = reader.readLine();
            }
            reader.close();
        }
        return ret;
    }

    static public void SavePeakCounts(List<ExperimentPeakRecord> list, File tsv) throws Exception {
        PrintStream stream = new PrintStream(tsv);
        for (ExperimentPeakRecord rec : list) {
            rec.save(stream);
        }
        stream.close();
    }

    static final public TreeMap<Integer, Integer> ReadPeakDist(File tsv) throws Exception {
        TreeMap<Integer, Integer> map = new TreeMap<>();
        if (tsv.exists()) {
            BufferedReader reader = new BufferedReader(new FileReader(tsv));
            String line = reader.readLine();
            while (line != null) {
                String[] tokens = line.split("\t");
                map.put(Integer.valueOf(tokens[0]), Integer.valueOf(tokens[1]));
                line = reader.readLine();
            }
            reader.close();
        }
        return map;
    }

    static public int[] histogram(int binWidth, int nBins, List<Integer> vals) {

        TreeMap<Integer, Integer> map = new TreeMap<>();
        for (int i = 1; i <= nBins; ++i) {
            map.put(i * binWidth, 0);
        }

        for (Integer v : vals) {
            Integer key = map.ceilingKey(v);
            if (key == null) {
                key = map.lastKey();
            }
            map.put(key, map.get(key) + 1);
        }

        int[] ret = new int[nBins];
        int i = 0;
        for (Integer v : map.values()) {
            ret[i] = v;
            ++i;
        }
        return ret;
    }

    public int[] calcHistogram(int width, int nBins, List<ExperimentPeakRecord> recs) {
        int[] ret = new int[nBins];
        int[] ceils = new int[nBins];
        ceils[0] = width;
        ceils[nBins - 1] = Integer.MAX_VALUE;
        for (int i = 1; i < nBins - 1; ++i) {
            ceils[i] = width + ceils[i - 1];
        }

        for (ExperimentPeakRecord rec : recs) {
            for (int i = 0; i < nBins; ++i) {
                int c = rec.getCount();
                if (c <= ceils[i]) {
                    ++ret[i];
                    break;
                }
            }
        }
        return ret;
    }

    public BarChartModel getWormHistogramBarChart() throws Exception {
        int nBins = 100;
        int width = 100;
        return getHistogramBarChart(getWormPeaks(), width, nBins);
    }

    public BarChartModel getFlyHistogramBarChart() throws Exception {
        int nBins = 150;
        int width = 100;
        return getHistogramBarChart(getFlyPeaks(), width, nBins);
    }

    public BarChartModel getHistogramBarChart(List<ExperimentPeakRecord> recs, int width, int nBins) throws Exception {
        BarChartModel barModel = new BarChartModel();
        ChartData data = new ChartData();

        BarChartDataSet barDataSet = new BarChartDataSet();
        barDataSet.setLabel("All Experiments ( TF and non TF)");

        int[] vals = calcHistogram(width, nBins, recs);
        List<String> bgColors = new ArrayList<>();
        List<Number> values = new ArrayList<>();
        for (int v : vals) {
            bgColors.add("rgb(255, 0, 0)");
            values.add(v);
        }
        barDataSet.setData(values);

        barDataSet.setBackgroundColor(bgColors);

        data.addChartDataSet(barDataSet);

        List<String> labels = new ArrayList<>();
        for (int i = 0; i < nBins; ++i) {
            labels.add(String.format("%d", (i + 1) * width));
        }
        data.setLabels(labels);
        barModel.setData(data);

        CartesianLinearAxes yAxis = new CartesianLinearAxes();
        yAxis.setBeginAtZero(true);
        CartesianLinearTicks ticks = new CartesianLinearTicks();
        yAxis.setTicks(ticks);
        CartesianScaleTitle yLabel = new CartesianScaleTitle();
        yLabel.setText("Number of Experiments");
        yLabel.setDisplay(true);
        yAxis.setScaleTitle(yLabel);

        CartesianLinearAxes xAxis = new CartesianLinearAxes();
        CartesianScaleTitle xLabel = new CartesianScaleTitle();
        xLabel.setText("Number of Peaks in Experiment");
        xLabel.setDisplay(true);
        xAxis.setScaleTitle(xLabel);

        CartesianScales cScales = new CartesianScales();
        cScales.addYAxesData(yAxis);
        cScales.addXAxesData(xAxis);

        BarChartOptions options = new BarChartOptions();
        options.setScales(cScales);

        Title title = new Title();
        title.setDisplay(true);
        title.setText("Peak Count Distribution");
        options.setTitle(title);

        barModel.setOptions(options);
        return barModel;
    }

    public BarChartModel getWormPeakDistBarChart() throws Exception {
        return getPeakDistBarChart("All Experiments, All Peaks", this.wormDist);
    }

    public BarChartModel getFlyPeakDistBarChart() throws Exception {
        return getPeakDistBarChart("All Experiments, All Peaks", this.flyDist);
    }

    public BarChartModel getWormNoDupPeakDistBarChart() throws Exception {
        return getPeakDistBarChart("TF Experiments, Dups Trimmed", this.wormNoDupTFDist);
    }

    public BarChartModel getFlyNoDupPeakDistBarChart() throws Exception {
        return getPeakDistBarChart("TF Experiments, Dups Trimmed", this.flyNoDupTFDist);
    }

    public BarChartModel getPeakDistBarChart(String chartTitle, TreeMap<Integer, Integer> dist) throws Exception {
        BarChartModel barModel = new BarChartModel();
        ChartData data = new ChartData();

        BarChartDataSet barDataSet = new BarChartDataSet();
        barDataSet.setLabel(chartTitle);

        List<String> bgColors = new ArrayList<>();
        List<Number> values = new ArrayList<>();
        List<String> labels = new ArrayList<>();

        int n = 0;
        int nVals = 750;
        for (Entry<Integer, Integer> e : dist.entrySet()) {
            bgColors.add("rgb(255, 0, 0)");
            values.add(e.getValue());
            labels.add(String.format("%d", e.getKey()));
            ++n;
            if (n > nVals) {
                break;
            }
        }

        barDataSet.setData(values);
        barDataSet.setBackgroundColor(bgColors);
        data.setLabels(labels);

        data.addChartDataSet(barDataSet);
        barModel.setData(data);

        CartesianLinearAxes yAxis = new CartesianLinearAxes();
        CartesianLinearTicks ticks = new CartesianLinearTicks();
        yAxis.setBeginAtZero(true);
        yAxis.setTicks(ticks);
        CartesianScaleTitle yLabel = new CartesianScaleTitle();
        yLabel.setText("Number of Peaks");
        yLabel.setDisplay(true);
        yAxis.setScaleTitle(yLabel);

        CartesianLinearAxes xAxis = new CartesianLinearAxes();
        CartesianScaleTitle xLabel = new CartesianScaleTitle();
        xLabel.setText("Peak Length");
        xLabel.setDisplay(true);
        xAxis.setScaleTitle(xLabel);

        CartesianScales cScales = new CartesianScales();
        cScales.addYAxesData(yAxis);
        cScales.addXAxesData(xAxis);

        BarChartOptions options = new BarChartOptions();
        options.setScales(cScales);

        Title title = new Title();
        title.setDisplay(true);
        title.setText("Peak Length Distribution");
        options.setTitle(title);

        barModel.setOptions(options);
        return barModel;
    }

    public List<ExperimentPeakRecord> getWormPeaks() {
        List<ExperimentPeakRecord> list = new ArrayList<>();
        list.addAll(this.wormPeaks.values());
        return list;
    }

    public List<ExperimentPeakRecord> getFlyPeaks() {
        List<ExperimentPeakRecord> list = new ArrayList<>();
        list.addAll(this.flyPeaks.values());
        return list;
    }

    public String getWormHubLink() {
        return String.format("http://genome.ucsc.edu/cgi-bin/hgTracks?db=ce11&hubClear=http://waterston.gs.washington.edu/modERN/CElegans_hub.txt");
    }

    public String getFlyHubLink() {
        return String.format("http://genome.ucsc.edu/cgi-bin/hgTracks?db=dm6&hubClear=http://waterston.gs.washington.edu/modERN/Dmel_hub.txt");
    }

    static public void SaveExp(List<ExperimentPeakRecord> list, TreeMap<String, ChipExperiment> expMap, File idrFile) throws Exception {
        BindingDomainGroups groups = new BindingDomainGroups();
        PrintStream stream = new PrintStream(idrFile);
        stream.println("exp\tidrRescue\tidrConsist\toverlapRescue\toverlapConsist\tnPeaks\tdomain");
        for (ExperimentPeakRecord rec : list) {
            String expID = rec.getID();
            ChipExperiment exp = expMap.get(expID);
            String domain = exp.getDomain();
            String group = groups.getDomainGroup(domain);
            stream.printf("%s\t%f\t%f\t%f\t%f\t%d\t%s\n",
                    expID, rec.getRescueRatio(), rec.getConsistencyRatio(), rec.getOverlapRescueRatio(), rec.getOverlapConsistencyRatio(), rec.getCount(), group);
        }
        stream.close();
    }

    static public void buildFiles() throws Exception {
        int nBins = 500;
        String head = "chrom\tchromStart\tchromEnd\texperiment\tscore\tstrand\tsignalValue\tsignalRank\tpValue\tpeak";
        //Worm
        TreeMap<String, ChipExperiment> expMap = new TreeMap<>();
        TreeMap<String, Integer> peakCounts = buildAggregateBed("CElegans", WormBed(), WormTFOnlyBed(), WormNoAnalysisTFOnlyBed(), WormNonTFOnlyBed(), expMap, head);
        List<ExperimentPeakRecord> peakList = new ArrayList<>();
        for (Entry entry : peakCounts.entrySet()) {
            peakList.add(new ExperimentPeakRecord((String) entry.getKey(), (Integer) entry.getValue(), "worm"));
        }
        // save some auxillary info files
        SaveExp(peakList, expMap, WormIDR());
        SavePeakCounts(peakList, WormTSV());

        // make the all peaks bigbed
        buildBigBed(WormBed(), "ce11");

        peakSizeDistribution(WormBed(), nBins, WormPeakDist());

        // trim the wide duplicated peaks and remove the M chromosome
        TreeSet<String> except = new TreeSet<>();
        except.add("chrM");
        File wormNoDup = TrimDuplicatedPeaks.trim(WormTFOnlyBed(), except, head);

        peakSizeDistribution(wormNoDup, nBins, WormNoDupPeakDist());

        // make the TF noDup noM peaks bigbed
        buildBigBed(wormNoDup, "ce11");

        // Fly
        expMap.clear();
        peakCounts = buildAggregateBed("Dmel", FlyBed(), FlyTFOnlyBed(), FlyNoAnalysisTFOnlyBed(), FlyNonTFOnlyBed(), expMap, head);
        peakList = new ArrayList<>();
        for (Entry entry : peakCounts.entrySet()) {
            peakList.add(new ExperimentPeakRecord((String) entry.getKey(), (Integer) entry.getValue(), "fly"));
        }
        SaveExp(peakList, expMap, FlyIDR());
        SavePeakCounts(peakList, FlyTSV());
        buildBigBed(FlyBed(), "dm6");
        peakSizeDistribution(FlyBed(), nBins, FlyPeakDist());
        except.clear();
        File flyNoDup = TrimDuplicatedPeaks.trim(FlyTFOnlyBed(), except, head);
        peakSizeDistribution(flyNoDup, nBins, FlyNoDupPeakDist());
        buildBigBed(flyNoDup, "dm6");
    }

    // build a bigBed and a bigWig file from a bed file
    // the bed files are sorted and clipped to the chromosome sizes
    // makes a script file to do the work and then starts the script running
    static public void buildBigBed(File bed, String assembly) throws Exception {
        File clippedBed = new File(bed.getPath() + ".clip");
        File bedSorted = new File(bed.getPath() + ".sort");
        File bigBed = new File(bed.getPath().replace(".bed", ".bb"));
        File bedGraph = new File(bed.getPath().replace(".bed", ".bedGraph"));
        File bigWig = new File(bed.getPath().replace(".bed", ".bw"));
        File errFile = new File(bed.getPath().replace(".bed", ".err"));
        File outputFile = new File(bed.getPath().replace(".bed", ".out"));

        int[] dels = {200, 50};

        File scriptFile = new File(bed.getPath().replace(".bed", ".sh"));
        PrintStream scriptStream = new PrintStream(scriptFile);

        scriptStream.printf("bedClip -truncate  %s  /net/waterston/vol9/%s.chrom.sizes %s \n",
                bed.getPath(), assembly, clippedBed.getPath());
        scriptStream.printf("/net/waterston/vol9/bedSort  %s  %s \n",
                clippedBed.getPath(), bedSorted.getPath());
        scriptStream.printf("bedtools genomecov -bg -i %s -g /net/waterston/vol9/%s.chrom.sizes  > %s\n",
                bedSorted.getPath(), assembly, bedGraph.getPath());
        scriptStream.printf("/net/waterston/vol9/bedToBigBed -type=bed6+4 -as=/net/waterston/vol9/narrowPeak.as  %s /net/waterston/vol9/%s.chrom.sizes %s \n",
                bedSorted.getPath(), assembly, bigBed.getPath());
        scriptStream.printf("/net/waterston/vol9/bedGraphToBigWig %s /net/waterston/vol9/%s.chrom.sizes %s \n",
                bedGraph.getPath(), assembly, bigWig);
        for (int i = 0; i < dels.length; ++i) {
            String suffix = String.format(".cluster.%d.bed", dels[i]);
            File clusterBed = new File(bed.getPath().replace(".bed", suffix));
            File clusterBedClipped = new File(clusterBed.getPath() + ".clip");
            File clusterBedSorted = new File(clusterBed.getPath() + ".sort");
            File clusterBigBed = new File(clusterBed.getPath().replace(".bed", ".bb"));
            scriptStream.printf("bedClip -truncate  %s  /net/waterston/vol9/%s.chrom.sizes %s \n",
                    clusterBed.getPath(), assembly, clusterBedClipped.getPath());
            scriptStream.printf("/net/waterston/vol9/bedSort  %s  %s \n",
                    clusterBedClipped.getPath(), clusterBedSorted.getPath());
            scriptStream.printf("/net/waterston/vol9/bedToBigBed -type=bed6+3  %s /net/waterston/vol9/%s.chrom.sizes %s \n",
                    clusterBedSorted.getPath(), assembly, clusterBigBed.getPath());
        }
        scriptStream.close();
        scriptFile.setExecutable(true, false);
        ProcessBuilder builder = new ProcessBuilder(scriptFile.getPath());
        builder.redirectError(errFile);
        builder.redirectOutput(outputFile);
        Process p = builder.start();
        p.waitFor();

    }

    //******* must be run on epic to find all the bed files - uses the species directory on epic to determine all experiments
    // accumulates all the peak files for a species
    // returns a map of the number of peaks by experiment
    // build a map of ChipExperiment objects
    // write four bed files and two tsv files
    // bed files:
    // 1) All experiments
    // 2) Experiments in Kudron2024 - these are TF experiments only
    // 3) non TF experiments
    // 4) TF experiments not in Kudron2024
    // tsv files for 1) and 2)
    public static TreeMap<String, Integer> buildAggregateBed(String species, File allPeaksBedFile, File tfPeaksBedFile, File noAnalysisFile, File nonTFFile,
            TreeMap<String, ChipExperiment> expMap, String head) throws Exception {
//        NonTFs nonTF = new NonTFs();
        PrintStream stream = new PrintStream(allPeaksBedFile);
        PrintStream tsvStream = new PrintStream(allPeaksBedFile.getPath().replace(".bed", ".tsv"));

        tsvStream.println(head);
        PrintStream tfstream = new PrintStream(tfPeaksBedFile);
        PrintStream tsvtfstream = new PrintStream(tfPeaksBedFile.getPath().replace(".bed", ".tsv"));;
        tsvtfstream.println(head);

        PrintStream noAnalysisStream = new PrintStream(noAnalysisFile);
        PrintStream nonTFStream = new PrintStream(nonTFFile);

        TreeMap<String, Integer> ret = new TreeMap<>();
        Directory dir = new Directory();
        File speciesDir = dir.getEpicDirectory(species);

        for (File expDir : speciesDir.listFiles()) {
            String expID = expDir.getName();

            List list = ChipHelper.getEquals("ChipExperiment", "expID", expID, "expID");
            if (list.isEmpty()) {
                System.out.printf("Experiment not found: %s\n", expID);
            }
            ChipExperiment exp = (ChipExperiment) (list.get(0));
            FileTable table = new FileTable(new File(expDir, String.format("%s.table.tsv", expID)));
            ArrayList<FileTableRecord> optimalRecs = table.getOptimalPeakRecords();
            for (FileTableRecord rec : optimalRecs) {
                if (rec.getFormat().equals("bed")) {
                    expMap.put(expID, exp);
                    File bedFile = new File(expDir, rec.name);
                    String[] tokens = expID.split("_");
                    PeakFile peakFile = new PeakFile(bedFile, tokens[0], "", tokens[2]);
                    String renamed = remapExpID.get(expID);
                    if (renamed == null) {
                        renamed = expID;
                    }
                    String[] expStrs = renamed.split("_");
                    expStrs[0] = exp.getGene();
                    StringBuilder builder = new StringBuilder();
                    builder.append(exp.getGene());
                    for (int i = 1; i < expStrs.length; ++i) {
                        builder.append("_");
                        builder.append(expStrs[i]);
                    }

                    peakFile.nameAllPeaks(builder.toString());
                    peakFile.rankPeaks();
                    peakFile.save(stream);
                    peakFile.save(tsvStream);
                    ret.put(expID, peakFile.getRecordCount());
                    if (exp.getGeneType() == null) {
                        System.out.println(expID);
                    }
                    if (!exp.getGeneType().equals("TF")) {
                        // save in the non TF file
                        peakFile.save(nonTFStream);
                    } else if (exp.isInAnalysis()) {
                        // save in the analysis file
                        peakFile.save(tfstream);
                        peakFile.save(tsvtfstream);
                    } else {
                        // save in the no analysis TF file - these will be TFs
                        peakFile.save(noAnalysisStream);
                    }
                }
            }
        }
        stream.close();
        tsvStream.close();
        tfstream.close();
        tsvtfstream.close();
        noAnalysisStream.close();
        nonTFStream.close();
        return ret;
    }

    static public void peakSizeDistribution(File aggPeakFile, int nBins, File outFile) throws Exception {
        TreeMap<Integer, Integer> map = new TreeMap<>();

        // find the maximumn peak length
        int maxLen = 0;
        BufferedReader reader = new BufferedReader(new FileReader(aggPeakFile));
        String line = reader.readLine();
        while (line != null) {
            NarrowPeakBedRecord peak = new NarrowPeakBedRecord(line);
            int len = peak.getEnd() - peak.getStart() + 1;
            if (len > maxLen) {
                maxLen = len;
            }
            line = reader.readLine();
        }
        reader.close();

        int del = (int) ((double) maxLen / (double) nBins);
        for (int i = 1; i < nBins; ++i) {
            map.put(del * i, 0);
        }
        map.put(maxLen + 1, 0);

        reader = new BufferedReader(new FileReader(aggPeakFile));
        line = reader.readLine();
        while (line != null) {
            NarrowPeakBedRecord peak = new NarrowPeakBedRecord(line);
            int len = peak.getEnd() - peak.getStart() + 1;
            Integer key = map.ceilingKey(len);
            map.put(key, map.get(key) + 1);
            line = reader.readLine();
        }
        reader.close();

        PrintStream stream = new PrintStream(outFile);
        for (Entry<Integer, Integer> e : map.entrySet()) {
            stream.printf("%d\t%d\n", e.getKey(), e.getValue());
        }
        stream.close();
    }

    static public void cluster(ArrayList<PeakFile> peakFileList, File clusterFile, int del) throws Exception {
        PeakClusters clusters = new PeakClusters(peakFileList, del, null, new TreeSet<>());
        File clusterOut = new File(String.format("%s.%d", clusterFile.getPath(), del));
        clusters.report(clusterOut);
        clusters.toBedFormat(clusterOut.getPath() + ".bed");
    }

    static public File WormTSV() {
        return new File(DestDirectory(), "AllWormPeakCounts.tsv");
    }

    static public File WormIDR() {
        return new File(DestDirectory(), "AllWormPeaksIDR.tsv");
    }

    static public File WormBed() {
        return new File(DestDirectory(), "AllWormPeaks.bed");
    }

    static public File WormTFOnlyBed() {
        return new File(DestDirectory(), "AllWormPeaks.TF.bed");
    }

    static public File WormNonTFOnlyBed() {
        return new File(DestDirectory(), "AllWormPeaks.NonTF.bed");
    }

    static public File WormNoAnalysisTFOnlyBed() {
        return new File(DestDirectory(), "AllWormPeaks.TF.NoAnalysis.bed");
    }

    static public File WormTFBed() {
        return new File(DestDirectory(), "AllWormPeaks.TF.noDups.bed");
    }

    static public File WormTFClusteredBed() {
        return new File(DestDirectory(), "AllWormPeaks.TF.noDups.clustered.bed");
    }

    static public File WormTFRankedBed() {
        return new File(DestDirectory(), "AllWormPeaks.TF.noDups.ranked.bed");
    }

    static public File WormClustersBed() {
        return new File(DestDirectory(), "AllWormPeaks.TF.noDups.clusters.bed");
    }

    static public File FlyTSV() {
        return new File(DestDirectory(), "AllFlyPeakCounts.tsv");
    }

    static public File FlyIDR() {
        return new File(DestDirectory(), "AllFlyPeaksIDR.tsv");
    }

    static public File FlyBed() {
        return new File(DestDirectory(), "AllFlyPeaks.bed");
    }

    static public File FlyTFOnlyBed() {
        return new File(DestDirectory(), "AllFlyPeaks.TF.bed");
    }

    static public File FlyNonTFOnlyBed() {
        return new File(DestDirectory(), "AllFlyPeaks.NonTF.bed");
    }

    static public File FlyNoAnalysisTFOnlyBed() {
        return new File(DestDirectory(), "AllFlyPeaks.TF.NoAnalysis.bed");
    }

    static public File FlyTFBed() {
        return new File(DestDirectory(), "AllFlyPeaks.TF.noDups.bed");
    }

    static public File FlyTFClusteredBed() {
        return new File(DestDirectory(), "AllFlyPeaks.TF.noDups.clustered.bed");
    }

    static public File FlyTFRankedBed() {
        return new File(DestDirectory(), "AllFlyPeaks.TF.noDups.ranked.bed");
    }

    static public File FlyClustersBed() {
        return new File(DestDirectory(), "AllFlyPeaks.TF.noDups.clusters.bed");
    }

    static public File WormPeakDist() {
        return new File(DestDirectory(), "WormPeakDist.tsv");
    }

    static public File FlyPeakDist() {
        return new File(DestDirectory(), "FlyPeakDist.tsv");
    }

    static public File WormNoDupPeakDist() {
        return new File(DestDirectory(), "WormNoDupPeakDist.tsv");
    }

    static public File FlyNoDupPeakDist() {
        return new File(DestDirectory(), "FlyNoDupPeakDist.tsv");
    }

    static public File WormTargetDistance() {
        return new File(DestDirectory(), "AllWormPeaks.TF.noDups.clusters.Target.dist");
    }

    static public String DestDirectory() {
        Directory dir = new Directory();
        if (new File(dir.getEpicDirectory()).exists()) {
            return dir.getEpicDirectory();
        }
        return dir.getDirectory();
    }

    // must be run on epic
    // destination is set by function BestDirectory()
    // builds the following bed and bigbed files (same for fly)
    // AllWormPeaks.bed + bb
    // AllWormPeaks.TF.bed + bb
    // AllWormPeaks.TF.noDups.bed + bb - also removed chrM (not so for fly)
    // these are unaltered 10 column bed files from the peak calling pipeline
    static public void main(String[] args) throws Exception {
//        destination = args[0];
        remapExpID = new TreeMap<>();
        remapExpID.put("ceh-28_OP241_L3larva_1", "ceh-38_OP241_L3larva_1");
        remapExpID.put("ceh-28_OP241_L4larva_1", "ceh-38_OP241_L4larva_1");
        remapExpID.put("nhr-27_OP208_youngadult_1", "nhr-270_OP208_youngadult_1");
        buildFiles();
        HibernateUtil.shutdown();
    }

    static TreeMap<String, String> remapExpID;
//    static String destination = "Vol9";
}
