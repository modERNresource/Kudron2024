/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.pipeline;

import java.io.File;
import java.io.FileReader;
import java.util.List;
import javax.json.Json;
import javax.json.JsonNumber;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonString;

/**
 *
 * @author gevirl
 */
public class Metadata {

    String status;
    String started = "";
    String submittedBy = "";
    String overlap = "";
    String idr = "";
    String expID = "";
    String submitID = "";
    String chipID = "";
    String optimalScore = "";
    String consvScore = "";
    String stage;
    JsonNumber idrThreshold;
    File reportHTML;
    File qcJSON;

    List<Alignment> alignments;
    List<Peaks> peaks;
    List<Reproduce> reproduce;
    List<Complexity> complexity;

    public Metadata(File metaFile) throws Exception {
        
        if (metaFile.exists()) {
            JsonReader reader = Json.createReader(new FileReader(metaFile));
            JsonObject metadata = reader.readObject();
            reader.close();

            chipID = metaFile.getParentFile().getName();
            status = metadata.getString("status");
            started = metadata.getJsonString("start").getString();
            JsonObject inputs = metadata.getJsonObject("inputs");
            if (inputs != null) {
                idrThreshold = inputs.getJsonNumber("chip.idr_thresh");
                if (idrThreshold==null){
                    idrThreshold = inputs.getJsonNumber("idr_thresh");
                }
                JsonString jsonDesc = inputs.getJsonString("chip.description");
                if (jsonDesc == null){
                    jsonDesc = inputs.getJsonString("description");
                }
                submittedBy = jsonDesc.getString();
                
                JsonString jsonTitle = inputs.getJsonString("chip.title");
                if (jsonTitle == null){
                    jsonTitle = inputs.getJsonString("title");
                }
                submitID = jsonTitle.getString();

            }
            JsonObject outputs = metadata.getJsonObject("outputs");
            JsonString report = outputs.getJsonString("chip.report");
            if (report != null) {
                reportHTML = new File(report.getString());
            }

            JsonString qcStr = outputs.getJsonString("chip.qc_json");
            if (qcStr != null) {
                String qc = qcStr.getString();
                qcJSON = new File(qc);
                reader = Json.createReader(new FileReader(qc));
                JsonObject qcObj = reader.readObject();
                this.peaks = Peaks.formPeaks(qcObj, null);

                JsonObject replic = qcObj.getJsonObject("replication");

                JsonObject repro = replic.getJsonObject("reproducibility");
                overlap = repro.getJsonObject("overlap").getJsonString("reproducibility").getString();
                idr = "";
                if (repro.getJsonObject("idr") != null) {
                    idr = repro.getJsonObject("idr").getJsonString("reproducibility").getString();
                }
                expID = qcObj.getJsonObject("general").getJsonString("title").getString();
                expID = expID.substring(0, expID.lastIndexOf("_"));
                String[] expIDTokens = expID.split("_");
                if (expIDTokens.length >= 3) {
                    stage = expIDTokens[2];
                }
                reader.close();

                this.alignments = Alignment.formAlignments(qcObj, null);
                this.reproduce = Reproduce.formReproduce(qcObj);
                this.complexity = Complexity.formComplexity(qcObj, null);
            }
        }
    }

    public File getQcJson() {
        return qcJSON;
    }

    public File getReportHtml() {
        return reportHTML;
    }

    public String getStage() {
        return stage;
    }

    public String getSubmitID() {
        return submitID;
    }
}
