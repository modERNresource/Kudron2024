/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.dcc;


import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonString;
import javax.json.JsonStructure;
import static org.rhwlab.chipseq.dcc.SubmitDCC.award;
import org.rhwlab.chipseq.qa.Directories;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipHelper;
import org.rhwlab.chipseqweb.ChipRun;
import org.rhwlab.chipseqweb.ChipSequencingFile;
import org.rhwlab.chipseqweb.ChipTag;
import org.rhwlab.chipseqweb.HibernateUtil;
import org.rhwlab.chipseqweb.Species;
import org.rhwlab.process.CheckDonors;

/**
 *
 * @author gevirl
 */
public class WormDonor extends SchemaBase {

    static File mailMsg = new File(Directories.sourceDir, "wormDonorMailMsg");
    CheckDonors checkDonor;

    public WormDonor() {
        super("worm_donor");
        try {
            checkDonor = new CheckDonors("CElegans", CheckDonors.wormUrl);
        } catch (Exception exc) {
            exc.printStackTrace();
        }
    }

    static public File emailListFile() {
        return new File(Directories.sourceDir, "WormDonorEmailList");
    }

    @Override
    public void submit(ChipExperiment chipExp, File aliasFile) throws Exception {
        JsonObject donorObj = this.checkDonor.getDonorObject(chipExp.getStrain());
        if (donorObj != null) {
            super.submit(chipExp, aliasFile);
        } 
        else {
            PrintStream stream = new PrintStream(new FileOutputStream(emailListFile(), true));
            stream.println(aliasFile.getPath());
            stream.close();
        }
    }

    public void printSubmitScript(PrintStream stream, File jsonFile) throws Exception {
        SubmitDCC.patch(stream, label, jsonFile);
        /*        
        String expID = jsonFile.getParentFile().getParentFile().getName();
        // send the email to idan
        stream.printf("mail -s \"modERN worm donor\" -r \"Louis Gevirtzman<gevirl@uw.edu>\" -a %s -c gevirl@uw.edu gabdank@stanford.edu < %s \n",jsonFile.getPath(),mailMsg.getPath());
        
        // update the experiment record in the db
        stream.printf("java -cp /net/waterston/vol9/ChipSeqPipeline/prog/ChipSeqWebCL.jar org.rhwlab.chipseq.dcc.WormDonor %s \n",expID);
         */
    }

    /* 
    @Override
    public boolean canSubmit(ChipExperiment chipExp, File aliasFile) {
        // has the email been sent?
        return chipExp.getDonorEmail()==null;
    }
     
    @Override
    public boolean isCompleted(File aliasFile) throws Exception {
        return false;
    }
*/
    public JsonStructure toJson(ChipExperiment exp) {
        JsonObjectBuilder builder = Json.createObjectBuilder();

        JsonObject donorObj = this.checkDonor.getDonorObject(exp.getStrain());
        if (donorObj != null) {
            JsonString accStr = donorObj.getJsonString("accession");
            if (accStr != null) {
                builder.add("record_id", accStr.getString());
            }
        }
        award(builder);
        builder.add("aliases", Json.createArrayBuilder().add(Aliases.donorAlias(exp)));
        builder.add("strain_name", exp.getStrain());
        builder.add("genetic_modifications", Json.createArrayBuilder().add(Aliases.geneticModAlias(exp)));
        if (exp.getGenotype() != null) {
            builder.add("genotype", exp.getGenotype());
        }
        SubmitDCC.donorSource(builder, exp);
        SubmitDCC.uwLab(builder);
        builder.add("external_ids", Json.createArrayBuilder().add(String.format("CGC:%s", exp.getStrain())));
        return builder.build();
    }

    @Override
    public JsonStructure toJson(Species species, ChipExperiment exp, ChipRun run, List<ChipTag> tagList, Map<String, Map<Integer, Map<Integer, List<ChipSequencingFile>>>> fileMap) throws Exception {
        return toJson(exp);
    }

    static public void main(String[] args) throws Exception {
        String expID = args[0];
        for (Object obj : ChipHelper.getEquals("ChipExperiment", "ExpID", expID, "ExpID")) {
            ChipExperiment chipExp = (ChipExperiment) obj;
            chipExp.setDonorEmail(new Date());
            ChipHelper.update(chipExp);
        }
        HibernateUtil.shutdown();
    }

}
