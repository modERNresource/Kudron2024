/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.dcc;

import java.io.File;
import java.util.List;
import java.util.Map;
import javax.json.Json;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObjectBuilder;
import javax.json.JsonStructure;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipRun;
import org.rhwlab.chipseqweb.ChipSequencingFile;
import org.rhwlab.chipseqweb.ChipTag;
import org.rhwlab.chipseqweb.Platform;
import org.rhwlab.chipseqweb.Species;

/**
 *
 * @author gevirl
 */
public class SequenceFile extends SchemaBase {

    public SequenceFile() {
        super("file");
    }

    @Override
    public JsonStructure toJson(Species species, ChipExperiment exp,ChipRun run, List<ChipTag> tagList, Map<String, Map<Integer, Map<Integer, List<ChipSequencingFile>>>> fileMap) throws Exception {
        Platform plat = new Platform();
        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();

        // do the control fastqs
        Map<Integer, Map<Integer, List<ChipSequencingFile>>> cntlRepMap = fileMap.get("ctl_fastqs");
        for (Integer rep : cntlRepMap.keySet()) {
            Map<Integer, List<ChipSequencingFile>> readMap = cntlRepMap.get(rep);
            String runType = runType(readMap);
            for (Integer read : readMap.keySet()) {
                List<ChipSequencingFile> seqFileList = readMap.get(read);
                for (ChipSequencingFile seqFile : seqFileList) {
                    JsonObjectBuilder builder = Json.createObjectBuilder();
                    commonJson(seqFile, plat, runType, builder);
                    builder.add("replicate", Aliases.ctlReplicateAlias(exp, rep));
                    builder.add("dataset", Aliases.ctlExperimentAlias(exp));
                    if (read == 2) {
                        List<ChipSequencingFile> potentialMates = readMap.get(1);
                        ChipSequencingFile mate = findMate(seqFile, potentialMates);
                        builder.add("paired_with", Aliases.fileAlias(mate));
                    }
                    arrayBuilder.add(builder);
                }
            }
        }

        // do the IP fastqs
        Map<Integer, Map<Integer, List<ChipSequencingFile>>> repMap = fileMap.get("fastqs");
        for (Integer rep : repMap.keySet()) {
            Map<Integer, List<ChipSequencingFile>> readMap = repMap.get(rep);
            String runType = runType(readMap);
            for (Integer read : readMap.keySet()) {
                List<ChipSequencingFile> seqFileList = readMap.get(read);
                for (ChipSequencingFile seqFile : seqFileList) {
                    JsonObjectBuilder builder = Json.createObjectBuilder();
                    commonJson(seqFile, plat, runType, builder);
                    builder.add("replicate", Aliases.ipReplicateAlias(exp, rep));
                    builder.add("dataset", Aliases.ipExperimentAlias(exp));                    
                    if (read == 2) {
                        List<ChipSequencingFile> potentialMates = readMap.get(1);
                        ChipSequencingFile mate = findMate(seqFile, potentialMates);
                        builder.add("paired_with", Aliases.fileAlias(mate));
                    }
                    Map<Integer, List<ChipSequencingFile>> cntlReadMap = cntlRepMap.get(rep);
                    if (cntlReadMap == null){
                        cntlReadMap = cntlRepMap.get(1); // no matching control, use first control rep
                    }
                    JsonArrayBuilder cntlArray = Json.createArrayBuilder();
                    for (Integer cntlRead : cntlReadMap.keySet()){
                        List<ChipSequencingFile> cntls = cntlReadMap.get(cntlRead);
                        for (ChipSequencingFile cntl : cntls){
                            cntlArray.add(Aliases.fileAlias(cntl));
                        }
                    }
                    builder.add("controlled_by",cntlArray);
                    arrayBuilder.add(builder);
                }
            }
        }
        return arrayBuilder.build();
    }

    private String runType(Map<Integer, List<ChipSequencingFile>> readMap) {
        if (readMap.size() == 1) {
            return "single-ended";
        }
        return "paired-ended";
    }

    public void commonJson(ChipSequencingFile file, Platform plat, String runType, JsonObjectBuilder builder) throws Exception {
        SubmitDCC.award(builder);
        SubmitDCC.yaleLab(builder);
        builder.add("file_format", "fastq");
        builder.add("output_type", "reads");
        builder.add("submitted_file_name", file.getLocalFilePath());
        builder.add("md5sum", file.getMd5());
        builder.add("aliases", Json.createArrayBuilder().add(Aliases.fileAlias(file)));
        builder.add("paired_end", file.getReadPair().toString());
        builder.add("run_type", runType);
        /*        
        if (mate == null){
            builder.add("run_type", "single-ended");
        }else {
            builder.add("run_type", "paired-ended");
            builder.add("paired_with", Aliases.fileAlias(mate));
        }
        if (file.getReadPair() == 2) {
            ChipSequencingFile mate = findMate(file, files);
            builder.add("paired_with", Aliases.fileAlias(mate));
        }
         */
        FastqFile fq = new FastqFile(new File(file.getLocalFilePath()));
        JsonObjectBuilder flowBuild = Json.createObjectBuilder();
        flowBuild.add("machine", fq.getMachine());
        flowBuild.add("flowcell", fq.getFlowcell());
        flowBuild.add("lane", Integer.toString(fq.getLane()));
        flowBuild.add("barcode", fq.getBarcode());
        builder.add("flowcell_details", Json.createArrayBuilder().add(flowBuild));
        builder.add("read_length", fq.getReadlen());

        builder.add("platform", plat.getPlatform(fq.getMachine()));
    }

    public ChipSequencingFile findMate(ChipSequencingFile r2file, List<ChipSequencingFile> r1files) {
        if (r1files.size() == 1) {
            return r1files.get(0);
        }
        for (ChipSequencingFile mate : r1files) {
            String r2 = r2file.getSourceFileName().replace("R2", "");
            String r1 = mate.getSourceFileName().replace("R1", "");
            if (r1.equals(r2)) {
                return mate;
            }
        }
        return null;
    }
}
