/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.dcc;


import java.util.List;
import java.util.Map;
import javax.json.Json;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonString;
import javax.json.JsonStructure;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipRun;
import org.rhwlab.chipseqweb.ChipSequencingFile;
import org.rhwlab.chipseqweb.ChipTag;
import org.rhwlab.chipseqweb.Species;

/**
 *
 * @author gevirl
 */
public class Biosample extends SchemaBase {

    JsonObject bioObj;

    public Biosample() {
        super("biosample");
    }

    public Biosample(JsonObject obj) {
        this();
        this.bioObj = obj;
    }

    public String getAge(){
        String age = "";
        JsonString str = bioObj.getJsonString("model_organism_age");
        if (str != null){
            age = str.getString();
        }
        return age;
    }
    
    public String getAgeUnits(){
        String units = "";
        JsonString str = bioObj.getJsonString("model_organism_age_units");
        if (str != null){
            units = str.getString();
        }
        return units;
    }
    public String getStage() {
        String stage = bioObj.getString("life_stage").replaceAll(" ", "");
        stage = stage.replaceAll("\\(", "_");
        stage = stage.replaceAll("\\)", "");
        return stage;
    }
    
    public Donor getDonor(){       
        return new Donor(bioObj.getJsonObject("donor")) ;
    }

    @Override
    public JsonStructure toJson(Species species, ChipExperiment exp, ChipRun run, List<ChipTag> tagList, Map<String, Map<Integer, Map<Integer, List<ChipSequencingFile>>>> fileMap) throws Exception {

        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        // make a Biosample json for each control

        for (Integer rep : fileMap.get("ctl_fastqs").keySet()) {
            JsonObjectBuilder builder = Json.createObjectBuilder();
            builder.add("aliases", Json.createArrayBuilder().add(Aliases.ctlBiosampleAlias(exp, rep)));
            bothSpeciesBiosample(builder, species, exp);
            arrayBuilder.add(builder);
        }

        // make a Biosample json for each IP
        for (Integer rep : fileMap.get("fastqs").keySet()) {
            JsonObjectBuilder builder = Json.createObjectBuilder();
            builder.add("aliases", Json.createArrayBuilder().add(Aliases.ipBiosampleAlias(exp, rep)));
            bothSpeciesBiosample(builder, species, exp);
            arrayBuilder.add(builder);
        }
        return arrayBuilder.build();
    }

    public void bothSpeciesBiosample(JsonObjectBuilder builder, Species species, ChipExperiment exp) {
        SubmitDCC.award(builder);
        builder.add("donor", Aliases.donorAlias(exp));

        if (exp.getAge() != null) {
            builder.add("model_organism_age", exp.getAge());
        } else {
            builder.add("model_organism_age", "unknown");
        }
        if (exp.getAgeUnits() != null) {
            builder.add("model_organism_age_units", exp.getAgeUnits());
        } else {
            builder.add("model_organism_age_units", "stage");
        }

        if (species.isFly()) {
            flyBiosample(builder, species, exp);
        } else {
            wormBiosample(builder, species, exp);
        }
    }

    public void flyBiosample(JsonObjectBuilder builder, Species species, ChipExperiment exp) {
        SubmitDCC.chiLab(builder);
        builder.add("biosample_ontology", "/biosample-types/whole_organisms_UBERON_0000468");
        builder.add("organism", "/organisms/dmelanogaster");
        builder.add("source", "/sources/kevin-white");
        builder.add("fly_life_stage", species.getStageDCC(exp.getStage()));
    }

    public void wormBiosample(JsonObjectBuilder builder, Species species, ChipExperiment exp) {
        SubmitDCC.yaleLab(builder);
        builder.add("biosample_ontology", "/biosample-types/whole_organisms_UBERON_0000468");
        builder.add("organism", "/organisms/celegans");
        builder.add("source", "/sources/valerie-reinke");
        builder.add("worm_life_stage", species.getStageDCC(exp.getStage()));
        if (exp.getWormSyncStage() != null) {
            builder.add("worm_synchronization_stage", exp.getWormSyncStage());
        }
    }

}
