/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.dcc;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonNumber;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonString;
import javax.json.JsonStructure;
import static org.rhwlab.chipseq.dcc.SubmitDCC.chiLab;
import static org.rhwlab.chipseq.dcc.SubmitDCC.uwLab;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipRun;
import org.rhwlab.chipseqweb.ChipSequencingFile;
import org.rhwlab.chipseqweb.ChipTag;
import org.rhwlab.chipseqweb.Species;
import org.rhwlab.encode.EncodeUrl;

/**
 *
 * @author gevirl
 */
public class GeneticModification extends SchemaBase {

    JsonObject jsonObj;

    public GeneticModification() {
        super("genetic_modification");
    }

    public GeneticModification(String accession) throws Exception {
        this();
        if (accession != null) {
            String expURL = String.format("https://www.encodeproject.org%s/?format=json", accession);
            EncodeUrl url = new EncodeUrl(expURL);
            url.getJson();
            jsonObj = url.getJsonObject();
        }
    }

    public String getDesc(){
        JsonString desc = jsonObj.getJsonString("description");
        if (desc != null){
            return desc.getString();
        }
        return "";
    }
    
    public JsonObject getModSite(String assembly) {
        JsonObject site = jsonObj.getJsonObject("modified_site_by_target_id");
        if (site != null) {
            JsonArray genes = site.getJsonArray("genes");
            if (genes != null && !genes.isEmpty()) {
                for (int i = 0; i < genes.size(); ++i) {
                    JsonObject gene = (JsonObject) genes.get(i);
                    JsonArray locs = gene.getJsonArray("locations");
                    if (locs != null && !locs.isEmpty()) {
                        JsonObject loc = (JsonObject) locs.getJsonObject(i);
                        JsonString s = loc.getJsonString("assembly");
                        if (s != null) {
                            if (s.getString().equals(assembly)) {
                                return loc;
                            }
                        }
                    }
                }
            }
        }
        return null;
    }

    public String getAssembly(JsonObject site) {
        String ret = "";
        if (site != null) {
            JsonString assemblyStr = site.getJsonString("assembly");
            if (assemblyStr != null) {
                ret = assemblyStr.getString();
            }
        }
        return ret;
    }

    public String getChromo(JsonObject site) {
        String ret = "";
        if (site != null) {
            JsonString str = site.getJsonString("chromosome");
            if (str != null) {
                ret = str.getString();
            }
        }
        return ret;
    }

    public Integer getStart(JsonObject site) {
        Integer ret = null;
        if (site != null) {
            JsonNumber n = site.getJsonNumber("start");
            if (n != null) {
                ret = n.intValue();
            }
        }
        return ret;
    }

    public Integer getEnd(JsonObject site) {
        Integer ret = null;
        if (site != null) {
            JsonNumber n = site.getJsonNumber("end");
            if (n != null) {
                ret = n.intValue();
            }
        }
        return ret;
    }

    public List<ChipTag> getTags() {
        List<ChipTag> tags = new ArrayList<>();

        JsonArray tagArray = this.jsonObj.getJsonArray("introduced_tags");
        if (!tagArray.isEmpty()) {
            for (int i = 0; i < tagArray.size(); ++i) {
                JsonObject obj = tagArray.getJsonObject(i);
                String name = "";
                JsonString nameObj = obj.getJsonString("name");
                if (nameObj != null) {
                    name = nameObj.getString();
                }
                String loc = "";
                JsonString locObj = obj.getJsonString("location");
                if (locObj != null) {
                    loc = locObj.getString();
                }
                ChipTag tag = new ChipTag();
                tag.setLocation(loc);;
                tag.setName(name);
                tags.add(tag);
            }
        }
        return tags;
    }

    public String getMethod() {
        JsonArray ja = jsonObj.getJsonArray("nucleic_acid_delivery_method");
        if (ja == null || ja.isEmpty()) {
            return jsonObj.getString("method");
        } else {
            JsonString value = (JsonString) ja.get(0);
            return value.getString();
        }

    }

    public String getTreatment() {
        String ret = null;
        JsonArray ja = jsonObj.getJsonArray("treatments");
        if (ja != null && !ja.isEmpty()) {
            JsonObject treatObj = ja.getJsonObject(0);
            JsonArray aliases = treatObj.getJsonArray("aliases");
            if (aliases != null && !aliases.isEmpty()) {
                ret = aliases.getJsonString(0).getString();
            }
        }
        return ret;
    }

    @Override
    public JsonStructure toJson(Species species, ChipExperiment exp, ChipRun run, List<ChipTag> tagList, Map<String, Map<Integer, Map<Integer, List<ChipSequencingFile>>>> fileMap) throws Exception {
        JsonObjectBuilder builder = Json.createObjectBuilder();

        builder.add("award", "U41HG007355");
        builder.add("purpose", "tagging");
        builder.add("category", "insertion");

        builder.add("aliases", Json.createArrayBuilder().add(Aliases.geneticModAlias(exp)));
        introducedTags(tagList, builder);
        JsonArrayBuilder docsArray = Json.createArrayBuilder();
        JsonArrayBuilder treatsArray = null;

        if (exp.getGeneticModDesc() != null) {
            builder.add("description", exp.getGeneticModDesc());
        }

        if (exp.getTreatment() != null && !exp.getTreatment().equals("")) {
            treatsArray = Json.createArrayBuilder();
            treatsArray.add(exp.getTreatment());
        }
        if (exp.getSpecies().equals("CElegans")) {
            builder.add("modified_site_by_target_id", species.getWormTarget(exp.getGene()));
            uwLab(builder);
            if (hasTag("eGFP", tagList)) {
                docsArray.add("253304b2-6d17-40c3-8c8b-4d706cee7388");
            }
            if (exp.getMethod().equals("bombardment")) {
                builder.add("modified_site_nonspecific", "random");
                builder.add("nucleic_acid_delivery_method", Json.createArrayBuilder().add(exp.getMethod()));
                docsArray.add("6b39b4a5-7efc-43df-aac8-40a0ad450e2b");
            } else {
                if (completeModifiedSite(exp)) {
                    addModifiedSite(exp, builder);
                }
                builder.add("method", exp.getMethod());

            }

        } else {
            // fly specific properties
            chiLab(builder);
            builder.add("method", exp.getMethod());
            builder.add("modified_site_by_target_id", species.getFlyTarget(exp.getGene()));
            if (completeModifiedSite(exp)) {
                addModifiedSite(exp, builder);
            }
            docsArray.add("c0a10893-9488-44e7-8c90-350722df29fd").add("08894bdc-e1f8-473c-a394-9c39ac020014");
        }
        builder.add("documents", docsArray);
        if (treatsArray != null) {
            builder.add("treatments", treatsArray);
        }
        return builder.build();
    }

    static public void addModifiedSite(ChipExperiment exp, JsonObjectBuilder builder) {
        JsonObjectBuilder jsonObj = Json.createObjectBuilder();
        jsonObj.add("assembly", exp.getAssembly());
        jsonObj.add("chromosome", exp.getChromosome());
        jsonObj.add("start", exp.getStart());
        jsonObj.add("end", exp.getEnd());
        builder.add("modified_site_by_coordinates", jsonObj);
    }

    static public JsonObjectBuilder introducedTags(List<ChipTag> tags, JsonObjectBuilder builder) {
        JsonArrayBuilder tagArray = Json.createArrayBuilder();
        for (ChipTag tag : tags) {
            JsonObjectBuilder tagObj = Json.createObjectBuilder();
            tagObj.add("name", tag.getName());
            tagObj.add("location", tag.getLocation());
            tagArray.add(tagObj);
        }
        builder.add("introduced_tags", tagArray);
        return builder;
    }

    static public boolean completeModifiedSite(ChipExperiment exp) {
        boolean ret = true;
        if (exp.getAssembly() == null) {
            ret = false;
        } else if (exp.getChromosome() == null) {
            ret = false;
        } else if (exp.getStart() == null) {
            ret = false;
        } else if (exp.getEnd() == null) {
            ret = false;
        } else if (exp.getAssembly().equals("")) {
            ret = false;
        } else if (exp.getChromosome().equals("")) {
            ret = false;
        }
        return ret;
    }

    static public boolean hasTag(String tagName, List<ChipTag> tagList) {
        for (ChipTag tag : tagList) {
            if (tag.getName().equals(tagName)) {
                return true;
            }
        }
        return false;
    }

}
