/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.dcc;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import org.rhwlab.chipseq.qa.Directories;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipTag;

/**
 *
 * @author gevirl
 */
public class Checks {

    List<String> warnings;
    List<String> errors;
    
    public Checks(){
        warnings = new ArrayList<>();
        errors = new ArrayList<>();
    }        

    public void checkExperiment(ChipExperiment exp, List<ChipTag> tags) {
        if (tags.isEmpty()){
            errors.add("No Introduced Tags");
        }

        if (exp.getSpecies().equals("CElegans")){
            checkWorm(exp);
        }else {
            checkFly(exp);
        }
        
        if (check(exp.getAge())) {
            errors.add("No Age");
        }
        if (check(exp.getAgeUnits())) {
            warnings.add("No Age Units");
        }   
        if (check(exp.getGenotype())){
            errors.add("No Genotype");
        }
        if (check(exp.getExpIpdesc())){
            warnings.add("No Experiment IP Description");
        }
        if (check(exp.getExpCtlDesc())){
            warnings.add("No Experiment INPUT Description");
        }
        if (check(exp.getGeneticModDesc())){
            warnings.add("No Genetic Modification Description");
        }
        if (check(exp.getTreatment())){
            warnings.add("No Treatment");
        }
        if (check(exp.getAntibody())){
            errors.add("No Antibody");
        }
    }

    public void checkWorm(ChipExperiment exp) {
        if (exp.getMethod().equals("CRISPR")){
            checkCRISPR(exp);
        }else {
            checkBombardment(exp);
        }
        if (check(exp.getWormSyncStage())){
            warnings.add("No Sync Stage");
        }
        File imageDir = new File(Directories.epicDir,"images");
        File imageFile = new File(imageDir,exp.getExpId()+".jpeg");
        if (!imageFile.exists()){
            warnings.add("No image uploaded");
        }
    }
    public void checkCRISPR(ChipExperiment exp) {
        if (check(exp.getGuideSequence())){
            errors.add("No Guide Sequence");
        }
        checkModifiedSite(exp);
    }

    public void checkBombardment(ChipExperiment exp) {
        if (check(exp.getReagent())){
            errors.add("No Fosmid id under Reagent");
        }
    }

    public void checkFly(ChipExperiment exp){
        if (check(exp.getBasesBeforeTag())){
            errors.add("No Bases Before Tag");
        }
        if (check(exp.getExternalId())){
            errors.add("No BDSC id number");
        }
        checkModifiedSite(exp);
    }
    
    public void checkModifiedSite(ChipExperiment exp) {
        if (check(exp.getAssembly())){
            errors.add("No Assembly in Modified Site");
        }
        if (check(exp.getChromosome())){
            errors.add("No Chromosome in Modified Site");
        }
        if (check(exp.getStart())){
            errors.add("No Start in Modified Site");
        }
        if (check(exp.getEnd())){
            errors.add("No End in Modified Site");
        }
    }
    static boolean check(String s) {
        return s == null || s.equals("");
    }
    
    static boolean check(Integer i){
        return i == null;
    }
    public List<String> getWarnings(){
        return warnings;
    }
    public List<String> getErrors(){
        return errors;
    }
}
