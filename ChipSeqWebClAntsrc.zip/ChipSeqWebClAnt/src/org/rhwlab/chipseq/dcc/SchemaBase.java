/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseq.dcc;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import org.rhwlab.chipseqweb.ChipExperiment;

/**
 *
 * @author gevirl
 */
public abstract class SchemaBase implements Schema {

    String label;

    public SchemaBase(String label) {
        this.label = label;
    }

    // submit the object
    @Override
    public void submit(ChipExperiment chipExp, File aliasFile) throws Exception {
        File submitScript = new File(aliasFile.getParent(), "submit.sh");
        File errorFile = new File(aliasFile.getParent(), "submit.err");
        File outFile = new File(aliasFile.getParent(), "submit.out");
        ProcessBuilder pb = new ProcessBuilder(submitScript.getPath());
        pb.redirectError(errorFile);
        pb.redirectError(outFile);
        Process p = pb.start();
        p.waitFor();
    }

    @Override
    public boolean canSubmit(ChipExperiment chipExp, File aliasFile) {
        return true;
    }

    @Override
    public boolean isCompleted(File aliasFile) throws Exception {
        boolean ret = false;
        String alias = aliasFile.getParentFile().getName();
        File logDir = new File(aliasFile.getParent(), "EU_Logs");
        if (logDir.exists()) {
            File postedFile = new File(logDir, "log_eu_prod_posted.txt");
            if (postedFile.exists()){
                BufferedReader reader = new BufferedReader(new FileReader(postedFile));
                String line = reader.readLine();
                while (line != null){
                    String[] tokens = line.split("\t");
                    if (tokens.length > 2){
                        if (tokens[1].equals(alias)){
                            ret = true;
                            break;
                        }
                    }
                    line = reader.readLine();
                }
                reader.close();
            }
        }
        return ret;
    }

    public String getLabel() {
        return label;
    }

    // default submission script for all but the donor object
    @Override
    public void printSubmitScript(PrintStream stream, File jsonFile) throws Exception {
        SubmitDCC.register(stream, label, jsonFile);
    }
    
    static public void main(String[] args) throws Exception{
        Experiment e = new Experiment();
        File aliasFile = new File("/net/waterston/vol9/ChipSeqPipeline/flt-1_OP797_earlyembryonic_1/valerie-reinke:flt-1_OP797_earlyembryonic_1_INPUT/experiment.json");
        boolean result = e.isCompleted(aliasFile);
        int usdhfis=0;
        
    }

}
