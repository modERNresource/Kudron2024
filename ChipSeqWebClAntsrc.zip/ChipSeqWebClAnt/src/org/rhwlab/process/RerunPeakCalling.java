/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.io.BufferedReader;
import java.util.Date;
import java.util.TreeMap;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonReader;
import javax.json.stream.JsonGenerator;
import org.rhwlab.chipseq.qa.Directories;
import org.rhwlab.chipseqweb.ChipHelper;
import org.rhwlab.chipseqweb.ChipRun;
import org.rhwlab.chipseqweb.HibernateUtil;

/**
 *
 * @author gevirl
 */
public class RerunPeakCalling {

    static public void submitRerun(File chipDir, boolean marked) throws Exception {
        File metaFile = new File(chipDir, "metadata.json");

        JsonReader reader = Json.createReader(new FileReader(metaFile));
        JsonObject metadata = reader.readObject();
        reader.close();
        JsonObject inputs = metadata.getJsonObject("inputs");

        String user = inputs.getString("chip.description");
        String chipTitle = inputs.getString("chip.title");
        String expID = chipTitle.substring(0, chipTitle.lastIndexOf("_"));

        // get a new submitID
        String submitID = ChipHelper.nextID("ChipRun", "SubmitID", expID, "getSubmitId");
        String[] tokens = submitID.split("_");
        String dir = tokens[tokens.length - 1];

        JsonObjectBuilder builder = Json.createObjectBuilder();
        builder.add("chip.title", submitID);

        builder.add("chip.description", user);

        builder.add("chip.always_use_pooled_ctl", false);
        builder.add("chip.true_rep_only", false);
        builder.add("chip.enable_count_signal_track", true);
        builder.add("chip.aligner", inputs.getString("chip.aligner"));
        builder.add("chip.use_bwa_mem_for_pe", true);
        builder.add("chip.align_only", false);
        String genomeTSV = inputs.getString("chip.genome_tsv");
        builder.add("chip.genome_tsv", genomeTSV);
        String species = "Dmel";
        if (genomeTSV.contains("WS245")) {
            species = "CElegans";
        }
        //       builder.add("chip.true_rep_only", false);
        //       builder.add("chip.enable_count_signal_track", true);
        String peakCaller = inputs.getString("chip.peak_caller");
        builder.add("chip.peak_caller", peakCaller);
        if (peakCaller.equals("spp")) {
            builder.add("chip.cap_num_peak", inputs.getInt("chip.cap_num_peak_spp"));
            builder.add("chip.pipeline_type", "tf");
        }
        if (peakCaller.equals("macs2")) {
            builder.add("chip.pipeline_type", "histone");
            builder.add("chip.cap_num_peak", inputs.getInt("chip.cap_num_peak_macs2"));
            builder.add("chip.pval_thresh", inputs.getJsonNumber("chip.pval_thresh").doubleValue());
        }

        builder.add("chip.idr_thresh", inputs.getJsonNumber("chip.idr_thresh").doubleValue());

        builder.add("chip.filter_picard_java_heap", "4G");
        builder.add("chip.gc_bias_picard_java_heap", "8G");

        builder.add("chip.align_bwa_mem_factor", 4.0);
        builder.add("chip.filter_mem_factor", 12.0);
        builder.add("chip.call_peak_spp_mem_factor", 250.0);
        builder.add("chip.call_peak_cpu",1);

        builder.add("chip.enable_gc_bias", true);

        addFilesToJson(inputs, builder);
        JsonObject json = builder.build();

        ChipRun run = new ChipRun(submitID, expID, user, new java.sql.Date(new java.util.Date().getTime()));
        ChipHelper.save(run);

        File expDir = new File(Directories.sourceDir, expID);
        File submitDir = new File(expDir, dir);
        Files.createDirectories(submitDir.toPath());
        File jsonFile = new File(submitDir, "pipeline.json");
        JsonGenerator gen = Json.createGenerator(new FileOutputStream(jsonFile));
        gen.write(json);
        gen.flush();
        gen.close();

        // write a script file
        File errFile = new File(submitDir, "pipeline.err");
        File outFile = new File(submitDir, "pipeline.out");
        File scriptFile = new File(submitDir, "SubmitPipeline.sh");
        File qsub = new File(submitDir, "SubmitPipeline.qsub");
        File submitErr = new File(submitDir, "Submit.err");
        File submitOut = new File(submitDir, "Submit.out");

        PrintWriter writer = new PrintWriter(scriptFile);
        writer.println("#! /bin/bash");
        writer.println("echo \"Doing qsub\"");
        writer.println("source /etc/bashrc");
        writer.println("source ~/.bashrc");
        writer.println("env");
        writer.printf("/opt/sge/bin/lx-amd64/qsub  -o %s -e %s -V -N %s -l mfree=4G  -P sage %s\n",
                outFile.getPath(), errFile.getPath(), expID, qsub.getPath());
        //       writer.printf("/opt/sge/bin/lx-amd64/qsub  -o %s -e %s -V -N %s -l h_rt=144:00:00 -l h_vmem=4G %s\n",
        //               outFile.getPath(), errFile.getPath(), expID, qsub.getPath());
//        writer.printf("/opt/sge/bin/lx-amd64/qsub -P sage -o %s -e %s -V -N %s -l h_rt=144:00:00 -l h_vmem=4G %s\n",
        //               outFile.getPath(), errFile.getPath(), expID, qsub.getPath());        
        writer.close();
        scriptFile.setExecutable(true, false);
        scriptFile.setReadable(true, false);

        // write a qsub file
        writer = new PrintWriter(qsub);
        File saveOrigChipDir = new File(submitDir, chipDir.getName());

        // save the original metadata file in the submit directory
        writer.printf("mkdir %s\n", saveOrigChipDir.getPath());
        writer.printf("cp %s %s\n", metaFile.getPath(), saveOrigChipDir.getPath());

        // record that the job has started
        writer.printf("cd %s\n", Directories.sourceDir.getPath());
        writer.printf("echo \"%s\t%s\" >> rerunsStarted\n", chipDir.getPath(), new Date().toString());

        ProcessBuilder pb;
        writer.printf("cd %s\n", expDir.getPath());
        if (System.getProperty("user.name").equals("gevirl")) {
            writer.println("env");
            writer.println("echo \"starting caper\"");
            writer.printf("caper run /net/waterston/vol2/home/gevirl/chip-seq-pipeline2/chip.wdl -i %s --conda\n", jsonFile.getPath());
            pb = new ProcessBuilder("ssh", "gevirl@grid.gs.washington.edu", scriptFile.getPath());
        } else {
            writer.println("conda env list");
            writer.println("conda activate");
            writer.println("conda list");
            writer.printf("caper run /net/waterston/vol2/home/gevirl/chip-seq-pipeline2/chip.wdl -i %s --conda\n", jsonFile.getPath());
            pb = new ProcessBuilder(scriptFile.getPath());
        }
        String markStr = "true";
        if (!marked) {
            markStr = "false";
        }
        writer.printf("java -cp /net/waterston/vol9/ChipSeqPipeline/prog/ChipSeqWebCL.jar org.rhwlab.process.CleanUpRerun %s %s %s %s\n",
                chipDir.getName(), submitID, species, markStr);
        writer.close();

        System.out.printf("submitRun: %s\n", submitID);
        pb.redirectError(submitErr);
        pb.redirectOutput(submitOut);
        Process p = pb.start();
        int sdigf = 0;
    }

    static private void addFilesToJson(JsonObject inputs, JsonObjectBuilder builder) throws Exception {

        addFiles(inputs, "chip.fastqs", builder);
        addFiles(inputs, "chip.ctl_fastqs", builder);

        builder.add("chip.paired_ends", paired("chip.paired_ends", inputs));
        builder.add("chip.ctl_paired_ends", paired("chip.ctl_paired_ends", inputs));
    }

    static private void addFiles(JsonObject inputs, String base, JsonObjectBuilder builder) {

        for (int rep = 1; rep <= 10; ++rep) {
            for (int pair = 1; pair <= 2; ++pair) {
                String key = String.format("%s_rep%d_R%d", base, rep, pair);
                JsonArray files = inputs.getJsonArray(key);
                if (files != null && files.size() > 0) {
                    JsonArrayBuilder array = Json.createArrayBuilder();
                    for (int i = 0; i < files.size(); ++i) {
                        array.add(files.getString(i));
                    }
                    builder.add(key, array);
                }
            }
        }
    }

    static private JsonArrayBuilder paired(String key, JsonObject inputs) {
        JsonArray reps = inputs.getJsonArray(key);
        JsonArrayBuilder array = Json.createArrayBuilder();
        for (int rep = 0; rep < reps.size(); ++rep) {
            boolean b = reps.getBoolean(rep);
            array.add(b);
        }
        return array;
    }

    static public TreeMap<String, Integer> readHead(BufferedReader reader) throws Exception {
        String line = reader.readLine();
        String[] heads = line.split("\t");
        TreeMap<String, Integer> headMap = new TreeMap<>();
        for (int i = 0; i < heads.length; ++i) {
            headMap.put(heads[i], i);
        }
        return headMap;
    }

    static void submitList(BufferedReader reader, TreeMap<String, Integer> headMap) throws Exception {
        String line = reader.readLine();
        while (line != null) {
            if (line.length() > 0) {
                String[] tokens = line.split("\t");
                String expID = tokens[headMap.get("ExpID")];
                File expDir = new File(Directories.sourceDir, expID);
                File chipDir = new File(expDir, "chip");
                String origRunID = tokens[headMap.get("ChipID")];
                File origRunDir = new File(chipDir, origRunID);
                boolean marked = tokens[headMap.get("MarkedForDCC")].charAt(0) != '"';
                System.out.printf("submitList: %s\t%s\n",expID, origRunID);
                RerunPeakCalling.submitRerun(origRunDir, marked);
            }
            line = reader.readLine();
        }
    }

    static public void main(String[] args) throws Exception {
        if (args.length == 2) {
            BufferedReader reader = new BufferedReader(new FileReader(new File(args[0])));
            TreeMap<String, Integer> headMap = readHead(reader);
            reader.close();
            reader = new BufferedReader(new FileReader(new File(args[1])));
            submitList(reader, headMap);
            reader.close();
        } else {

            File inFile = new File("/net/waterston/vol9/ChipSeqPipeline/originalPipelineRuns.tab");
            if (args.length == 1) {
                inFile = new File(args[0]);
            }
            BufferedReader reader = new BufferedReader(new FileReader(inFile));
            TreeMap<String, Integer> headMap = readHead(reader);
            submitList(reader, headMap);
            reader.close();
        }
        HibernateUtil.shutdown();
    }

}
