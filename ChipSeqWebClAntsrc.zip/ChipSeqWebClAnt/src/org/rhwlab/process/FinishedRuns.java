/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import java.io.File;
import java.io.FileReader;
import java.util.List;
import java.util.TreeMap;
import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import org.rhwlab.chipseq.pipeline.PipelineRun;
import org.rhwlab.chipseq.qa.Directories;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipHelper;
import org.rhwlab.chipseqweb.ChipRun;
import org.rhwlab.chipseqweb.HibernateUtil;
import org.rhwlab.chipseqweb.beans.Directory;
import org.rhwlab.chipseqweb.ucsc.BigWigGenerate;
import org.rhwlab.chipseqweb.ucsc.TrackHub;

/**
 *
 * @author gevirl
 */
public class FinishedRuns {

    // the runID must be null for the finishing to take place
    static public void finishExperimentRuns(String species, File expDir) throws Exception {
        File chipDir = new File(expDir, "chip");
        System.out.printf("FinishedRuns: finishExprimentRuns: chipDir = %s\n", chipDir.getPath());
        if (chipDir.exists()) {
            for (File runDir : chipDir.listFiles()) {
                System.out.printf("FinishedRuns: finishExprimentRuns: runDir = %s\n", runDir.getPath());
                File metaFile = new File(runDir, "metadata.json");
                if (metaFile.exists()) {
                    JsonReader reader = Json.createReader(new FileReader(metaFile));
                    JsonObject metadata = reader.readObject();
                    reader.close();

                    String status = metadata.getString("status");
                    if (status.equalsIgnoreCase("Succeeded")) {
                        System.out.println("Metatdata file exists");
                        ChipRun run = updateChipRun(runDir, species);
                        if (run != null) {
                            // clip all the peak files to the chromosome limits
//                        BedClipping.clipRun(species, runDir);      
                            // build all the wigs files 
                            
/*                           
                            // this has been removed because it must be run on epic (either by hand or by cron job)
                            // it can't be run as part of the pipeline run submission as the pipeline is run on a cluster machine, not epic
                            if (!run.getSubmitBy().startsWith("ENC")) {
                                System.out.printf("FinishedRuns: bigwig generate\n");
                                BigWigGenerate.processRun(runDir);
                                // build the track hub and move files to epic
                                String genome = "ce11";
                                if (species.equals("Dmel")) {
                                    genome = "dm6";
                                }
                                TrackHub hub = new TrackHub(genome, runDir);
                                hub.call();
                            }
 */                           
                        }
                    }
                }
            }
        }
    }

    public static ChipRun updateChipRun(File runDir, String species) throws Exception {
        PipelineRun pipelineRun = new PipelineRun(runDir);
        ChipRun chipRun = pipelineRun.getRun();
        
        if (chipRun != null) {
            System.out.printf("chipRun = %s\n", chipRun.getChipId());
            chipRun.setChipId(runDir.getName());
            chipRun.setStatus(pipelineRun.getStatus());
            chipRun.setSpecies(species);
            if (pipelineRun.getReproduce() != null) {
                chipRun.setIdrConserve(pipelineRun.getIdrConserve());
                chipRun.setIdrConsist(pipelineRun.getIdrConsist());
                chipRun.setIdrOptimal(pipelineRun.getIdrOptimal());
                chipRun.setIdrRescue(pipelineRun.getIdrRescue());
                chipRun.setIdrThreshold(pipelineRun.getIdrThreshold());
                chipRun.setOverlapConserve(pipelineRun.getOverlapConserve());
                chipRun.setOverlapConsist(pipelineRun.getOverlapConsist());
                chipRun.setOverlapOptimal(pipelineRun.getOverlapOptimal());
                chipRun.setOverlapRescue(pipelineRun.getOverlapRescue());
            }
            ChipHelper.update(chipRun);
            System.out.printf("FinishedRuns: finishExperimentRuns: clipping %s\n", chipRun.getChipId());

        }
        return chipRun;
    }

    // this was run once to modify all the peak files before DCC submission
    static public void clipRunBeds(String species, File expDir) throws Exception {
        File chipDir = new File(expDir, "chip");
        System.out.printf("FinishedRuns: finishExprimentRuns: chipDir = %s\n", chipDir.getPath());
        if (chipDir.exists()) {
            for (File runDir : chipDir.listFiles()) {
                System.out.printf("FinishedRuns: finishExprimentRuns: runDir = %s\n", runDir.getPath());
                File metaFile = new File(runDir, "metadata.json");
                if (metaFile.exists()) {
                    PipelineRun pipelineRun = new PipelineRun(runDir);
                    ChipRun chipRun = pipelineRun.getRun();
                    if (chipRun != null) {

                        // clip all the peak files to the chromosome limits
                        BedClipping.clipRun(species, runDir);
                    }

                }
            }
        }
    }

    // associated chipID with submitID on finished runs
    // must be run as waterston-jboss because it modifies the peak files
    public static void main(String[] args) throws Exception {
        /*        
        Directory dir = new Directory();
        File expdir = new File(dir.getDirectory(),"erm_erm-GFP_embryonic_1");
        
        finishExperimentRuns("CElegans",expdir);
        
        updateChipRun(new File("/net/waterston/vol9/ChipSeqPipeline/dmd-6_RJP5356_L4larva_1/chip/37c8acbb-2f74-4723-a981-821bbec27688"),"Celegans");
         */
        TreeMap<String, List<ChipExperiment>> map = ChipHelper.allExperiments();
        for (String species : map.keySet()) {
            for (ChipExperiment exp : map.get(species)) {
                File expDir = new File(Directories.sourceDir, exp.getExpId());
                finishExperimentRuns(species, expDir);
                //               clipRunBeds(species, expDir);

            }
        }

        HibernateUtil.shutdown();
    }

}
