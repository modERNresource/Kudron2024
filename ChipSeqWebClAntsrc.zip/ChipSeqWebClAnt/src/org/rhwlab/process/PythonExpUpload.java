/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import java.io.File;
import java.io.PrintStream;
import javax.json.JsonArray;
import javax.json.JsonObject;
import org.rhwlab.chipseqweb.MD5;
import org.rhwlab.encode.EncodeUrl;

/**
 *
 * @author gevirl
 */
public class PythonExpUpload {

    static public void main(String[] args) throws Exception {
        File dir = new File( "/net/waterston/vol9/ChipSeqPipeline");
        String expAcc = "ENCSR728JEY";
        
        PrintStream md5Stream = new PrintStream(new File(dir,String.format("%s.md5", expAcc)));
        PrintStream pyStream = new PrintStream(new File(dir, String.format("%s.py", expAcc)));
        pyStream.println("import encode_utils as eu");
        pyStream.println("from encode_utils.connection import Connection");
        pyStream.println("conn = Connection(\"prod\")");    
        
        String expURL = String.format("https://www.encodeproject.org/experiments/%s/?format=json", expAcc);
        EncodeUrl url = new EncodeUrl(expURL);
        url.getJson();
        JsonObject jsonObj = url.getJsonObject();
        JsonArray filesArray = jsonObj.getJsonArray("files");
        for (int i = 0; i < filesArray.size(); ++i) {
            JsonObject fileObj = (JsonObject) filesArray.get(i);
            String status = fileObj.getString("status");
            String subName = fileObj.getString("submitted_file_name");
            String acc = fileObj.getString("accession");
            if (!status.equals("in progress")) {
                System.out.printf("%s\t%s\n", status, subName);
                File localFile = new File(subName);
                String md5 = MD5.compute(localFile);
                md5Stream.printf("%s\t%s\n",acc , md5);
                
                pyStream.printf("conn.upload_file(file_id=\"%s\", file_path=\"%s\" )\n", acc, subName);
                int dfiugfd = 0;
            }
        }
        md5Stream.close();
        pyStream.close();
    }
}
