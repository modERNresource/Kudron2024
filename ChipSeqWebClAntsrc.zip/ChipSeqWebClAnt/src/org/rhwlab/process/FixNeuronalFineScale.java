/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;

/**
 *
 * @author gevirl
 */
public class FixNeuronalFineScale {
    static public void main(String[] args)throws Exception{
        File file = new File("/net/waterston/vol9/ChipSeqPipeline/neuronal_subsubcluster_annotations.txt");
        PrintStream stream = new PrintStream(new File(file.getPath().replace(".txt", ".modified.txt")));
        
        BufferedReader reader = new BufferedReader(new FileReader(file));
        String line = reader.readLine();
        stream.println(line);
        
        line = reader.readLine();
        while (line != null){
            String[] tokens = line.split("\t");
            String[] firstTokens = tokens[0].split("_");
            for (int i=2 ; i<firstTokens.length ; ++i){
                if (i != 2){
                    stream.print("_");
                }
                stream.print(firstTokens[i]);
            }
            for (int i=1 ; i<tokens.length ; ++i){
                stream.printf("\t%s", tokens[i]);
            }
            stream.println();

            line = reader.readLine();
        }
        reader.close();
        stream.close();
    }
    
}
