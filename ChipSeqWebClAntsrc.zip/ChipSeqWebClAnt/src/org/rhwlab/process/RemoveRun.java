/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import java.io.File;
import java.sql.ResultSet;
import java.util.List;
import org.rhwlab.chipseqweb.ChipHelper;
import org.rhwlab.chipseqweb.ChipRun;
import org.rhwlab.chipseqweb.HibernateUtil;
import org.rhwlab.chipseqweb.beans.Directory;
import org.rhwlab.db.MySql;

/**
 *
 * @author gevirl
 */
public class RemoveRun {

    static public void RemoveRun(String submitID) throws Exception {
        Directory dir = new Directory();
        List l = ChipHelper.getEquals("ChipRun", "SubmitID", submitID, "SubmitID");
        System.out.printf("list size: %d\n", l.size());
        if (!l.isEmpty()) {
            ChipRun chipRun = (ChipRun) l.get(0);

            // remove the submit directory
            File submitDir = dir.submitDirectory(chipRun);
            String cmd = String.format("rm -rf %s", submitDir);
            System.out.println(cmd);
            Process proc = Runtime.getRuntime().exec(cmd);
            proc.waitFor();

            // remove the chip run directory
            File expDir = submitDir.getParentFile();
            File chipDir = new File(expDir, "chip");
            File runDir = new File(chipDir, chipRun.getChipId());
            cmd = String.format("rm -rf %s", runDir.getPath());
            proc = Runtime.getRuntime().exec(cmd);
            System.out.println(cmd);
            proc.waitFor();

            // remove the db entry
            ChipHelper.remove(chipRun);
        }
    }

    static public void main(String[] args) throws Exception {
        String sql = "SELECT * FROM ChipRun where submittedOn = '2022-03-03'";
        ResultSet rs = MySql.getMySql().execute(sql);
        while(rs.next()){
            String submitID = rs.getString("SubmitID");
            System.out.println(submitID);
            RemoveRun(submitID);
        }
  


        HibernateUtil.shutdown();
    }
}
