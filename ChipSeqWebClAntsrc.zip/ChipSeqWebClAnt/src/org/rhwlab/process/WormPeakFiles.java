/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import java.io.File;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import org.rhwlab.chipseq.PeakClusters;
import org.rhwlab.chipseq.PeakFile;
import org.rhwlab.chipseqweb.HibernateUtil;

/**
 *
 * @author gevirl
 */
public class WormPeakFiles {

    List<PeakFile> peakFileList;

    public WormPeakFiles() throws Exception {
        File oldDir = new File("/net/waterston/vol2/home/gevirl/ChipSeqPeaks/worm/ce11");
        peakFileList = PeakClusters.PeakFiles(oldDir, "");  // these files have chr in chromosome

        PipelinePeakFiles files = new PipelinePeakFiles("CElegans");
        for (String experiment : files.dccPeakFiles().keySet()) {
            peakFileList.add(files.dccPeakFiles().get(experiment));
        }
    }

    public void saveByStage(File dir) throws Exception {
        TreeMap<String, List<PeakFile>> map = new TreeMap<>();
        for (PeakFile file : peakFileList) {
            List<PeakFile> list = map.get(file.getStage());
            if (list == null) {
                list = new ArrayList<>();
                map.put(file.getStage(), list);
            }
            list.add(file);
        }
        for (String stage : map.keySet()){
            PrintStream stream = new PrintStream(new File(dir,stage));
            for (PeakFile file : map.get(stage)){
                file.save(stream);
            }
            stream.close();
        }
    }

    static public void main(String[] args) throws Exception {
        File outDir = new File("/net/waterston/vol9/ChipSeqPipeline/PeaksByStage");
        WormPeakFiles files = new WormPeakFiles();
        files.saveByStage(outDir);
        HibernateUtil.shutdown();
    }
}
