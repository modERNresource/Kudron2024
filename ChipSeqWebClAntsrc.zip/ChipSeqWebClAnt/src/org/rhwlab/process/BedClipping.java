/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.GZIPInputStream;
import org.broad.igv.bbfile.BBFileReader;
import org.rhwlab.chipseq.qa.Directories;
import org.rhwlab.chipseqweb.HibernateUtil;

/**
 *
 * @author gevirl
 */
public class BedClipping {

    File chromoSizes;

    public BedClipping(File chromoSizes) {
        this.chromoSizes = chromoSizes;
    }

    // clip bed records and replace input file
    // input can be bigBed or gzipped or text bed
    public long clipFile(File file) throws Exception {

        try {
            BBFileReader bbReader = new BBFileReader(file.getPath());
            if (bbReader.isBigBedFile()) {
                // clip the bigBed
                return clipBigBed(file);
            }
        } catch (Exception exc) {
            return clipNonBB(file);
        }

        return clipNonBB(file);
    }

    private long clipNonBB(File file) throws Exception {
        long ret;
        if (isGzip(file)) {
            // clip the gzip
            ret = clipGzip(file);
        } else {
            // clip the text bed
            ret = clipBed(file);
        }
        return ret;
    }

    static public boolean isGzip(File file) throws Exception {
        FileInputStream stream = new FileInputStream(file);
        boolean ret = true;
        try {
            new GZIPInputStream(stream);
            
        } catch (Exception exc2) {
            ret = false;
        }
        stream.close();
        return ret;
    }

    public long clipGzip(File gzipFile) throws Exception {
        // decompress gzip to temporary bed
        File bed = new File(gzipFile.getPath() + ".bed");
        ProcessBuilder pb = new ProcessBuilder("zcat", gzipFile.getPath());
        pb.redirectOutput(bed);
        Process p = pb.start();
        p.waitFor();

        // clip 
        long ret = clipBed(bed);

        // compress clipped bed into gzip
        if (ret > 0) {
            pb = new ProcessBuilder("gzip", "-c", bed.getPath());
            pb.redirectOutput(gzipFile);
            p = pb.start();
            p.waitFor();
        }

        // remove the temporary bed
        Runtime.getRuntime().exec(String.format("rm -f %s", bed.getPath())).waitFor();
        return ret;
    }

    public long clipBigBed(File bigBed) throws Exception {
        long ret = 0;

        // convert bigBed to temporary bed
        File bed = new File(bigBed.getPath() + ".bed");
        String cmd = String.format("/net/waterston/vol9/bigBedToBed %s %s\n", bigBed.getPath(), bed.getPath());
        Runtime.getRuntime().exec(cmd).waitFor();

        // clip the bed
        ret = clipBed(bed);

        // convert bed back to bigBed
        if (ret > 0) {
            cmd = String.format("/net/waterston/vol9/bedToBigBed %s %s %s\n", bed.getPath(), chromoSizes.getPath(), bigBed.getPath());
            Runtime.getRuntime().exec(cmd).waitFor();
        }

        // remove the temporary bed file
//        Runtime.getRuntime().exec(String.format("rm -f %s", bed.getPath())).waitFor();
        return ret;
    }

    // clip a single bed File and replace the input file with the clipped file
    public long clipBed(File inputBed) throws Exception {
        File tmpBed = new File(inputBed.getPath() + ".tmp");
        long ret = clipBed(inputBed, tmpBed);
        if (ret > 0) {
            Runtime.getRuntime().exec(String.format("rm -f %s", inputBed.getPath())).waitFor();
            Runtime.getRuntime().exec(String.format("mv %s %s", tmpBed.getPath(), inputBed.getPath())).waitFor();
        }
        return ret;
    }

    // clip a single bed file to an output file - return the length of the output bed file
    public long clipBed(File inBed, File outBed) throws Exception {
        System.out.printf("bedClip %s %s\n", inBed.getPath(), outBed.getPath());
//        ProcessBuilder pb = new ProcessBuilder("/net/waterston/vol2/home/gevirl/miniconda3/envs/encode-chip-seq-pipeline-spp/bin/bedClip", inBed.getPath(), chromoSizes.getPath(), outBed.getPath());        
        ProcessBuilder pb = new ProcessBuilder("/net/waterston/vol2/home/gevirl/miniconda3/envs/encode-chip-seq-pipeline-spp/bin/bedClip", "-truncate", inBed.getPath(), chromoSizes.getPath(), outBed.getPath());
        Process p = pb.start();
        p.waitFor();
        return outBed.length();
    }

    // find all the peak files in a directory recursively
    public static List<File> findPeakFiles(File dir) {
 //       System.out.printf("findPeakFiles: dir = %s\n", dir.getPath());
        List<File> ret = new ArrayList<>();
        for (File file : dir.listFiles()) {
            if (file.isDirectory()) {
                if (!(file.getName().contains("inputs") || file.getName().contains("glob") || file.getName().startsWith("tmp."))) {
                    ret.addAll(findPeakFiles(file));
                }
            } else if (file.getName().endsWith(".regionPeak.gz")) {
                ret.add(file);
            } else if (file.getName().endsWith(".unthresholded-peaks.txt.gz")) {
                ret.add(file);
            }
        }
        return ret;
    }

    static public void clipRun(String species, File dir) throws Exception {
        BedClipping bedClipping = ForSpecies(species);
        for (File peakFile : findPeakFiles(dir)) {
 //           if (peakFile.getName().equals("rep1-pr1_vs_rep1-pr2.idr0.01.unthresholded-peaks.txt.gz")) {

                long r = bedClipping.clipGzip(peakFile);  // peak file has been clipped into itself
                if (r > 0) {
                    replaceGlobFile(peakFile); // replace the glob file that matches this peakfile if there is one
                }
                // is there a bigBed for this peak file
                File bbFile = new File(peakFile.getPath().replace(".gz", ".bb"));
                if (bbFile.exists()) {
                    // remake the bigBed file to match the trimmed peak file
                    // decompress gzip to temporary bed
                    File bed = new File(peakFile.getPath() + ".bed");
                    ProcessBuilder pb = new ProcessBuilder("zcat", peakFile.getPath());
                    pb.redirectOutput(bed);
                    Process p = pb.start();
                    p.waitFor();

                    // sort the bed
                    File sortedBed = new File(bed.getPath() + ".sort");
                    pb = new ProcessBuilder("sort", "-k1,1", "-k2,2n", bed.getPath());
                    pb.redirectOutput(sortedBed);
                    p = pb.start();
                    p.waitFor();

                    String cmd = String.format("/net/waterston/vol9/bedToBigBed -type=bed6+4 %s %s %s", sortedBed.getPath(), bedClipping.chromoSizes.getPath(), bbFile.getPath());
                    System.out.println(cmd);
                    Runtime.getRuntime().exec(cmd).waitFor();

                    // remove the temporary bed file
                    //               Runtime.getRuntime().exec(String.format("rm -f %s", bed.getPath())).waitFor();
                    //               Runtime.getRuntime().exec(String.format("rm -f %s", sortedBed.getPath())).waitFor();    
                    replaceGlobFile(bbFile);  // replace the bigBed glob file if it exists
                }
            }
//        }
    }

    // replace the glob file that matches the given bed or bigBed file
    static public void replaceGlobFile(File peakFile) throws Exception {
        File globFile = findGlobFile(peakFile);
        if (globFile != null) {
            String cmd = String.format("cp %s %s", peakFile.getPath(), globFile.getPath());
            System.out.println(cmd);
            Runtime.getRuntime().exec(cmd).waitFor();
        }
    }

    static public File findGlobFile(File peakFile) {
        for (File globDir : peakFile.getParentFile().listFiles()) {
            if (globDir.isDirectory()) {
                if (globDir.getName().contains("glob")) {
                    for (File globFile : globDir.listFiles()) {
                        if (peakFile.getName().equals(globFile.getName())) {
                            return globFile;
                        }
                    }
                }
            }

        }
        return null;
    }

    public static BedClipping ForSpecies(String species) {
        BedClipping bedClipping = null;
        if (species.equals("Dmel") || species.equalsIgnoreCase("fly")) {
            bedClipping = new BedClipping(flySizes);
        } else if (species.equals("CElegans") || species.equalsIgnoreCase("worm")) {
            bedClipping = new BedClipping(wormSizes);
        }
        return bedClipping;
    }

    // this is run as waterston-jboss in order to replace bed and bigBed files
    public static void main(String[] args) throws Exception {
        String species = args[0];
        String expID = args[1];
        File expDir = new File(Directories.sourceDir, expID);
        System.out.printf("BedClipping: Experiment directory: %s\n", expDir.getPath());
        FinishedRuns.finishExperimentRuns(species, expDir);
        HibernateUtil.shutdown();
        /*        
        File chipDir = new File(expDir, "chip");
        if (chipDir.exists()) {
            for (File runDir : chipDir.listFiles()) {
                File metaFile = new File(runDir, "metadata.json");
                if (metaFile.exists()) {

                    clipRun(species, runDir );
                }
            }
        }
         */
        //       File runDir = new File("/net/waterston/vol9/ChipSeqPipeline/arid-1_RW12194_L4larva_1/chip/73969b05-6cca-496e-a200-a8fdb772ec05");
        //       clipRun("worm", runDir);

        /*
        File dir = new File("/net/waterston/vol9/ChipSeqPipeline/Aef1_Aef1-GFP_embryonic_1/chip/cbc1f87b-116c-45f4-a2fc-bd213dc95d4b");

        List l = findPeakFiles(dir);

        int kasdhfiu = 0;

        BedClipping bedClipping = ForSpecies(args[0]);

        if (bedClipping != null) {
            long r = bedClipping.clipFile(new File(args[1]));
        }

        File bb = new File("/net/waterston/vol9/ChipSeqPipeline/rep.pooled_x_2021-132_034_159_S122_L002_R1_001.nodup.300K.bfilt.regionPeak.bb");
        File gzBed = new File("/net/waterston/vol9/ChipSeqPipeline/pooled-pr1_vs_pooled-pr2.idr0.01.unthresholded-peaks.txt.gz");
         */
    }
    static File flySizes = new File("/net/waterston/vol9/dm6/DM6.chrom.sizes");
    static File wormSizes = new File("/net/waterston/vol9/WS245chr/WS245chr.chrom.sizes");
}
