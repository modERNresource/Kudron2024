/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.attribute.FileTime;
import javax.json.JsonObject;
import org.rhwlab.chipseqweb.MD5;
import org.rhwlab.encode.EncodeUrl;

/**
 *
 * @author gevirl
 */
public class PythonFileUpload {

    static public File findRC(File file) {
        File rc = null;
        File parent = file.getParentFile();
        while (parent != null) {
            File test = new File(parent, "rc");
            if (test.exists()) {
                rc = test;
                break;
            }
            parent = parent.getParentFile();
        }
        return rc;
    }

    static public void firstLines(PrintStream stream) {
        stream.println("import encode_utils as eu");
        stream.println("from encode_utils.connection import Connection");
        stream.println("conn = Connection(\"prod\")");
    }

    static public void main(String[] args) throws Exception {
        File needCorrect = new File("/net/waterston/vol9/ChipSeqPipeline/bedErrorCorrectionsNeeded");
        PrintStream correctStream = new PrintStream(needCorrect);

        PrintStream shStream = new PrintStream("/net/waterston/vol9/ChipSeqPipeline/PythonBedUpload.sh");
        shStream.println("export DCC_API_KEY=BXTSKHIS");
        shStream.println("export DCC_SECRET_KEY=vwhzube43dekyyc6");
        shStream.println("export DCC_LAB=/labs/robert-waterston");
        shStream.println("export DCC_AWARD=U41HG007355");  
        
        PrintStream allStream = new PrintStream("/net/waterston/vol9/ChipSeqPipeline/PythonBedUploadAll.py");
        firstLines(allStream);
        
        File pythonDir = new File("/net/waterston/vol9/ChipSeqPipeline/PythonBedUpload");

        File accFile = new File("/net/waterston/vol9/ChipSeqPipeline/bedErrorAccessions.txt");
        File mdFile = new File("/net/waterston/vol9/ChipSeqPipeline/bedErrorAccessions.md5.tsv");
        PrintStream md5Stream = new PrintStream(mdFile);
        BufferedReader reader = new BufferedReader(new FileReader(accFile));
        String acc = reader.readLine();
        while (acc != null) {

            File pythonFile = new File(pythonDir, acc + ".py");
            shStream.printf("python %s\n", pythonFile.getPath());
            PrintStream stream = new PrintStream(pythonFile);
            firstLines(stream);

            String expURL = String.format("https://www.encodeproject.org/files/%s/?format=json", acc);
            EncodeUrl url = new EncodeUrl(expURL);
            url.getJson();
            JsonObject jsonObj = url.getJsonObject();
            String fileName = jsonObj.getString("submitted_file_name");
            stream.printf("conn.upload_file(file_id=\"%s\", file_path=\"%s\" )\n", acc, fileName);
            allStream.printf("conn.upload_file(file_id=\"%s\", file_path=\"%s\" )\n", acc, fileName);
            File localFile = new File(fileName);
            String md5 = MD5.compute(localFile);
            md5Stream.printf("%s\t%s\n",acc,md5 );
            FileTime localTime = Files.getLastModifiedTime(localFile.toPath());
            File rcFile = findRC(localFile);

            FileTime rcTime = Files.getLastModifiedTime(rcFile.toPath());

            if (localTime.compareTo(rcTime) < 0) {
                correctStream.printf("Time: %s\n\t%s\n\t%s\n", localFile.getPath(), localTime.toString(), rcTime.toString());
                int kjsdhfi0 = 0;
            }
            if (!localFile.exists()) {
                System.out.println(fileName);
            }
            acc = reader.readLine();
            stream.close();
        }
        reader.close();
        shStream.close();
        allStream.close();
        md5Stream.close();
                
    }
}
