/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintStream;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TreeMap;
import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import org.rhwlab.chipseq.pipeline.FileTable;
import org.rhwlab.chipseq.pipeline.FileTableRecord;
import org.rhwlab.chipseq.pipeline.PipelineRun;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipHelper;
import org.rhwlab.chipseqweb.ChipRun;
import org.rhwlab.chipseqweb.ChipSequencingFile;
import org.rhwlab.chipseqweb.HibernateUtil;
import org.rhwlab.chipseqweb.beans.Directory;

/**
 *
 * @author gevirl
 */
/* 
transfer files to epic for display on modERNpipeline website
args[0] is the expID or a file of expIDs to transfer
*** must be run on epic
experiment must be marked for submission or was generated from old alignments
if the experiment is accessioned, there will be links to fastq and bams in DCC
if not accessioned, fastq and bams are copied to epic


*** after running , if successful, all chip directories and the sequence files can be removed 
 and experiment status changed to xfered
 */
public class XferFiles {

    public static String XferByAccession(String accession) throws Exception {
        String ret = null;
        List runList = ChipHelper.getEquals("ChipRun", "SubmitBy", accession, "SubmitBy");
        if (!runList.isEmpty()) {
            List expList = ChipHelper.getEquals("ChipExperiment", "Accession", accession, "Accession");
            if (!expList.isEmpty()) {
                ChipRun run = (ChipRun) runList.get(0);
                ChipExperiment exp = (ChipExperiment) expList.get(0);
                boolean success = Xfer(exp, run);
                if (success) {
                    ret = exp.getExpId();
                }
            }
        }
        return ret;
    }

    static public String XferBySubmitID(String expID, String submitID) throws Exception {
        String ret = null;
        ChipRun run = null;
        if (submitID == null) {
            List runList = ChipHelper.getEquals("ChipRun", "ExpID", expID, "SubmitID");
            if (runList.size() == 1) {
                run = (ChipRun) runList.get(0);
            }
        } else {
            List runList = ChipHelper.getEquals("ChipRun", "SubmitID", submitID, "SubmitID");
            if (!runList.isEmpty()) {
                run = (ChipRun) runList.get(0);
            }
        }

        if (run != null) {
            System.out.printf("Run found %s\n", run.getChipId());
            List expList = ChipHelper.getEquals("ChipExperiment", "ExpID", expID, "ExpID");
            if (!expList.isEmpty()) {
                ChipExperiment exp = (ChipExperiment) expList.get(0);
                if (run.getChipId() != null) {
                    boolean success = Xfer(exp, run);
                    if (success) {
                        ret = exp.getExpId();
                    }
                }
            }
        }
        return ret;
    }

    // this writes scripts that transfer to epic experiments and removes sequence files and chip directories
    // the experiments/runs are marked, complete, and are not reprocessed DCC bam experiments (ENCODE bams)
    public static void XferMarkedScript(PrintStream xferStream, PrintStream cleanChipStream, PrintStream cleanSeqStream) throws Exception {
        Directory dir = new Directory();

        TreeMap<String, List<ChipExperiment>> allExpsMap = ChipHelper.allExperiments();
        for (String species : allExpsMap.keySet()) {
            List<ChipExperiment> expList = allExpsMap.get(species);
            for (ChipExperiment exp : expList) {
                if (exp.getExpId().equals("Adf1_Adf1-GFP_embryonic_1")) {
                    int sdasdf = 0;
                }
                String status = exp.getStatus();
                if (status != null && (exp.getStatus().equals("Complete") || exp.getStatus().equals("Active"))) {
                    String desc = exp.getDescription();
                    if (desc == null || !desc.contains("ENCODE bams")) {
                        List runList = ChipHelper.getEquals("ChipRun", "ExpID", exp.getExpId(), "ExpID");
                        for (Object obj : runList) {
                            ChipRun run = (ChipRun) obj;
                            if (run.getMarkedForDcc() != null) {
                                File expEpicDir = new File(dir.getEpicDirectory(species), exp.getExpId());
                                if (!expEpicDir.exists()) {
                                    xferStream.printf(
                                            "java -cp /net/waterston/vol9/ChipSeqPipeline/prog/ChipSeqWebCL.jar org.rhwlab.process.XferFiles submit %s %s\n",
                                            run.getExpId(), run.getSubmitId());
                                    File expDir = new File(dir.getDirectory(), exp.getExpId());
                                    File chipDir = new File(expDir, "chip");
                                    cleanChipStream.printf("rm -rf %s\n", chipDir.getPath());

                                    // clean files that have accessions
                                    List fileList = ChipHelper.getEquals("ChipSequencingFile", "ExpID", exp.getExpId(), "FileID");
                                    for (Object fileObj : fileList) {
                                        ChipSequencingFile seqFile = (ChipSequencingFile) fileObj;
                                        String fileAcc = seqFile.getAccession();
                                        if (fileAcc != null) {
                                            cleanSeqStream.printf("rm %s\n", seqFile.getLocalFilePath());
                                        }
                                    }

                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // makes script to transfer completed ENCODE bam runs that have not yet been transfered
    // script includes clean up commands
    public static ArrayList<String> XferAnyEncodeBamRuns(File outFile, File xferScript, boolean force) throws Exception {
        PrintStream xferStream = new PrintStream(xferScript);
        PrintStream outStream = new PrintStream(new FileOutputStream(outFile));
        ArrayList<String> expsXfer = new ArrayList<>();
        TreeMap<String, List<ChipExperiment>> allExpsMap = ChipHelper.allExperiments();
        for (String species : allExpsMap.keySet()) {
            List<ChipExperiment> expList = allExpsMap.get(species);
            for (ChipExperiment exp : expList) {
                outStream.printf("\nXfer exp: %s\n", exp.getExpId());
                String desc = exp.getDescription();
                if (desc != null && desc.contains("ENCODE bams")) {  // only transfering experiments from encode download 
                    File epicDir = epicDirectory(species, exp.getExpId());
                    if (force || !epicDir.exists()) { // has not been transfered already
                        System.out.printf("Epic dir %s does not exist\n", epicDir.getPath());
                        List runList = ChipHelper.getEquals("ChipRun", "SubmitBy", exp.getAccession(), "SubmitBy");
                        if (!runList.isEmpty()) { // there is a run with the correct accession

                            ChipRun run = (ChipRun) runList.get(0);
                            if (run.getChipId() != null) {  // the run finished correctly
                                Directory dir = new Directory();
                                File expDir = new File(dir.getDirectory(), exp.getExpId());
                                File runDir = new File(new File(expDir, "chip"), run.getChipId());
                                if (PipelineRun.runSucceeded(runDir)) {
                                    xferStream.printf(
                                            "java -cp /net/waterston/vol9/ChipSeqPipeline/prog/ChipSeqWebCL.jar org.rhwlab.process.XferFiles submit %s %s\n",
                                            run.getExpId(), run.getSubmitId());
                                    outStream.printf("Transfered: %s\n", exp.getExpId());
                                    clean(run.getExpId(), xferStream, xferStream);
                                } else {
                                    outStream.printf("pipleine did not succeed for %s\n", exp.getExpId());
                                }
                            } else {
                                outStream.printf("run did not finish - no chip id in db %s\n", exp.getExpId());
                            }
                        } else {
                            outStream.printf("no run with accession matching %s\n", exp.getExpId());
                        }
                    } else {
                        outStream.printf("epic directory exists %s\n", exp.getExpId());
                    }
                } else {
                    outStream.printf("not from bams %s\n", exp.getExpId());
                }
            }
        }
        outStream.close();
        xferStream.close();
        return expsXfer;
    }

    // transfer a run if it  succeeded in metadata file
    // this write a script file to run to do the transfer, then runs the script
    public static boolean Xfer(ChipExperiment exp, ChipRun run) throws Exception {
        String species = exp.getSpecies();
        String expID = exp.getExpId();
        String chipID = run.getChipId();
        String accession = exp.getAccession();
        Directory dir = new Directory();
        File expDir = new File(dir.getDirectory(), expID);
        File chipDir = new File(expDir, "chip");
        File runDir = new File(chipDir, chipID);
        File metaFile = metadataFile(runDir);
        boolean succeed = succeeded(metaFile);

        if (succeed) {
            //           System.out.println("Sleeping 10 sec");
            //           Thread.sleep(10000);
            boolean inDCC = accession != null;
            FileTable fileTable = new FileTable(exp, run);

            // make the epic exp directory
            File epicExpDir = makeEpicDirectory(species, expID);

            // write a script to copy the files to the directory and change the source of the files in the table
            File script = new File(epicExpDir, "cpFiles.sh");
            PrintStream scriptStream = new PrintStream(script);
            // copy the files in the file table
            for (FileTableRecord rec : fileTable.getRecords()) {
                // if not accessioned in the DCC, copy all files including bam and fastq
                // if accessioned in the DCC, copy everything but bam and fastq
                if (!inDCC || ((!"bam".equals(rec.getFormat())) && (!"fastq".equals(rec.getFormat())))) {
                    // moving not accessioned fastq and bams, and all files not bams or fastq
                    File src = new File(rec.getSource().getPath());
                    File dest = new File(epicExpDir, src.getName());
                    scriptStream.printf("cp %s %s\n", src.getPath(), dest.getPath());
                    rec.setSource(dest);
                }
            }
            // copy the metadata file of the run
            File metaDest = new File(epicExpDir, metaFile.getName());
            scriptStream.printf("cp %s %s\n", metaFile.getPath(), metaDest.getPath());

            // copy the gc html file
            File qcHtml = qcHtmlFile(runDir);
            File qcDestHtml = new File(epicExpDir, qcHtml.getName());
            scriptStream.printf("cp %s %s\n", qcHtml.getPath(), qcDestHtml.getPath());

            // copy the qc json 
            File qcJson = qcJsonFile(runDir);
            File qcDestJson = new File(epicExpDir, qcJson.getName());
            scriptStream.printf("cp %s %s\n", qcJson.getPath(), qcDestJson.getPath());

            scriptStream.close();

            // run the script
            script.setExecutable(true, false);
            script.setReadable(true, false);
            ProcessBuilder pb = new ProcessBuilder(script.getPath());
            pb.redirectError(new File(epicExpDir, "cpFiles.err"));
            pb.redirectOutput(new File(epicExpDir, "cpFiles.out"));
            Process p = pb.start();
            p.waitFor();

            // save the file table to the exp dir
            File table = new File(epicExpDir, String.format("%s.table.tsv", expID));
            PrintStream stream = new PrintStream(table);
            fileTable.report(stream);
            stream.close();

            exp.setToEpic(true);
            ChipHelper.update(exp);
        }
        return succeed;
    }

    public static File qcJsonFile(File runDir) {
        return new File(qcExecutionDir(runDir), "qc.json");
    }
    
    public static File qcHtmlFile(File runDir){
        return new File(qcExecutionDir(runDir), "qc.html");
    }

    public static File qcExecutionDir(File runDir) {
        return new File(new File(runDir, "call-qc_report"), "execution");
    }
    
    public static File metadataFile(File runDir){
        return new File(runDir, "metadata.json");
    }

    public static File makeEpicDirectory(String species, String expID) throws Exception {
        File ret = epicDirectory(species, expID);
        Files.createDirectories(ret.toPath());
        ret.setExecutable(true, false);
        ret.setReadable(true, false);
        ret.setWritable(true, false);
        return ret;
    }

    public static File epicDirectory(String species, String expID) throws Exception {
        Directory dir = new Directory();
        File epicDir = new File(dir.getWormEpicDirectory());
        if (species.equals("Dmel")) {
            epicDir = new File(dir.getFlyEpicDirectory());
        }
        return new File(epicDir, expID);
    }

    public static void clean(String expID, PrintStream cleanChipStream, PrintStream cleanSeqStream) throws Exception {
        Directory dir = new Directory();
        File expDir = new File(dir.getDirectory(), expID);
        File chipDir = new File(expDir, "chip");
        cleanChipStream.printf("rm -rf %s\n", chipDir.getPath());

        // clean files that have accessions
        List fileList = ChipHelper.getEquals("ChipSequencingFile", "ExpID", expID, "FileID");
        for (Object fileObj : fileList) {
            ChipSequencingFile seqFile = (ChipSequencingFile) fileObj;
            String fileAcc = seqFile.getAccession();
            if (fileAcc != null) {
                cleanSeqStream.printf("rm %s\n", seqFile.getLocalFilePath());
            }
        }
    }

    public static boolean succeeded(File metaFile) throws Exception {
        JsonReader reader = Json.createReader(new FileReader(metaFile));
        JsonObject metadata = reader.readObject();
        reader.close();
        String status = metadata.getString("status");
        return status.equals("Succeeded");
    }

    /* ********* must be run on epic as waterston-jboss
    copies file to epic and removes chip directories owned by waterston-jboss   
     */
    public static void main(String[] args) throws Exception {

        Directory dir = new Directory();
        File logFile = new File(dir.getDirectory(), "xfer.log");
        File outFile = new File(dir.getDirectory(), "xfer.out");
        File xferScript = new File(dir.getDirectory(), "xfer.script.sh");
        PrintStream logStream = new PrintStream(new FileOutputStream(logFile, true));
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd 'at' HH:mm:ss z");
        Date date = new Date(System.currentTimeMillis());
        logStream.printf("\n%s\n", formatter.format(date));

        // find any run that can be transfered
        ArrayList<String> expsXfer = new ArrayList<>();
        switch (args[0]) {
            case "force":
                expsXfer = XferAnyEncodeBamRuns(outFile, xferScript, true);
                break;
            case "bams":
                expsXfer = XferAnyEncodeBamRuns(outFile, xferScript, false);
                break;
            case "accession":
                String res1 = XferByAccession(args[1]);
                if (res1 != null) {
                    expsXfer.add(res1);
                }
                break;
            case "submit":
                String res2 = null;
                if (args.length == 2) {
                    res2 = XferBySubmitID(args[1], null);
                } else if (args.length == 3) {
                    res2 = XferBySubmitID(args[1], args[2]);
                }
                if (res2 != null) {
                    expsXfer.add(res2);
                }
                break;
            case "marked":
                PrintStream xferStream = new PrintStream(new File(dir.getDirectory(), "xferMarked.sh"));
                PrintStream cleanChipStream = new PrintStream(new File(dir.getDirectory(), "cleanChipScript.sh"));
                PrintStream cleanSeqStream = new PrintStream(new File(dir.getDirectory(), "cleanSeqScript.sh"));
                XferMarkedScript(xferStream, cleanChipStream, cleanSeqStream);
                xferStream.close();
                cleanChipStream.close();
                cleanSeqStream.close();
                break;
            default:
                break;
        }

        logStream.printf("\n%s\t%d\n", formatter.format(date), expsXfer.size());
        for (String e : expsXfer) {
            logStream.println(e);
        }
        logStream.close();
        HibernateUtil.shutdown();
    }
}
