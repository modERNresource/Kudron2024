package org.rhwlab.process;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 *
 * @author gevirl
 */
public class FormContingencyTableForPeakLocations {

    TreeSet<String> positionSet = new TreeSet<>();
    TreeMap<String, TreeMap<String, Integer>> table = new TreeMap<>(); // TF -> position -> count

    public FormContingencyTableForPeakLocations(File peakFile, String locationColumn, int maxMetaPeak) throws Exception {

        TreeMap<String, Integer> headMap = new TreeMap<>();
        BufferedReader reader = new BufferedReader(new FileReader(peakFile));
        String[] heads = reader.readLine().split("\t");
        for (int i = 0; i < heads.length; ++i) {
            headMap.put(heads[i], i);
        }
        String line = reader.readLine();
        while (line != null) {
            String[] tokens = line.split("\t");
            int n = Integer.parseInt(tokens[headMap.get("numPeaks")]);
            if (n <= maxMetaPeak) {
                String tf = tokens[headMap.get("TF")];
                String loc = tokens[headMap.get(locationColumn)];
                String targetDist = tokens[headMap.get("targetDist")];
                int dist = Integer.parseInt(targetDist);
                if (loc.equals("5P")) {
//                System.out.printf("%s\t%d\n", loc,dist);
                }
                String pos = Position(loc, dist);
                positionSet.add(pos);

                TreeMap<String, Integer> tfMap = table.get(tf);
                if (tfMap == null) {
                    tfMap = new TreeMap<>();
                    table.put(tf, tfMap);
                }

                Integer position = tfMap.get(pos);
                if (position == null) {
                    tfMap.put(pos, 1);
                } else {
                    tfMap.put(pos, position + 1);
                }
            }
            line = reader.readLine();
        }
        reader.close();
    }

    public void report(File file) throws Exception {
        PrintStream stream = new PrintStream(file);
        TreeMap<String, Integer> posTotals = new TreeMap<>();
        int gTotal = 0;

        // print the header
        stream.print("TF");
        for (String pos : this.positionSet) {
            stream.printf("\t%s", pos);
            posTotals.put(pos, 0);
        }
        stream.println("\tTotal");

        for (String tf : this.table.keySet()) {
            TreeMap<String, Integer> tfMap = table.get(tf);
            stream.print(tf);
            int tfTotal = 0;
            for (String pos : this.positionSet) {
                Integer count = tfMap.get(pos);
                if (count == null) {
                    count = 0;
                }
                posTotals.put(pos, count + posTotals.get(pos));
                gTotal = gTotal + count;
                tfTotal = tfTotal + count;
                stream.printf("\t%d", count);
            }
            stream.printf("\t%d\n", tfTotal);
        }

        // print the position totals
        stream.print("Total");
        for (String pos : this.positionSet) {
            stream.printf("\t%d", posTotals.get(pos));
        }
        stream.printf("\t%d\n", gTotal);
        stream.close();
    }

    static public String Position(String loc, int dist) {
        if (loc.contains("I")) {
            return "Intron";
        }
        if (loc.contains("E")) {
            return "Exon";
        }
        if (loc.contains("3P")) {
            return "3P";
        }
        if (loc.contains("5P")) {
            if (Math.abs(dist) <= 500) {
                return "5P<=500";
            } else {
                return "5P>500";
            }
        }
        return null;
    }

    public static void main(String[] args) throws Exception {

        File[] peakFiles = {new File("/net/waterston/vol2/home/gevirl/Downloads/FlyTFPeaksPrimaryTargets.tsv"),
            new File("/net/waterston/vol2/home/gevirl/Downloads/FlyTFPeaksPrimaryTargets.tsv")};
        int[] thresh = {84, 277};

        for (int i = 0; i < peakFiles.length; ++i) {
            File peakFile = peakFiles[i];
            FormContingencyTableForPeakLocations geneTable = new FormContingencyTableForPeakLocations(peakFile, "GeneLoc", thresh[i]);
            File reportFile = new File(peakFile.getPath().replace(".tsv", String.format(".%d.gene.report.tsv",thresh[i])));
            geneTable.report(reportFile);

            FormContingencyTableForPeakLocations transcriptTable = new FormContingencyTableForPeakLocations(peakFile, "TranscriptLoc", thresh[i]);
            reportFile = new File(peakFile.getPath().replace(".tsv", String.format(".%d.transcript.report.tsv",thresh[i])));
            transcriptTable.report(reportFile);
        }
        int ihdf = 0;
    }
}
