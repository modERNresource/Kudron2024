/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import org.rhwlab.process.PipelinePeakFiles;
import java.io.File;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import org.rhwlab.chipseq.PeakClusters;
import org.rhwlab.chipseq.PeakFile;
import org.rhwlab.chipseq.PeakTargetQuality;
import org.rhwlab.chipseq.qa.Directories;
import static org.rhwlab.chipseq.PeakTargetQuality.peakFileQuality;
import org.rhwlab.chipseqweb.HibernateUtil;
import org.rhwlab.gene.model.Annotation;
import org.rhwlab.gene.model.GeneIntervals;
import org.rhwlab.gene.model.ModelFromGFF;
import org.rhwlab.singlecell.expression.PrefixMaps;
import org.rhwlab.singlecell.expression.SingleCellExprMat;

/**
 *
 * @author gevirl
 */
public class PeakQuality {

    // compute quality scores for peaks in all peak files
    public static void main(String[] args) throws Exception {
        int clusterSpacing = 200;
        File qualDir = new File(Directories.sourceDir, "Quality");

        // get the gene model
 //       File gffFile = new File("/net/waterston/vol9/References/WS260/c_elegans.PRJNA13758.WS260.annotations.WormBase.gff3");
        File gffFile = new File("/net/waterston/vol9/References/WS280/c_elegans.PRJNA13758.WS280.annotations.wormbase.gff3");
        
        Annotation.remapChromo = true;   // puts chr into chromosome
        ModelFromGFF gff = new ModelFromGFF(gffFile);
        TreeMap<String, GeneIntervals> intervalsMap = new TreeMap<>();
        for (String chromo : gff.getChromosomes()) {
            intervalsMap.put(chromo, new GeneIntervals(chromo, gff));
        }
        // get the expression matrices
        new PrefixMaps();
        TreeMap<String, SingleCellExprMat> expMatMap = PrefixMaps.getWormExpressionMatrices();


        // get all the peak files in the local pipeline
        PipelinePeakFiles peakFiles = new PipelinePeakFiles("CElegans");
        TreeMap<String, PeakFile> allPeakFileMap = peakFiles.allPeakFiles();
        TreeMap<String, PeakFile> dccPeakFileMap = peakFiles.dccPeakFiles();
        HibernateUtil.shutdown();

        // add in all the dcc peak files
        List<PeakFile> oldDCCFileList = PeakClusters.PeakFiles(new File("/net/waterston/vol2/home/gevirl/ChipSeqPeaks/worm/ce11"), "");  // these files have chr in chromosome
        List<PeakFile> clusterable = new ArrayList<>();
        clusterable.addAll(dccPeakFileMap.values());
        clusterable.addAll(oldDCCFileList);
        
        // form clusters
        double thresh = 0.1;
        PeakClusters clusters = new PeakClusters(clusterable, clusterSpacing);
        clusters.locateInGenome(gff,null);
        File clusterFile = new File(qualDir, String.format("PeakClusters.%s", clusterSpacing));
        clusters.report(clusterFile);
        PeakTargetQuality.clusterFileQuality(clusterFile, expMatMap, gff, thresh);

        // quality for all the local peak files       
//        PrintStream summaryStream = new PrintStream(new File(qualDir, "Summary"));
        for (String submitID : allPeakFileMap.keySet()) {
System.out.printf("SubmitID: %s\n",submitID);            
            PeakFile peakFile = allPeakFileMap.get(submitID);
            PeakTargetQuality[] quals = peakFileQuality(peakFile, expMatMap, gff, thresh, intervalsMap);
            File outFile = new File(qualDir, submitID + ".qual");
            PrintStream stream = new PrintStream(outFile);

            for (PeakTargetQuality qual : quals) {
                if (!qual.getTF().equals(qual.getTarget())) {
                    qual.report(stream);

                }
            }
            stream.close();
//           summaryStream.printf("%s\t%d\t%f\t%f\n", submitID, quals.length, quals[0].getQuality(), total / quals.length);

        }
//        summaryStream.close();

        // quality for all the dcc peak files
        for (PeakFile peakFile : oldDCCFileList) {
            File file = peakFile.getInfile();
            if (file.getName().endsWith("regionPeak.gz")) {
                if (file.getName().contains("LYS-2")) {
                    int hfd = 0;
                }
                PeakTargetQuality[] quals = peakFileQuality(peakFile, expMatMap, gff, thresh, intervalsMap);
                File outFile = new File(file.getPath().replace("regionPeak.gz", "regionPeak.qual"));
                PrintStream stream = new PrintStream(outFile);
                for (PeakTargetQuality qual : quals) {
                    if (!qual.getTF().equals(qual.getTarget())) {
                        qual.report(stream);
                    }
                }
                stream.close();
            }
        }
    }    
}
