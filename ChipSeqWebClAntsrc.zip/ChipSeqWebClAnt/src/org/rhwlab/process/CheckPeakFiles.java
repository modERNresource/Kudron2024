/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import org.rhwlab.chipseq.pipeline.PipelineRun;
import org.rhwlab.chipseq.qa.Directories;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipHelper;
import org.rhwlab.chipseqweb.ChipRun;
import org.rhwlab.chipseqweb.HibernateUtil;

/**
 *
 * @author gevirl
 */
public class CheckPeakFiles {

    // check for non gz peak files
    public static void main(String[] args) throws Exception {
        ArrayList<File> allPeakFiles = new ArrayList<>();
        TreeMap<String, List<ChipExperiment>> map = ChipHelper.allExperiments();
        if (args.length == 0) {
            for (String species : map.keySet()) {
                for (ChipExperiment exp : map.get(species)) {
                    if (!exp.getExpId().startsWith("arid")) {
                        File expDir = new File(Directories.sourceDir, exp.getExpId());
                        File chipDir = new File(expDir, "chip");
//              System.out.printf("CheckPeakFiles:  chipDir = %s\n", chipDir.getPath());
                        if (chipDir.exists()) {
                            for (File runDir : chipDir.listFiles()) {
                                System.out.printf("\nCheckPeakFiles:  runDir = %s\n", runDir.getPath());
                                if (runDir.getName().equals("e21a3962-6af6-406d-9e90-5b567b480334")) {
                                    int jdjd = 0;
                                }
                                File metaFile = new File(runDir, "metadata.json");
                                if (metaFile.exists()) {
                                    PipelineRun pipelineRun = new PipelineRun(runDir);
                                    ChipRun chipRun = pipelineRun.getRun();
                                    if (chipRun != null) {

                                        List<File> peakFiles = BedClipping.findPeakFiles(runDir);
                                        allPeakFiles.addAll(peakFiles);
                                    }

                                }
                            }
                        }

                    }
                }
            }
        } else {
            for (String arg : args) {
                List<File> peakFiles = BedClipping.findPeakFiles(new File(arg));
                allPeakFiles.addAll(peakFiles);
            }
        }
        for (File file : allPeakFiles) {
            if (!BedClipping.isGzip(file)) {
                System.out.println(file.getPath());
            }
        }
        HibernateUtil.shutdown();
    }
}
