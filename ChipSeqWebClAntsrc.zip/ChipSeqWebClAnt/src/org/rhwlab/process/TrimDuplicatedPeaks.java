/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import htsjdk.samtools.util.IntervalTreeMap;
import java.io.File;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.TreeSet;
import org.rhwlab.bedformat.NarrowPeakBedRecord;
import org.rhwlab.chipseq.pipeline.ExperimentIntervalTree;
import org.rhwlab.chipseqweb.beans.Directory;

/**
 *
 * @author gevirl
 */
public class TrimDuplicatedPeaks {
    // adjusts the ends of duplicated peaks so that they are not overlapping - does not remove peaks
    // except is a set of chromosomes that does get removed
    static public File trim(File peakFile,TreeSet<String> except,String head) throws Exception {
//        File peakFile = new File(new File(dir.getDirectory(), "macs2"), "AllWormPeaks.bed");
        File noDupFile = new File(peakFile.getPath().replace(".bed", ".noDups.bed"));
        PrintStream stream = new PrintStream(noDupFile);
        PrintStream tsvstream = new PrintStream(noDupFile.getPath().replace(".bed", ".tsv"));
        tsvstream.println(head);
                
        ExperimentIntervalTree tree = new ExperimentIntervalTree(peakFile,except);

        for (String expID : tree.getTree().keySet()) {
            IntervalTreeMap expMap = tree.getTree().get(expID);
            for (Object obj : expMap.values()) {
                ArrayList<NarrowPeakBedRecord> list = (ArrayList<NarrowPeakBedRecord>) obj;
                if (list.size() > 1) {
                    // make sure list is sorted by apex
                    list.sort(new Comparator() {
                        @Override
                        public int compare(Object o1, Object o2) {
                            NarrowPeakBedRecord rec1 = (NarrowPeakBedRecord) o1;
                            NarrowPeakBedRecord rec2 = (NarrowPeakBedRecord) o2;
                            return Integer.compare(rec1.getPeakOffset(), rec2.getPeakOffset());
                        }
                    });

//                    briefDisplay(list);
                    // fix the ends of duplicate interval records
                    for (int i = 0; i < list.size() - 1; ++i) {
                        NarrowPeakBedRecord low = list.get(i);
                        NarrowPeakBedRecord high = list.get(i + 1);
                        int midLoc = (low.getPeakLocation() + high.getPeakLocation()) / 2;
                        low.setEnd(midLoc);

                        int highLoc = high.getPeakLocation();
                        high.setStart(midLoc + 1);
                        high.setPeakOffset(highLoc - midLoc - 1);
                    }
//                    briefDisplay(list);
                }
                for (NarrowPeakBedRecord bed : list){
                    stream.println(bed.toString());
                    tsvstream.println(bed.toString());
                }
            }
        }
        stream.close();
        tsvstream.close();
        return noDupFile;
    }    
}
