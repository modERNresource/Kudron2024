/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import java.io.File;
import java.io.PrintStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonString;
import javax.json.JsonValue;
import javax.json.JsonValue.ValueType;
import org.rhwlab.chipseq.dcc.Aliases;
import org.rhwlab.chipseq.qa.Directories;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipHelper;
import org.rhwlab.chipseqweb.ChipRun;
import org.rhwlab.chipseqweb.HibernateUtil;
import org.rhwlab.encode.EncodeUrl;

/**
 *
 * @author gevirl
 */
public class CheckAnalyses {

    // find any files in the given array of files that are derived from the given file
    static public List<JsonObject> derivedFiles(JsonObject file, JsonArray files) {
        List<JsonObject> ret = new ArrayList<>();
        String id = file.getString("@id");
        for (int i = 0; i < files.size(); ++i) {
            JsonObject test = files.getJsonObject(i);
            String testID = test.getString("@id");
            if (!test.equals(testID)) {
                JsonArray derivedArray = test.getJsonArray("derived_from");
                if (derivedArray != null) {
                    for (int j = 0; j < derivedArray.size(); ++j) {
                        String derived = derivedArray.getString(j);
                        if (id.equals(derived)) {
                            ret.add(test);
                        }
                    }
                }
            }
        }
        return ret;
    }

    static public JsonObject findFileIn(String id, JsonArray files) {
        JsonObject ret = null;

        for (int i = 0; i < files.size(); ++i) {
            JsonObject test = files.getJsonObject(i);
            String testID = test.getString("@id");
            if (testID.equals(id)) {
                ret = test;
                break;
            }
        }
        return ret;
    }

    static public Map<String, String> encodeSubmit(JsonObject fileObj, String[] columns) {
        Map<String, String> ret = new TreeMap<>();
        for (String name : columns) {
            String colValue = null;
            JsonValue jsonValue = fileObj.get(name);
            ValueType type = jsonValue.getValueType();
            if (type.equals(ValueType.OBJECT)) {
                JsonObject obj = (JsonObject) jsonValue;
                colValue = obj.getString("@id");
            } else if (type.equals(ValueType.STRING)) {
                JsonString jsonString = (JsonString) jsonValue;
                colValue = jsonString.getString();
            } else if (type.equals(ValueType.ARRAY)) {
                JsonArray jsonArray = (JsonArray) jsonValue;
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < jsonArray.size(); ++i) {
                    JsonString stringObj = (JsonString) jsonArray.get(i);
                    if (i > 0) {
                        builder.append(",");
                    }
                    builder.append(stringObj.getString());
                    int oaisdjfoih = 0;
                }
                colValue = builder.toString();
            }
            ret.put(name, colValue);
        }
        return ret;
    }

    static String alias(String submitName) {
        return submitName.replace("/net/waterston/vol9/ChipSeqPipeline/", "robert-waterston:").replaceAll("/", "-");
    }

    static public void printHeads(PrintStream stream) {
        stream.printf("%s", submitColumns[0]);
        for (int i = 1; i < submitColumns.length; ++i) {
            stream.printf("\t%s", submitColumns[i]);
        }
        stream.println();
    }

    public static String[] submitColumns = {"aliases", "lab", "award", "dataset", "file_format", "file_format_type", "submitted_file_name", "output_type", "derived_from", "step_run"};

    /* *********************
    finds analyses that need submitting
    reports content error peaks and big bed associated
    reports experiments that have not had the fastq submitted yet
    reports experimetns with upload failed files
    
    ****** run as waterston-jboss on epic *******
    
     *************************** */
    static public void main(String[] args) throws Exception {

        TreeMap<String,String> chipReplace = new TreeMap<>();
        chipReplace.put("c83f6aa3-731e-4176-b18c-d846349d449f","f18f7c60-6a5b-4358-8fbd-123ec9864f82");
        chipReplace.put("41daa32d-6783-4cc0-9ff2-0731e317e36f","d9f31d73-30a1-4fcf-b70a-b733e8ae2284");
        chipReplace.put("c3b81e5e-5212-4b5a-830b-ad2ecb199e4c","61b6192b-5b57-49a7-a8a0-8a4f45204bb5");
        chipReplace.put("69e32406-c6f7-43e0-b78a-093f78db6620","2785d5b4-90a8-4260-b988-a7fff7fc9c95");
        chipReplace.put("37c8acbb-2f74-4723-a981-821bbec27688","3bab7356-6df9-4f3d-a506-21720ece0b54");
        
        
        TreeMap<String, List<ChipExperiment>> expMap = ChipHelper.allExperiments();
        TreeMap<String, List<String>> aMap = new TreeMap<>();
        ArrayList<String> failedList = new ArrayList<>();
        ArrayList<Map> contentErrorBeds = new ArrayList<>();
        ArrayList<Map> contentErrorBigBeds = new ArrayList<>();
        ArrayList<String> initSubmitList = new ArrayList<>();
        ArrayList<String> bedAccessions = new ArrayList<>();
        ArrayList<String> bigBedAccessions = new ArrayList<>();
        ArrayList<String> releaseAble = new ArrayList<String>();
        ArrayList<String> notReleaseAble = new ArrayList<String>();

        for (String species : expMap.keySet()) {
            ArrayList<String> aList = new ArrayList<>();
            aMap.put(species, aList);
            for (ChipExperiment exp : expMap.get(species)) {

                // is there a marked run
                List<ChipRun> runList = ChipHelper.getEquals("ChipRun", "ExpID", exp.getExpId(), "SubmitID");
                ChipRun markedRun = null;
                for (ChipRun run : runList) {
                    if (run.getMarkedForDcc() != null) {
                        markedRun = run;
                    }
                }

                //                   if (analyses == null || analyses.isEmpty()) {
                //  only process the marked run
                if (markedRun != null) {
                    boolean uploadFailed = false;
                    boolean hasFastq = false;
                    boolean hasContentError = false;

                    // get the experiment dcc record
                    String expAlias = Aliases.ipExperimentAlias(exp);
                    String expURL = String.format("https://www.encodeproject.org/experiments/%s/?format=json", expAlias);
                    EncodeUrl url = new EncodeUrl(expURL);
                    url.getJson();
                    JsonObject jsonObj = url.getJsonObject();
                    JsonArray analyses = jsonObj.getJsonArray("analyses");
                    JsonArray files = jsonObj.getJsonArray("files");
                    if (jsonObj.getJsonString("accession") != null) {
                        String expAcc = jsonObj.getString("accession");

                        for (int i = 0; i < files.size(); ++i) {
                            JsonObject file = files.getJsonObject(i);
                            String status = file.getString("status");
                            String submitName = file.getString("submitted_file_name");
                            if (status.equals("upload failed")) {
                                uploadFailed = true;
                            }
                            if (submitName.contains("fastq")) {
                                hasFastq = true;
                            }
                            if (status.equals("content error")) {
                                hasContentError = true;
                                Map<String, String> vals = encodeSubmit(file, submitColumns);
                                vals.put("aliases", alias(submitName));
                                contentErrorBeds.add(vals);
                                bedAccessions.add(file.getString("accession"));

                                // bigBed file do not have content errors, so need this
                                List<JsonObject> derivedList = derivedFiles(file, files);
                                for (JsonObject bigBedObj : derivedList) {
                                    Map<String, String> bbVals = encodeSubmit(bigBedObj, submitColumns);
                                    bbVals.put("aliases", alias(bbVals.get("submitted_file_name")));
                                    bbVals.put("derived_from", vals.get("aliases"));
                                    contentErrorBigBeds.add(bbVals);
                                    bigBedAccessions.add(bigBedObj.getString("accession"));
                                }
                                int aksdfj = 0;
                            }
                        }

                        if (uploadFailed) {
                            failedList.add(exp.getExpId());
                        } else if (analyses == null || analyses.isEmpty()) {
                            // no analysis in experiment
                            if (hasFastq) {
                                aList.add(exp.getExpId());
                            } else {
                                initSubmitList.add(exp.getExpId());
                            }

                        }
                        if (!hasContentError & hasFastq) {
                            releaseAble.add(expAcc);
                        } else {
                            notReleaseAble.add(expAcc);
                        }

                    }
                }
            }
        }

        PrintStream contentErrorTSV = new PrintStream(new File("/net/waterston/vol9/ChipSeqPipeline/contentErrorBeds.tsv"));
        printHeads(contentErrorTSV);
        for (Map<String, String> map : contentErrorBeds) {
            contentErrorTSV.printf("%s", map.get(submitColumns[0]));
            for (int i = 1; i < submitColumns.length; ++i) {
                contentErrorTSV.printf("\t%s", map.get(submitColumns[i]));
            }
            contentErrorTSV.println();
        }
        contentErrorTSV.close();

        PrintStream fileNameStream = new PrintStream("/net/waterston/vol9/ChipSeqPipeline/contentErrorFileNames.sh");
        for (Map<String, String> map : contentErrorBeds) {
            String fName = map.get("submitted_file_name");
            for (String key : chipReplace.keySet()){
                if (fName.contains(key)){
                    String fNewName = fName.replace(key, chipReplace.get(key));
                    fileNameStream.printf("cp %s %s\n", fNewName,fName);  
                    break;
                }
            }
        }
        fileNameStream.close();

        contentErrorTSV = new PrintStream(new File("/net/waterston/vol9/ChipSeqPipeline/contentErrorBigBeds.tsv"));
        printHeads(contentErrorTSV);
        for (Map<String, String> map : contentErrorBigBeds) {
            contentErrorTSV.printf("%s", map.get(submitColumns[0]));
            for (int i = 1; i < submitColumns.length; ++i) {
                contentErrorTSV.printf("\t%s", map.get(submitColumns[i]));
            }
            contentErrorTSV.println();
        }
        contentErrorTSV.close();

        PrintStream stream = new PrintStream(new File("/net/waterston/vol9/ChipSeqPipeline/bedErrorAccessions.txt"));
        for (String acc : bedAccessions) {
            stream.println(acc);
        }
        stream.close();

        stream = new PrintStream(new File("/net/waterston/vol9/ChipSeqPipeline/bigBedErrorAccessions.txt"));
        for (String acc : bigBedAccessions) {
            stream.println(acc);
        }
        stream.close();

        PrintStream uploadFailedStream = new PrintStream("/net/waterston/vol9/ChipSeqPipeline/uploadFailed");
        for (String exp : failedList) {
            uploadFailedStream.println(exp);
        }
        uploadFailedStream.close();

        PrintStream releaseStream = new PrintStream("/net/waterston/vol9/ChipSeqPipeline/releaseExps");
        for (String acc : releaseAble) {
            releaseStream.println(acc);
        }
        releaseStream.close();

        PrintStream notReleaseStream = new PrintStream("/net/waterston/vol9/ChipSeqPipeline/notReleaseExps");
        for (String acc : notReleaseAble) {
            notReleaseStream.println(acc);
        }
        notReleaseStream.close();

        System.out.println("\nNeeds Initial Submit:");
        for (String is : initSubmitList) {
            System.out.println(is);;
        }
        System.out.println("\nAnalysis to submit");
        for (String species : expMap.keySet()) {
            for (String expID : aMap.get(species)) {
                File expDir = new File(Directories.sourceDir, expID);
                File accDir = new File(expDir, "accession");
                if (!accDir.exists()) {
                    Files.createDirectories(accDir.toPath());
                }
                System.out.printf("source /net/waterston/vol9/ChipSeqPipeline/%s/submitAnalysis.sh\n", expID);
            }
        }
        HibernateUtil.shutdown();
        int djfhdsiu = 0;
    }
}
