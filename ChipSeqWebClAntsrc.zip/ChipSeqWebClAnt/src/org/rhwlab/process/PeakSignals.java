/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.TreeMap;
import java.util.TreeSet;
import org.rhwlab.gene.model.Annotation;
import org.rhwlab.gene.model.ModelFromGFF;
import static org.rhwlab.process.PeakClustering.gffFile;

/**
 *
 * @author gevirl
 */
public class PeakSignals {

    static public void reportPeakSignals(File topicFile, File vocabFile, File outFile) throws Exception {
        TreeSet<String> notFound = new TreeSet<>();
        TreeSet<String> found = new TreeSet<>();
        double minRank = 1.0e-20;

        Annotation.remapChromo = false;
        ModelFromGFF gff = new ModelFromGFF(gffFile);

        // get the vocabulary (target genes)
        TreeMap<String, Integer> vocabMap = new TreeMap<>();
        BufferedReader reader = new BufferedReader(new FileReader(vocabFile));
        String line = reader.readLine();
        int index = 0;
        while (line != null) {
            String[] names = gff.nameTripletFromWBGene(line);
            vocabMap.put(names[1], index);
            ++index;
            line = reader.readLine();
        }
        reader.close();

        // get the topics (tfs)
        TreeMap<String, Integer> topicMap = new TreeMap<>();

        reader = new BufferedReader(new FileReader(topicFile));
        reader.readLine(); // skip the head
        line = reader.readLine();
        index = 0;
        while (line != null) {
            String[] names = line.split("\t");
            topicMap.put(names[0], index);
            ++index;
            line = reader.readLine();
        }
        reader.close();

        AllTFPeaks peaks = new AllTFPeaks();
        double[][] ranksMat = new double[peaks.getAllTFs().length][];
        for (int i = 0; i < ranksMat.length; ++i) {
            double[] r = new double[vocabMap.size()];
            Arrays.fill(r, minRank);
            ranksMat[i] = r;
        }

        TreeMap<String, TreeMap<Integer, Annotation>> tssMap = gff.proteinCodeingGenesByTSS();
        for (String chr : tssMap.keySet()) {
            TreeMap<Integer, Annotation> annotMap = tssMap.get(chr);
            String chromo = chr.replace("tDNA", "");
            for (Integer tss : annotMap.keySet()) {
                Annotation annot = annotMap.get(tss);
                String[] target = gff.nameTripletFromWBGene(annot.getGeneID());
                Integer col = vocabMap.get(target[1]);
                if (col != null) {

                    TreeMap<String, Double> ranks = peaks.highestRank(chromo, tss - 2000, tss + 2000);

                    for (String tf : ranks.keySet()) {
                        String[] tfNames = gff.geneNameTriplet(tf);

                        Integer row = topicMap.get(tfNames[2]);
                        if (row == null) {
                            notFound.add(tf);
                        } else {
                            ranksMat[row][col] = ranks.get(tf);
                            found.add(tf);
                        }
                    }
                }
            }
        }
        for (String nf : notFound) {
            System.out.println(nf);
        }
        System.out.printf("tfs found: %d\n", found.size());

        // normalize the rank matrix
        for (int t = 0; t < ranksMat.length; ++t) {
            double sum = ranksMat[t][0];
            for (int v = 1; v < vocabMap.size(); ++v) {
                sum = sum + ranksMat[t][v];
            }
            for (int v = 0; v < vocabMap.size(); ++v) {
                ranksMat[t][v] = ranksMat[t][v] / sum;
            }
        }
        // report the topic - vocab file
        PrintStream stream = new PrintStream(outFile);
        for (int t = 0; t < ranksMat.length; ++t) {
            stream.printf("%e", ranksMat[t][0]);
            for (int v = 1; v < vocabMap.size(); ++v) {
                stream.printf("\t%e", ranksMat[t][v]);
            }
            stream.println();
        }
        stream.close();
        int iudfh = 0;
    }

    public static void main(String[] args) throws Exception {
        File dir = new File("/net/waterston/vol9/UVA_YoungAdult");
//        File vocabFile = new File(dir, "CellTypeExprRounded.vocab");

        File topicFile = new File(dir, "chipTFs.tsv");
        File vocabFile = new File(dir, "CellType_Target_Expr.vocab");
        File outFile = new File(dir, "TF_Gene");
        
        reportPeakSignals( topicFile, vocabFile, outFile);
    }
}
