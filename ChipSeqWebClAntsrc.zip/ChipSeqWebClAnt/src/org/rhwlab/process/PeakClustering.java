/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import java.io.File;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import org.rhwlab.chipseq.PeakClusters;
import org.rhwlab.chipseq.PeakFile;
import org.rhwlab.chipseqweb.HibernateUtil;
import org.rhwlab.gene.model.Annotation;
import org.rhwlab.gene.model.ModelFromGFF;
import org.rhwlab.tfs.TF_DB;

/**
 *
 * @author gevirl
 */
public class PeakClustering {

    static public void cluster(int clusterSpacing, File outDir, PipelinePeakFiles peakFiles, File oldDir, File gffFile, Set<String> stagesToUse) throws Exception {

        TF_DB tfdb = new TF_DB();
        int[] bins = {50, 75, 100, 125, 150, 175, 200};

        // get all the peak files in the local pipeline
        TreeMap<String, PeakFile> dccPeakFileMap = peakFiles.dccPeakFiles();
        HibernateUtil.shutdown();

        // add in all the dcc peak files
        List<PeakFile> oldDCCFileList = PeakClusters.PeakFiles(oldDir, "");  // these files have chr in chromosome
        List<PeakFile> clusterable = new ArrayList<>();
//        clusterable.addAll(dccPeakFileMap.values());
//        clusterable.addAll(oldDCCFileList);
        System.out.println("Checking new pipeline data");
        for (PeakFile pf : dccPeakFileMap.values()) {
            System.out.printf("%s\n", pf.getTF());
            if (tfdb.isTF(pf.getTF())) {
                if (checkStage(pf.getStage(), stagesToUse)) {
                    clusterable.add(pf);
                } else {
                    System.out.printf("Not in stages to use: %s\n", pf.getTF());
                }

            } else {
                System.out.printf("Not a TF: %s\n", pf.getTF());
            }
        }

        System.out.println("Checking old data");
        for (PeakFile pf : oldDCCFileList) {
            System.out.printf("%s\n", pf.getTF());
            if (tfdb.isTF(pf.getTF())) {
                if (checkStage(pf.getStage(), stagesToUse)) {
                    clusterable.add(pf);
                } else {
                    System.out.printf("Not in stages to use: %s\n", pf.getTF());
                }
            } else {
                System.out.printf("Not a TF: %s\n", pf.getTF());
            }
        }

        TreeSet<String> stages = new TreeSet<>();
        for (PeakFile peakFile : clusterable) {
            if (peakFile.getStage().equals("IP")) {
                int asoidfjosi = 0;
            }
            stages.add(peakFile.getStage());
        }

        for (String stage : stages) {
            System.out.println(stage);
        }

        // get the gene model
        Annotation.remapChromo = true;
        ModelFromGFF gff = new ModelFromGFF(gffFile);

        // form clusters
        PeakClusters clusters = new PeakClusters(clusterable, clusterSpacing, bins);
        if (gff != null) {
            clusters.locateInGenome(gff, null);
        }
        File clusterFile = new File(outDir, String.format("PeakClusters.%s", clusterSpacing));
        clusters.report(clusterFile);

        clusters.reportAsBagOfWords(clusterFile.getPath());

        clusters.reportSignalValues(clusterFile.getPath());

    }

    static int  wormPeaksForModeling(File outDir, String[] stages, int clusterSpacing, boolean tss) throws Exception {
        TreeSet<String> stageSet = new TreeSet<>();
        stageSet.addAll(Arrays.asList(stages));

        List<PeakFile> peakFiles = allWormTF_PeakFiles(stageSet);
        PrintStream stream = new PrintStream(new File(outDir,"AllPeaks.bed"));
        for (PeakFile peakFile : peakFiles){
            peakFile.save(stream);
        }
        stream.close();

        PeakClusters clusters = cluster(clusterSpacing, peakFiles, tss);

        File clusterFile = new File(outDir, String.format("PeakClusters.%s", clusterSpacing));
        clusters.report(clusterFile);
        clusters.reportSignalValues(clusterFile.getPath());
        return clusters.getPeakCount();
    }

    // form a list of all tf peakfile 
    static public List<PeakFile> allWormTF_PeakFiles(Set<String> priorityStages) throws Exception {
        TF_DB tfdb = new TF_DB();
        List<PeakFile> allPeakFiles = allWormPeakFiles();

        TreeSet<String> prioritytfs = new TreeSet<>();
        int priorityExps = 0;
        TreeSet<String> nonprioritytfs = new TreeSet<>();
        int nonPriorityExps = 0;

        List<PeakFile> tfPeakFiles = new ArrayList<>();
        List<PeakFile> nonPriority = new ArrayList<>();

        //add all the priority stage peak files
        TreeSet<String> tfsSet = new TreeSet<>();
        for (PeakFile pf : allPeakFiles) {
            if (pf.getTF().equals("pie-1")){
                int sidufh=0;
            }
            if (tfdb.isTF(pf.getTF())) {
                tfsSet.add(pf.getTF());
                if (priorityStages.contains(pf.getStage())) {
                    tfPeakFiles.add(pf);
                    prioritytfs.add(pf.getTF());
                    ++priorityExps;
                } else {
                    nonPriority.add(pf);
                }
            }
        }
        PrintStream tfStream = new PrintStream("/net/waterston/vol9/ChipSeqPipeline/ChippedTFs");
        for (String tf : tfsSet){
            tfStream.println(tf);
        }
        tfStream.close();
        
        // add nonpriority stage peak files if tf has not been added from priority stages
        for (PeakFile pf : nonPriority) {
            if (!prioritytfs.contains(pf.getTF())) {
                tfPeakFiles.add(pf);
                nonprioritytfs.add(pf.getTF());
                ++nonPriorityExps;
            }
        }
        System.out.printf("Prioirty Experiments: %d    TFs: %d\n", priorityExps, prioritytfs.size());
        printList(System.out, new ArrayList(prioritytfs));

        System.out.printf("Non Prioirty Experiments: %d    TFs: %d\n", nonPriorityExps, nonprioritytfs.size());
        printList(System.out, new ArrayList(nonprioritytfs));

        return tfPeakFiles;
    }

    static void printList(PrintStream stream, List<String> list) {
        int n = 12;
        int left = list.size();
        int index = 0;
        while (left > 0) {
            stream.printf("%s", list.get(index));
            ++index;
            --left;
            for (int i = 1; i < n; ++i) {

                if (index < list.size()) {
                    stream.printf("  %s", list.get(index));
                    ++index;
                    --left;
                }
            }
            stream.println();
        }
    }

    static public List<PeakFile> allWormPeakFiles() throws Exception {
        PipelinePeakFiles peakFiles = new PipelinePeakFiles("CElegans");

        // get all the peak files in the local pipeline submitted to DCC
        TreeMap<String, PeakFile> dccPeakFileMap = peakFiles.dccPeakFiles();
        HibernateUtil.shutdown();

        List<PeakFile> allPeakFiles = PeakClusters.PeakFiles(oldWormDir, "");  // these files have chr in chromosome
        allPeakFiles.addAll(dccPeakFileMap.values());

        return allPeakFiles;
    }

    // cluster a list of peak files with a given spacing, standard bins
    static public PeakClusters cluster(int clusterSpacing, List<PeakFile> clusterable, boolean tss) throws Exception {

        int[] bins = {50, 75, 100, 125, 150, 175, 200};

        // get the gene model
        Annotation.remapChromo = true;
        ModelFromGFF gff = new ModelFromGFF(gffFile);
        TreeMap<String, TreeMap<Integer, Annotation>> tssMap = null;
        if (tss) {
            tssMap = gff.proteinCodeingGenesByTSS();
        }
        // form clusters
        PeakClusters clusters = new PeakClusters(clusterable, clusterSpacing, bins);
        if (gff != null) {
            clusters.locateInGenome(gff, tssMap);
        }
        return clusters;

    }

    static boolean checkStage(String stage, Set<String> stagesToUse) {
        return stagesToUse == null | stagesToUse.contains(stage);
    }

    static public void clusterWorm() throws Exception {

        File oldDir = new File("/net/waterston/vol2/home/gevirl/ChipSeqPeaks/worm/ce11");
        PipelinePeakFiles peakFiles = new PipelinePeakFiles("CElegans");
        int clusterSpacing = 200;

        File outDir = new File("/net/waterston/vol9/ChipSeqPipeline/WormPeakClustersEmb");
        TreeSet<String> stages = new TreeSet<>();
        stages.addAll(Arrays.asList(emb));
        cluster(clusterSpacing, outDir, peakFiles, oldDir, gffFile, stages);

        outDir = new File("/net/waterston/vol9/ChipSeqPipeline/WormPeakClustersPostEmb");
        stages = new TreeSet<>();
        stages.addAll(Arrays.asList(postEmb));
        cluster(clusterSpacing, outDir, peakFiles, oldDir, gffFile, stages);
    }

    static public void clusterFly() throws Exception {
        File outDir = new File("/net/waterston/vol9/ChipSeqPipeline/FlyPeakClusters");
        File oldDir = new File("/net/waterston/vol2/home/gevirl/ChipSeqPeaks/fly/dm6");
        PipelinePeakFiles peakFiles = new PipelinePeakFiles("Dmel");
        int clusterSpacing = 200;

        cluster(clusterSpacing, outDir, peakFiles, oldDir, null, null);
    }

    static public void clusterWormPriorityStages() throws Exception {
        File outDir = new File("/net/waterston/vol9/ChipSeqPipeline/WormPeakClustersPostEmbPriority");
        wormPeaksForModeling(outDir, postEmb, 200, false);
    }

    static public int clusterWormPriorityStagesTSS() throws Exception {
        File outDir = new File("/net/waterston/vol9/ChipSeqPipeline/WormPeakClustersPostEmbPriorityTSS");
        return wormPeaksForModeling(outDir, postEmb, 200, true);
    }

    public static void main(String[] args) throws Exception {
        int n = clusterWormPriorityStagesTSS();
        System.out.printf("Total peaks clustered: %d\n", n);
        // clusterWorm();
        //     clusterFly();
    }
    static File gffFile = new File("/net/waterston/vol9/References/WS260/c_elegans.PRJNA13758.WS260.annotations.WormBase.gff3");
    static File oldWormDir = new File("/net/waterston/vol2/home/gevirl/ChipSeqPeaks/worm/ce11");
    static String[] emb = {"E", "EE", "EM", "Em", "LE", "ME", "earlyembryonic", "lateembryonic", "midembryonic"};
    static String[] postEmb = {"L1", "L1larva", "L2", "L2larva", "L3", "L4", "L4larva", "YA", "yAd", "youngadult"};

}
