/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.List;
import java.util.TreeMap;
import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import org.rhwlab.chipseq.qa.Directories;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipHelper;
import org.rhwlab.chipseqweb.ChipSequencingFile;
import org.rhwlab.chipseqweb.HibernateUtil;

/**
 *
 * @author gevirl
 */
// lists all the experments that have a dcc accession
// update the accession column in the db from submission log files
public class ExpAccessions {

    static public void main(String[] args) throws Exception {
        TreeMap<String, List<ChipExperiment>> map = ChipHelper.allExperiments();
        for (String species : map.keySet()) {
            for (ChipExperiment exp : map.get(species)) {
                File expDir = new File(Directories.sourceDir, exp.getExpId());
                if (expDir.exists()) {
                    for (File file : expDir.listFiles()) {
                        File ipDir = null;
                        if (file.getName().equals("experiment") || file.getName().endsWith("_IP")) {
                            ipDir = file;
                        }
                        if (ipDir != null) {
                            File euDir = new File(ipDir, "EU_Logs");
                            File accFile = new File(euDir, "log_eu_prod_posted.txt");
                            if (accFile.exists()) {
                                BufferedReader reader = new BufferedReader(new FileReader(accFile));
                                String line = reader.readLine();
                                while (line != null) {
                                    String[] tokens = line.split("\t");
                                    if (tokens[1].endsWith("IP")) {
                                        System.out.printf("%s\t%s\n", exp.getExpId(), tokens[3]);
                                        exp.setAccession(tokens[3]);

                                    }
                                    line = reader.readLine();
                                   ChipHelper.update(exp);
                                }
                                reader.close();
                            }
                            int laskdhiushd = 0;

                        } else {

                        }

                    }
                }
            }
        }
        HibernateUtil.shutdown();
    }
}
