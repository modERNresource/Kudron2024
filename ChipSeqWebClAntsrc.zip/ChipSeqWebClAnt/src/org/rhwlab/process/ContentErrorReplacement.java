/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.process;

import java.io.File;
import java.util.List;
import java.util.Map;
import javax.json.JsonArray;
import javax.json.JsonObject;
import org.rhwlab.chipseq.dcc.Aliases;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipHelper;
import org.rhwlab.chipseqweb.HibernateUtil;
import org.rhwlab.encode.EncodeUrl;
import static org.rhwlab.process.CheckAnalyses.alias;
import static org.rhwlab.process.CheckAnalyses.derivedFiles;
import static org.rhwlab.process.CheckAnalyses.encodeSubmit;
import static org.rhwlab.process.CheckAnalyses.submitColumns;

/**
 *
 * @author gevirl
 */

/*
   replace the bed and derived bigBed files from one chip run to a chip rum with content errors
    args[0] the source chip  run directory
    args[1] - the destination chip run directory with content error files

    writes a script to move all the relevant files to std out

 */
public class ContentErrorReplacement {

    static public String cpCommand(String chipID,String path){
        return String.format("cp %s %s",replaceChipID(chipID,path),path);
    }
    
    static public String replaceChipID(String chipID, String path) {
        String[] tokens = path.split("/");
        tokens[7] = chipID;
        StringBuilder builder = new StringBuilder();
        for (int j = 1; j < tokens.length; ++j) {
            builder.append("/");
            builder.append(tokens[j]);
        }
        return builder.toString();
    }

    public static void main(String[] args) throws Exception {
        File sourceDir = new File(args[0]);
        File destDir = new File(args[1]);

        String sourceChipID = sourceDir.getPath().split("/")[7];
        String destExpID = destDir.getParentFile().getParentFile().getName();

        //get the dcc experiment record of the destination directory (has the errors)
        ChipExperiment exp = (ChipExperiment) ChipHelper.getEquals("ChipExperiment", "ExpID", destExpID, "ExpID").get(0);

        String expAlias = Aliases.ipExperimentAlias(exp);
        String expURL = String.format("https://www.encodeproject.org/experiments/%s/?format=json", expAlias);
        EncodeUrl url = new EncodeUrl(expURL);
        url.getJson();
        JsonObject jsonObj = url.getJsonObject();
        JsonArray analyses = jsonObj.getJsonArray("analyses");
        JsonArray files = jsonObj.getJsonArray("files");

        for (int i = 0; i < files.size(); ++i) {
            JsonObject file = files.getJsonObject(i);
            String status = file.getString("status");
            if (status.equals("content error")) {

                List<JsonObject> derivedList = derivedFiles(file, files);
                for (JsonObject bigBedObj : derivedList) {
                    System.out.println(cpCommand(sourceChipID,bigBedObj.getString("submitted_file_name")));
                }
                
                String destPath = file.getString("submitted_file_name");
                System.out.println(cpCommand(sourceChipID,destPath));
                

            }
        }
        HibernateUtil.shutdown();
    }
}
