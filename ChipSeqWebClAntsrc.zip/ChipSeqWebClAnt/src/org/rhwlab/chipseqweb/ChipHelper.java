/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseqweb;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

/**
 *
 * @author gevirl
 */
public class ChipHelper {

    static public Session  getSession()throws Exception {
        SessionFactory factory = HibernateUtil.getSessionFactory();
        Session session = factory.openSession();
        while(!session.isConnected()){
            System.out.println("ChipHelper sleep");
            Thread.sleep(1000);          
        }  
        return session;
    }
    static public List filesFor(String expID) throws Exception {
        Session session = getSession();
        Transaction tx = session.beginTransaction();
        Query q = session.createQuery("from ChipSequencingFile  where ExpID = :expid order by expID,SeqType,Replicate,ReadPair");
        q.setString("expid", expID);
        List l = q.list();
        tx.commit();
        session.close();
        return l;
    }

    static public boolean check(String user, String password) throws Exception{

        Session session = getSession();

        Transaction tx = session.beginTransaction();
        Query query = session.createQuery("from ChipUser where Username = :user and Password = :pass");
        query.setString("user", user);
        query.setString("pass", password);
        boolean ret = !query.list().isEmpty();
        tx.commit();
        session.close();
        return ret;
    }

    static public TreeMap<String, List<ChipExperiment>> allExperiments() throws Exception {
        TreeMap<String, List<ChipExperiment>> ret = new TreeMap<>();
        for (Object obj : ChipHelper.getAll("ChipExperiment", "ExpID")) {
            ChipExperiment exp = (ChipExperiment) obj;
            String species = exp.getSpecies();
            List list = ret.get(species);
            if (list == null) {
                list = new ArrayList<>();
                ret.put(species, list);
            }
            list.add(obj);
        }
        return ret;
    }

    static public List allExperiments(String species) throws Exception {
        return getEquals("ChipExperiment", "Species", species, "Gene");
    }

    static public List allTags(String expID) throws Exception {
        return getEquals("ChipTag","ExpID",expID,"Name");
    }
    static public List allSortedBy(String table, String field) throws Exception {
        Session session = getSession();

        Transaction tx = session.beginTransaction();
        Query query = session.createQuery(String.format("from %s order by %s", table, field));
        List list = query.list();
        tx.commit();
        session.close();
        return list;
    }

    static public List getAll(String table, String sortedBy) throws Exception {
        Session session = getSession();

        Transaction tx = session.beginTransaction();

        Query query = session.createQuery(String.format("from %s order by %s", table, sortedBy));
        List l = query.list();
        tx.commit();
        session.close();
        return l;
    }

    static public List getEquals(String table, String field, String base, String sortedBy) throws Exception{
        Session session = getSession();
        Transaction tx = session.beginTransaction();
        Query query = session.createQuery(String.format("from %s where %s = :base order by %s", table, field, sortedBy));
        query.setString("base", base);
        List l = query.list();
        tx.commit();
        session.close();
        return l;
    }

    static public List getLike(String table, String field, String base)  throws Exception{
        Session session = getSession();
        Transaction tx = session.beginTransaction();
        Query query = session.createQuery(String.format("from %s where %s like :base", table, field));
        query.setString("base", base + "%");
        List l = query.list();
        tx.commit();
        session.close();
        return l;
    }

    static public String nextID(String table, String field, String base, String method) throws Exception {
        int max = 0;
        for (Object obj : getLike(table, field, base)) {
            String id = (String) obj.getClass().getMethod(method).invoke(obj);
            String[] tokens = id.split("_");
            int i = Integer.valueOf(tokens[tokens.length - 1]);
            if (i > max) {
                max = i;
            }
        }
        return String.format("%s_%d", base, max + 1);
    }

    static public void save(Object rec) throws Exception {
        Session session = getSession();
        Transaction tx = session.beginTransaction();
        session.save(rec);
        tx.commit();
        session.close();
    }

    static public void update(Object rec)throws Exception  {
        Session session = getSession();
        Transaction tx = session.beginTransaction();
        session.update(rec);
        tx.commit();
        session.close();
    }

    static public void remove(Object obj)throws Exception  {
        Session session = getSession();
        Transaction tx = session.beginTransaction();
        session.delete(obj);
        tx.commit();
        session.close();        

    }
    
    static public void main(String[] args)throws Exception {
        ChipHelper.allExperiments();
    }
}
