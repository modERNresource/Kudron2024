/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseqweb;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.TreeMap;
import java.util.TreeSet;
import org.rhwlab.gene.model.Annotation;
import org.rhwlab.gene.model.ModelGFF;
import org.rhwlab.gene.model.ModelGFF_Fly;

/**
 *
 * @author gevirl
 */
public class Update {

    public static void WormTF(File file) throws Exception {
        TreeSet<String> set = new TreeSet<>();

        BufferedReader reader = new BufferedReader(new FileReader(file));
        TreeMap<String, Integer> headIndex = formIndex(reader.readLine().split("\t"));

        String line = reader.readLine();
        while (line != null) {
            String[] tokens = line.split("\t");
            String gene = tokens[headIndex.get("Gene name")];
            List list = ChipHelper.getEquals("ChipExperiment", "Gene", gene, "ExpID");
            for (Object obj : list) {
                ChipExperiment exp = (ChipExperiment) obj;
                if (exp.getStage().equals(tokens[headIndex.get("Stage")])) {
                    if (exp.getStrain().equals(tokens[headIndex.get("Strain")])) {
                        String geneType = tokens[headIndex.get("Type")];
                        String domain = tokens[headIndex.get("Domain")];
                        exp.setGeneType(geneType);
                        exp.setDomain(domain);
                        //                       System.out.printf("%s\t%s\n",exp.getExpId(),exp.getDomain());
                        //                       ChipHelper.update(exp);
                        int asidufh = 0;

                    }
                }
            }
            String key = String.format("%s%s%s%s", gene, tokens[headIndex.get("Type")], tokens[headIndex.get("Strain")], tokens[headIndex.get("Peaks")]);
            if (set.contains(key)) {
                System.out.println(key);
            } else {
                set.add(key);
            }
            line = reader.readLine();
        }
        reader.close();
    }

    public static void WormNonTF(File file) throws Exception {
        BufferedReader reader = new BufferedReader(new FileReader(file));
        TreeMap<String, Integer> headIndex = formIndex(reader.readLine().split("\t"));

        String line = reader.readLine();
        while (line != null) {
            String[] tokens = line.split("\t");
            String gene = tokens[headIndex.get("Gene")];
            List list = ChipHelper.getEquals("ChipExperiment", "Gene", gene, "ExpID");
            for (Object obj : list) {
                ChipExperiment exp = (ChipExperiment) obj;
                if (exp.getStage().equals(tokens[headIndex.get("Stage")])) {
                    if (exp.getStrain().equals(tokens[headIndex.get("Strain")])) {
                        String geneType = tokens[headIndex.get("Type")];
                        String classify = tokens[headIndex.get("Classification")];
                        if (classify.equals("")) {
                            classify = "Non TF";
                        }
                        exp.setGeneType(classify);
                        exp.setDomain("");
                        //                       System.out.printf("%s\t%s\n",exp.getExpId(),exp.getGeneType());
                        //                       ChipHelper.update(exp);
                        int asidufh = 0;
                    }
                }
            }
            line = reader.readLine();
        }
        reader.close();
    }

    public static void FlyTF_NonTF(File file, ModelGFF_Fly gff) throws Exception {
        BufferedReader reader = new BufferedReader(new FileReader(file));
        TreeMap<String, Integer> headIndex = formIndex(reader.readLine().split("\t"));

        String line = reader.readLine();
        while (line != null) {
            String[] tokens = line.split("\t");
            String fgGene = tokens[headIndex.get("FBID_KEY")];
            
            boolean chipped = tokens[headIndex.get("Data")].equals("Y");
            boolean tf = tokens[headIndex.get("TF or NOT")].equals("TF");
            String gene = tokens[headIndex.get("SYMBOL")];
            
            if (!tf && chipped) {
                String geneType = tokens[headIndex.get("")];
                ArrayList<String> aliases = gff.aliases(fgGene);
                if (aliases == null){
                    aliases = new ArrayList<>();
                }
                aliases.add(0, gene);
                
                boolean matched = false;
                for (String alias : aliases) {
                    List list = ChipHelper.getEquals("ChipExperiment", "Gene", alias, "ExpID");
                    if (!list.isEmpty()) {
                        matched = true;
                        for (Object obj :list){
                            ChipExperiment exp = (ChipExperiment)obj;
                            exp.setGeneType(geneType);
                            System.out.println(line);
                            ChipHelper.update(exp);
                            int asdf=0;
                        }
                    }
                }
                if (!matched){
                    gff.aliases(fgGene);
 //                   System.out.println(line);
                    int jdsf=0;
                }
            }
            line = reader.readLine();
        }
        reader.close();
    }

    public static TreeMap<String, Integer> formIndex(String[] tokens) {
        TreeMap<String, Integer> ret = new TreeMap<>();
        for (int i = 0; i < tokens.length; ++i) {
            ret.put(tokens[i], i);
        }
        return ret;
    }

    public static void main(String[] args) throws Exception {
        File tfFile = new File("/net/waterston/vol9/ChipSeqPipeline/Worm_TF_3-29-2023-1.tsv");
//        Update.WormTF(tfFile);

        File nontfFile = new File("/net/waterston/vol9/ChipSeqPipeline/Worm_nonTF_3-29-2023-1.tsv");
//        Update.WormNonTF(nontfFile);

        File gffFile = new File("/net/waterston/vol9/dm6/dmel-all-r6.49.flybase.gff3");
        Annotation.remapChromo = false;
        ModelGFF_Fly gff = new ModelGFF_Fly(gffFile);
        Collection<Annotation> genes = gff.getAnnotationsByType("gene");

        File flyFile = new File("/net/waterston/vol9/ChipSeqPipeline/Fly_GeneStatus.tsv");
        Update.FlyTF_NonTF(flyFile, gff);

        HibernateUtil.shutdown();
    }
}
//
