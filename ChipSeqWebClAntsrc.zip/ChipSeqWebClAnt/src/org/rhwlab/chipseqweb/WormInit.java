/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseqweb;

import java.io.File;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import org.rhwlab.db.MySql;
import java.util.List;

/**
 *
 * @author gevirl
 */
// set the Foasmid ID for bombardment strain
public class WormInit {

    public WormInit() throws Exception {
//        Annotation.remapChromo = false;
//        gff3 = new ModelFromGFF(new File("/net/waterston/vol9/References/WS245/AllWormBase.gff3"));
    }

    static public void setDescriptions() throws Exception {
        ResultSet allExps = MySql.getMySql().execute("select * from ChipExperiment");
        while (allExps.next()) {
            String species = allExps.getString("Species");
            String expID = allExps.getString("ExpID");
            String gene = allExps.getString("Gene");
            String genotype = allExps.getString("Genotype");
            setExpDescs(expID, species, gene);
            if (species.equals("CElegans")) {
                setGenModDesc(expID, genotype);
            }

        }
    }

    static public void setGenModDesc(String expID, String genotype) throws Exception {
        PreparedStatement updateState = MySql.getMySql().getStatement("update ChipExperiment set GeneticModDesc = ?  where ExpID = ?");
        updateState.setString(1, genotype);
        updateState.setString(2, expID);
        updateState.execute();
    }

    static public void setExpDescs(String expID, String species, String gene) throws Exception {
        PreparedStatement updateState = MySql.getMySql().getStatement("update ChipExperiment set ExpIPDesc = ? , ExpCtlDesc = ? where ExpID = ?");
        updateState.setString(2, setCtlDesc(species, gene));
        updateState.setString(1, setIpDesc(species, gene));
        updateState.setString(3, expID);
        updateState.execute();
    }

    static public String setCtlDesc(String species, String gene) {
        if (species.equals("Dmel")) {
            return String.format("Input control for ChIP-seq on transgenic flies expressing %s-eGFP fusion proteins.", gene);
        } else {
            return String.format("This is the ChIP-seq control of transgenic worms expressing %s-eGFP fusion proteins.", gene);
        }
    }

    static public String setIpDesc(String species, String gene) {
        if (species.equals("Dmel")) {
            return String.format("ChIP-seq on transgenic flies expressing %s-eGFP fusion proteins. The IP was performed using an anti-GFP antibody.", gene);
        } else {
            return String.format("ChIP-seq on transgenic worms expressing %s-eGFP fusion proteins. The IP was performed using an anti-GFP antibody.", gene);
        }
    }

    static public void setGenotype() throws Exception {
        ResultSet allExps = MySql.getMySql().execute("select * from ChipExperiment");
        while (allExps.next()) {
            String strain = allExps.getString("Strain");
            String expID = allExps.getString("ExpID");
            setGenotype(expID, strain);
        }
    }

    static public String setGenotype(String expID, String strain) throws Exception {
        PreparedStatement state = MySql.getMySql().getStatement("Select * from Strain where StrainID = ?");
        state.setString(1, strain);
        ResultSet rs = state.executeQuery();
        if (rs.next()) {
            String genotype = rs.getString("Genotype");
            PreparedStatement updateState = MySql.getMySql().getStatement("update ChipExperiment set Genotype = ? where ExpID = ?");
            updateState.setString(1, genotype);
            updateState.setString(2, expID);
            updateState.execute();
            return genotype;
        }
        return null;
    }

    static public void setCRISPR() throws Exception {
        ResultSet allExps = MySql.getMySql().execute("select * from ChipExperiment");
        while (allExps.next()) {
            String method = allExps.getString("Method");
            String strain = allExps.getString("Strain");
            String expID = allExps.getString("ExpID");
            if (method.equals("CRISPR")) {
                //               setCRISPRGuide(expID, strain);
                //              setCRISPRTags(expID, strain);
                setCRISPRSite(expID, strain);
            }
        }
    }

    static public void setCRISPRGuide(String expID, String strain) throws Exception {
        PreparedStatement state = MySql.getMySql().getStatement("Select * from Strain where StrainID = ?");
        state.setString(1, strain);
        ResultSet rs = state.executeQuery();
        if (rs.next()) {
            String rescueID = rs.getString("Rescue");
            if (rescueID == null) {
                int iudfguigsd = 0;
            } else {
                String constructID = constructID(rescueID);
                PreparedStatement dsState = MySql.getMySql().getStatement("Select * from dsHybridDesign where ConstructID = ?");
                dsState.setString(1, constructID);
                ResultSet dsRS = dsState.executeQuery();
                if (dsRS.next()) {
                    String guide = dsRS.getString("GuideRNA");
                    PreparedStatement chipState = MySql.getMySql().getStatement(
                            "update ChipExperiment set GuideSequence = ? where ExpID = ?");
                    chipState.setString(1, guide);
                    chipState.setString(2, expID);
                    chipState.execute();

                }
            }
        }
    }

    static public String constructID(String rescueID) {
        String[] tokens = rescueID.split("_");
        if (tokens.length >= 4) {
            return String.format("%s_%s_%s_%s", tokens[0], tokens[1], tokens[2], tokens[3]);
        } else {
            int sduifhsdui = 0;
        }
        return "";
    }

    static public void setCRISPRSite(String expID, String strain) throws Exception {
        PreparedStatement state = MySql.getMySql().getStatement("Select * from Strain where StrainID = ?");
        state.setString(1, strain);
        ResultSet rs = state.executeQuery();
        if (rs.next()) {
            String rescueID = rs.getString("Rescue");
            if (rescueID != null) {
                String constructID = constructID(rescueID);
                PreparedStatement dsState = MySql.getMySql().getStatement("Select * from dsHybridDesign where ConstructID = ?");
                dsState.setString(1, constructID);
                ResultSet dsRS = dsState.executeQuery();
                if (dsRS.next()) {
                    String transcript = dsRS.getString("Transcript");
                    String guide = dsRS.getString("GuideRNA");
                    String tagLoc = dsRS.getString("EditLocation");
                    String chromo = dsRS.getString("Chromosome");
                    String assembly = dsRS.getString("Assembly");
                    int coord = dsRS.getInt("Coordinate");
                    int coordend = dsRS.getInt("CoordinateEnd");
                    String gene = dsRS.getString("Gene");
                    if (chromo == null) {
                        System.out.printf("%s , %s\n", constructID, gene);
                    } else {
                        PreparedStatement chipState = MySql.getMySql().getStatement(
                                "update ChipExperiment set Chromosome = ? , Start = ? , End = ? , Assembly = ? where ExpID = ?");
                        chipState.setString(1, chromo);
                        chipState.setInt(2, coord);
                        chipState.setInt(3, coordend);
                        chipState.setString(4, assembly);
                        chipState.setString(5, expID);
                        chipState.execute();
                    }

                }
            }
        }
    }

    static public void setCRISPRTags(String expID, String strain) throws Exception {
        PreparedStatement state = MySql.getMySql().getStatement("Select * from Strain where StrainID = ?");
        state.setString(1, strain);
        ResultSet rs = state.executeQuery();
        if (rs.next()) {
            String rescueID = rs.getString("Rescue");
            if (rescueID != null) {
                String constructID = constructID(rescueID);
                PreparedStatement dsState = MySql.getMySql().getStatement("Select * from dsHybridDesign where ConstructID = ?");
                dsState.setString(1, constructID);
                ResultSet dsRS = dsState.executeQuery();
                if (dsRS.next()) {
                    String transcript = dsRS.getString("Transcript");
                    String guide = dsRS.getString("GuideRNA");
                    String tagLoc = dsRS.getString("EditLocation");
                    String chromo = dsRS.getString("Chromosome");
                    String assembly = dsRS.getString("Assembly");
                    int coord = dsRS.getInt("Coordinate");
                    String gene = dsRS.getString("Gene");

                    if (tagLoc != null) {
                        String tagID = ChipHelper.nextID("ChipTag", "TagID", expID, "getTagId");
                        String tagName = "C-terminal";
                        if (tagLoc.equals("N")) {
                            tagName = "N-terminal";
                        }
                        PreparedStatement tagState = MySql.getMySql().getStatement("insert into ChipTag (TagID,ExpID,Name,Location) values (?,?,?,?)");
                        tagState.setString(1, tagID);
                        tagState.setString(2, expID);
                        tagState.setString(3, "eGFP");
                        tagState.setString(4, tagName);
                        tagState.execute();

                        tagID = ChipHelper.nextID("ChipTag", "TagID", expID, "getTagId");
                        tagState.setString(1, tagID);
                        tagState.setString(2, expID);
                        tagState.setString(3, "3xFLAG");
                        tagState.setString(4, tagName);
                        tagState.execute();
                    }
                }
            }
        }
    }

    static public void setBombTags() throws Exception {
        ResultSet allExps = MySql.getMySql().execute("select * from ChipExperiment");
        while (allExps.next()) {
            String method = allExps.getString("Method");
            String strain = allExps.getString("Strain");
            String expID = allExps.getString("ExpID");
            if (method.equals("bombardment")) {
                setBombTags(expID, strain);
            }
        }
    }

    static public void setBombTags(String expID, String strain) throws Exception {

        String tagID = ChipHelper.nextID("ChipTag", "TagID", expID, "getTagId");
        PreparedStatement tagState = MySql.getMySql().getStatement("insert into ChipTag (TagID,ExpID,Name,Location) values (?,?,?,?)");
        tagState.setString(1, tagID);
        tagState.setString(2, expID);
        tagState.setString(3, "eGFP");
        tagState.setString(4, "C-terminal");
        tagState.execute();

        tagID = ChipHelper.nextID("ChipTag", "TagID", expID, "getTagId");
        tagState.setString(1, tagID);
        tagState.setString(2, expID);
        tagState.setString(3, "3xFLAG");
        tagState.setString(4, "C-terminal");
        tagState.execute();
    }

    static public void dsHybridDesignUpdate() throws Exception {
        File gff2 = new File("/net/waterston/vol9/References/WS235/c_elegans.WS235.annotations.UTR.gff2");
        UTR utr = new UTR(gff2);

        ResultSet allDesigns = MySql.getMySql().execute("select * from dsHybridDesign");
        while (allDesigns.next()) {
            String transcript = allDesigns.getString("Transcript");
            String constructID = allDesigns.getString("ConstructID");
            if (transcript != null) {

                List<String[]> utrList = utr.getLikeUTR(transcript);
                if (utrList.isEmpty()) {
                    System.out.printf("%s no UTR\n", transcript);
                } else if (utrList.size() == 1 || UTR.sameUTR(utrList)) {
                    // update the db
                    String[] tokens = utrList.get(0);
                    String chromosome = tokens[0].replace("CHROMOSOME_", "");
                    int loc;
                    if (tokens[6].equals("+")) {
                        loc = Integer.valueOf(tokens[3]) - 3;
                    } else {
                        loc = Integer.valueOf(tokens[4]) + 3;
                    }
                    PreparedStatement state = MySql.getMySql().getStatement("update dsHybridDesign set Chromosome = ?, Coordinate = ? , Assembly = ? where ConstructID = ?");
                    state.setString(1, chromosome);
                    state.setInt(2, loc);
                    state.setString(3, "ce11");
                    state.setString(4, constructID);
                    state.execute();

                } else {
                    System.out.printf("%s multiple UTR\n", transcript);
                }
            }
        }

    }

    static public void setFosmidID() throws Exception {
        ResultSet allExps = MySql.getMySql().execute("select * from ChipExperiment");
        while (allExps.next()) {
            String method = allExps.getString("Method");
            String strain = allExps.getString("Strain");
            String expID = allExps.getString("ExpID");
            if (method.equals("bombardment")) {
                setFosmidID(expID, strain);
            }
        }
    }

    // set the fosmid ID for a bombardment experiment
    static public void setFosmidID(String expID, String strain) throws Exception {
        PreparedStatement state = MySql.getMySql().getStatement("Select * from Strain where StrainID = ?");
        state.setString(1, strain);
        ResultSet rs = state.executeQuery();
        if (rs.next()) {
            String constructType = rs.getString("ConstructType");
            String constructID = rs.getString("ConstructID");
            if (constructType != null) {
                if (constructType.equalsIgnoreCase("Fosmid")) {
                    PreparedStatement fosmidState = MySql.getMySql().getStatement("Select * from Fosmid where FosmidID = ?");
                    fosmidState.setString(1, constructID);
                    ResultSet fosrs = fosmidState.executeQuery();
                    if (fosrs.next()) {
                        String fosmidName = fosrs.getString("FosmidName");
                        System.out.println(fosmidName);
                        PreparedStatement updateState = MySql.getMySql().getStatement("update ChipExperiment set Reagent = ? where ExpID = ?");
                        updateState.setString(1, fosmidName);
                        updateState.setString(2, expID);
                        updateState.execute();
                    }
                }
            }
        }
    }

    static public void main(String[] args) throws Exception {

//        WormInit.setBombTags();
        WormInit.setCRISPR();
    }
}
