/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseqweb;

import java.io.File;
import java.nio.file.Files;
import java.util.List;

/**
 *
 * @author gevirl
 */
public class FixFileSizes {
    static public void main(String[] args)throws Exception {
        List list = ChipHelper.getAll("ChipSequencingFile", "FileID");
        for (Object obj : list){
            ChipSequencingFile seqFile = (ChipSequencingFile)obj;
            File file = new File(seqFile.getLocalFilePath());
            long size = Files.size(file.toPath());
            System.out.printf("%s : %d\n",file.getPath(),size);
            seqFile.setFileSize(size);
            ChipHelper.update(obj);
        }
        int uiadifuhs=0;
    }
}
