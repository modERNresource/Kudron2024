/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseqweb.commandline;

import java.io.PrintWriter;
import java.util.Date;

/**
 *
 * @author gevirl
 */
public class CommandLine {
    static public void main(String[] args)throws Exception {
        PrintWriter writer = new PrintWriter("/net/waterston/vol9/commandline.out");
        Date date = new Date();
        writer.println(date.toLocaleString());
        writer.close();
    }
}
