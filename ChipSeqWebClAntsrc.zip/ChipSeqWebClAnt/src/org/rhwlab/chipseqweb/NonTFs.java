/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseqweb;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.TreeSet;

/**
 *
 * @author gevirl
 */
public class NonTFs {
    TreeSet<String> wormNonTFs = new TreeSet<>();
    
    public NonTFs() throws Exception {
        InputStream inStream = this.getClass().getResourceAsStream("/org/rhwlab/chipseqweb/WormNonTFs");
        BufferedReader reader = new BufferedReader(new InputStreamReader(inStream));
        String nonTF = reader.readLine();
        while (nonTF != null){
            wormNonTFs.add(nonTF);
            nonTF = reader.readLine();
        }
        reader.close();        
    }  
    
    public boolean isNonTF(String species,String gene){
        if (species.equals("CElegans")){
            return wormNonTFs.contains(gene);
        }
        return false;
    }
}
