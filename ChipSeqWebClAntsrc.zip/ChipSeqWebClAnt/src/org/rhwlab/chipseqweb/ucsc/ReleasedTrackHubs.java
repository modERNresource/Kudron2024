/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseqweb.ucsc;

import java.io.File;
import java.io.PrintWriter;
import org.rhwlab.chipseqweb.beans.Directory;

/**
 *
 * @author gevirl
 */
// form the UCSC trackhb for all the released datasets
// must be run on epic machine
// based on FileTable files 
public class ReleasedTrackHubs {

    File speciesDir;
    File hubDir;
    String fullSpeciesName;
    String speciesLabel;
    String genome;

    public ReleasedTrackHubs(File speciesDir, File hubDir) {
        this.speciesDir = speciesDir;
        this.hubDir = hubDir;
        if (speciesDir.getName().equals("fly")) {
            this.fullSpeciesName = "D. melanogaster";
            this.speciesLabel = "Dmel";
            this.genome = "dm6";
        }
        if (speciesDir.getName().equals("worm")) {
            this.fullSpeciesName = "C. elegans";
            speciesLabel = "CElegans";
            this.genome = "ce11";
        }
    }

    // construc a trackhub from the experiments in the species directory and put resulting trackhub in the hubDir
    public void buildHub() throws Exception {
        File genomeTxtFile = buildHubTxtFile();
        File trackFile = buildGenomesTxtFile(genomeTxtFile);
        buildTrackDbFile(trackFile);
    }

    private File buildHubTxtFile() throws Exception {
        String hubLabel = String.format("modERN %s ChIP-seq", fullSpeciesName);
        File hubTxt = new File(hubDir, String.format("%s_hub.txt", speciesLabel));
        PrintWriter writer = new PrintWriter(hubTxt);
        writer.printf("hub %s\n", hubLabel.replaceAll(" ", "_"));;
        writer.printf("shortLabel %s\n", hubLabel);
        writer.printf("longLabel %s\n", hubLabel);
        File genomeFile = new File(hubDir, String.format("%s_genomes.txt", speciesLabel));
        writer.printf("genomesFile %s \n", genomeFile.getName());
        writer.println("email gevirl@uw.edu");
        writer.close();
        hubTxt.setReadable(true, false);
        return genomeFile;
    }

    private File buildGenomesTxtFile(File txt) throws Exception {
        PrintWriter writer = new PrintWriter(txt);
        writer.printf("genome %s\n", genome);
        File trackDbFile = new File(hubDir, String.format("%s_trackDb.txt", genome));
        writer.printf("trackDb %s \n", trackDbFile.getName());
        writer.close();
        txt.setReadable(true, false);
        return trackDbFile;
    }

    private void buildTrackDbFile(File track) throws Exception {
        Directory dir = new Directory();
        dir.getEpicDirectory();
        PrintWriter writer = new PrintWriter(track);

        // add the aggregate peaks file and the peaks wig file
        if (this.speciesLabel.equals("CElegans")) {
            String bedUrl = String.format("http://waterston.gs.washington.edu/ChipSeqPipeline/AllWormPeaks.TF.noDups.clustered.bb");
            makeTrack(null,"TF_Peaks", "TF_Peaks", "pack", bedUrl, "bigBed 9 +", writer, 1, true);

            String wigURL = String.format("http://waterston.gs.washington.edu/ChipSeqPipeline/AllWormPeaks.TF.noDups.bw");
            makeTrack(null,"PeakSignal", "PeakSignal", "full", wigURL, "bigWig", writer, 2, false);

            String clUrl = String.format("http://waterston.gs.washington.edu/ChipSeqPipeline/AllWormPeaks.TF.noDups.clusters.bb");
            makeTrack(null,"MetaPeaks", "MetaPeaks", "pack", clUrl, "bigBed 9", writer, 3, true);
            
            String primeUrl = String.format("http://waterston.gs.washington.edu/ChipSeqPipeline/AllWormPeaks.TF.noDups.clusters.distance.bb");
            makeTrack(null,"PrimaryTarget", "PrimaryTarget", "pack", primeUrl, "bigBed 11 +", writer, 4, false);      
            
            String altUrl = String.format("http://waterston.gs.washington.edu/ChipSeqPipeline/AllWormPeaks.TF.noDups.clusters.altdist.bb");
            makeTrack(null,"AlternateTarget", "AlternateTarget", "pack", altUrl, "bigBed 11 +", writer, 5, false);            
/*            
            String twoUrl = String.format("http://waterston.gs.washington.edu/ChipSeqPipeline/AllWormPeaks.TF.noDups.clusters.twoTarget.bb");
            makeTrack("TwoTarget", "TwoTarget", "pack", twoUrl, "bigBed 9 +", writer, 4, false);            

            String posUrl = String.format("http://waterston.gs.washington.edu/ChipSeqPipeline/AllWormPeaks.TF.noDups.clusters.posTarget.bb");
            makeTrack("PosTarget", "PosTarget", "pack", posUrl, "bigBed 9 +", writer, 4, false);

            String negUrl = String.format("http://waterston.gs.washington.edu/ChipSeqPipeline/AllWormPeaks.TF.noDups.clusters.negTarget.bb");
            makeTrack("NegTarget", "NegTarget", "pack", negUrl, "bigBed 9 +", writer, 5, false);

            String bothUrl = String.format("http://waterston.gs.washington.edu/ChipSeqPipeline/AllWormPeaks.TF.noDups.clusters.bothTarget.bb");
            makeTrack("BothTarget", "BothTarget", "pack", bothUrl, "bigBed 9 +", writer, 6, false);
            
            String noneUrl = String.format("http://waterston.gs.washington.edu/ChipSeqPipeline/AllWormPeaks.TF.noDups.clusters.noneTarget.bb");
            makeTrack("NoTarget", "NoTarget", "pack", noneUrl, "bigBed 9 +", writer, 7, false); 
            
            String conUrl = String.format("http://waterston.gs.washington.edu/ChipSeqPipeline/AllWormPeaks.TF.noDups.clusters.consvTarget.bb");
            makeTrack("ConservativeTarget", "ConservativeTarget", "pack", conUrl, "bigBed 9 +", writer, 8, false);
*/
            String modelPosUrl = String.format("http://waterston.gs.washington.edu/ChipSeqPipeline/c_elegans.PRJNA13758.WS285.annotations.wormbase.pos.bb");
            makeGeneModlTrack(writer, "WS285_+Strand", "c_elegans.PRJNA13758.WS285_+Strand", modelPosUrl, "pack", 6);
            
            String modelNegUrl = String.format("http://waterston.gs.washington.edu/ChipSeqPipeline/c_elegans.PRJNA13758.WS285.annotations.wormbase.neg.bb");
            makeGeneModlTrack(writer, "WS285_-Strand", "c_elegans.PRJNA13758.WS285_-Strand", modelNegUrl, "pack", 17);            
            
            
            // composite track for macs2 beds
 /*           
            int i = 11;
            String macLabel = "MACS2";
            String type = "bigBed 5";
            makeCompositeTrack(macLabel,macLabel,"hide", type, writer, i, false);
            ++i;
            
            for (int c = 2; c <= 50; ++c) {

                String name = String.format("AllWormPeaks.TF.noDups.macs2.%d.bb", c);
                String macs2URL = String.format("http://waterston.gs.washington.edu/ChipSeqPipeline/%s", name);
                String[] tokens = name.split("\\.");
                String label = String.format("MACS2_Clusters_%d", c);
                makeTrack(macLabel,label, label, "dense", macs2URL, type, writer, i, false);
                ++i;

            }
    */         
 /*            
            String allbedUrl = String.format("http://waterston.gs.washington.edu/ChipSeqPipeline/AllWormPeaks.bb");
            makeTrack("AllPeak", "AllPeak", "pack", allbedUrl, "bigNarrowPeak", writer, i,false);     
            ++i;

            String clusterBed200Url = String.format("http://waterston.gs.washington.edu/ChipSeqPipeline/AllWormPeaks.cluster.200.bb");
            makeTrack("PeakClusters_200", "PeakClusters_200", "dense", clusterBed200Url, "bigBed 6 +", writer, i,false);
            ++i;

            String clusterBed50Url = String.format("http://waterston.gs.washington.edu/ChipSeqPipeline/AllWormPeaks.cluster.50.bb");
            makeTrack("PeakClusters_50", "PeakClusters_50", "dense", clusterBed50Url, "bigBed 6 +", writer, i,false);
            ++i;
             */
        }
        if (this.speciesLabel.equals("Dmel")) {
            String bedUrl = String.format("http://waterston.gs.washington.edu/ChipSeqPipeline/AllFlyPeaks.TF.noDups.clustered.bb");
            makeTrack(null,"TF_Peaks", "TF_Peaks", "pack", bedUrl, "bigBed 9 +", writer, 1, true);

            String wigURL = String.format("http://waterston.gs.washington.edu/ChipSeqPipeline/AllFlyPeaks.TF.noDups.bw");
            makeTrack(null,"PeakSignal", "PeakSignal", "full", wigURL, "bigWig", writer, 2, false);
            
            String clUrl = String.format("http://waterston.gs.washington.edu/ChipSeqPipeline/AllFlyPeaks.TF.noDups.clusters.bb");
            makeTrack(null,"MetaPeaks", "MetaPeaks", "pack", clUrl, "bigBed 9", writer, 3, true);
            
            String primeUrl = String.format("http://waterston.gs.washington.edu/ChipSeqPipeline/AllFlyPeaks.TF.noDups.clusters.distance.bb");
            makeTrack(null,"PrimaryTarget", "PrimaryTarget", "pack", primeUrl, "bigBed 11 +", writer, 4, false);      
            
            String altUrl = String.format("http://waterston.gs.washington.edu/ChipSeqPipeline/AllFlyPeaks.TF.noDups.clusters.altdist.bb");
            makeTrack(null,"AlternateTarget", "AlternateTarget", "pack", altUrl, "bigBed 11 +", writer, 5, false);              
        }

        writer.close();
        track.setReadable(true, false);
    }

        static private void makeCompositeTrack(String shortLabel, String longLabel, String vis, String type, PrintWriter writer, int priority, boolean rbgOn) {
        writer.printf("track %s\n", shortLabel);
        writer.println("compositeTrack on");
        writer.println("allButtonPair on");
        writer.printf("shortLabel %s\n", shortLabel);
        writer.printf("longLabel %s\n", longLabel);
        writer.printf("type %s\n", type);
        writer.println("color 0,0,0");
        writer.println("maxHeightPixels 128:40:15");
        writer.printf("visibility %s\n", vis);
        writer.println("autoScale on");
        writer.printf("priority %d\n", priority);
        if (rbgOn) {
            writer.println("itemRgb on");
        }

        writer.println();
    }
    static private void makeTrack(String parent,String shortLabel, String longLabel, String vis, String url, String type, PrintWriter writer, int priority, boolean rbgOn) {

        writer.printf("track %s\n", shortLabel);
        writer.printf("shortLabel %s\n", shortLabel);
        writer.printf("longLabel %s\n", longLabel);
        if (parent != null){
            writer.printf("parent %s\n", parent);
        }        
        writer.printf("type %s\n", type);
        writer.println("color 0,0,0");
        writer.println("maxHeightPixels 128:40:15");
        writer.printf("visibility %s\n", vis);
        writer.println("autoScale on");
        writer.printf("bigDataUrl %s\n", url);
        writer.printf("priority %d\n", priority);
        if (rbgOn) {
            writer.println("itemRgb on");
        }

        writer.println();
    }

    static private void makeGeneModlTrack(PrintWriter writer, String shortLabel, String longLabel, String url, String vis, int priority) {
        writer.printf("track %s\n", shortLabel);
        writer.printf("shortLabel %s\n", shortLabel);
        writer.printf("longLabel %s\n", longLabel);
        writer.printf("type %s\n", "bigGenePred");
        writer.printf("visibility %s\n", vis);
        writer.printf("bigDataUrl %s\n", url);
        writer.printf("priority %d\n", priority);
        writer.println("baseColorDefault genomicCodons");
        writer.println("labelFields name2,geneName");
        writer.println("defaultLabelFields name2,geneName");
        writer.println();
    }

    static public void main(String[] args) throws Exception {
        Directory dir = new Directory();
        File hubDir = new File(dir.getEpicHtmlDir(), "modERN");

        ReleasedTrackHubs wormHub = new ReleasedTrackHubs(new File(dir.getWormEpicDirectory()), hubDir);
        wormHub.buildHub();

        ReleasedTrackHubs flyHub = new ReleasedTrackHubs(new File(dir.getFlyEpicDirectory()), hubDir);
        flyHub.buildHub();

    }
}
