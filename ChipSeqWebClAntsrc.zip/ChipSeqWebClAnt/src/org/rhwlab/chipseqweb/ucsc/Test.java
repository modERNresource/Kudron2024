/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseqweb.ucsc;

import java.util.ArrayList;
import java.util.Map;
import java.util.Random;

/**
 *
 * @author gevirl
 */
public class Test {
    public static void main(String[] args) throws Exception{
        int n = Runtime.getRuntime().availableProcessors();
        int iuhfuis=0;
        
        Map<String,String> env = System.getenv();
        ArrayList<String> list = new ArrayList<>();
        for (String s : env.keySet()){
            list.add(s);
        }
        
        int i =2;
        System.out.printf("%d\t%s\t%s\t%s\t%s\n",list.size(), list.get(0),list.get(1),list.get(2),list.get(3));
        list.remove(i);
        System.out.printf("%d\t%s\t%s\t%s\t%s\n",list.size(), list.get(0),list.get(1),list.get(2),list.get(3));
        int aisudhf=0;
    }
}
