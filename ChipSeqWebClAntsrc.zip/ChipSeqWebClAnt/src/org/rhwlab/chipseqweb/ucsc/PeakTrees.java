/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseqweb.ucsc;

import htsjdk.samtools.util.Interval;
import htsjdk.samtools.util.IntervalTree;
import htsjdk.samtools.util.IntervalTree.Node;
import htsjdk.samtools.util.IntervalTreeMap;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;
import org.rhwlab.bedformat.BedBase;
import org.rhwlab.bedformat.BedInCluster;
import org.rhwlab.bedformat.Bed_9;
import org.rhwlab.bedformat.NarrowPeakBedRecord;
import org.rhwlab.chipseq.cluster.PeakTreeBed;

/**
 *
 * @author gevirl
 */
public class PeakTrees {

    PeakTreeBed[][] records;

    public PeakTrees(List<File> files) throws Exception {
        records = new PeakTreeBed[files.size()][];
        int i = 0;
        for (File file : files) {
            ArrayList<PeakTreeBed> list = readBed(file);
            records[i] = list.toArray(new PeakTreeBed[0]);
            ++i;
        }
        for (i = 1; i < records.length; ++i) {
            linkRecords(records[i - 1], records[i]);
        }
    }

    final public void linkRecords(PeakTreeBed[] parent, PeakTreeBed[] child) {
        int c = 0;
        int p = 0;
        while (p < parent.length) {
            if (parent[p].isWithin(child[c])) {
                parent[p].addChild(child[c]);
                ++c;
                if (c == child.length) {
                    return;
                }
            } else {
                ++p;
            }
        }
    }

    final public ArrayList<PeakTreeBed> readBed(File bed) throws Exception {
        ArrayList<PeakTreeBed> recList = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new FileReader(bed));
        String line = reader.readLine();
        while (line != null) {
            PeakTreeBed peakTreeBed = new PeakTreeBed(line);
            peakTreeBed.shortenNames();
            recList.add(peakTreeBed);
            line = reader.readLine();
        }
        reader.close();
        return recList;
    }

    // trims terminal nodes that exist for only one level
    // it is trimmed if a terminal node has a sibling
    public List<PeakTreeBed> trimmedTerminal() {
        List<PeakTreeBed> ret = new ArrayList<>();
        for (PeakTreeBed topRec : records[0]) {

            List<PeakTreeBed> termRecs = topRec.terminalRecords();
            for (PeakTreeBed rec : termRecs) {
                if (!rec.hasSiblings()) {
                    ret.add(rec);
                } else {
                    rec.unlink();
                }
            }
        }
        return ret;
    }

    // returns all the terminal records in the tree
    public List<PeakTreeBed> terminalRecs() {
        List<PeakTreeBed> ret = new ArrayList<>();
        for (PeakTreeBed topRec : records[0]) {
            for (PeakTreeBed rec : topRec.terminalRecords()) {
                ret.add(rec);
            }
        }
        return ret;
    }

    static public Bed_9 bestChoice(NarrowPeakBedRecord peak, IntervalTree intervalTree) {
        Bed_9 cluster = null;
        int apex = peak.getPeakLocation();

        Node node = intervalTree.minOverlapper(apex, apex);
        if (node != null) {
            cluster = (Bed_9) node.getValue();    // apex in a cluster
        }

        if (cluster == null) {
            Iterator iter = intervalTree.overlappers(peak.getStart(), peak.getEnd());
            ArrayList<Bed_9> list = new ArrayList<>();
            while (iter.hasNext()) {
                Node obj = (Node) iter.next();
                list.add((Bed_9) obj.getValue());
            }
            if (!list.isEmpty()) {
                if (list.size() == 1) {
                    cluster = list.get(0);
                } else {
                    // overlaps more than one cluster - pick closest
                    cluster = list.get(0);
                    int minD = distance(peak, cluster);
                    for (int i = 2; i < list.size(); ++i) {
                        int d = distance(peak, list.get(i));
                        if (d < minD) {
                            cluster = list.get(i);
                            minD = d;
                        }
                    }
                }
            }
        }
        return cluster;
    }

    static int distance(NarrowPeakBedRecord peak, Bed_9 cluster) {
        int l = peak.getPeakLocation();
        return Math.min(Math.abs(l - cluster.getStart()), Math.abs(l - cluster.getStart()));
    }

    public IntervalTreeMap formClusters() throws Exception {
        PrintStream dumpStream = new PrintStream("AllWormPeaks.TF.noDups.macs2.dump");
        IntervalTreeMap ret = new IntervalTreeMap<>();

        // get the trimmed terminal list of nodes
        List<PeakTreeBed> termList = trimmedTerminal();

        // move up the tree to birth parents
        List<PeakTreeBed> birthParents = new ArrayList<>();
        for (PeakTreeBed rec : termList){
            birthParents.add(rec.birthParent());
        }
                
        // organize by root parent
        TreeMap<PeakTreeBed,List<PeakTreeBed>> rootMap = new TreeMap<>();
        for (PeakTreeBed birthBed : birthParents){
            PeakTreeBed root = birthBed.rootParent();
            List<PeakTreeBed> list = rootMap.get(root);
            if (list == null){
                list = new ArrayList<>();
                rootMap.put(root, list);
            }
            list.add(birthBed);
        }
        
        // expand the birth parents to fill the space of their root
        for (PeakTreeBed root : rootMap.keySet()){
            if (root.getName().equals("2_narrowPeak47068")){
                for (PeakTreeBed b : rootMap.get(root)){
                    System.out.println(b.toString());
                }
            }
            List<PeakTreeBed> nodeList = rootMap.get(root);
            if (nodeList.size()>1){
                PeakTreeBed first = nodeList.get(0);
                first.setStart(root.getStart());
                
                PeakTreeBed lower = first;               
                for (int i=1 ; i<nodeList.size() ; ++i){
                    PeakTreeBed higher = nodeList.get(i);
                    int mid = (lower.getEnd() + higher.getStart())/2;
                    lower.setEnd(mid);
                    higher.setStart(mid+1);
                    lower = higher;
                }
                lower.setEnd(root.getEnd());
            }
            
            for (PeakTreeBed bed : nodeList){
                if (bed.getStart() >= bed.getEnd()){
                    int iasudhf=0;
                }
            }
        }
        
        // color the clusters
        String[] colors = {"0,0,255", "0,255,0", "255,0,0"};
        int c = 0;
        for (PeakTreeBed rec : birthParents) {
            Bed_9 cluster = new Bed_9(rec.getTokens());
            cluster.setItemRgb(colors[c]);
            ++c;
            if (c == colors.length) {
                c = 0;
            }                        
            dumpStream.printf("%s,%d,%d\t%s,%d,%d\n", rec.getName(), rec.getStart(), rec.getEnd(), cluster.getName(), cluster.getStart(), cluster.getEnd());
            Interval interval = new Interval(cluster.getChromosome(), cluster.getStart(), cluster.getEnd(), false, cluster.getName());
            ret.put(interval, cluster);
        }
        dumpStream.close();
        return ret;
    }

    public static BedInCluster assignToCluster(NarrowPeakBedRecord peak, IntervalTreeMap clusters, String noClusterColor) {

        if (peak.getChromosome().equals("chrIII")) {
            if (peak.getStart() == 10809303) {
                if (peak.getEnd() == 10809860) {
                    int sadf = 0;
                }
            }
        }
        Bed_9 bed9Peak = new Bed_9(peak.getTokens());
        bed9Peak.setThickStart(peak.getPeakLocation() - 2);
        bed9Peak.setThickEnd(peak.getPeakLocation() + 2);

        BedInCluster ret = new BedInCluster(bed9Peak.getTokens());

        IntervalTree intervalTree = clusters.debugGetTree(peak.getChromosome());
        if (intervalTree != null) {
            Bed_9 cluster = bestChoice(peak, intervalTree);
            if (cluster != null) {
                ret.setItemRgb(cluster.getItemRgb());
                ret.setCluster(cluster.getName());
            } else {
                ret.setItemRgb(noClusterColor);
                ret.setCluster(null);
            }
        }
        return ret;
    }

    // cluster the TF peaks using the MACS2 tree clustering, fly and worm
    static public void main(String[] args) throws Exception {
 //       String[] bases = {"AllFlyPeaks.TF.noDups", "AllWormPeaks.TF.noDups"};
    String[] bases = { "AllFlyPeaks.TF.noDups"};
 //       File dir = new File("/data/www/site/waterston/html/ChipSeqPipeline");
        File dir = new File("/net/waterston/vol9/ChipSeqPipeline/test");
        for (String fileBase : bases) {
            File peakFile = new File(dir, fileBase + ".bed");
            File clusteredPeaks = new File(peakFile.getPath().replace(".bed", ".cluster.bed"));
            File clusterFile = new File(peakFile.getPath().replace(".bed", ".clusters"));

            List<File> files = new ArrayList<>();
            for (int i = 2; i <= 50; ++i) {
                files.add(new File(dir, String.format("%s.macs2.%d.bed", fileBase, i)));
            }
            PeakTrees trees = new PeakTrees(files);
            IntervalTreeMap clusters = trees.formClusters();

            String black = "0,0,0";

            // assign each peak to a cluster or leave it unclustered
            TreeMap<String, List<BedBase>> clusterMap = new TreeMap<>();
            String singleton = "Singleton";
            int c = 1;
            PrintStream stream = new PrintStream(clusteredPeaks);
            BufferedReader reader = new BufferedReader(new FileReader(peakFile));
            String line = reader.readLine();
            while (line != null) {
                NarrowPeakBedRecord peak = new NarrowPeakBedRecord(line);
                if (!peak.getChromosome().equals("chrM")) {
                    BedInCluster assignedPeak = assignToCluster(peak, clusters, black);
                    if (assignedPeak.getCluster() == null) {
                        assignedPeak.setCluster(String.format("%s_%d", singleton, c));
                        ++c;
                    }
                    List<BedBase> bedList = clusterMap.get(assignedPeak.getCluster());
                    if (bedList == null) {
                        bedList = new ArrayList<>();
                        clusterMap.put(assignedPeak.getCluster(), bedList);
                    }
                    bedList.add(assignedPeak);
                    stream.println(assignedPeak.toString());
                }
                line = reader.readLine();
            }
            reader.close();
            stream.close();

            PrintStream cStream = new PrintStream(clusterFile);
            for (String clName : clusterMap.keySet()) {
                List<BedBase> list = clusterMap.get(clName);
                if (list.size() > 1) {
                    // find the maximum peak length
                    int s = Integer.MAX_VALUE;
                    int e = 0;
                    int lenMax = 0;
                    for (BedBase bed : list) {
                        int len = bed.getEnd() - bed.getStart() + 1;
                        if (len > lenMax) {
                            lenMax = len;
                        }
                        if (s > bed.getStart()) {
                            s = bed.getStart();
                        }
                        if (e < bed.getEnd()) {
                            e = bed.getEnd();
                        }
                    }
                    // find any duplicates
                    int dups = 0;
                    if (list.size() > 1) {
                        IntervalTree tree = new IntervalTree();
                        for (BedBase bed : list) {
                            Node node = tree.find(bed.getStart(), bed.getEnd());
                            if (node == null) {
                                ArrayList<BedBase> beds = new ArrayList<>();
                                beds.add(bed);
                                tree.put(bed.getStart(), bed.getEnd(), beds);
                            } else {
                                ArrayList<BedBase> beds = (ArrayList<BedBase>) node.getValue();
                                beds.add(bed);
                            }
                        }
                        Iterator iter = tree.iterator();
                        while (iter.hasNext()) {
                            Node node = (Node) iter.next();
                            ArrayList<BedBase> beds = (ArrayList<BedBase>) node.getValue();
                            if (beds.size() > 1) {
                                dups = dups + beds.size();
                            }
                        }
                    }
                    cStream.printf("%s\t%d\t%d\t%s\t%d\t%d\t%d\n", list.get(0).getChromosome(), s, e, clName, list.size(), lenMax, dups);
                }
            }
            cStream.close();

            // add all the 
            PeakTreeBed[] top = trees.records[0];
            for (int i = 0; i < top.length; ++i) {
                int count = top[i].terminalNodeCount();
                if (count > 5) {
                    PeakTreeBed t = top[i];
                    System.out.printf("%s\t%d\t%d : %d\n", t.getChromosome(), t.getStart(), t.getEnd(), count);
                    int iusdfh = 0;
                }
            }
        }
        int sakdfh = 0;
    }
}
