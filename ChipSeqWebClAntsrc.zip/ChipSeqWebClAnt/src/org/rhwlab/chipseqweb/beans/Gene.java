/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseqweb.beans;

import org.rhwlab.gene.model.ModelFromGFF;

/**
 *
 * @author gevirl
 */
public class Gene {
    String common;
    String sequence;
    String wbGene;
    
    public Gene(String name,ModelFromGFF gff){
        String[] names = gff.geneNameTriplet(name.replaceAll(" ", ""));
        if (names == null) return;
        this.common = names[1];
        this.sequence = names[0];
        this.wbGene = names[2];
    }
    public String getCommon(){
        return common;
    }
    public String getWBGene(){
        return wbGene;
    }
}
