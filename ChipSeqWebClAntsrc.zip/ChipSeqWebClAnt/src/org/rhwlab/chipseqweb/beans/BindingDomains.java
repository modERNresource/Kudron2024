/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseqweb.beans;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.TreeMap;
import java.util.TreeSet;
import org.rhwlab.chipseqweb.ChipExperiment;
import org.rhwlab.chipseqweb.ChipHelper;
import org.rhwlab.chipseqweb.HibernateUtil;
import org.rhwlab.chipseqweb.NonTFs;
import org.rhwlab.gene.model.ModelFromGFF;

/**
 *
 * @author gevirl
 */
public class BindingDomains {

    String[] heads;
    TreeMap<String, Integer> columnMap = new TreeMap<>();
    TreeMap<String, String> domainMap = new TreeMap<>();

    public BindingDomains(File tsv, ModelFromGFF gff, String geneColumn, String domainColumn) throws Exception {
        BufferedReader reader = new BufferedReader(new FileReader(tsv));
        String line = reader.readLine();
        heads = line.split("\t");
        int i = 0;
        for (String head : heads) {
            columnMap.put(head, i);
            ++i;
        }
        int domainCol = columnMap.get(domainColumn);
        int geneCol = columnMap.get(geneColumn);
        line = reader.readLine();
        while (line != null) {
            String[] tokens = line.split("\t");
            if (tokens[1].equals("lsy-12")) {
                int aiuehf = 0;
            }
            String s = tokens[geneCol];
            Gene g = new Gene(s, gff);
            String wbGene = g.getWBGene();
            if (wbGene == null) {
                System.out.printf("Not found: %s\n", s);
            } else {
                domainMap.put(wbGene, tokens[domainCol]);
            }
            line = reader.readLine();
        }
        reader.close();
    }

    public String getDomain(String wbgene) {
        return domainMap.get(wbgene);
    }

    static public void main(String[] args) throws Exception {
        File tsv = new File("/net/waterston/vol9/ChipSeqPipeline/wormDomains.tsv");
        File gffFile = new File("/net/waterston/vol9/WS285/c_elegans.PRJNA13758.WS285.annotations.wormbase.gff3");
        ModelFromGFF gff = new ModelFromGFF(gffFile);
//        BindingDomains bd = new BindingDomains(tsv, gff, "Sequence name", "DBD");
        BindingDomains bd = new BindingDomains(tsv, gff, "WBGeneID", "DBD");
        NonTFs non = new NonTFs();

        TreeSet<String> missing = new TreeSet<>();
        for (Object obj : ChipHelper.allExperiments("CElegans")) {
            ChipExperiment exp = (ChipExperiment) obj;
            if (!non.isNonTF("CElegans", exp.getGene())) {
                if (exp.getToEpic() != null) {
                    if (exp.getToEpic()) {
                        Gene g = new Gene(exp.getGene(), gff);
                        String domain = bd.getDomain(g.getWBGene());
                        if (domain == null) {
                            missing.add(exp.getGene());                         
                        } else {
                            exp.setDomain(domain);
                            ChipHelper.update(exp);
                        }
                    }
                }
            }
        }
        for (String tf : missing){
            System.out.println(tf);
        }
        HibernateUtil.shutdown();
    }
}
