/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseqweb.beans;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.security.MessageDigest;

/**
 *
 * @author gevirl
 */
public class UtilsURL {
    static public long download(URL url,File outputFile) throws Exception {
        URLConnection connect = url.openConnection();

        InputStream inStream = connect.getInputStream();
        long fileTotal = connect.getContentLengthLong();
        long fileCurrent = 0;
        FileOutputStream outStream = new FileOutputStream(outputFile);
        byte[] b = new byte[4096];
        while (fileCurrent < fileTotal) {

            int n = inStream.read(b);
            if (n > 0) {
                outStream.write(b, 0, n);
                fileCurrent = fileCurrent + n;
                outStream.flush();
            } else {
                int usduihfuish = 0;
            }
        }
        inStream.close();
        outStream.getChannel().force(true);
        outStream.close();   
        
        return fileTotal;
    }
}
