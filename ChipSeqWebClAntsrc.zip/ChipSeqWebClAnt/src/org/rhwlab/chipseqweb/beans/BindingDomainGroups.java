/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseqweb.beans;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.TreeMap;

/**
 *
 * @author gevirl
 */
public class BindingDomainGroups {
    TreeMap<String,String> map = new TreeMap<>(); // binding domain -> group
    public BindingDomainGroups()throws Exception{
        BufferedReader reader = new BufferedReader(new FileReader("/net/waterston/vol9/ChipSeqPipeline/WormExpDomains.tsv"));
        String line = reader.readLine();
        while(line != null){
            String[] tokens = line.split("\t");
            map.put(tokens[0], tokens[2]);
            line = reader.readLine();
        }
        reader.close();
    }
    
    public String getDomainGroup(String domain){
        if (domain == null){
            return "";
        }
        return map.get(domain);
    }
}
