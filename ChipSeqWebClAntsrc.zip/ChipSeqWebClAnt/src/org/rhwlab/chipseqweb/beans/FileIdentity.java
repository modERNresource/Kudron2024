/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseqweb.beans;

import org.rhwlab.chipseqweb.ChipSequencingFile;

/**
 *
 * @author gevirl
 */
public class FileIdentity {
    Integer replicate;
    String type;
    Integer read;
    
    public FileIdentity(Integer replicate,String type,Integer read){
        this.read = read;
        this.replicate = replicate;
        this.type = type;
    }
    
    public void setFileIdentity(ChipSequencingFile seqFile){
        if (read != null){
            seqFile.setReadPair(read);
        }
        if (replicate != null){
            seqFile.setReplicate(replicate);
        }
        if (type != null){
            seqFile.setSeqType(type);
        }
    }
}
