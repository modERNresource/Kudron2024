/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseqweb;

import java.io.File;
import java.sql.Connection;
import org.hibernate.Session;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.SessionFactory;
import org.hibernate.SessionFactory.SessionFactoryOptions;
import org.hibernate.StatelessSession;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;


/**
 * Hibernate Utility class with a convenient method to get Session Factory
 * object.
 *
 * @author gevirl
 */
public class HibernateUtil {

    private static final SessionFactory sessionFactory;
    
    static {
        try {
            
            // Create the SessionFactory from standard (hibernate.cfg.xml) 
            // c/onfig file.
 //           Configuration config = new Configuration();
//            Configuration config1 = config.configure(new File("/net/waterston/vol2/home/gevirl/NetBeansProjects/ChipSeqWebCL/src/hibernate.cfg.xml"));
 //           Configuration config2 = new Configuration().configure("/hibernate.cfg.xml");
//            sessionFactory = new Configuration().configure("/hibernate.cfg.xml").buildSessionFactory(new StandardServiceRegistryBuilder().build());
            
            sessionFactory = new AnnotationConfiguration().configure().buildSessionFactory();
            SessionFactoryOptions opt = sessionFactory.getSessionFactoryOptions();
            int iqef=0;

        } catch (Throwable ex) {
            // Log the exception. 
            System.err.println("Initial SessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }
    
    public static SessionFactory getSessionFactory() {
        
        return sessionFactory;
    }
    public static void shutdown() {
        // Close caches and connection pools
        getSessionFactory().close();
    }  
    
    static public void main(String[] args )throws Exception {
        SessionFactory f = HibernateUtil.getSessionFactory();
        StatelessSession ss;
        
        Session s = f.openSession();
       
        boolean con = s.isConnected();
        Connection connect = s.disconnect();
        s.reconnect(connect);
        int jdjsjsdf=0;
    }
}
