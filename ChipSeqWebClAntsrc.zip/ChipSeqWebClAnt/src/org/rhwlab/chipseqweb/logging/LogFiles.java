/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseqweb.logging;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.nio.file.Files;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 *
 * @author gevirl
 */
public class LogFiles {
    Calendar cal;
    File dirFile;
       
    public LogFiles(File dirFile){
        this.dirFile = dirFile;
        cal = Calendar.getInstance();
    }
    
    public String getDateString(){
        return DateFormat.getInstance().format(cal.getTime());
    }
    
    public String getMonth(){
        return cal.getDisplayName(Calendar.MONTH, Calendar.SHORT_FORMAT, Locale.US);
    }

    public int getYear(){
        return cal.get(Calendar.YEAR);
    }
    
    public PrintStream getRunsLogFile() throws Exception {
        File yearDir = new File(dirFile,Integer.toString(getYear()));       
        File monthDir = new File(yearDir,getMonth());
        Files.createDirectories(monthDir.toPath());
        File outFile = new File(monthDir,"RunFiles.tsv");
        return new PrintStream(new FileOutputStream(outFile,true));
    }
    
    public PrintStream getAggregateLogFile() throws Exception {
        File yearDir = new File(dirFile,Integer.toString(getYear()));       
        File monthDir = new File(yearDir,getMonth());
        Files.createDirectories(monthDir.toPath());
        File outFile = new File(monthDir,"AggregateFiles.tsv");
        return new PrintStream(new FileOutputStream(outFile,true));
    }    
    static public void main(String[] args)throws Exception {
        

        
        
        Date now = new Date();       
        DateFormat format = DateFormat.getInstance();
        System.out.println(format.format(now));
        
        Calendar cal = Calendar.getInstance();
//        String month =cal.getDisplayName(Calendar.MONTH, Calendar.SHORT_FORMAT, Locale.US);
        
        Date calDate = cal.getTime();
        System.out.println(format.format(calDate));
        
        
    }
    static public File logDir = new File("/data/www/site/waterston/html/ChipSeqPipeline/logs");
    static public File wormLogDir = new File(logDir,"worm");
    static public File flyLogDir = new File(logDir,"fly");
}
