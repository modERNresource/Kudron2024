/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.rhwlab.chipseqweb;


import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.TreeMap;
import java.util.TreeSet;
import javax.json.JsonArray;
import javax.json.JsonObject;
import org.rhwlab.encode.EncodeUrl;
import org.rhwlab.tfs.TFResourceFile;

/**
 *
 * @author gevirl
 */
@Named("species")
@SessionScoped
public class Species implements Serializable {

    String species = "CElegans";
    TreeSet<String> wormNonTFs = new TreeSet<>();
    TreeSet<String> flyNonTFs = new TreeSet<>();
    String wormGenomeTSV = "/net/waterston/vol9/WS245chr/WS245chr.tsv";
    String flyGenomeTSV = "/net/waterston/vol9/dm6/DM6.tsv";
    String flyTargetURL = "https://www.encodeproject.org/search/?type=Target&organism.scientific_name=Drosophila+melanogaster&limit=all&format=json";
    String wormTargetURL = "https://www.encodeproject.org/search/?type=Target&organism.scientific_name=Caenorhabditis+elegans&limit=all&format=json";

    static TFResourceFile tfFile;

    TreeMap<String, String> flyTargets = new TreeMap<>();
    TreeMap<String, String> wormTargets = new TreeMap<>();

    /**
     * Creates a new instance of Species
     */
    public Species() throws Exception {
        if (tfFile == null) {
            tfFile = new TFResourceFile("/org/rhwlab/tfs/allTFs.tsv");
        }

        // get the fly trgets from dcc
        EncodeUrl url = new EncodeUrl(flyTargetURL);
        url.getJson();
        JsonObject jsonObj = url.getJsonObject();
        JsonArray graphList = jsonObj.getJsonArray("@graph");
        for (int i = 0; i < graphList.size(); ++i) {
            JsonObject graphObj = graphList.getJsonObject(i);
            flyTargets.put(graphObj.getJsonString("label").getString(), graphObj.getJsonString("@id").getString());
        }

        url = new EncodeUrl(wormTargetURL);
        url.getJson();
        jsonObj = url.getJsonObject();
        graphList = jsonObj.getJsonArray("@graph");
        for (int i = 0; i < graphList.size(); ++i) {
            JsonObject graphObj = graphList.getJsonObject(i);
 //           System.out.println(graphObj.getJsonString("label").getString());
            wormTargets.put(graphObj.getJsonString("label").getString(), graphObj.getJsonString("@id").getString());
        }
        wormTargets.put("madf-1","/targets/madf-1-celegans");

        // get the list of non TF genes
       
        InputStream inStream = this.getClass().getResourceAsStream("/org/rhwlab/chipseqweb/WormNonTFs");
        BufferedReader reader = new BufferedReader(new InputStreamReader(inStream));
        String nonTF = reader.readLine();
        while (nonTF != null){
            this.wormNonTFs.add(nonTF);
            nonTF = reader.readLine();
        }
        reader.close();
    }
    

    public String geneType(String gene){
        if (this.wormNonTFs.contains(gene)){
            return "Non TF";
        }
        return "TF";
    }

    public String getWormTarget(String label) {
        String ret = this.wormTargets.get(label);
        if (ret == null) {
            ret = "";
        }
        return ret;
    }

    public String getFlyTarget(String label) {
        String ret = this.flyTargets.get(label);
        if (ret == null) {
            ret = "";
        }
        return ret;
    }

    public String getTarget(ChipExperiment e){
        String ret;
        if (e.getSpecies().equals("CElegans")){
            ret = wormTargets.get(e.getGene());
        }else {
            ret = flyTargets.get(e.getGene());
        }
        if (ret == null) ret = "";
        return ret;
    }

    public List getStages() {
        if (species == null) {
            return new ArrayList<>();
        }

        if (isWorm()) {
            return new ArrayList(dccWorm.keySet());
        } else {
            return new ArrayList(dccFly.keySet());
        }
    }
    
    public String getStageDCC(String stage){
        if (isWorm()){
            return dccWorm.get(stage);
        }
        return dccFly.get(stage);
    }

    public void setSpecies(String s) {
        species = s;
    }

    public String getSpecies() {
        return species;
    }

    public boolean isWorm() {
        return species.equals("CElegans");
    }

    public boolean isFly() {
        return species.equals("Dmel");
    }

    public String flyLabel(){
        return "Dmel";
    }
    public String wormLabel(){
        return "CElegans";
    }
    
    public String getDonorLabel() {
        if (isWorm()) {
            return "WormDonor";
        }
        return "FlyDonor";
    }

    public TreeSet<String> getTFs() {

        if (isWorm()) {
            return new TreeSet(wormTargets.keySet());
        } else {
            return new TreeSet(flyTargets.keySet());
        }
    }

    public String getGenomeTSV() {
        if (isWorm()) {
            return wormGenomeTSV;
        } else {
            return flyGenomeTSV;
        }
    }

    static public String getWBGene(String tf) throws Exception {
        return tfFile.getWBGene(tf);
    }

    static public void main(String[] args) throws Exception {
        Species sp = new Species();
        int usdgfiusdf=0;
    }


    static LinkedHashMap<String, String> dccWorm = new LinkedHashMap<>();  // uw stage >- dcc Stage
    static LinkedHashMap<String, String> dccFly = new LinkedHashMap<>();  // uw stage >- dcc Stage
    {
        dccWorm.put("earlyembryonic", "early embryonic");
        dccWorm.put("midembryonic","midembryonic");
        dccWorm.put("lateembryonic","late embryonic");
        dccWorm.put("mixedstage_embryonic","mixed stage (embryonic)");
        dccWorm.put("L1larva","L1 larva");
        dccWorm.put("L2larva","L2 larva");
        dccWorm.put("L3larva","L3 larva");
        dccWorm.put("L4larva","L4 larva");
        dccWorm.put("L4_youngadult","L4/young adult");
        dccWorm.put("youngadult","young adult");
        dccWorm.put("dauer","dauer");
        dccWorm.put("adult","adult");

        dccFly.put("embryonic","embryonic");
        dccFly.put("larva","larva");
        dccFly.put("first_instar_larva","first instar larva");
        dccFly.put("second_instar_larva","second instar larva");
        dccFly.put("third_instar_larva","third instar larva");
        dccFly.put("wandering_third_instar_larva","wandering third instar larva");
        dccFly.put("prepupa","prepupa");
        dccFly.put("pupa","pupa");
        dccFly.put("adult","adult");

        
    }
}
